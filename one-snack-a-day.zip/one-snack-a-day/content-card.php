<article id="post-<?php the_ID(); ?>" <?php post_class('osad-card'); ?>>
  <a href="<?php the_permalink(); ?>" class="osad-card-inner">
    <div class="osad-card-meta">
      <span class="osad-card-category">
        <?php
          $cat = get_the_category();
          echo $cat ? esc_html( $cat[0]->name ) : __( 'News & Snacks', 'one-snack-a-day' );
        ?>
      </span>
      <span class="osad-card-date"><?php echo get_the_date( 'F j, Y' ); ?></span>
    </div>
    <h2 class="osad-card-title"><?php the_title(); ?></h2>
  </a>
</article>
