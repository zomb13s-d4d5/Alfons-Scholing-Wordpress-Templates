<?php get_header(); ?>

<section class="osad-grid">
<?php if ( have_posts() ) : ?>
  <?php while ( have_posts() ) : the_post(); ?>
    <?php get_template_part( 'content', 'card' ); ?>
  <?php endwhile; ?>
<?php else : ?>
  <p class="osad-empty"><?php _e( 'No snacks yet. Come back tomorrow.', 'one-snack-a-day' ); ?></p>
<?php endif; ?>
</section>

<?php get_footer(); ?>
