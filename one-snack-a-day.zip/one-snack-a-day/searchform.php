<?php
?>
<form role="search" method="get" class="osad-search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
  <label class="screen-reader-text" for="osad-search-field"><?php _e( 'Search', 'one-snack-a-day' ); ?></label>
  <input type="search" id="osad-search-field" class="osad-search-input"
         placeholder="<?php esc_attr_e( 'Search smart questions, topics, or countries', 'one-snack-a-day' ); ?>"
         value="<?php echo get_search_query(); ?>" name="s" />
  <button type="submit" class="osad-search-button">
    <?php _e( 'Search', 'one-snack-a-day' ); ?>
  </button>
</form>
