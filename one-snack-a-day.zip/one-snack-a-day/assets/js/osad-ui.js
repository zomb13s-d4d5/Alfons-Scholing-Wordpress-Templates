(function($){
  // On iOS, first tap highlights card, second tap follows link
  $(document).on('touchstart', '.osad-card-inner', function(e){
    var $this = $(this);
    if (!$this.data('touched')) {
      $this.data('touched', true);
      setTimeout(function(){ $this.data('touched', false); }, 700);
      e.preventDefault();
    }
  });
})(jQuery);
