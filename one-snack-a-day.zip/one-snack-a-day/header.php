<?php
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<div class="osad-bg"></div>
<div class="osad-page">
  <header class="osad-header">
    <div class="osad-logo-wrap">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="osad-logo-link">
        <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/osad-logo.webp' ); ?>"
             alt="<?php bloginfo( 'name' ); ?>" class="osad-logo">
      </a>
    </div>

    <div class="osad-title-block">
      <h1 class="osad-site-title"><?php bloginfo( 'name' ); ?></h1>
      <p class="osad-site-tagline">
        <?php bloginfo( 'description' ); ?>
      </p>
    </div>

    <nav class="osad-main-nav">
      <?php
      wp_nav_menu( array(
        'theme_location' => 'primary',
        'container'      => false,
        'menu_class'     => 'osad-menu',
        'fallback_cb'    => false
      ) );
      ?>
    </nav>

    <div class="osad-search-wrap">
      <?php get_search_form(); ?>
    </div>
  </header>

  <main class="osad-main">
