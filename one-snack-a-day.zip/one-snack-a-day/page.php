<?php get_header(); ?>

<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
  <article id="post-<?php the_ID(); ?>" <?php post_class('osad-single osad-page-single'); ?>>
    <header class="osad-single-header">
      <h1 class="osad-single-title"><?php the_title(); ?></h1>
    </header>

    <div class="osad-single-content">
      <?php the_content(); ?>
    </div>
  </article>
<?php endwhile; endif; ?>

<?php get_footer(); ?>
