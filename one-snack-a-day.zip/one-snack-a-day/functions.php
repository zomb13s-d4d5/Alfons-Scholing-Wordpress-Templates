<?php
/**
 * One Snack A Day functions and definitions
 */

if ( ! function_exists( 'osad_setup' ) ) :
function osad_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );

    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'one-snack-a-day' ),
    ) );

    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ) );
}
endif;
add_action( 'after_setup_theme', 'osad_setup' );

function osad_assets() {
    wp_enqueue_style(
        'osad-fonts',
        'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&family=Inter:wght@400;500&display=swap',
        array(),
        null
    );

    wp_enqueue_style(
        'osad-layout',
        get_template_directory_uri() . '/assets/css/osad-layout.css',
        array('osad-fonts'),
        '1.6'
    );

    wp_enqueue_script(
        'osad-ui',
        get_template_directory_uri() . '/assets/js/osad-ui.js',
        array('jquery'),
        '1.0',
        true
    );
}
add_action( 'wp_enqueue_scripts', 'osad_assets' );
