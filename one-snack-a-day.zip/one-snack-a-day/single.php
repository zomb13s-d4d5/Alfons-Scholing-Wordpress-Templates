<?php get_header(); ?>

<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
  <article id="post-<?php the_ID(); ?>" <?php post_class('osad-single'); ?>>
    <header class="osad-single-header">
      <div class="osad-single-meta">
        <span class="osad-single-category">
          <?php
            $cat = get_the_category();
            echo $cat ? esc_html( $cat[0]->name ) : __( 'News & Snacks', 'one-snack-a-day' );
          ?>
        </span>
        <span class="osad-single-date"><?php echo get_the_date( 'F j, Y' ); ?></span>
      </div>
      <h1 class="osad-single-title"><?php the_title(); ?></h1>
    </header>

    <div class="osad-single-content">
      <?php the_content(); ?>
    </div>

    <footer class="osad-single-footer">
      <?php wp_link_pages(); ?>
      <?php if ( comments_open() || get_comments_number() ) : ?>
        <div class="osad-single-comments">
          <?php comments_template(); ?>
        </div>
      <?php endif; ?>
    </footer>
  </article>
<?php endwhile; endif; ?>

<?php get_footer(); ?>
