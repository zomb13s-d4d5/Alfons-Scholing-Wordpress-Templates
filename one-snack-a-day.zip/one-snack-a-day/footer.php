  </main>

  <footer class="osad-footer">
    <p>© <?php echo date('Y'); ?> One Snack A Day – NotYouAgain.ai</p>
  </footer>
</div>
<?php wp_footer(); ?>
</body>
</html>
