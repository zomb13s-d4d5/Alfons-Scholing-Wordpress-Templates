<?php
/*
Plugin Name: 074KU Programming Autoposter
Plugin URI:  https://074ku.eu/
Description: Autoposter voor programmeren & cyber security. Plaatst elke 15 minuten een nieuw bericht en maakt bij activatie ook een handboekpagina aan.
Version:     1.1 (15min)
Author:      NotYouAgain.ai Studio
License:     GPLv2 or later
*/

if ( ! defined('ABSPATH') ) { exit; }

// --- 15-minuten interval toevoegen ---
add_filter('cron_schedules', function($schedules){
    if ( ! isset($schedules['every_15_minutes']) ) {
        $schedules['every_15_minutes'] = array(
            'interval' => 15 * 60,
            'display'  => __('Every 15 Minutes', 'k074')
        );
    }
    return $schedules;
});

// --- Activering: event plannen + handboek aanmaken ---
register_activation_hook(__FILE__, function(){
    if ( ! wp_next_scheduled('k074_autoposter_event') ) {
        wp_schedule_event( time(), 'every_15_minutes', 'k074_autoposter_event' );
    }
    k074_create_or_update_handbook_page();
});

// --- Deactivering: event opruimen ---
register_deactivation_hook(__FILE__, function(){
    $timestamp = wp_next_scheduled('k074_autoposter_event');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'k074_autoposter_event');
    }
});

// --- Kern: event callback ---
add_action('k074_autoposter_event', function(){
    k074_publish_next_topic_post();
});

// --- Onderwerpenlijst ---
function k074_get_topics(){
    return array(
        'Intro to Programming: Variables, Types & Control Flow',
        'Data Structures 101: Arrays, Lists, Hash Maps',
        'Object‑Oriented Programming: Classes, Inheritance & Interfaces',
        'Version Control with Git: Branching, Merging & Rebasing',
        'Python for Scripting: CLI Utilities & Virtual Environments',
        'Web Security Basics: OWASP Top 10 & Threat Modeling',
        'APIs: REST vs GraphQL and Authentication Flows',
        'Databases: SQL Joins, Indexing & Transactions',
        'Asynchronous Programming: Promises, Futures & async/await',
        'DevOps Essentials: CI/CD, Containers & Observability',
        'Cryptography Basics: Hashing, Symmetric & Public‑Key',
        'Secure Coding Practices: Input Validation & Output Encoding'
    );
}

// --- Volgende index ophalen en opslaan ---
function k074_next_index(){
    $opt_key = 'k074_autoposter_index';
    $idx = (int) get_option($opt_key, 0);
    $topics = k074_get_topics();
    $next = $idx % max(1, count($topics));
    update_option($opt_key, $idx + 1, false);
    return $next;
}

// --- Willekeurige afbeelding uit uploads ---
function k074_random_upload_image_tag(){
    $upload_dir = wp_get_upload_dir();
    $base = trailingslashit($upload_dir['basedir']);
    $url  = trailingslashit($upload_dir['baseurl']);

    if ( ! is_dir($base) ) return '';

    $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base));
    $candidates = array();
    foreach ($rii as $file) {
        if ($file->isDir()) continue;
        $ext = strtolower(pathinfo($file->getFilename(), PATHINFO_EXTENSION));
        if (in_array($ext, array('jpg','jpeg','png','gif','webp'))) {
            $rel = str_replace($base, '', $file->getPathname());
            $candidates[] = esc_url($url . str_replace(DIRECTORY_SEPARATOR, '/', $rel));
        }
    }
    if (empty($candidates)) return '';
    $pick = $candidates[array_rand($candidates)];
    return '<p><img src=\"' . $pick . '\" alt=\"autoposter image\" style=\"max-width:100%;height:auto;border-radius:8px\" /></p>';
}

// --- Volgende bericht publiceren ---
function k074_publish_next_topic_post(){
    $topics = k074_get_topics();
    $i = k074_next_index();
    $title = $topics[$i];

    $intro = 'Dagelijkse 074KU post over programmeren en cyber security. ';
    $img   = k074_random_upload_image_tag();
    $body  = $img . '<p>' . esc_html($intro) . '</p>'
          . '<h2>Onderwerp</h2><p>' . esc_html($title) . '</p>'
          . '<h3>Snelle bullets</h3><ul>'
          . '<li>Wat en waarom</li><li>Mini‑voorbeeld</li><li>Bronnen & vervolg</li></ul>';

    $post_id = wp_insert_post(array(
        'post_title'   => wp_strip_all_tags($title),
        'post_content' => $body,
        'post_status'  => 'publish',
        'post_author'  => get_current_user_id(),
        'post_category'=> array( get_option('default_category') ),
        'tags_input'   => array('programmeren','code','cybersecurity','074ku')
    ), true);

    if (is_wp_error($post_id)) {
        error_log('074KU Autoposter error: ' . $post_id->get_error_message());
    }
}

// --- Handboekpagina ---
function k074_create_or_update_handbook_page(){
    $slug = 'programmeergids-beginners-tot-pro';
    $existing = get_page_by_path($slug);
    $content = '<h1>Programmeergids: van beginner tot pro</h1>'
             . '<p>Een compacte leerlijn met kernonderdelen: basis, talen, tooling, security en verdieping.</p>'
             . '<h2>1. Grondbeginselen</h2><ul>'
             . '<li>Variabelen, types, expressies, control flow</li>'
             . '<li>Datastructuren & algoritmen</li>'
             . '<li>Complexiteit (Big‑O)</li></ul>'
             . '<h2>2. Talen</h2><ul>'
             . '<li>Python, JavaScript/TypeScript, PHP, Java/Kotlin, C/C++</li>'
             . '<li>CLI, scripting, web & backend</li></ul>'
             . '<h2>3. Tooling</h2><ul>'
             . '<li>Git, branches, PR‑flow</li>'
             . '<li>Testen (unit/integration), linting</li>'
             . '<li>CI/CD, containers</li></ul>'
             . '<h2>4. Security</h2><ul>'
             . '<li>OWASP Top 10, input validatie, output encoding</li>'
             . '<li>AuthN/AuthZ, secrets‑beheer</li></ul>'
             . '<h2>5. Verdieping</h2><ul>'
             . '<li>Asynchroon, concurrentie, schaalbaarheid</li>'
             . '<li>Architectuur & patterns</li></ul>';

    $page = array(
        'post_title'     => 'Programmeergids: van beginner tot pro',
        'post_name'      => $slug,
        'post_content'   => $content,
        'post_status'    => 'publish',
        'post_type'      => 'page',
        'comment_status' => 'closed'
    );

    if ($existing) {
        $page['ID'] = $existing->ID;
    }
    $id = wp_insert_post($page, true);
    if (is_wp_error($id)) {
        error_log('074KU Handbook error: ' . $id->get_error_message());
    }
}
