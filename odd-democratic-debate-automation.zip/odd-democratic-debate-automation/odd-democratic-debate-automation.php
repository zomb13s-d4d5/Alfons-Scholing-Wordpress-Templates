<?php
/*
Plugin Name: ODD Democratic Debate Automation
Description: Automatically categorises posts into European activism/issue areas, assigns unique category colours, styles headers, and emits META/OG tags.
Version: 2.0.2
Author: OpenAI
License: GPL2+
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class ODD_Democratic_Debate_Automation {
    const VERSION = '2.0.2';

    // Post meta.
    const PRIMARY_META        = 'sdai_primary_cat';
    const SCORES_META         = 'sdai_scores_json';
    const CONFIDENCE_META     = 'sdai_confidence';
    const NEEDS_REVIEW_META   = 'sdai_needs_review';
    const MANUAL_OVERRIDE_META= 'sdai_manual_override';
    const LAST_HASH_META      = 'sdai_last_classified_hash';

    // Term meta.
    const COLOR_META          = 'sdai_header_color';
    const FG_META             = 'sdai_header_fg';

    // Options.
    const REGISTRY_OPTION     = 'sdai_color_registry';
    const BACKFILL_PENDING    = 'sdai_backfill_pending';
    const BACKFILL_LAST_ID    = 'sdai_backfill_last_id';

    // Cron.
    const CRON_HOOK           = 'sdai_backfill_batch_event';
    const BATCH_SIZE          = 25;

    private static $in_classify = array();
    private static $backfill_where_last_id = 0;

    public static function init() {
        register_activation_hook( __FILE__, array( __CLASS__, 'activate' ) );
        register_deactivation_hook( __FILE__, array( __CLASS__, 'deactivate' ) );

        // Automatic classification triggers.
        add_action( 'wp_after_insert_post', array( __CLASS__, 'after_insert_post' ), 20, 4 );
        add_action( 'save_post_post', array( __CLASS__, 'on_save_post' ), 20, 3 );
        add_action( 'transition_post_status', array( __CLASS__, 'on_transition_post_status' ), 20, 3 );

        // Backfill (batched).
        add_action( self::CRON_HOOK, array( __CLASS__, 'process_backfill_batch' ) );
        add_action( 'init', array( __CLASS__, 'maybe_resume_backfill' ) );

        // Front-end styling + meta.
        add_action( 'init', array( __CLASS__, 'enable_comment_support' ) );
        add_filter( 'post_class', array( __CLASS__, 'filter_post_class' ), 10, 3 );
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
        add_action( 'wp_head', array( __CLASS__, 'print_meta_tags' ), 5 );
        add_filter( 'document_title_parts', array( __CLASS__, 'filter_document_title_parts' ), 20 );
        add_filter( 'comments_template', array( __CLASS__, 'filter_comments_template' ) );
        add_filter( 'comments_open', array( __CLASS__, 'force_comments_open' ), 20, 2 );

        // Optional editor tools (meta box) + category colour picker.
        add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_boxes' ) );
        add_action( 'save_post', array( __CLASS__, 'save_meta_box' ) );
        add_action( 'created_category', array( __CLASS__, 'ensure_term_color' ), 10, 1 );
        add_action( 'edited_category', array( __CLASS__, 'save_term_color' ), 10, 1 );
        add_action( 'category_add_form_fields', array( __CLASS__, 'render_add_term_fields' ) );
        add_action( 'category_edit_form_fields', array( __CLASS__, 'render_edit_term_fields' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_assets' ) );
    }

    public static function activate() {
        self::ensure_registry();
        self::enable_comment_support();
        self::ensure_default_categories();
        self::assign_colors_to_all_categories();

        // Start (or restart) a safe batched backfill.
        update_option( self::BACKFILL_PENDING, 1, false );
        update_option( self::BACKFILL_LAST_ID, 0, false );
        self::schedule_backfill();
    }

    public static function deactivate() {
        wp_clear_scheduled_hook( self::CRON_HOOK );
    }

    private static function ensure_registry() {
        if ( false === get_option( self::REGISTRY_OPTION, false ) ) {
            add_option( self::REGISTRY_OPTION, array(), '', false );
        }
    }

    /**
     * Issue-area categories suitable for European civic/activist discourse.
     * Keywords include a small set of common variants across major European languages.
     */
    private static function category_blueprints() {
        $blueprints = array(
            'labour-rights' => array(
                'name' => 'Labour Rights',
                'keywords' => array(
                    'worker','workers','union','strike','wage','wages','collective bargaining','workplace','labour','labor',
                    'travail','salaires','syndicat','grève',
                    'arbeit','lohn','gewerkschaft','streik',
                    'trabajo','salario','sindicato','huelga',
                    'lavoro','salario','sciopero','sindacato',
                ),
            ),
            'public-services' => array(
                'name' => 'Public Services & Welfare',
                'keywords' => array(
                    'public services','nhs','healthcare','hospital','education','school','teacher','transport','welfare','social care','public funding',
                    'service public','santé','hôpital','éducation','école','transports','protection sociale',
                    'gesundheit','krankenhaus','bildung','schule','öffentlicher verkehr','sozialstaat',
                    'sanidad','hospital','educación','escuela','transporte público','bienestar',
                    'sanità','ospedale','istruzione','scuola','trasporto pubblico','welfare',
                ),
            ),
            'housing-justice' => array(
                'name' => 'Housing Justice',
                'keywords' => array(
                    'housing','rent','rents','tenant','tenants','landlord','eviction','homelessness','social housing','mortgage',
                    'logement','loyer','expulsion','sans-abri',
                    'wohnung','miete','mieter','räumung','obdachlosigkeit',
                    'vivienda','alquiler','desahucio','sinhogarismo',
                    'casa','affitto','sfratto','senza tetto',
                ),
            ),
            'climate-justice' => array(
                'name' => 'Climate & Environmental Justice',
                'keywords' => array(
                    'climate','climate crisis','emissions','pollution','biodiversity','environment','ecology','just transition','fossil','renewables',
                    'climat','crise climatique','émissions','pollution','biodiversité','transition juste',
                    'klima','klimakrise','emissionen','verschmutzung','biodiversität','gerechter wandel',
                    'clima','crisis climática','emisiones','contaminación','biodiversidad','transición justa',
                    'clima','crisi climatica','emissioni','inquinamento','biodiversità','transizione giusta',
                ),
            ),
            'migrant-rights' => array(
                'name' => 'Migrant & Refugee Rights',
                'keywords' => array(
                    'migrant','migrants','refugee','refugees','asylum','border','deportation','immigration','inclusion',
                    'migrant','réfugié','asile','frontière','expulsion','immigration',
                    'migrant','flüchtling','asyl','grenze','abschiebung','einwanderung',
                    'migrante','refugiado','asilo','frontera','deportación','inmigración',
                    'migrante','rifugiato','asilo','confine','deportazione','immigrazione',
                ),
            ),
            'anti-racism' => array(
                'name' => 'Anti‑Racism & Equality',
                'keywords' => array(
                    'anti-racism','racism','discrimination','hate crime','equal rights','minority rights',
                    'antiracisme','racisme','discrimination','crime de haine','égalité',
                    'antirassismus','rassismus','diskriminierung','hasskriminalität','gleichberechtigung',
                    'antirracismo','racismo','discriminación','delito de odio','igualdad',
                    'antirazzismo','razzismo','discriminazione','crimini d\'odio','uguaglianza',
                ),
            ),
            'gender-and-lgbtq' => array(
                'name' => 'Gender & LGBTQ+ Rights',
                'keywords' => array(
                    'gender equality','women\'s rights','reproductive rights','abortion','domestic violence','lgbt','lgbtq','trans rights','pride',
                    'droits des femmes','égalité femmes-hommes','avortement','violences domestiques','lgbt','trans',
                    'frauenrechte','gleichstellung','abtreibung','häusliche gewalt','lgbt','trans',
                    'derechos de las mujeres','igualdad de género','aborto','violencia doméstica','lgbt','trans',
                    'diritti delle donne','parità di genere','aborto','violenza domestica','lgbt','trans',
                ),
            ),
            'disability-rights' => array(
                'name' => 'Disability Rights & Access',
                'keywords' => array(
                    'disability','disabled','accessibility','reasonable accommodation','inclusive design','ableism',
                    'handicap','accessibilité','validisme',
                    'behinderung','barrierefreiheit','ableismus',
                    'discapacidad','accesibilidad','capacitismo',
                    'disabilità','accessibilità','abilismo',
                ),
            ),
            'digital-rights' => array(
                'name' => 'Digital Rights & Privacy',
                'keywords' => array(
                    'privacy','surveillance','data protection','gdpr','digital rights','encryption','censorship','platform accountability',
                    'vie privée','surveillance','protection des données','rgpd','chiffrement',
                    'datenschutz','überwachung','dsgvo','verschlüsselung','zensur',
                    'privacidad','vigilancia','protección de datos','rgpd','cifrado','censura',
                    'privacy','sorveglianza','protezione dei dati','gdpr','crittografia','censura',
                ),
            ),
            'democratic-reform' => array(
                'name' => 'Democratic Reform & Accountability',
                'keywords' => array(
                    'democracy','democratic','voting','election','parliament','citizens\' assembly','transparency','accountability','representation','corruption',
                    'démocratie','élections','parlement','assemblée citoyenne','transparence','responsabilité','corruption',
                    'demokratie','wahl','parlament','bürger*innenrat','transparenz','rechenschaft','korruption',
                    'democracia','elecciones','parlamento','asamblea ciudadana','transparencia','rendición de cuentas','corrupción',
                    'democrazia','elezioni','parlamento','assemblea cittadina','trasparenza','responsabilità','corruzione',
                ),
            ),
            'corporate-accountability' => array(
                'name' => 'Corporate Accountability & Tax Justice',
                'keywords' => array(
                    'corporate','tax justice','tax avoidance','lobbying','monopoly','privatisation','privatization','regulation','shareholders','profits',
                    'justice fiscale','évasion fiscale','lobbying','monopole','privatisation','régulation',
                    'steuergerechtigkeit','steuervermeidung','lobbyismus','monopol','privatisierung','regulierung',
                    'justicia fiscal','evasión fiscal','lobbying','monopolio','privatización','regulación',
                    'giustizia fiscale','elusione fiscale','lobbying','monopolio','privatizzazione','regolazione',
                ),
            ),
            'peace-and-solidarity' => array(
                'name' => 'Peace, Solidarity & Human Rights',
                'keywords' => array(
                    'peace','ceasefire','human rights','solidarity','humanitarian','occupation','diplomacy','arms trade','anti-war',
                    'paix','cessez-le-feu','droits humains','solidarité','humanitaire','occupation','diplomatie','commerce des armes',
                    'frieden','waffenstillstand','menschenrechte','solidarität','humanitär','besatzung','diplomatie','waffenhandel',
                    'paz','alto el fuego','derechos humanos','solidaridad','humanitario','ocupación','diplomacia','comercio de armas',
                    'pace','cessate il fuoco','diritti umani','solidarietà','umanitario','occupazione','diplomazia','commercio di armi',
                ),
            ),
            'anti-fascism' => array(
                'name' => 'Anti‑Fascism & Civil Liberties',
                'keywords' => array(
                    'anti-fascism','far right','neo-nazi','hate group','civil liberties','protest rights','police violence',
                    'antifascisme','extrême droite','néonazi','libertés civiles','droit de manifester','violences policières',
                    'antifaschismus','rechtsextrem','neonazi','bürgerrechte','demonstrationsrecht','polizeigewalt',
                    'antifascismo','extrema derecha','neonazi','libertades civiles','derecho a protestar','violencia policial',
                    'antifascismo','estrema destra','neonazi','libertà civili','diritto di protesta','violenza della polizia',
                ),
            ),
        );

        /**
         * Filter to allow site owners to adjust categories/keywords without editing plugin files.
         *
         * @param array $blueprints
         */
        return apply_filters( 'sdai_category_blueprints', $blueprints );
    }

    public static function ensure_default_categories() {
        foreach ( self::category_blueprints() as $slug => $blueprint ) {
            $term = get_term_by( 'slug', $slug, 'category' );
            if ( ! $term ) {
                wp_insert_term( $blueprint['name'], 'category', array( 'slug' => $slug ) );
            }
        }
    }

    public static function assign_colors_to_all_categories() {
        $terms = get_terms( array(
            'taxonomy'   => 'category',
            'hide_empty' => false,
        ) );
        if ( is_wp_error( $terms ) ) {
            return;
        }
        foreach ( $terms as $term ) {
            self::ensure_term_color( (int) $term->term_id );
        }
    }

    public static function after_insert_post( $post_id, $post, $update, $post_before ) {
        self::maybe_classify_post( $post_id, $post );
    }

    public static function on_save_post( $post_id, $post, $update ) {
        self::maybe_classify_post( $post_id, $post );
    }

    public static function on_transition_post_status( $new_status, $old_status, $post ) {
        if ( $post instanceof WP_Post ) {
            self::maybe_classify_post( $post->ID, $post );
        }
    }

    private static function maybe_classify_post( $post_id, $post = null ) {
        $post = $post instanceof WP_Post ? $post : get_post( $post_id );
        if ( ! $post || 'post' !== $post->post_type ) {
            return;
        }
        if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
            return;
        }
        if ( 'auto-draft' === $post->post_status ) {
            return;
        }
        if ( get_post_meta( $post_id, self::MANUAL_OVERRIDE_META, true ) ) {
            return;
        }
        self::classify_post( $post_id );
    }

    private static function fingerprint_post( $post ) {
        return md5( implode( '|', array(
            (string) $post->post_status,
            (string) $post->post_title,
            (string) $post->post_excerpt,
            (string) $post->post_content,
        ) ) );
    }

    private static function count_hits_wordish( $haystack, $needle ) {
        $needle = trim( (string) $needle );
        if ( '' === $needle ) {
            return 0;
        }
        // If it contains whitespace or punctuation, treat as phrase.
        if ( preg_match( '/[^\p{L}\p{N}_-]/u', $needle ) ) {
            return substr_count( $haystack, $needle );
        }
        $pattern = '/(?:^|\b)' . preg_quote( $needle, '/' ) . '(?:\b|$)/iu';
        if ( ! preg_match_all( $pattern, $haystack, $m ) ) {
            return 0;
        }
        return count( $m[0] );
    }

    public static function classify_post( $post_id, $force = false ) {
        $post = get_post( $post_id );
        if ( ! $post || 'post' !== $post->post_type ) {
            return;
        }

        if ( ! $force && ! empty( self::$in_classify[ $post_id ] ) ) {
            return;
        }

        $fingerprint = self::fingerprint_post( $post );
        $prev = (string) get_post_meta( $post_id, self::LAST_HASH_META, true );
        if ( ! $force && $prev && hash_equals( $prev, $fingerprint ) ) {
            return;
        }

        self::$in_classify[ $post_id ] = true;

        self::ensure_default_categories();

        $text = strtolower( wp_strip_all_tags( $post->post_title . ' ' . $post->post_excerpt . ' ' . $post->post_content ) );
        $title = strtolower( wp_strip_all_tags( $post->post_title ) );

        $scores = array();
        foreach ( self::category_blueprints() as $slug => $blueprint ) {
            $score = 0;
            foreach ( (array) $blueprint['keywords'] as $kw ) {
                $kw = strtolower( (string) $kw );
                if ( '' === $kw ) {
                    continue;
                }
                $hits = self::count_hits_wordish( $text, $kw );
                if ( $hits > 0 ) {
                    $score += $hits;
                    // Weight title matches higher.
                    $score += 2 * self::count_hits_wordish( $title, $kw );
                }
            }
            $scores[ $slug ] = $score;
        }

        arsort( $scores );
        $slugs = array_keys( $scores );
        $best_slug = isset( $slugs[0] ) ? $slugs[0] : 'uncategorized';
        $best_score = isset( $scores[ $best_slug ] ) ? (int) $scores[ $best_slug ] : 0;
        $second_slug = isset( $slugs[1] ) ? $slugs[1] : '';
        $second_score = $second_slug && isset( $scores[ $second_slug ] ) ? (int) $scores[ $second_slug ] : 0;
        $margin = $best_score - $second_score;

        // Simple confidence heuristic.
        $threshold_primary = 2;
        $threshold_margin  = 1;
        $needs_review = 0;
        $term_ids = array();

        if ( $best_score >= $threshold_primary && $margin >= $threshold_margin ) {
            $primary = get_term_by( 'slug', $best_slug, 'category' );
            if ( $primary && ! is_wp_error( $primary ) ) {
                $term_ids[] = (int) $primary->term_id;
                update_post_meta( $post_id, self::PRIMARY_META, (int) $primary->term_id );
                self::ensure_term_color( (int) $primary->term_id );
            }
            foreach ( $scores as $slug => $score ) {
                if ( $slug === $best_slug || $score < 2 ) {
                    continue;
                }
                $term = get_term_by( 'slug', $slug, 'category' );
                if ( $term && ! is_wp_error( $term ) ) {
                    $term_ids[] = (int) $term->term_id;
                }
            }
        } else {
            $needs_review = 1;
            $uncat = get_term_by( 'slug', 'uncategorized', 'category' );
            if ( $uncat && ! is_wp_error( $uncat ) ) {
                $term_ids[] = (int) $uncat->term_id;
                update_post_meta( $post_id, self::PRIMARY_META, (int) $uncat->term_id );
                self::ensure_term_color( (int) $uncat->term_id );
            }
        }

        if ( ! empty( $term_ids ) ) {
            wp_set_post_terms( $post_id, array_values( array_unique( $term_ids ) ), 'category', false );
        }

        update_post_meta( $post_id, self::SCORES_META, wp_json_encode( $scores ) );
        update_post_meta( $post_id, self::CONFIDENCE_META, $best_score );
        update_post_meta( $post_id, self::NEEDS_REVIEW_META, $needs_review );
        update_post_meta( $post_id, self::LAST_HASH_META, $fingerprint );

        unset( self::$in_classify[ $post_id ] );
    }

    // ----------------------- Backfill -----------------------

    public static function maybe_resume_backfill() {
        if ( get_option( self::BACKFILL_PENDING ) ) {
            self::schedule_backfill();
        }
    }

    private static function schedule_backfill() {
        if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
            wp_schedule_single_event( time() + 15, self::CRON_HOOK );
        }
    }

    public static function posts_where_backfill( $where ) {
        global $wpdb;
        if ( self::$backfill_where_last_id > 0 ) {
            $where .= $wpdb->prepare( " AND {$wpdb->posts}.ID > %d", self::$backfill_where_last_id );
        }
        return $where;
    }

    public static function process_backfill_batch() {
        if ( ! get_option( self::BACKFILL_PENDING ) ) {
            return;
        }

        self::ensure_default_categories();

        $last_id = (int) get_option( self::BACKFILL_LAST_ID, 0 );
        self::$backfill_where_last_id = $last_id;
        add_filter( 'posts_where', array( __CLASS__, 'posts_where_backfill' ) );

        $q = new WP_Query( array(
            'post_type'              => 'post',
            'post_status'            => array( 'publish', 'draft', 'future', 'pending', 'private' ),
            'posts_per_page'         => self::BATCH_SIZE,
            'orderby'                => 'ID',
            'order'                  => 'ASC',
            'fields'                 => 'ids',
            'no_found_rows'          => true,
            'ignore_sticky_posts'    => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ) );

        remove_filter( 'posts_where', array( __CLASS__, 'posts_where_backfill' ) );
        self::$backfill_where_last_id = 0;

        if ( empty( $q->posts ) ) {
            update_option( self::BACKFILL_PENDING, 0, false );
            update_option( self::BACKFILL_LAST_ID, 0, false );
            return;
        }

        $max = $last_id;
        foreach ( (array) $q->posts as $pid ) {
            $pid = (int) $pid;
            $max = max( $max, $pid );
            if ( get_post_meta( $pid, self::MANUAL_OVERRIDE_META, true ) ) {
                continue;
            }
            self::classify_post( $pid, true );
        }

        update_option( self::BACKFILL_LAST_ID, $max, false );
        update_option( self::BACKFILL_PENDING, 1, false );
        self::schedule_backfill();
    }

    // ----------------------- Styling + Meta -----------------------

    public static function filter_post_class( $classes, $class, $post_id ) {
        $primary = (int) get_post_meta( $post_id, self::PRIMARY_META, true );
        if ( $primary ) {
            $classes[] = 'sdai-primary-cat-' . $primary;
        }
        return $classes;
    }

    public static function enqueue_assets() {
        $css = "
        .sdai-category-chip, .sdai-category-box, .sdai-dynamic-header { color: var(--sdai-header-fg, #fff); background: var(--sdai-header-bg, #000); }
        body.single article[class*='sdai-primary-cat-'] .entry-header,
        body.single article[class*='sdai-primary-cat-'] .wp-block-post-title,
        body.single .type-post[class*='sdai-primary-cat-'] .entry-title,
        body.blog article[class*='sdai-primary-cat-'] .entry-title a,
        body.archive article[class*='sdai-primary-cat-'] .entry-title a { color: var(--sdai-header-fg, #ffffff); }
        body.single article[class*='sdai-primary-cat-'] .entry-header,
        body.single .type-post[class*='sdai-primary-cat-'] .wp-block-post-title,
        body.single .type-post[class*='sdai-primary-cat-'] .entry-title {
            background: var(--sdai-header-bg, transparent);
            color: var(--sdai-header-fg, #fff);
            box-shadow: inset 0 0 0 4px var(--sdai-header-bg, transparent);
            padding: 0.3em 0.4em;
        }
        body.blog article[class*='sdai-primary-cat-'], body.archive article[class*='sdai-primary-cat-'] { border-left: 8px solid var(--sdai-header-bg, #000); padding-left: 1rem; }
        body.single .sdai-comments-wrap { margin-top: 3rem; padding-top: 1.25rem; border-top: 4px solid var(--sdai-header-bg, #000); }
        body.single .sdai-comments-title,
        body.single .comment-reply-title { display: inline-block; background: var(--sdai-header-bg, #000); color: var(--sdai-header-fg, #fff); padding: 0.3em 0.45em; box-shadow: inset 0 0 0 4px var(--sdai-header-bg, #000); }
        body.single .sdai-comments-wrap a { color: var(--sdai-header-bg, #000); }
        body.single .sdai-comments-list,
        body.single .children { list-style: none; margin: 0; padding: 0; }
        body.single .sdai-comments-list .children { margin-left: 1.5rem; padding-left: 1rem; border-left: 2px solid var(--sdai-header-bg, #000); }
        body.single .sdai-comment-card { margin: 0 0 1.25rem; padding: 1rem; border-left: 8px solid var(--sdai-header-bg, #000); background: color-mix(in srgb, var(--sdai-header-bg, #000) 8%, transparent); }
        body.single .sdai-comment-meta { margin-bottom: 0.5rem; }
        body.single .sdai-comment-author { font-weight: 700; }
        body.single .sdai-comment-date { opacity: 0.8; font-size: 0.92em; }
        body.single .sdai-comment-awaiting { font-style: italic; margin-top: 0.5rem; }
        body.single .comment-respond { margin-top: 2rem; padding: 1rem; border: 2px solid var(--sdai-header-bg, #000); }
        body.single .comment-form p { margin: 0 0 1rem; }
        body.single .comment-form input[type='text'],
        body.single .comment-form input[type='email'],
        body.single .comment-form input[type='url'],
        body.single .comment-form textarea { width: 100%; border: 2px solid var(--sdai-header-bg, #000); padding: 0.75rem; background: transparent; color: inherit; box-sizing: border-box; }
        body.single .comment-form input:focus,
        body.single .comment-form textarea:focus { outline: 0; box-shadow: 0 0 0 3px color-mix(in srgb, var(--sdai-header-bg, #000) 22%, transparent); }
        body.single .comment-form .submit,
        body.single .sdai-reply-link { display: inline-block; background: var(--sdai-header-bg, #000); color: var(--sdai-header-fg, #fff) !important; border: 0; padding: 0.7rem 1rem; text-decoration: none; cursor: pointer; }
        ";

        wp_register_style( 'sdai-dynamic-style', false, array(), self::VERSION );
        wp_enqueue_style( 'sdai-dynamic-style' );

        $terms = get_terms( array(
            'taxonomy'   => 'category',
            'hide_empty' => false,
        ) );
        if ( ! is_wp_error( $terms ) ) {
            foreach ( $terms as $term ) {
                $bg = get_term_meta( $term->term_id, self::COLOR_META, true );
                $fg = get_term_meta( $term->term_id, self::FG_META, true );
                if ( ! $bg || ! $fg ) {
                    continue;
                }
                $css .= ".sdai-primary-cat-{$term->term_id}{--sdai-header-bg: {$bg}; --sdai-header-fg: {$fg};}";
                $css .= ".category-{$term->slug}{--sdai-header-bg: {$bg}; --sdai-header-fg: {$fg};}";
            }
        }

        wp_add_inline_style( 'sdai-dynamic-style', $css );
    }


    public static function enable_comment_support() {
        add_post_type_support( 'post', 'comments' );
    }

    public static function force_comments_open( $open, $post_id ) {
        if ( is_admin() ) {
            return $open;
        }
        if ( 'post' === get_post_type( $post_id ) ) {
            return true;
        }
        return $open;
    }

    public static function filter_comments_template( $template ) {
        if ( is_singular( 'post' ) ) {
            $plugin_template = plugin_dir_path( __FILE__ ) . 'templates/comments.php';
            if ( file_exists( $plugin_template ) ) {
                return $plugin_template;
            }
        }
        return $template;
    }

    public static function filter_document_title_parts( $parts ) {
        if ( ! is_singular( 'post' ) ) {
            return $parts;
        }
        $post_id = get_queried_object_id();
        $primary = (int) get_post_meta( $post_id, self::PRIMARY_META, true );
        if ( $primary ) {
            $term = get_term( $primary, 'category' );
            if ( $term && ! is_wp_error( $term ) ) {
                $parts['title'] = $term->name . ': ' . get_the_title( $post_id );
            }
        }
        return $parts;
    }

    public static function print_meta_tags() {
        if ( ! is_singular( 'post' ) ) {
            return;
        }
        $post_id = get_queried_object_id();
        $post = get_post( $post_id );
        if ( ! $post ) {
            return;
        }
        $primary = (int) get_post_meta( $post_id, self::PRIMARY_META, true );
        $term = $primary ? get_term( $primary, 'category' ) : null;

        $title = $term && ! is_wp_error( $term ) ? $term->name . ': ' . get_the_title( $post_id ) : get_the_title( $post_id );
        $raw = has_excerpt( $post_id ) ? get_the_excerpt( $post_id ) : wp_strip_all_tags( $post->post_content );
        $desc = wp_trim_words( $raw, 28, '…' );

        echo "\n<meta name=\"description\" content=\"" . esc_attr( $desc ) . "\" />\n";

        $image = get_the_post_thumbnail_url( $post_id, 'full' );
        $url = get_permalink( $post_id );
        echo '<meta property="og:type" content="article" />' . "\n";
        echo '<meta property="og:title" content="' . esc_attr( $title ) . '" />' . "\n";
        echo '<meta property="og:description" content="' . esc_attr( $desc ) . '" />' . "\n";
        echo '<meta property="og:url" content="' . esc_url( $url ) . '" />' . "\n";
        if ( $image ) {
            echo '<meta property="og:image" content="' . esc_url( $image ) . '" />' . "\n";
        }
    }

    // ----------------------- Category colours -----------------------

    private static function get_palette_color( $index ) {
        $h = fmod( $index * 137.508, 360 );
        $s = 85;
        $l = 55;
        return self::hsl_to_hex( $h, $s, $l );
    }

    private static function hsl_to_hex( $h, $s, $l ) {
        $s /= 100;
        $l /= 100;
        $c = (1 - abs(2 * $l - 1)) * $s;
        $x = $c * (1 - abs(fmod($h / 60, 2) - 1));
        $m = $l - $c / 2;
        $r = $g = $b = 0;
        if ( $h < 60 ) { $r = $c; $g = $x; }
        elseif ( $h < 120 ) { $r = $x; $g = $c; }
        elseif ( $h < 180 ) { $g = $c; $b = $x; }
        elseif ( $h < 240 ) { $g = $x; $b = $c; }
        elseif ( $h < 300 ) { $r = $x; $b = $c; }
        else { $r = $c; $b = $x; }
        $r = (int) round( ($r + $m) * 255 );
        $g = (int) round( ($g + $m) * 255 );
        $b = (int) round( ($b + $m) * 255 );
        return sprintf( '#%02x%02x%02x', $r, $g, $b );
    }

    private static function relative_luminance( $hex ) {
        $hex = ltrim( $hex, '#' );
        if ( 3 === strlen( $hex ) ) {
            $hex = preg_replace('/(.)/', '$1$1', $hex);
        }
        $rgb = array(
            hexdec( substr( $hex, 0, 2 ) ) / 255,
            hexdec( substr( $hex, 2, 2 ) ) / 255,
            hexdec( substr( $hex, 4, 2 ) ) / 255,
        );
        foreach ( $rgb as &$v ) {
            $v = ( $v <= 0.03928 ) ? $v / 12.92 : pow( ( $v + 0.055 ) / 1.055, 2.4 );
        }
        return 0.2126 * $rgb[0] + 0.7152 * $rgb[1] + 0.0722 * $rgb[2];
    }

    private static function readable_foreground( $bg ) {
        $l = self::relative_luminance( $bg );
        $white_ratio = ( max( $l, 1 ) + 0.05 ) / ( min( $l, 1 ) + 0.05 );
        $black_ratio = ( max( $l, 0 ) + 0.05 ) / ( min( $l, 0 ) + 0.05 );
        return $white_ratio >= $black_ratio ? '#ffffff' : '#000000';
    }

    public static function ensure_term_color( $term_id ) {
        $term_id = (int) $term_id;
        if ( ! $term_id ) {
            return;
        }
        self::ensure_registry();

        $existing = get_term_meta( $term_id, self::COLOR_META, true );
        $registry = get_option( self::REGISTRY_OPTION, array() );

        if ( $existing && sanitize_hex_color( $existing ) ) {
            $registry[ $term_id ] = $existing;
            update_option( self::REGISTRY_OPTION, $registry, false );
            if ( ! get_term_meta( $term_id, self::FG_META, true ) ) {
                update_term_meta( $term_id, self::FG_META, self::readable_foreground( $existing ) );
            }
            return;
        }

        $used = array_values( $registry );
        for ( $i = 0; $i < 256; $i++ ) {
            $candidate = self::get_palette_color( $i );
            if ( ! in_array( $candidate, $used, true ) ) {
                update_term_meta( $term_id, self::COLOR_META, $candidate );
                update_term_meta( $term_id, self::FG_META, self::readable_foreground( $candidate ) );
                $registry[ $term_id ] = $candidate;
                update_option( self::REGISTRY_OPTION, $registry, false );
                return;
            }
        }

        $candidate = self::get_palette_color( wp_rand( 257, 999 ) );
        update_term_meta( $term_id, self::COLOR_META, $candidate );
        update_term_meta( $term_id, self::FG_META, self::readable_foreground( $candidate ) );
        $registry[ $term_id ] = $candidate;
        update_option( self::REGISTRY_OPTION, $registry, false );
    }

    public static function save_term_color( $term_id ) {
        if ( ! current_user_can( 'manage_categories' ) ) {
            return;
        }
        if ( ! isset( $_POST['sdai_term_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['sdai_term_nonce'] ) ), 'sdai_save_term' ) ) {
            return;
        }
        $color = isset( $_POST['sdai_header_color'] ) ? sanitize_hex_color( wp_unslash( $_POST['sdai_header_color'] ) ) : '';
        if ( $color ) {
            update_term_meta( $term_id, self::COLOR_META, $color );
            update_term_meta( $term_id, self::FG_META, self::readable_foreground( $color ) );
            $registry = get_option( self::REGISTRY_OPTION, array() );
            $registry[ (int) $term_id ] = $color;
            update_option( self::REGISTRY_OPTION, $registry, false );
        } else {
            self::ensure_term_color( $term_id );
        }
    }

    public static function render_add_term_fields() {
        wp_nonce_field( 'sdai_save_term', 'sdai_term_nonce' );
        echo '<div class="form-field term-color-wrap"><label for="sdai_header_color">Header colour</label><input name="sdai_header_color" id="sdai_header_color" class="sdai-color-field" value="" /><p>Leave blank to auto-assign a unique colour.</p></div>';
    }

    public static function render_edit_term_fields( $term ) {
        $color = get_term_meta( $term->term_id, self::COLOR_META, true );
        wp_nonce_field( 'sdai_save_term', 'sdai_term_nonce' );
        echo '<tr class="form-field term-color-wrap"><th scope="row"><label for="sdai_header_color">Header colour</label></th><td><input name="sdai_header_color" id="sdai_header_color" class="sdai-color-field" value="' . esc_attr( $color ) . '" /><p class="description">Unique category colour used for headers and article accents.</p></td></tr>';
    }

    public static function admin_assets( $hook ) {
        if ( false === strpos( $hook, 'edit-tags.php' ) && false === strpos( $hook, 'term.php' ) ) {
            return;
        }
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script( 'wp-color-picker' );
        wp_add_inline_script( 'wp-color-picker', "jQuery(function($){ $('.sdai-color-field').wpColorPicker(); });" );
    }

    // ----------------------- Optional editor meta box -----------------------

    public static function add_meta_boxes() {
        add_meta_box( 'sdai-classifier', 'ODD Classification', array( __CLASS__, 'render_meta_box' ), 'post', 'side' );
    }

    public static function render_meta_box( $post ) {
        wp_nonce_field( 'sdai_meta_box', 'sdai_meta_box_nonce' );
        $manual = (int) get_post_meta( $post->ID, self::MANUAL_OVERRIDE_META, true );
        $primary = (int) get_post_meta( $post->ID, self::PRIMARY_META, true );
        $confidence = get_post_meta( $post->ID, self::CONFIDENCE_META, true );
        $needs_review = (int) get_post_meta( $post->ID, self::NEEDS_REVIEW_META, true );
        $categories = get_terms( array( 'taxonomy' => 'category', 'hide_empty' => false ) );

        echo '<p><label><input type="checkbox" name="sdai_manual_override" value="1" ' . checked( 1, $manual, false ) . ' /> Manual override</label></p>';
        echo '<p><label for="sdai_primary_cat_select">Primary category</label><br><select name="sdai_primary_cat_select" id="sdai_primary_cat_select" style="width:100%">';
        echo '<option value="">Auto</option>';
        foreach ( $categories as $category ) {
            echo '<option value="' . esc_attr( $category->term_id ) . '" ' . selected( $primary, $category->term_id, false ) . '>' . esc_html( $category->name ) . '</option>';
        }
        echo '</select></p>';
        echo '<p><strong>Confidence:</strong> ' . esc_html( $confidence ? $confidence : '—' ) . '</p>';
        echo '<p><strong>Needs review:</strong> ' . ( $needs_review ? 'Yes' : 'No' ) . '</p>';
    }

    public static function save_meta_box( $post_id ) {
        if ( ! isset( $_POST['sdai_meta_box_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['sdai_meta_box_nonce'] ) ), 'sdai_meta_box' ) ) {
            return;
        }
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
        if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
            return;
        }

        $manual = isset( $_POST['sdai_manual_override'] ) ? 1 : 0;
        update_post_meta( $post_id, self::MANUAL_OVERRIDE_META, $manual );

        $selected = isset( $_POST['sdai_primary_cat_select'] ) ? (int) $_POST['sdai_primary_cat_select'] : 0;
        if ( $manual && $selected ) {
            update_post_meta( $post_id, self::PRIMARY_META, $selected );
            wp_set_post_terms( $post_id, array( $selected ), 'category', false );
            self::ensure_term_color( $selected );
            update_post_meta( $post_id, self::NEEDS_REVIEW_META, 0 );
        } elseif ( ! $manual ) {
            self::classify_post( $post_id, true );
        }
    }
}

ODD_Democratic_Debate_Automation::init();
