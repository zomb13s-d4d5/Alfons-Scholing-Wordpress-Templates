<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( post_password_required() ) {
    return;
}

if ( ! function_exists( 'sdai_render_comment' ) ) {
    function sdai_render_comment( $comment, $args, $depth ) {
        $tag = ( 'div' === $args['style'] ) ? 'div' : 'li';
        ?>
        <<?php echo esc_html( $tag ); ?> <?php comment_class( 'sdai-comment-item' ); ?> id="comment-<?php comment_ID(); ?>">
            <article class="sdai-comment-card">
                <header class="sdai-comment-meta">
                    <div class="sdai-comment-author"><?php echo get_comment_author_link(); ?></div>
                    <div class="sdai-comment-date"><a href="<?php echo esc_url( get_comment_link( $comment, $args ) ); ?>"><?php printf( esc_html__( '%1$s at %2$s', 'odd-democratic-debate-automation' ), esc_html( get_comment_date( '', $comment ) ), esc_html( get_comment_time( '', $comment ) ) ); ?></a></div>
                </header>

                <div class="sdai-comment-content">
                    <?php comment_text(); ?>
                </div>

                <?php if ( '0' === $comment->comment_approved ) : ?>
                    <p class="sdai-comment-awaiting"><?php esc_html_e( 'Your comment is awaiting moderation.', 'odd-democratic-debate-automation' ); ?></p>
                <?php endif; ?>

                <div class="sdai-comment-actions">
                    <?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'], 'reply_text' => __( 'Reply', 'odd-democratic-debate-automation' ), 'class' => 'sdai-reply-link' ) ) ); ?>
                    <?php edit_comment_link( __( 'Edit', 'odd-democratic-debate-automation' ), ' <span class="edit-link">', '</span>' ); ?>
                </div>
            </article>
        <?php
    }
}
?>

<div id="comments" class="comments-area sdai-comments-wrap">
    <?php if ( have_comments() ) : ?>
        <h2 class="sdai-comments-title">
            <?php
            $count = get_comments_number();
            printf( esc_html( _n( '%s Comment', '%s Comments', $count, 'odd-democratic-debate-automation' ) ), number_format_i18n( $count ) );
            ?>
        </h2>

        <ol class="comment-list sdai-comments-list">
            <?php
            wp_list_comments( array(
                'style'       => 'ol',
                'short_ping'  => true,
                'avatar_size' => 0,
                'callback'    => 'sdai_render_comment',
            ) );
            ?>
        </ol>

        <?php the_comments_navigation(); ?>
    <?php endif; ?>

    <?php
    comment_form( array(
        'class_form'         => 'comment-form sdai-comment-form',
        'title_reply_before' => '<h3 id="reply-title" class="comment-reply-title">',
        'title_reply_after'  => '</h3>',
        'label_submit'       => __( 'Post Comment', 'odd-democratic-debate-automation' ),
    ) );
    ?>
</div>
