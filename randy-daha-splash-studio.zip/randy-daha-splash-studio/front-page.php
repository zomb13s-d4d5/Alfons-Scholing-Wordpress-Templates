<?php
if (!defined('ABSPATH')) {
    exit;
}
get_header();
$featured_items = randy_daha_get_featured_items();
$site_name = get_bloginfo('name') ? get_bloginfo('name') : 'Randy Daha';
$tagline = get_theme_mod('randy_daha_tagline', 'Caribbean x Dutch street studio aesthetics');
?>
<div class="site-bg" style="background-image:url('<?php echo esc_url(randy_daha_get_background_image()); ?>');"></div>
<div class="site-overlay"></div>

<div class="app-shell app-shell--viewport">
    <header class="glass shell-header shell-header--top-only">
        <div class="brand-block">
            <div class="brand-kicker"><?php echo esc_html($site_name); ?></div>
            <div class="brand-subtitle"><?php echo esc_html($tagline); ?></div>
        </div>

        <nav class="top-nav" aria-label="<?php esc_attr_e('Primary navigation', 'randy-daha-splash-studio'); ?>">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'container'      => false,
                'fallback_cb'    => 'randy_daha_fallback_menu',
            ));
            ?>
        </nav>
    </header>

    <main class="shell-main shell-main--empty" aria-hidden="true"></main>

    <footer class="glass content-rail-wrap content-rail-wrap--footer">
        <?php if ($featured_items->have_posts()) : ?>
            <div class="rail-heading">
                <span><?php esc_html_e('Content', 'randy-daha-splash-studio'); ?></span>
                <small><?php esc_html_e('Swipe sideways to browse. Tap a card to open.', 'randy-daha-splash-studio'); ?></small>
            </div>

            <div class="content-rail" aria-label="<?php esc_attr_e('Content thumbnails', 'randy-daha-splash-studio'); ?>" tabindex="0">
                <?php while ($featured_items->have_posts()) : $featured_items->the_post(); ?>
                    <button class="rail-card" type="button" data-panel="post-<?php the_ID(); ?>">
                        <span class="rail-card-type"><?php echo esc_html(get_post_type_object(get_post_type())->labels->singular_name ?? ucfirst(get_post_type())); ?></span>
                        <strong><?php the_title(); ?></strong>
                        <span class="rail-card-meta"><?php echo esc_html(wp_trim_words(get_the_excerpt() ? get_the_excerpt() : wp_strip_all_tags(get_the_content()), 12)); ?></span>
                    </button>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
        <?php endif; ?>
    </footer>
</div>

<div class="modal-layer" hidden>
    <div class="modal-backdrop" data-close-modal="true"></div>
    <section class="glass modal-panel" role="dialog" aria-modal="true" aria-labelledby="modal-title">
        <button class="modal-close" type="button" data-close-modal="true" aria-label="<?php esc_attr_e('Close panel', 'randy-daha-splash-studio'); ?>">×</button>
        <div class="modal-content"></div>
    </section>
</div>

<div class="modal-templates" hidden>
    <?php
    $modal_posts = randy_daha_get_featured_items();
    if ($modal_posts->have_posts()) :
        while ($modal_posts->have_posts()) : $modal_posts->the_post();
            ?>
            <article class="panel-template post-template" id="post-<?php the_ID(); ?>">
                <p class="panel-kicker"><?php echo esc_html(get_post_type_object(get_post_type())->labels->singular_name ?? ucfirst(get_post_type())); ?></p>
                <h2><?php the_title(); ?></h2>
                <?php if (has_post_thumbnail()) : ?>
                    <div class="panel-image"><?php the_post_thumbnail('large'); ?></div>
                <?php endif; ?>
                <div class="panel-body"><?php the_content(); ?></div>
            </article>
            <?php
        endwhile;
        wp_reset_postdata();
    endif;
    ?>
</div>
<?php get_footer(); ?>
