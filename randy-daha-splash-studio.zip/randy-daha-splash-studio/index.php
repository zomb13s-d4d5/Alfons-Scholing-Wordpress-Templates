<?php
if (!defined('ABSPATH')) {
    exit;
}
get_header();
?>
<div class="site-bg" style="background-image:url('<?php echo esc_url(randy_daha_get_background_image()); ?>');"></div>
<div class="site-overlay"></div>
<div class="default-page-shell">
    <header class="glass shell-header shell-header--static">
        <div class="brand-block">
            <div class="brand-kicker"><?php bloginfo('name'); ?></div>
            <div class="brand-subtitle"><?php bloginfo('description'); ?></div>
        </div>
        <nav class="top-nav">
            <?php wp_nav_menu(array('theme_location' => 'primary', 'container' => false, 'fallback_cb' => 'randy_daha_fallback_menu')); ?>
        </nav>
    </header>

    <main class="glass page-panel">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <article <?php post_class(); ?>>
                <p class="panel-kicker"><?php echo esc_html(get_post_type()); ?></p>
                <h1><?php the_title(); ?></h1>
                <div class="panel-body"><?php the_content(); ?></div>
            </article>
        <?php endwhile; else : ?>
            <article>
                <h1><?php esc_html_e('Nothing found', 'randy-daha-splash-studio'); ?></h1>
            </article>
        <?php endif; ?>
    </main>
</div>
<?php get_footer(); ?>
