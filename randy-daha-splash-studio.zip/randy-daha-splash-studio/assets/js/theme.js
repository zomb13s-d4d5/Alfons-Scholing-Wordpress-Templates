(function () {
  const modalLayer = document.querySelector('.modal-layer');
  const modalContent = document.querySelector('.modal-content');
  const closeTriggers = document.querySelectorAll('[data-close-modal="true"]');
  const openers = document.querySelectorAll('[data-panel]');
  const rail = document.querySelector('.content-rail');

  function openPanel(panelId) {
    if (!modalLayer || !modalContent) return;
    const template = document.getElementById(panelId);
    if (!template) return;
    modalContent.innerHTML = template.innerHTML;
    modalLayer.hidden = false;
    document.body.classList.add('modal-open');
  }

  function closePanel() {
    if (!modalLayer || !modalContent) return;
    modalLayer.hidden = true;
    modalContent.innerHTML = '';
    document.body.classList.remove('modal-open');
  }

  openers.forEach((button) => {
    button.addEventListener('click', function (event) {
      event.preventDefault();
      const panelId = this.getAttribute('data-panel');
      openPanel(panelId);
    });
  });

  closeTriggers.forEach((element) => {
    element.addEventListener('click', closePanel);
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      closePanel();
    }
  });

  if (rail) {
    rail.addEventListener('wheel', function (event) {
      if (Math.abs(event.deltaY) > Math.abs(event.deltaX)) {
        rail.scrollLeft += event.deltaY;
        event.preventDefault();
      }
    }, { passive: false });

    let isPointerDown = false;
    let startX = 0;
    let scrollLeft = 0;

    rail.addEventListener('pointerdown', function (event) {
      if (event.pointerType === 'mouse') return;
      isPointerDown = true;
      startX = event.clientX;
      scrollLeft = rail.scrollLeft;
    });

    rail.addEventListener('pointermove', function (event) {
      if (!isPointerDown) return;
      const distance = event.clientX - startX;
      rail.scrollLeft = scrollLeft - distance;
    });

    ['pointerup', 'pointercancel', 'pointerleave'].forEach(function (type) {
      rail.addEventListener(type, function () {
        isPointerDown = false;
      });
    });
  }
})();
