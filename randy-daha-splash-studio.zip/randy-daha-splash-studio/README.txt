Randy Daha Splash Studio Theme
==============================

Installation
------------
1. Upload the ZIP in WordPress under Appearance > Themes > Add New > Upload Theme.
2. Activate the theme.
3. Go to Settings > Reading and assign a static front page if desired.
4. Go to Appearance > Customize > Randy Daha Visuals to replace the splash background and hero tagline.
5. Create posts, pages, or Studio Panels. They will appear in the bottom content rail.
6. Assign a menu to the Primary Menu location for the glass top navigation.

What this theme does
--------------------
- Fixed full-viewport splash background
- No long page scroll on the homepage
- Glass header and content rail
- JavaScript lightbox/modal panels for content
- Horizontal thumbnail rail for content browsing
- Built-in custom post type: Studio Panels

Recommended next edits
----------------------
- Replace the default fallback panel text with Randy's real biography and contact info.
- Add audio embeds, videos, galleries, and notebooks inside posts or Studio Panels.
- Add custom logo and menu.
- Optimize the background image if a smaller web-sized version is preferred.


Update: This version removes the center hero block and keeps the entire interface inside the viewport, with an iOS-friendly top bar and bottom horizontal content rail.
