<?php
if (!defined('ABSPATH')) {
    exit;
}

function randy_daha_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'height'      => 120,
        'width'       => 320,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));

    register_nav_menus(array(
        'primary' => __('Primary Menu', 'randy-daha-splash-studio'),
    ));
}
add_action('after_setup_theme', 'randy_daha_theme_setup');

function randy_daha_enqueue_assets() {
    wp_enqueue_style(
        'randy-daha-theme',
        get_template_directory_uri() . '/assets/css/theme.css',
        array(),
        filemtime(get_template_directory() . '/assets/css/theme.css')
    );

    wp_enqueue_script(
        'randy-daha-theme',
        get_template_directory_uri() . '/assets/js/theme.js',
        array(),
        filemtime(get_template_directory() . '/assets/js/theme.js'),
        true
    );

    wp_localize_script('randy-daha-theme', 'randyDahaTheme', array(
        'homeUrl'         => home_url('/'),
        'closeLabel'      => __('Close', 'randy-daha-splash-studio'),
        'openLabel'       => __('Open panel', 'randy-daha-splash-studio'),
        'defaultBg'       => get_template_directory_uri() . '/assets/images/randy-splash-bg.png',
        'backgroundImage' => esc_url(randy_daha_get_background_image()),
    ));
}
add_action('wp_enqueue_scripts', 'randy_daha_enqueue_assets');

function randy_daha_register_post_types() {
    $supports = array('title', 'editor', 'excerpt', 'thumbnail', 'page-attributes');

    register_post_type('studio_panel', array(
        'labels' => array(
            'name'          => __('Studio Panels', 'randy-daha-splash-studio'),
            'singular_name' => __('Studio Panel', 'randy-daha-splash-studio'),
        ),
        'public'       => true,
        'show_in_rest' => true,
        'menu_icon'    => 'dashicons-images-alt2',
        'supports'     => $supports,
        'has_archive'  => true,
        'rewrite'      => array('slug' => 'studio'),
    ));
}
add_action('init', 'randy_daha_register_post_types');

function randy_daha_customize_register($wp_customize) {
    $wp_customize->add_section('randy_daha_visuals', array(
        'title'    => __('Randy Daha Visuals', 'randy-daha-splash-studio'),
        'priority' => 30,
    ));

    $wp_customize->add_setting('randy_daha_background_image', array(
        'default'           => get_template_directory_uri() . '/assets/images/randy-splash-bg.png',
        'sanitize_callback' => 'esc_url_raw',
    ));

    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'randy_daha_background_image', array(
        'label'    => __('Splash Background', 'randy-daha-splash-studio'),
        'section'  => 'randy_daha_visuals',
        'settings' => 'randy_daha_background_image',
    )));

    $wp_customize->add_setting('randy_daha_tagline', array(
        'default'           => 'Caribbean x Dutch street studio aesthetics',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control('randy_daha_tagline', array(
        'type'    => 'text',
        'label'   => __('Hero Tagline', 'randy-daha-splash-studio'),
        'section' => 'randy_daha_visuals',
    ));
}
add_action('customize_register', 'randy_daha_customize_register');

function randy_daha_get_background_image() {
    $value = get_theme_mod('randy_daha_background_image');
    if (!empty($value)) {
        return $value;
    }
    return get_template_directory_uri() . '/assets/images/randy-splash-bg.png';
}

function randy_daha_body_classes($classes) {
    if (is_front_page()) {
        $classes[] = 'randy-daha-immersive-home';
    }
    return $classes;
}
add_filter('body_class', 'randy_daha_body_classes');

function randy_daha_fallback_menu() {
    $pages = get_pages(array(
        'sort_column' => 'menu_order,post_title',
        'sort_order'  => 'ASC',
    ));

    if (empty($pages)) {
        return;
    }

    echo '<ul class="menu">';
    foreach ($pages as $page) {
        if ((int) $page->ID === (int) get_option('page_on_front')) {
            continue;
        }
        printf(
            '<li><a href="#" data-panel="post-%1$d">%2$s</a></li>',
            (int) $page->ID,
            esc_html($page->post_title)
        );
    }
    echo '</ul>';
}

function randy_daha_get_featured_items($limit = 12) {
    $front_page_id = (int) get_option('page_on_front');

    $query = new WP_Query(array(
        'post_type'           => array('post', 'page', 'studio_panel'),
        'posts_per_page'      => $limit,
        'post_status'         => 'publish',
        'ignore_sticky_posts' => true,
        'post__not_in'        => $front_page_id ? array($front_page_id) : array(),
        'orderby'             => array('menu_order' => 'ASC', 'date' => 'DESC'),
    ));

    return $query;
}
