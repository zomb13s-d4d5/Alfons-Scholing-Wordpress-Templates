(function () {
    const themeData = window.miniMesaTheme || {};
    const backgrounds = Array.isArray(themeData.backgrounds) ? themeData.backgrounds : [];
    const intervalMs = Number(themeData.intervalMs || 6500);
    const bgLayers = Array.from(document.querySelectorAll('.mm-bg-layer'));
    let activeIndex = 0;
    let activeLayer = 0;

    function preload(url) {
        return new Promise((resolve) => {
            const img = new Image();
            img.onload = resolve;
            img.onerror = resolve;
            img.src = url;
        });
    }

    async function initBackgrounds() {
        if (!bgLayers.length || !backgrounds.length) return;
        await Promise.all(backgrounds.map(preload));
        bgLayers[0].style.backgroundImage = `url("${backgrounds[0]}")`;
        bgLayers[0].classList.add('is-active');
        if (backgrounds.length < 2) return;
        setInterval(() => {
            const nextIndex = (activeIndex + 1) % backgrounds.length;
            const nextLayer = activeLayer === 0 ? 1 : 0;
            bgLayers[nextLayer].style.backgroundImage = `url("${backgrounds[nextIndex]}")`;
            bgLayers[nextLayer].classList.add('is-active');
            bgLayers[activeLayer].classList.remove('is-active');
            activeLayer = nextLayer;
            activeIndex = nextIndex;
        }, intervalMs);
    }

    function getPosts() {
        const el = document.getElementById('mini-mesa-posts');
        if (!el) return [];
        try {
            return JSON.parse(el.textContent) || [];
        } catch (error) {
            return [];
        }
    }

    function fitStage() {
        const viewport = document.querySelector('.mm-viewport');
        const stage = document.querySelector('.mm-stage');
        if (!viewport || !stage) return;

        const adminBar = document.getElementById('wpadminbar');
        const adminOffset = adminBar ? adminBar.offsetHeight : 0;
        const vw = window.innerWidth;
        const vh = window.innerHeight - adminOffset;
        const horizontalPad = vw < 900 ? 12 : 18;
        const verticalPad = vw < 900 ? 10 : 18;
        const baseW = Number(stage.dataset.stageWidth || 980);
        const baseH = Number(stage.dataset.stageHeight || 1000);
        const scale = Math.min((vw - horizontalPad * 2) / baseW, (vh - verticalPad * 2) / baseH);
        const safeScale = Math.max(scale, 0.1);

        viewport.style.top = `${adminOffset}px`;
        viewport.style.height = `${vh}px`;
        stage.style.width = `${baseW}px`;
        stage.style.height = `${baseH}px`;
        stage.style.transform = `scale(${safeScale})`;
        document.documentElement.style.overflow = 'hidden';
        document.body.style.overflow = 'hidden';
    }

    function initPanels() {
        const posts = getPosts();
        const grid = document.querySelector('.mm-grid');
        const cards = Array.from(document.querySelectorAll('.mm-card-button'));
        const prev = document.querySelector('.mm-page-prev');
        const next = document.querySelector('.mm-page-next');
        const status = document.querySelector('.mm-page-status');
        const lightbox = document.querySelector('.mm-lightbox');
        const content = document.querySelector('.mm-lightbox-content');
        const closeButtons = Array.from(document.querySelectorAll('[data-lightbox-close]'));
        const stage = document.querySelector('.mm-stage');
        const swipeArea = document.querySelector('.mm-main');
        const slotCount = Number(stage?.dataset.slotCount || cards.length || 6);
        const pageSize = Math.max(1, slotCount);
        const pageCount = Math.max(1, Math.ceil(posts.length / pageSize));
        let page = 0;
        let armedId = null;
        let touchStartX = 0;
        let touchStartY = 0;
        let touchActive = false;
        let animating = false;

        function closeLightbox() {
            if (!lightbox || !content) return;
            lightbox.hidden = true;
            content.innerHTML = '';
            document.body.classList.remove('mm-lightbox-open');
        }

        function openLightbox(post) {
            if (!lightbox || !content || !post) return;
            const thumb = post.thumb ? `<div class="mm-lightbox-thumb"><img src="${post.thumb}" alt=""></div>` : '';
            content.innerHTML = `
                <article class="mm-lightbox-article">
                    <p class="mm-kicker">${post.date || ''}</p>
                    <h2>${post.title || ''}</h2>
                    ${thumb}
                    <div class="mm-lightbox-body"><p>${post.excerpt || ''}</p></div>
                    <p><a class="mm-read-full" href="${post.link || '#'}">Read full article</a></p>
                </article>`;
            lightbox.hidden = false;
            document.body.classList.add('mm-lightbox-open');
        }

        function setAnimation(direction) {
            if (!grid) return;
            grid.classList.remove('is-slide-next', 'is-slide-prev');
            void grid.offsetWidth;
            if (direction === 'next') {
                grid.classList.add('is-slide-next');
            } else if (direction === 'prev') {
                grid.classList.add('is-slide-prev');
            }
            if (direction) {
                animating = true;
                window.setTimeout(() => {
                    grid.classList.remove('is-slide-next', 'is-slide-prev');
                    animating = false;
                }, 260);
            }
        }

        function render(direction = '') {
            const start = page * pageSize;
            const items = posts.slice(start, start + pageSize);

            cards.forEach((button, index) => {
                const post = items[index];
                button.classList.remove('is-live', 'is-empty', 'is-armed', 'has-thumb');
                button.style.backgroundImage = '';
                button.disabled = false;
                if (!post) {
                    button.innerHTML = '<span class="mm-card-abbr">&nbsp;</span>';
                    button.classList.add('is-empty');
                    button.disabled = true;
                    button.dataset.postIndex = '';
                    button.setAttribute('aria-label', '');
                    return;
                }
                button.innerHTML = `<span class="mm-card-abbr">${String(post.abbr || '...').substring(0, 3)}</span>`;
                button.classList.add('is-live');
                button.dataset.postIndex = String(start + index);
                button.setAttribute('aria-label', post.title || 'Article');
                if (post.thumb) {
                    button.style.backgroundImage = `linear-gradient(rgba(8,16,31,0.42), rgba(8,16,31,0.42)), url("${post.thumb}")`;
                    button.classList.add('has-thumb');
                }
            });

            if (prev) prev.disabled = page <= 0;
            if (next) next.disabled = page >= pageCount - 1;
            if (status) {
                status.textContent = posts.length ? `${page + 1} / ${pageCount}` : '0 / 0';
            }
            armedId = null;
            setAnimation(direction);
            requestAnimationFrame(fitStage);
        }

        function goToPage(nextPage, direction) {
            if (animating) return;
            if (nextPage < 0 || nextPage > pageCount - 1 || nextPage === page) return;
            page = nextPage;
            render(direction);
        }

        cards.forEach((button) => {
            button.addEventListener('click', () => {
                const idx = Number(button.dataset.postIndex);
                if (!Number.isFinite(idx) || !posts[idx]) return;
                const currentId = String(idx);
                cards.forEach((btn) => btn.classList.remove('is-armed'));
                if (armedId === currentId) {
                    armedId = null;
                    openLightbox(posts[idx]);
                    return;
                }
                armedId = currentId;
                button.classList.add('is-armed');
            });
        });

        if (prev) {
            prev.addEventListener('click', () => goToPage(page - 1, 'prev'));
        }

        if (next) {
            next.addEventListener('click', () => goToPage(page + 1, 'next'));
        }

        if (swipeArea) {
            swipeArea.addEventListener('touchstart', (event) => {
                if (!event.touches || event.touches.length !== 1) return;
                touchActive = true;
                touchStartX = event.touches[0].clientX;
                touchStartY = event.touches[0].clientY;
            }, { passive: true });

            swipeArea.addEventListener('touchend', (event) => {
                if (!touchActive || !event.changedTouches || !event.changedTouches.length) return;
                const endX = event.changedTouches[0].clientX;
                const endY = event.changedTouches[0].clientY;
                const deltaX = endX - touchStartX;
                const deltaY = endY - touchStartY;
                touchActive = false;

                if (Math.abs(deltaX) < 50 || Math.abs(deltaX) < Math.abs(deltaY)) return;
                if (deltaX < 0) {
                    goToPage(page + 1, 'next');
                } else {
                    goToPage(page - 1, 'prev');
                }
            }, { passive: true });
        }

        closeButtons.forEach((button) => button.addEventListener('click', closeLightbox));
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape' && lightbox && !lightbox.hidden) {
                closeLightbox();
            }
            if (event.key === 'ArrowLeft' && prev && !prev.disabled) {
                prev.click();
            }
            if (event.key === 'ArrowRight' && next && !next.disabled) {
                next.click();
            }
        });

        render();
    }

    window.addEventListener('resize', fitStage);
    window.addEventListener('orientationchange', fitStage);
    window.addEventListener('load', fitStage);

    initBackgrounds();
    initPanels();
    requestAnimationFrame(fitStage);
})();
