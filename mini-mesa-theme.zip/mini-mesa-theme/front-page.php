<?php
get_header();

$subtitle    = get_theme_mod('mini_mesa_subtitle', 'Youth think tank');
$about_title = get_theme_mod('mini_mesa_about_title', 'About Mini Mesa');
$about_text  = get_theme_mod('mini_mesa_about_text', 'Mini Mesa is a youth think tank for ambitious young people with ideas to test, sharpen, and share. It is a space for essays, proposals, research, and civic imagination—bringing together reflection, public debate, and fresh perspectives on culture, society, and the future.');

if ($about_title === 'Explanation / Promotion') {
    $about_title = 'About Mini Mesa';
}

if ($about_text === 'Mini Mesa is a youth think tank platform for essays, proposals, public thought, and contemporary civic debate.') {
    $about_text = 'Mini Mesa is a youth think tank for ambitious young people with ideas to test, sharpen, and share. It is a space for essays, proposals, research, and civic imagination—bringing together reflection, public debate, and fresh perspectives on culture, society, and the future.';
}
$footer_text = get_theme_mod('mini_mesa_footer_text', 'Mini Mesa — youth think tank.');
$page_size   = mini_mesa_get_page_size();
$grid_config = mini_mesa_get_grid_config($page_size);
$grid_columns = $grid_config['columns'];
$grid_rows    = $grid_config['rows'];
$card_count   = $grid_config['slots'];
$stage_height = $grid_config['height'];

$post_query = new WP_Query([
    'post_type'              => 'post',
    'posts_per_page'         => -1,
    'ignore_sticky_posts'    => true,
    'post_status'            => 'publish',
    'no_found_rows'          => true,
    'update_post_meta_cache' => false,
    'update_post_term_cache' => false,
]);

$cards = [];
if ($post_query->have_posts()) {
    while ($post_query->have_posts()) {
        $post_query->the_post();
        $title = trim(wp_strip_all_tags(get_the_title()));
        $abbr  = function_exists('mb_substr') ? mb_substr($title, 0, 3) : substr($title, 0, 3);
        $cards[] = [
            'id'      => get_the_ID(),
            'abbr'    => strtoupper($abbr),
            'title'   => get_the_title(),
            'date'    => get_the_date('j F Y'),
            'excerpt' => wp_trim_words(get_the_excerpt() ?: wp_strip_all_tags(get_the_content()), 40),
            'link'    => get_permalink(),
            'thumb'   => has_post_thumbnail() ? get_the_post_thumbnail_url(get_the_ID(), 'large') : '',
        ];
    }
    wp_reset_postdata();
}
?>
<div class="mm-site-shell">
    <div class="mm-backgrounds" aria-hidden="true">
        <div class="mm-bg-layer is-active"></div>
        <div class="mm-bg-layer"></div>
        <div class="mm-bg-overlay"></div>
    </div>

    <div class="mm-viewport">
        <div class="mm-stage" data-stage-width="980" data-stage-height="<?php echo esc_attr($stage_height); ?>" data-page-size="<?php echo esc_attr($page_size); ?>" data-slot-count="<?php echo esc_attr($card_count); ?>">
            <header class="mm-header" id="top">
                <div class="mm-header-copy">
                    <h1 class="mm-site-title"><?php echo esc_html(get_bloginfo('name') ?: 'Mini Mesa'); ?></h1>
                    <p class="mm-site-subtitle"><?php echo esc_html($subtitle); ?></p>
                </div>
                <a class="mm-brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php esc_attr_e('Homepage', 'mini-mesa'); ?>">
                    <?php echo mini_mesa_get_brand_mark(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                </a>
            </header>

            <main class="mm-main" id="articles">
                <section class="mm-grid mm-grid--<?php echo esc_attr($grid_rows); ?>rows mm-grid--<?php echo esc_attr($card_count); ?>" aria-label="Article panels" style="--mm-grid-columns: <?php echo esc_attr($grid_columns); ?>; --mm-grid-rows: <?php echo esc_attr($grid_rows); ?>;">
                    <?php for ($i = 0; $i < $card_count; $i++) : ?>
                        <article class="mm-card" data-card-index="<?php echo esc_attr($i); ?>">
                            <button class="mm-card-button" type="button" disabled>
                                <span class="mm-card-abbr">&nbsp;</span>
                            </button>
                        </article>
                    <?php endfor; ?>
                </section>

                <nav class="mm-pager" aria-label="<?php esc_attr_e('Article pages', 'mini-mesa'); ?>">
                    <button class="mm-page-arrow mm-page-prev" type="button" aria-label="<?php esc_attr_e('Previous articles', 'mini-mesa'); ?>">&lt;&lt;</button>
                    <span class="mm-page-status" aria-live="polite"></span>
                    <button class="mm-page-arrow mm-page-next" type="button" aria-label="<?php esc_attr_e('Next articles', 'mini-mesa'); ?>">&gt;&gt;</button>
                </nav>
            </main>

            <section class="mm-promo" id="about">
                <div class="mm-promo-mark">
                    <?php echo mini_mesa_get_brand_mark(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                </div>
                <div class="mm-promo-copy">
                    <p class="mm-promo-title"><?php echo esc_html($about_title); ?></p>
                    <p class="mm-promo-text"><?php echo esc_html($about_text); ?></p>
                </div>
            </section>

            <footer class="mm-footer" id="footer">
                <p><?php echo esc_html($footer_text); ?></p>
                <small>&copy; <?php echo esc_html(date_i18n('Y')); ?> <?php echo esc_html(get_bloginfo('name') ?: 'Mini Mesa'); ?></small>
            </footer>
        </div>
    </div>
</div>

<div class="mm-lightbox" hidden>
    <div class="mm-lightbox-backdrop" data-lightbox-close></div>
    <div class="mm-lightbox-dialog" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e('Article preview', 'mini-mesa'); ?>">
        <button class="mm-lightbox-close" type="button" aria-label="<?php esc_attr_e('Close', 'mini-mesa'); ?>" data-lightbox-close>&times;</button>
        <div class="mm-lightbox-content"></div>
    </div>
</div>

<script id="mini-mesa-posts" type="application/json"><?php echo wp_json_encode($cards); ?></script>
<?php get_footer(); ?>
