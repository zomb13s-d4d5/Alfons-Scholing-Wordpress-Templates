Mini Mesa One Page WordPress Theme

Included:
- One-page front-page layout
- Rotating background images
- Glass-panel content shell
- Internal scrolling panel area
- JavaScript lightbox for recent posts
- WordPress Customizer options for subtitle, about text, footer text, and five background images

Install:
1. Upload the ZIP in WordPress Appearance > Themes.
2. Activate the theme.
3. Set a static homepage to the front page if needed.
4. Publish posts to populate the card grid automatically.
5. Set a Site Icon in WordPress to use it as the favicon-logo.
6. Optionally assign a Primary Menu.

Notes:
- The theme ships with five default abstract backgrounds from the provided assets.
- On desktop, the viewport stays fixed and the glass content panel scrolls internally.
- On smaller screens, the layout relaxes into a more natural mobile scroll mode.
