<?php
if (!defined('ABSPATH')) {
    exit;
}

function mini_mesa_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', [
        'height'      => 120,
        'width'       => 120,
        'flex-height' => true,
        'flex-width'  => true,
    ]);
    add_theme_support('custom-header');
    add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script']);

    register_nav_menus([
        'primary' => __('Primary Menu', 'mini-mesa'),
    ]);
}
add_action('after_setup_theme', 'mini_mesa_setup');

function mini_mesa_get_page_size() {
    $raw = (int) get_option('posts_per_page', 6);
    return max(1, min(12, $raw));
}

function mini_mesa_get_grid_config($page_size) {
    if ($page_size <= 2) {
        return ['columns' => $page_size, 'rows' => 1, 'slots' => max(1, $page_size), 'height' => 860];
    }

    if ($page_size <= 4) {
        return ['columns' => 2, 'rows' => 2, 'slots' => 4, 'height' => 930];
    }

    if ($page_size <= 6) {
        return ['columns' => 3, 'rows' => 2, 'slots' => 6, 'height' => 1000];
    }

    if ($page_size <= 9) {
        return ['columns' => 3, 'rows' => 3, 'slots' => 9, 'height' => 1120];
    }

    return ['columns' => 4, 'rows' => 3, 'slots' => 12, 'height' => 1060];
}

function mini_mesa_enqueue_assets() {
    wp_enqueue_style(
        'mini-mesa-fonts',
        'https://fonts.googleapis.com/css2?family=Alegreya:wght@500;700;800&family=Inter:wght@400;500;600;700&display=swap',
        [],
        null
    );

    wp_enqueue_style(
        'mini-mesa-theme-base',
        get_stylesheet_uri(),
        ['mini-mesa-fonts'],
        filemtime(get_stylesheet_directory() . '/style.css')
    );

    wp_enqueue_style(
        'mini-mesa-theme',
        get_template_directory_uri() . '/assets/css/theme.css',
        ['mini-mesa-theme-base'],
        filemtime(get_template_directory() . '/assets/css/theme.css')
    );

    wp_enqueue_script(
        'mini-mesa-theme',
        get_template_directory_uri() . '/assets/js/theme.js',
        [],
        filemtime(get_template_directory() . '/assets/js/theme.js'),
        true
    );

    $default_backgrounds = [
        get_template_directory_uri() . '/assets/images/bg-4.jpg',
        get_template_directory_uri() . '/assets/images/bg-1.jpg',
        get_template_directory_uri() . '/assets/images/bg-3.jpg',
        get_template_directory_uri() . '/assets/images/bg-2.jpg',
        get_template_directory_uri() . '/assets/images/bg-5.jpg',
    ];

    $custom_backgrounds = [];
    for ($i = 1; $i <= 5; $i++) {
        $image = get_theme_mod('mini_mesa_bg_' . $i);
        if (!empty($image)) {
            $custom_backgrounds[] = esc_url_raw($image);
        }
    }

    $backgrounds = !empty($custom_backgrounds) ? $custom_backgrounds : $default_backgrounds;
    $page_size = mini_mesa_get_page_size();
    $grid_config = mini_mesa_get_grid_config($page_size);

    wp_localize_script('mini-mesa-theme', 'miniMesaTheme', [
        'backgrounds' => $backgrounds,
        'fadeMs'      => 1400,
        'intervalMs'  => 6500,
        'pageSize'    => $page_size,
        'slotCount'   => $grid_config['slots'],
    ]);
}
add_action('wp_enqueue_scripts', 'mini_mesa_enqueue_assets');

function mini_mesa_customize_register($wp_customize) {
    $wp_customize->add_section('mini_mesa_theme_options', [
        'title'    => __('Mini Mesa Theme Options', 'mini-mesa'),
        'priority' => 30,
    ]);

    $settings = [
        'mini_mesa_subtitle' => [
            'label'   => __('Subtitle', 'mini-mesa'),
            'default' => 'Youth think tank for new debate, research, and civic imagination.',
            'type'    => 'text',
        ],
        'mini_mesa_about_title' => [
            'label'   => __('About Panel Title', 'mini-mesa'),
            'default' => 'About Mini Mesa',
            'type'    => 'text',
        ],
        'mini_mesa_about_text' => [
            'label'   => __('About Panel Text', 'mini-mesa'),
            'default' => 'Mini Mesa is a youth think tank for ambitious young people with ideas to test, sharpen, and share. It is a space for essays, proposals, research, and civic imagination—bringing together reflection, public debate, and fresh perspectives on culture, society, and the future.',
            'type'    => 'textarea',
        ],
        'mini_mesa_footer_text' => [
            'label'   => __('Footer Text', 'mini-mesa'),
            'default' => 'Mini Mesa — youth think tank.',
            'type'    => 'textarea',
        ],
    ];

    foreach ($settings as $setting_id => $args) {
        $wp_customize->add_setting($setting_id, [
            'default'           => $args['default'],
            'sanitize_callback' => $args['type'] === 'textarea' ? 'sanitize_textarea_field' : 'sanitize_text_field',
        ]);

        $wp_customize->add_control(new WP_Customize_Control($wp_customize, $setting_id, [
            'label'   => $args['label'],
            'section' => 'mini_mesa_theme_options',
            'type'    => $args['type'],
        ]));
    }

    for ($i = 1; $i <= 5; $i++) {
        $setting_id = 'mini_mesa_bg_' . $i;
        $wp_customize->add_setting($setting_id, [
            'sanitize_callback' => 'esc_url_raw',
        ]);

        $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, $setting_id, [
            'label'    => sprintf(__('Background Image %d', 'mini-mesa'), $i),
            'section'  => 'mini_mesa_theme_options',
            'settings' => $setting_id,
        ]));
    }
}
add_action('customize_register', 'mini_mesa_customize_register');

function mini_mesa_fallback_menu() {
    echo '<ul class="mm-nav-list">';
    echo '<li><a href="#top">Home</a></li>';
    echo '<li><a href="#articles">Articles</a></li>';
    echo '<li><a href="#about">About</a></li>';
    echo '<li><a href="#footer">Info</a></li>';
    echo '</ul>';
}

function mini_mesa_get_brand_mark() {
    $site_icon = get_site_icon_url(96);

    if ($site_icon) {
        return '<img src="' . esc_url($site_icon) . '" alt="' . esc_attr(get_bloginfo('name')) . '" class="mm-brand-icon" />';
    }

    $custom_logo_id = get_theme_mod('custom_logo');
    if ($custom_logo_id) {
        return wp_get_attachment_image($custom_logo_id, 'thumbnail', false, ['class' => 'mm-brand-icon']);
    }

    return '<span class="mm-brand-fallback">MM</span>';
}


function mini_mesa_maybe_enqueue_comment_reply() {
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'mini_mesa_maybe_enqueue_comment_reply');


function mini_mesa_fix_singular_scroll() {
    if (!is_singular()) {
        return;
    }
    $script = "document.documentElement.style.overflowY='auto';document.documentElement.style.height='auto';document.body.style.overflowY='auto';document.body.style.overflowX='hidden';";
    wp_add_inline_script('mini-mesa-theme', $script, 'after');
}
add_action('wp_enqueue_scripts', 'mini_mesa_fix_singular_scroll', 20);


function mini_mesa_enable_comments_support() {
    add_post_type_support('post', 'comments');
    add_post_type_support('page', 'comments');
}
add_action('init', 'mini_mesa_enable_comments_support');


function mini_mesa_force_comments_open($open, $post_id) {
    if (is_admin()) {
        return $open;
    }

    $post = get_post($post_id);
    if (!$post) {
        return $open;
    }

    if (in_array($post->post_type, ['post', 'page'], true)) {
        return true;
    }

    return $open;
}
add_filter('comments_open', 'mini_mesa_force_comments_open', 20, 2);

function mini_mesa_default_comment_status($status, $post_type, $comment_type) {
    if ($comment_type === 'comment' && in_array($post_type, ['post', 'page'], true)) {
        return 'open';
    }

    return $status;
}
add_filter('get_default_comment_status', 'mini_mesa_default_comment_status', 10, 3);
