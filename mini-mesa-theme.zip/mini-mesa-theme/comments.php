<?php
if (post_password_required()) {
    return;
}
?>
<section id="comments" class="mm-comments glass-panel <?php echo have_comments() ? 'mm-comments-has-items' : 'mm-comments-empty'; ?>">
    <h2 class="mm-comments-title">
        <?php
        $count = get_comments_number();
        if ($count > 0) {
            printf(
                esc_html(_n('%s Comment', '%s Comments', $count, 'mini-mesa')),
                esc_html(number_format_i18n($count))
            );
        } else {
            esc_html_e('Comments', 'mini-mesa');
        }
        ?>
    </h2>

    <?php if (have_comments()) : ?>
        <ol class="comment-list">
            <?php
            wp_list_comments([
                'style'       => 'ol',
                'short_ping'  => true,
                'avatar_size' => 48,
            ]);
            ?>
        </ol>

        <?php the_comments_navigation(); ?>
    <?php else : ?>
        <p class="mm-comments-empty-text"><?php esc_html_e('Be the first to leave a comment.', 'mini-mesa'); ?></p>
    <?php endif; ?>

    <?php
    comment_form([
        'class_submit'       => 'submit',
        'title_reply'        => __('Leave a comment', 'mini-mesa'),
        'title_reply_before' => '<h3 id="reply-title" class="comment-reply-title">',
        'title_reply_after'  => '</h3>',
    ]);
    ?>
</section>
