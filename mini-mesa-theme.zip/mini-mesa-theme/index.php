<?php
if (!defined('ABSPATH')) {
    exit;
}

if (is_front_page()) {
    get_template_part('front-page');
    return;
}

if (is_single()) {
    get_template_part('single');
    return;
}

if (is_page()) {
    get_template_part('page');
    return;
}

get_header();
?>
<div class="mm-single-wrapper">
    <div class="mm-single-background"></div>
    <main class="mm-single-main glass-panel">
        <header class="mm-single-topbar">
            <a class="mm-home-button" href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Home', 'mini-mesa'); ?></a>
            <div class="mm-single-branding">
                <p class="mm-single-site-name"><?php echo esc_html(get_bloginfo('name') ?: 'Mini Mesa'); ?></p>
            </div>
        </header>

        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <article <?php post_class('mm-single-article'); ?>>
                <p class="mm-kicker"><?php echo esc_html(get_the_date('j F Y')); ?></p>
                <h1><?php the_title(); ?></h1>
                <div class="mm-single-content"><?php the_content(); ?></div>
            </article>
        <?php endwhile; else : ?>
            <article class="mm-single-article">
                <h1><?php esc_html_e('Nothing found', 'mini-mesa'); ?></h1>
            </article>
        <?php endif; ?>
    </main>
</div>
<?php
get_footer();
