<?php get_header(); ?>
<div class="site-shell split-layout inner-view-shell single-view-shell">
  <section class="hero-scene split-scene">
    <div class="scanlines" aria-hidden="true"></div>
    <?php otaku_nextlevel_render_topbar(); ?>
    <div class="split-frame split-frame-inner">
      <?php otaku_nextlevel_render_left_rail(); ?>
      <main class="right-article-panel inner-panel-stage" aria-label="Article view">
        <div class="article-panel-shell inner-content-shell inner-content-shell-scroll">
          <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <article <?php post_class('single-story-shell'); ?>>
              <header class="single-story-hero <?php echo has_post_thumbnail() ? 'has-thumb' : 'no-thumb'; ?>">
                <div class="single-story-media">
                  <?php if (has_post_thumbnail()) { the_post_thumbnail('full'); } else { echo '<img src="' . esc_url(get_template_directory_uri() . '/assets/images/default-bg.png') . '" alt="">'; } ?>
                </div>
                <div class="single-story-overlay">
                  <div class="card-kicker"><?php echo esc_html(get_the_date()); ?></div>
                  <h1 class="single-story-title"><?php the_title(); ?></h1>
                  <div class="single-story-deck"><?php echo esc_html(wp_trim_words(get_the_excerpt(), 30)); ?></div>
                  <div class="single-story-meta-line">
                    <span><?php echo esc_html(get_the_author()); ?></span>
                    <span><?php echo wp_kses_post(get_the_category_list(' · ')); ?></span>
                  </div>
                </div>
              </header>
              <div class="single-story-content entry-content">
                <?php the_content(); ?>
              </div>
            </article>
          <?php endwhile; endif; ?>
        </div>
      </main>
    </div>
  </section>
</div>
<?php otaku_nextlevel_render_overlay_menu(); ?>
<?php get_footer(); ?>
