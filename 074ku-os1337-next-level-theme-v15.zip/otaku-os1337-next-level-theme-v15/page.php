<?php get_header(); ?>
<div class="site-shell split-layout inner-view-shell page-view-shell">
  <section class="hero-scene split-scene">
    <div class="scanlines" aria-hidden="true"></div>
    <?php otaku_nextlevel_render_topbar(); ?>
    <div class="split-frame split-frame-inner">
      <?php otaku_nextlevel_render_left_rail(); ?>
      <main class="right-article-panel inner-panel-stage" aria-label="Page view">
        <div class="article-panel-shell inner-content-shell inner-content-shell-scroll">
          <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <article <?php post_class('single-story-shell page-story-shell'); ?>>
              <header class="single-story-hero single-story-hero-page <?php echo has_post_thumbnail() ? 'has-thumb' : 'no-thumb'; ?>">
                <div class="single-story-media">
                  <?php if (has_post_thumbnail()) { the_post_thumbnail('full'); } else { echo '<img src="' . esc_url(get_template_directory_uri() . '/assets/images/default-bg.png') . '" alt="">'; } ?>
                </div>
                <div class="single-story-overlay">
                  <div class="card-kicker"><?php esc_html_e('Page', 'otaku-nextlevel'); ?></div>
                  <h1 class="single-story-title"><?php the_title(); ?></h1>
                </div>
              </header>
              <div class="single-story-content entry-content">
                <?php the_content(); ?>
              </div>
            </article>
          <?php endwhile; endif; ?>
        </div>
      </main>
    </div>
  </section>
</div>
<?php otaku_nextlevel_render_overlay_menu(); ?>
<?php get_footer(); ?>
