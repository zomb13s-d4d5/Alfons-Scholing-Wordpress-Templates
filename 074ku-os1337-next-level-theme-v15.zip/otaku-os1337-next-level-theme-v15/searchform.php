<form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>">
  <label class="screen-reader-text" for="site-search"><?php esc_html_e('Search for:', 'otaku-nextlevel'); ?></label>
  <input type="search" id="site-search" class="search-field" placeholder="<?php echo esc_attr__('Search articles, lessons, archives…', 'otaku-nextlevel'); ?>" value="<?php echo get_search_query(); ?>" name="s">
  <button type="submit"><?php esc_html_e('Search', 'otaku-nextlevel'); ?></button>
</form>
