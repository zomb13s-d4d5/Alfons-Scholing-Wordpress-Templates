<?php get_header(); ?>
<div class="site-shell split-layout inner-view-shell archive-view-shell">
  <section class="hero-scene split-scene">
    <div class="scanlines" aria-hidden="true"></div>
    <?php otaku_nextlevel_render_topbar(); ?>
    <div class="split-frame split-frame-inner">
      <?php otaku_nextlevel_render_left_rail(); ?>
      <main class="right-article-panel inner-panel-stage" aria-label="Archive overview">
        <div class="article-panel-shell inner-content-shell inner-content-shell-scroll">
          <header class="inner-hero inner-hero-archive">
            <div class="inner-hero-copy">
              <div class="kicker"><?php echo esc_html(post_type_archive_title('', false) ?: single_cat_title('', false) ?: single_tag_title('', false) ?: __('Archive', 'otaku-nextlevel')); ?></div>
              <h1 class="article-panel-title"><?php the_archive_title(); ?></h1>
              <div class="article-panel-subtitle"><?php the_archive_description(); ?></div>
            </div>
          </header>
          <?php if (have_posts()) : ?>
            <div class="archive-card-grid">
              <?php while (have_posts()) : the_post(); ?>
                <article <?php post_class('archive-story-card'); ?>>
                  <a class="archive-story-media" href="<?php the_permalink(); ?>">
                    <?php if (has_post_thumbnail()) { the_post_thumbnail('large'); } else { echo '<img src="' . esc_url(get_template_directory_uri() . '/assets/images/default-bg.png') . '" alt="">'; } ?>
                  </a>
                  <div class="archive-story-body">
                    <div class="card-kicker"><?php echo esc_html(get_the_date()); ?></div>
                    <h2 class="archive-story-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <div class="archive-story-excerpt"><?php echo esc_html(wp_trim_words(get_the_excerpt(), 28)); ?></div>
                    <div class="archive-story-meta">
                      <span><?php echo esc_html(get_the_author()); ?></span>
                      <a class="story-readmore" href="<?php the_permalink(); ?>"><?php esc_html_e('Read me more', 'otaku-nextlevel'); ?></a>
                    </div>
                  </div>
                </article>
              <?php endwhile; ?>
            </div>
            <nav class="pagination-wrap"><?php the_posts_pagination(['mid_size'=>1,'prev_text'=>'‹','next_text'=>'›']); ?></nav>
          <?php else : ?>
            <div class="archive-empty-state"><?php esc_html_e('No entries found in this archive yet.', 'otaku-nextlevel'); ?></div>
          <?php endif; ?>
        </div>
      </main>
    </div>
  </section>
</div>
<?php otaku_nextlevel_render_overlay_menu(); ?>
<?php get_footer(); ?>
