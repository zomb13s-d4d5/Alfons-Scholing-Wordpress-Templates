document.addEventListener('DOMContentLoaded', () => {
  const menu = document.getElementById('commandDeck');
  const openers = document.querySelectorAll('.js-open-menu');
  const closers = document.querySelectorAll('.js-close-menu');
  const trigger = document.querySelector('.character-menu-trigger');

  const setMenu = (open) => {
    if (!menu) return;
    menu.classList.toggle('is-open', open);
    menu.setAttribute('aria-hidden', open ? 'false' : 'true');
    document.body.style.overflow = open ? 'hidden' : '';
    if (trigger) {
      trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
    }
  };

  openers.forEach((button) => {
    button.addEventListener('click', () => setMenu(true));
  });

  closers.forEach((button) => {
    button.addEventListener('click', () => setMenu(false));
  });

  if (menu) {
    menu.addEventListener('click', (event) => {
      if (event.target === menu) setMenu(false);
    });
  }

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') setMenu(false);
  });

  const slider = document.querySelector('.js-archive-slider');
  const track = document.querySelector('.js-archive-track');
  const cards = document.querySelectorAll('.js-archive-card');
  const prev = document.querySelector('.js-archive-prev');
  const next = document.querySelector('.js-archive-next');
  const current = document.querySelector('.js-archive-current');
  const total = document.querySelector('.js-archive-total');

  if (slider && track && cards.length && prev && next && current && total) {
    let index = 0;

    const getVisibleCount = () => 1;

    const updateSlider = () => {
      const visible = getVisibleCount();
      const maxIndex = Math.max(0, cards.length - visible);
      index = Math.min(index, maxIndex);

      const firstCard = cards[0];
      const cardStyle = window.getComputedStyle(firstCard);
      const gap = parseFloat(window.getComputedStyle(track).gap || 0);
      const width = firstCard.getBoundingClientRect().width;
      const offset = index * (width + gap);

      track.style.transform = `translateX(-${offset}px)`;
      current.textContent = String(index + 1);
      total.textContent = String(maxIndex + 1);
      prev.disabled = index <= 0;
      next.disabled = index >= maxIndex;
    };

    prev.addEventListener('click', () => {
      index -= 1;
      updateSlider();
    });

    next.addEventListener('click', () => {
      index += 1;
      updateSlider();
    });

    window.addEventListener('resize', updateSlider);
    updateSlider();
  }
});
