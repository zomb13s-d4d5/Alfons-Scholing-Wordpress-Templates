<?php
if (!defined('ABSPATH')) {
    exit;
}

function otaku_nextlevel_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', [
        'height'      => 120,
        'width'       => 120,
        'flex-height' => true,
        'flex-width'  => true,
    ]);
    add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script']);

    register_nav_menus([
        'primary' => __('Primary Menu', 'otaku-nextlevel'),
    ]);
}
add_action('after_setup_theme', 'otaku_nextlevel_setup');

function otaku_nextlevel_enqueue_assets() {
    wp_enqueue_style('otaku-nextlevel-style', get_stylesheet_uri(), [], wp_get_theme()->get('Version'));
    wp_enqueue_script('otaku-nextlevel-script', get_template_directory_uri() . '/assets/js/theme.js', [], wp_get_theme()->get('Version'), true);

    $hero_bg = get_theme_mod('otaku_nextlevel_bg_image', get_template_directory_uri() . '/assets/images/default-bg.png');
    $hero_char = get_theme_mod('otaku_nextlevel_character_image', get_template_directory_uri() . '/assets/images/default-characters.png');

    $inline_css = ':root { --bg-image: url(' . esc_url($hero_bg) . '); }';
    wp_add_inline_style('otaku-nextlevel-style', $inline_css);

    wp_localize_script('otaku-nextlevel-script', 'otakuNextLevel', [
        'characterImage' => esc_url($hero_char),
    ]);
}
add_action('wp_enqueue_scripts', 'otaku_nextlevel_enqueue_assets');

function otaku_nextlevel_customize_register($wp_customize) {
    $wp_customize->add_section('otaku_nextlevel_scene', [
        'title'    => __('Hero Scene', 'otaku-nextlevel'),
        'priority' => 30,
    ]);

    $wp_customize->add_setting('otaku_nextlevel_bg_image', [
        'default'           => get_template_directory_uri() . '/assets/images/default-bg.png',
        'sanitize_callback' => 'esc_url_raw',
    ]);
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'otaku_nextlevel_bg_image', [
        'label'    => __('Hero Background Image', 'otaku-nextlevel'),
        'section'  => 'otaku_nextlevel_scene',
        'settings' => 'otaku_nextlevel_bg_image',
    ]));

    $wp_customize->add_setting('otaku_nextlevel_character_image', [
        'default'           => get_template_directory_uri() . '/assets/images/default-characters.png',
        'sanitize_callback' => 'esc_url_raw',
    ]);
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'otaku_nextlevel_character_image', [
        'label'    => __('Character Image', 'otaku-nextlevel'),
        'section'  => 'otaku_nextlevel_scene',
        'settings' => 'otaku_nextlevel_character_image',
    ]));

    $texts = [
        'brand_text'        => 'OTAKU.EU :: OS 1337',
        'status_left'       => 'hash & coffee idle',
        'status_right'      => 'local 03:41',
        'hero_kicker'       => '074KU.EU',
        'hero_meta'         => 'Shadow School Interface / Learn the Code',
        'hero_title'        => 'Learn To Program',
        'hero_copy'         => 'A futuristic coding-school front page built like a premium sci-fi dashboard. Use the characters to open a full-screen navigation layer, browse articles, launch courses, and search the archive.',
        'cta_label'         => 'Open Command Deck',
        'updates_heading'   => 'Shadow School Update',
        'updates_copy'      => 'Courses, articles, and category pages now live inside a cinematic mech-hangar experience for iPhone, iPad, and desktop.',
    ];

    foreach ($texts as $id => $default) {
        $wp_customize->add_setting('otaku_nextlevel_' . $id, [
            'default'           => $default,
            'sanitize_callback' => 'sanitize_text_field',
        ]);
        $wp_customize->add_control('otaku_nextlevel_' . $id, [
            'label'   => ucwords(str_replace('_', ' ', $id)),
            'section' => 'otaku_nextlevel_scene',
            'type'    => 'text',
        ]);
    }
}
add_action('customize_register', 'otaku_nextlevel_customize_register');

function otaku_nextlevel_mod($key, $fallback = '') {
    return get_theme_mod('otaku_nextlevel_' . $key, $fallback);
}

function otaku_nextlevel_fallback_menu() {
    $pages = get_pages(['sort_column' => 'menu_order']);
    if (empty($pages)) {
        echo '<ul class="primary-menu">';
        echo '<li><a href="' . esc_url(home_url('/')) . '">Home</a></li>';
        echo '<li><a href="' . esc_url(home_url('/blog/')) . '">Archive</a></li>';
        echo '</ul>';
        return;
    }

    echo '<ul class="primary-menu">';
    foreach (array_slice($pages, 0, 8) as $page) {
        echo '<li><a href="' . esc_url(get_permalink($page->ID)) . '">' . esc_html($page->post_title) . '</a></li>';
    }
    echo '</ul>';
}


function otaku_nextlevel_render_topbar() {
    ?>
    <div class="topbar">
      <div class="brand">
        <a class="brand-home" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php esc_attr_e('Home', 'otaku-nextlevel'); ?>">
          <?php $site_icon = get_site_icon_url(64); ?>
          <?php if ($site_icon) : ?>
            <img class="brand-mark" src="<?php echo esc_url($site_icon); ?>" alt="" aria-hidden="true">
          <?php else : ?>
            <span class="brand-mark brand-mark-fallback" aria-hidden="true"></span>
          <?php endif; ?>
        </a>
        <div class="brand-copy"><?php echo esc_html(otaku_nextlevel_mod('brand_text', 'OTAKU.EU :: OS 1337')); ?></div>
      </div>
      <div class="status-cluster">
        <div class="status-pill"><?php echo esc_html(otaku_nextlevel_mod('status_left', 'hash & coffee idle')); ?></div>
        <div class="status-pill"><?php echo esc_html(otaku_nextlevel_mod('status_right', 'local 03:41')); ?></div>
      </div>
    </div>
    <?php
}

function otaku_nextlevel_render_left_rail() {
    $character_image = get_theme_mod('otaku_nextlevel_character_image', get_template_directory_uri() . '/assets/images/default-characters.png');
    ?>
    <aside class="left-command-rail" aria-label="Character menu area">
      <div class="rail-panel rail-panel-characters-only">
        <button class="character-menu-trigger js-open-menu" type="button" aria-controls="commandDeck" aria-expanded="false" aria-label="Open command deck menu">
          <span class="character-stage-glow" aria-hidden="true"></span>
          <img class="character-image side-character-image" src="<?php echo esc_url($character_image); ?>" alt="Android hero characters opening the command deck menu">
        </button>
      </div>
    </aside>
    <?php
}

function otaku_nextlevel_render_overlay_menu() {
    ?>
    <div class="overlay-menu" id="commandDeck" aria-hidden="true">
      <div class="overlay-panel">
        <div class="overlay-content">
          <div class="overlay-header">
            <div>
              <div class="kicker"><?php esc_html_e('Command Deck', 'otaku-nextlevel'); ?></div>
              <h2 class="overlay-title"><?php bloginfo('name'); ?></h2>
            </div>
            <button type="button" class="close-menu js-close-menu"><?php esc_html_e('Close', 'otaku-nextlevel'); ?></button>
          </div>

          <div class="overlay-grid overlay-grid-priority">
            <section class="menu-card hero-menu-card">
              <div class="kicker"><?php echo esc_html(otaku_nextlevel_mod('hero_kicker', '074KU.EU')); ?></div>
              <div class="dashboard-meta"><?php echo esc_html(otaku_nextlevel_mod('hero_meta', 'Shadow School Interface / Learn the Code')); ?></div>
              <h3 class="dashboard-title"><?php echo esc_html(otaku_nextlevel_mod('hero_title', 'Learn To Program')); ?></h3>
              <div class="dashboard-copy"><?php echo esc_html(otaku_nextlevel_mod('hero_copy', 'A futuristic coding-school front page built like a premium sci-fi dashboard. Use the characters to open a full-screen navigation layer, browse articles, launch courses, and search the archive.')); ?></div>

              <div class="module-card compact-module-card">
                <div class="section-label"><?php esc_html_e('Search', 'otaku-nextlevel'); ?></div>
                <?php get_search_form(); ?>
                <ul class="module-list">
                  <li><strong><?php echo esc_html(otaku_nextlevel_mod('updates_heading', 'Shadow School Update')); ?></strong><br><?php echo esc_html(otaku_nextlevel_mod('updates_copy', 'Courses, articles, and category pages now live inside a cinematic mech-hangar experience for iPhone, iPad, and desktop.')); ?></li>
                </ul>
              </div>
            </section>

            <div class="menu-card">
              <div class="section-label"><?php esc_html_e('Navigation', 'otaku-nextlevel'); ?></div>
              <?php
              if (has_nav_menu('primary')) {
                  wp_nav_menu([
                      'theme_location' => 'primary',
                      'container'      => false,
                      'menu_class'     => 'primary-menu',
                      'fallback_cb'    => false,
                  ]);
              } else {
                  otaku_nextlevel_fallback_menu();
              }
              ?>
            </div>

            <div class="menu-card">
              <div class="section-label"><?php esc_html_e('Latest Articles', 'otaku-nextlevel'); ?></div>
              <ul class="overlay-links">
                <?php
                $latest = get_posts(['posts_per_page' => 6, 'post_status' => 'publish']);
                if (!empty($latest)) :
                    foreach ($latest as $post) : setup_postdata($post); ?>
                      <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
                    <?php endforeach; wp_reset_postdata();
                else : ?>
                  <li><a href="<?php echo esc_url(admin_url('post-new.php')); ?>"><?php esc_html_e('Create your first post', 'otaku-nextlevel'); ?></a></li>
                <?php endif; ?>
              </ul>
            </div>

            <div class="menu-card">
              <div class="section-label"><?php esc_html_e('Categories', 'otaku-nextlevel'); ?></div>
              <ul class="module-list">
                <?php
                $categories = get_categories(['number' => 6, 'hide_empty' => false]);
                if (!empty($categories)) :
                    foreach ($categories as $category) {
                        echo '<li><a href="' . esc_url(get_category_link($category->term_id)) . '">' . esc_html($category->name) . '</a></li>';
                    }
                else : ?>
                  <li><?php esc_html_e('Create categories for course tracks, archives, and topics.', 'otaku-nextlevel'); ?></li>
                <?php endif; ?>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php
}
