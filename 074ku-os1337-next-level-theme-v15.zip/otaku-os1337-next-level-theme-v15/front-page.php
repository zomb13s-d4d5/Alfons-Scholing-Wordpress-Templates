<?php get_header();
$character_image = get_theme_mod('otaku_nextlevel_character_image', get_template_directory_uri() . '/assets/images/default-characters.png');

$featured_posts_query = new WP_Query([
    'posts_per_page'      => 12,
    'ignore_sticky_posts' => true,
    'post_status'         => 'publish',
]);

$display_categories = get_categories([
    'number'     => 8,
    'hide_empty' => false,
    'orderby'    => 'count',
    'order'      => 'DESC',
]);
?>
<div class="site-shell split-layout">
  <section class="hero-scene split-scene">
    <div class="scanlines" aria-hidden="true"></div>

    <div class="topbar">
      <div class="brand">
        <a class="brand-home" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php esc_attr_e('Home', 'otaku-nextlevel'); ?>">
          <span class="brand-mark brand-mark-favorite" aria-hidden="true"></span>
        </a>
        <div class="brand-copy"><?php echo esc_html(otaku_nextlevel_mod('brand_text', 'OTAKU.EU :: OS 1337')); ?></div>
      </div>
      <div class="status-cluster">
        <div class="status-pill"><?php echo esc_html(otaku_nextlevel_mod('status_left', 'hash & coffee idle')); ?></div>
        <div class="status-pill"><?php echo esc_html(otaku_nextlevel_mod('status_right', 'local 03:41')); ?></div>
      </div>
    </div>

    <div class="split-frame">
      <aside class="left-command-rail" aria-label="Character menu area">
        <div class="rail-panel rail-panel-characters-only">
          <button class="character-menu-trigger js-open-menu" type="button" aria-controls="commandDeck" aria-expanded="false" aria-label="Open command deck menu">
            <span class="character-stage-glow" aria-hidden="true"></span>
            <img class="character-image side-character-image" src="<?php echo esc_url($character_image); ?>" alt="Android hero characters opening the command deck menu">
          </button>
        </div>
      </aside>

      <main class="right-article-panel" id="latest-stream" aria-label="Latest articles overview">
        <div class="article-panel-shell article-panel-shell-structured">
          <div class="article-topline">
            <section class="category-strip-panel" aria-label="Site categories">
              <div class="category-strip">
              <?php if (!empty($display_categories)) : ?>
                <?php foreach ($display_categories as $category) : ?>
                  <a class="category-strip-link" href="<?php echo esc_url(get_category_link($category->term_id)); ?>">
                    <span class="category-strip-name"><?php echo esc_html($category->name); ?></span>
                    <span class="category-strip-count"><?php echo esc_html((string) $category->count); ?></span>
                  </a>
                <?php endforeach; ?>
              <?php else : ?>
                <div class="category-strip-empty"><?php esc_html_e('Add categories to shape the archive.', 'otaku-nextlevel'); ?></div>
              <?php endif; ?>
            </div>
          </section>

            <section class="archive-slider-panel archive-slider-panel-floating" aria-label="Older articles slider navigation">
              <div class="archive-slider-head">
                <div class="archive-slider-controls">
                  <button class="archive-nav-button js-archive-prev" type="button" aria-label="Previous articles">
                    <span aria-hidden="true">&#8249;</span>
                  </button>
                  <div class="archive-slider-status"><span class="js-archive-current">1</span> / <span class="js-archive-total">1</span></div>
                  <button class="archive-nav-button js-archive-next" type="button" aria-label="Next articles">
                    <span aria-hidden="true">&#8250;</span>
                  </button>
                </div>
              </div>
            </section>
          </div>

          <div class="article-scroll-column article-scroll-column-structured">
            <section class="latest-feature-panel" aria-label="Featured article slider">
              <?php if ($featured_posts_query->have_posts()) : ?>
                <div class="featured-slider js-archive-slider" data-visible="1">
                  <div class="archive-track js-archive-track">
                    <?php while ($featured_posts_query->have_posts()) : $featured_posts_query->the_post(); ?>
                      <article class="story-card story-card-featured js-archive-card">
                        <a class="story-card-media" href="<?php the_permalink(); ?>">
                          <?php if (has_post_thumbnail()) {
                              the_post_thumbnail('large');
                          } else {
                              echo '<img src="' . esc_url(get_template_directory_uri() . '/assets/images/default-bg.png') . '" alt="">';
                          } ?>
                        </a>
                        <div class="story-card-body">
                          <div class="card-kicker"><?php echo esc_html(get_the_date()); ?></div>
                          <h3 class="story-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                          <div class="story-card-excerpt"><?php echo esc_html(wp_trim_words(get_the_excerpt(), 24)); ?></div>
                          <div class="story-card-meta">
                            <?php
                            $categories = get_the_category();
                            if (!empty($categories)) {
                                echo '<span>' . esc_html($categories[0]->name) . '</span>';
                            }
                            ?>
                            <a class="story-readmore" href="<?php the_permalink(); ?>"><?php esc_html_e('Read me more', 'otaku-nextlevel'); ?></a>
                          </div>
                        </div>
                      </article>
                    <?php endwhile; wp_reset_postdata(); ?>
                  </div>
                </div>
              <?php else : ?>
                <article class="story-card story-card-featured">
                  <div class="story-card-media"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/default-bg.png'); ?>" alt=""></div>
                  <div class="story-card-body">
                    <div class="card-kicker"><?php esc_html_e('Demo slot', 'otaku-nextlevel'); ?></div>
                    <h3 class="story-card-title"><?php esc_html_e('Your latest article appears here', 'otaku-nextlevel'); ?></h3>
                    <div class="story-card-excerpt"><?php esc_html_e('Publish a post to fill this featured latest-story block.', 'otaku-nextlevel'); ?></div>
                  </div>
                </article>
              <?php endif; ?>
            </section>

            
          </div>
        </div>
      </main>
    </div>
  </section>
</div>

<div class="overlay-menu" id="commandDeck" aria-hidden="true">
  <div class="overlay-panel">
    <div class="overlay-content">
      <div class="overlay-header">
        <div>
          <div class="kicker"><?php esc_html_e('Command Deck', 'otaku-nextlevel'); ?></div>
          <h2 class="overlay-title"><?php bloginfo('name'); ?></h2>
        </div>
        <button type="button" class="close-menu js-close-menu"><?php esc_html_e('Close', 'otaku-nextlevel'); ?></button>
      </div>

      <div class="overlay-grid overlay-grid-priority">
        <section class="menu-card hero-menu-card">
          <div class="kicker"><?php echo esc_html(otaku_nextlevel_mod('hero_kicker', '074KU.EU')); ?></div>
          <div class="dashboard-meta"><?php echo esc_html(otaku_nextlevel_mod('hero_meta', 'Shadow School Interface / Learn the Code')); ?></div>
          <h3 class="dashboard-title"><?php echo esc_html(otaku_nextlevel_mod('hero_title', 'Learn To Program')); ?></h3>
          <div class="dashboard-copy"><?php echo esc_html(otaku_nextlevel_mod('hero_copy', 'A futuristic coding-school front page built like a premium sci-fi dashboard. Use the characters to open a full-screen navigation layer, browse articles, launch courses, and search the archive.')); ?></div>

          <div class="module-card compact-module-card">
            <div class="section-label"><?php esc_html_e('Search', 'otaku-nextlevel'); ?></div>
            <?php get_search_form(); ?>
            <ul class="module-list">
              <li><strong><?php echo esc_html(otaku_nextlevel_mod('updates_heading', 'Shadow School Update')); ?></strong><br><?php echo esc_html(otaku_nextlevel_mod('updates_copy', 'Courses, articles, and category pages now live inside a cinematic mech-hangar experience for iPhone, iPad, and desktop.')); ?></li>
            </ul>
          </div>
        </section>

        <div class="menu-card">
          <div class="section-label"><?php esc_html_e('Navigation', 'otaku-nextlevel'); ?></div>
          <?php
          if (has_nav_menu('primary')) {
              wp_nav_menu([
                  'theme_location' => 'primary',
                  'container'      => false,
                  'menu_class'     => 'primary-menu',
                  'fallback_cb'    => false,
              ]);
          } else {
              otaku_nextlevel_fallback_menu();
          }
          ?>
        </div>

        <div class="menu-card">
          <div class="section-label"><?php esc_html_e('Latest Articles', 'otaku-nextlevel'); ?></div>
          <ul class="overlay-links">
            <?php
            $latest = get_posts(['posts_per_page' => 6, 'post_status' => 'publish']);
            if (!empty($latest)) :
                foreach ($latest as $post) : setup_postdata($post); ?>
                  <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
                <?php endforeach; wp_reset_postdata();
            else : ?>
              <li><a href="<?php echo esc_url(admin_url('post-new.php')); ?>"><?php esc_html_e('Create your first post', 'otaku-nextlevel'); ?></a></li>
            <?php endif; ?>
          </ul>
        </div>

        <div class="menu-card">
          <div class="section-label"><?php esc_html_e('Categories', 'otaku-nextlevel'); ?></div>
          <ul class="module-list">
            <?php
            $categories = get_categories(['number' => 6, 'hide_empty' => false]);
            if (!empty($categories)) :
                foreach ($categories as $category) {
                    echo '<li><a href="' . esc_url(get_category_link($category->term_id)) . '">' . esc_html($category->name) . '</a></li>';
                }
            else : ?>
              <li><?php esc_html_e('Create categories for course tracks, archives, and topics.', 'otaku-nextlevel'); ?></li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<?php get_footer(); ?>
