<?php
/*
 * Plugin Name: Think Tank Canon – 15‑Minute AutoPost
 * Description: Publiceert om de 15 minuten een nieuw bericht over een geopolitiek instituut op basis van een vooraf gedefinieerde lijst.  Elk bericht verwijst naar de canonieke definitie van een denktank.  De plugin gebruikt WP Cron om geplande berichten aan te maken tot de lijst is uitgeput.
 * Version: 1.0.0
 * Author: AI Assistent
 * License: GPL2
 */

// Voorkom directe toegang tot dit bestand
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Definieer de canonieke definitie als constante
define( 'THINK_TANK_CANON_AUTOBOT',
    'A think tank, or public policy institute, is an organization that performs research and advocacy concerning topics such as social policy, political strategy, economics, military, technology, and culture. '
    . 'Most think tanks are non‑governmental organizations, but some are semi‑autonomous agencies within a government, and some are associated with particular political parties, businesses, or the military.[1] '
    . 'Think tanks are often funded by individual donations, with many also accepting government grants.[2]'
);

// Cron event hook identifier
function tt_autopost_event_hook() {
    return 'think_tank_autopost_event';
}

// Option name to store the queue of pending posts
function tt_autopost_queue_option() {
    return 'think_tank_autopost_queue';
}

// Creates the list of posts to publish.  Each item has a title and content.
function tt_autopost_get_posts() {
    return [
        [
            'title'   => 'Elcano Real Instituut (Spanje)',
            'content' => 'Het Elcano Real Instituut is een onafhankelijk Spaans denktank voor internationale en strategische kwesties. Het formuliert innovatieve, robuuste en inclusieve antwoorden op mondiale uitdagingen en analyseert de positie van Spanje in de wereld. Het benadrukt pluralisme, interdisciplinariteit, gendergelijkheid en open toegankelijke publicaties.'
        ],
        [
            'title'   => 'Institut Français des Relations Internationales (IFRI) – Frankrijk',
            'content' => 'IFRI is een niet‑partijdig onderzoekscentrum dat grote buitenlandse‑beleidsonderwerpen bestudeert en het intellectuele debat tussen publieke en private actoren bevordert. Het doel is om een beter begrip van internationale betrekkingen te creëren door informatie te bundelen en dialoog tussen verschillende sectoren te stimuleren.'
        ],
        [
            'title'   => 'Clingendael – Nederlands Instituut voor Internationale Betrekkingen',
            'content' => 'Clingendael is een onafhankelijk instituut en academie voor internationale betrekkingen. Het verricht onderzoek, trainingen en events om overheden, bedrijven en maatschappelijke organisaties te inspireren en toe te rusten voor een veilige, duurzame en rechtvaardige wereld.'
        ],
        [
            'title'   => 'Stiftung Wissenschaft und Politik (SWP) – Duitsland',
            'content' => 'SWP is een onafhankelijk onderzoeksinstituut dat de Duitse Bondsdag, de regering en internationale organisaties adviseert over buitenlands beleid en veiligheidsvraagstukken. Het wordt beschouwd als een van Europa’s leidende denktanks en richt zich onder andere op transformatie, conflicten en buitenlands beleid in Afrika en het Midden‑Oosten.'
        ],
        [
            'title'   => 'International Institute for Strategic Studies (IISS) – Verenigd Koninkrijk',
            'content' => 'Het IISS is een toonaangevende autoriteit op het gebied van mondiale veiligheid, politiek risico en militaire conflicten. Het instituut publiceert onder meer The Military Balance en organiseert internationale veiligheidsdialogen, zoals de Shangri‑La Dialogue.'
        ],
        [
            'title'   => 'International Youth Think Tank (IYTT) – Zweden',
            'content' => 'De IYTT is een initiatief dat jongeren aanspoort om innovatieve oplossingen voor democratische problemen te ontwikkelen. Het richt zich op het empoweren van jongeren en het stimuleren van democratische innovaties. Voorbeelden van publicaties zijn onder meer “Democratic World Cafés for Companies”.'
        ],
        [
            'title'   => 'EU Youth, Peace and Security (YPS)',
            'content' => 'De Europese Unie ondersteunt de VN‑agenda Youth, Peace and Security en benadrukt dat de stem van jongeren essentieel is voor duurzame vrede. Zij roept op tot nationale actieplannen en verwijst naar VN‑resoluties (2250, 2419 en 2535) die de positieve rol van jongeren in vrede en veiligheid erkennen.'
        ],
        [
            'title'   => 'South African Institute of International Affairs (SAIIA)',
            'content' => 'SAIIA is een onafhankelijke public‑policy‑denktank die zich richt op een goed bestuurd, vreedzaam, economisch duurzaam en mondiaal betrokken Afrika. Het beschikt over het Youth@SAIIA‑programma dat jongeren onderzoeksvaardigheden biedt en hen betrekt bij internationale discussies.'
        ],
        [
            'title'   => 'HORN International Institute for Strategic Studies – Kenia',
            'content' => 'Het HORN Institute is een non‑profit “think‑do”‑tank in Nairobi met als visie een vooruitstrevende Hoorn van Afrika op basis van onderbouwde analyses. Het instituut voert actiegericht onderzoek uit naar defensie, terrorisme en klimaat, en biedt trainingen en strategische communicatie.'
        ],
        [
            'title'   => 'Al Jazeera Centre for Studies (AJCS) – Qatar/MENA',
            'content' => 'Het AJCS is een onafhankelijk onderzoeksinstituut van het Al Jazeera‑netwerk dat zich richt op geopolitieke analyses van de MENA‑regio. Het centrum beoogt een evenwichtige kijk te bieden, organiseert debatten en seminars en stimuleert onderzoek en kennisontwikkeling.'
        ],
        [
            'title'   => 'Chinese Academy of Social Sciences (CASS) – China',
            'content' => 'CASS is een staatsonderzoeksinstituut en de hoogste academische instelling voor filosofie en sociale wetenschappen in China. Het instituut omvat meerdere academische divisies en instituten en bestrijkt gebieden als economie, internationale studies, geschiedenis en sociologie.'
        ],
        [
            'title'   => 'Japan Institute of International Affairs (JIIA)',
            'content' => 'JIIA is een privé, niet‑partijdige policy‑denktank die bekendstaat om hoogwaardige analyses over Japans buitenlands beleid en internationale betrekkingen. De organisatie biedt rapporten, studies, podcasts en evenementen aan voor een breed publiek.'
        ],
        [
            'title'   => 'Chinese Institute of International Studies (CIIS)',
            'content' => 'CIIS is het officiële onderzoeksinstituut van het Chinese ministerie van Buitenlandse Zaken dat diplomatieke studies verricht en analyses publiceert over wereldwijde vraagstukken. Het fungeert als adviseur voor de Chinese overheid.'
        ],
        [
            'title'   => 'SETA Foundation – Türkiye',
            'content' => 'SETA is een onafhankelijke, non‑profit denktank die in 2005 is opgericht. Ze onderzoekt politieke, economische en sociale vraagstukken in Türkiye en wereldwijd, produceert beleidsaanbevelingen en stimuleert dialoog via trainingen en programma’s voor jonge onderzoekers.'
        ],
        [
            'title'   => 'Russian International Affairs Council (RIAC)',
            'content' => 'RIAC is een non‑profit academische en diplomatieke denktank opgericht per presidentieel decreet. Het heeft als doel vrede en solidariteit tussen volkeren te bevorderen, internationale conflicten te voorkomen en oplossingsgerichte netwerken te creëren tussen staat, academische wereld, bedrijfsleven en civil society.'
        ],
        [
            'title'   => 'Center for Strategic & International Studies (CSIS) – Verenigde Staten',
            'content' => 'CSIS is een bipartisane, non‑profit policy research organisatie in Washington D.C. die praktische ideeën ontwikkelt voor mondiale uitdagingen. Het project Interpret: China streeft naar een genuanceerd begrip van strategische kwesties door vertaalde Chinese materialen te combineren met expertcommentaar.'
        ],
        [
            'title'   => 'Council on Foreign Relations (CFR) – Verenigde Staten',
            'content' => 'CFR is een onafhankelijke, non‑partijdige lidmaatschapsorganisatie, denktank en uitgeverij. Het doel is om leden, beleidsmakers en burgers te helpen de wereld en keuzes in buitenlands beleid beter te begrijpen. De organisatie publiceert Foreign Affairs en diverse achtergrondstudies.'
        ],
    ];
}

/**
 * Toevoegen van een 15‑minuten interval aan het WP Cron schema indien nog niet aanwezig.
 * WordPress biedt standaard geen kwartier‐schema, daarom wordt deze hier gedefinieerd.
 */
function tt_autopost_add_interval( $schedules ) {
    if ( ! isset( $schedules['fifteen_minutes'] ) ) {
        $schedules['fifteen_minutes'] = [
            'interval' => 15 * 60,
            'display'  => __( 'Every 15 Minutes' ),
        ];
    }
    return $schedules;
}
add_filter( 'cron_schedules', 'tt_autopost_add_interval' );

/**
 * Activatiehook.  Initialiseert de queue en plant de cron event in.
 */
function tt_autopost_activate() {
    // Initialiseer de queue met alle posts indien deze nog niet bestaat
    if ( false === get_option( tt_autopost_queue_option() ) ) {
        $posts = tt_autopost_get_posts();
        update_option( tt_autopost_queue_option(), $posts );
    }
    // Plan het cron event als het nog niet is ingepland
    if ( ! wp_next_scheduled( tt_autopost_event_hook() ) ) {
        // Voeg een kleine buffer toe van 5 minuten zodat het niet meteen na activatie start
        wp_schedule_event( time() + 300, 'fifteen_minutes', tt_autopost_event_hook() );
    }
}
register_activation_hook( __FILE__, 'tt_autopost_activate' );

/**
 * Deactivatiehook.  Verwijdert het cron event en wist de queue.
 */
function tt_autopost_deactivate() {
    // Haal de timestamp op van de volgende geplande gebeurtenis
    $timestamp = wp_next_scheduled( tt_autopost_event_hook() );
    if ( $timestamp ) {
        wp_unschedule_event( $timestamp, tt_autopost_event_hook() );
    }
    // Laat de queue staan voor later gebruik; verwijder niet zodat heractivatie kan doorgaan
}
register_deactivation_hook( __FILE__, 'tt_autopost_deactivate' );

/**
 * Cron callback.  Publiceert het volgende denktankbericht en werkt de queue bij.
 */
function tt_autopost_cron_callback() {
    $queue = get_option( tt_autopost_queue_option(), [] );
    if ( empty( $queue ) ) {
        // Geen posts meer om te publiceren; cron taak annuleren
        $timestamp = wp_next_scheduled( tt_autopost_event_hook() );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, tt_autopost_event_hook() );
        }
        return;
    }
    // Pak de eerste post uit de queue
    $post_data = array_shift( $queue );
    // Update de queue in de database
    update_option( tt_autopost_queue_option(), $queue );
    // Stel de inhoud van het bericht samen
    $definition_intro = '<p><em>' . esc_html( THINK_TANK_CANON_AUTOBOT ) . '</em></p>';
    $content  = $definition_intro;
    $content .= '<p>' . esc_html( $post_data['content'] ) . '</p>';
    // Publiceer het bericht
    wp_insert_post( [
        'post_title'   => sanitize_text_field( $post_data['title'] ),
        'post_content' => wp_kses_post( $content ),
        'post_status'  => 'publish',
        'post_type'    => 'post',
        'post_author'  => get_current_user_id(),
    ] );
}
add_action( tt_autopost_event_hook(), 'tt_autopost_cron_callback' );

?>