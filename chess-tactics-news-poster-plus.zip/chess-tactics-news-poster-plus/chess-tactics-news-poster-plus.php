<?php
/*
 * Plugin Name: Chess Tactics News Poster Plus
 * Description: Automatisch Europese nieuwsfeeds scannen en schaaktactieken uitlichten.  Deze plugin zoekt in een reeks Europese RSS‑feeds naar trefwoorden die verband houden met veelvoorkomende schaaktechnieken zoals dubbele aanval, penning, vork, röntgenaanval, aftrekaanval en afleiding.  Als een nieuwsitem één of meer van deze trefwoorden bevat, wordt een nieuw bericht aangemaakt onder een botaccount.  Het bericht bevat een kort fragment van het nieuws, een link naar het originele artikel, een uitleg van de gevonden schaaktactiek en een speelse afsluitende opmerking.  De plugin houdt bij welke links al zijn gepubliceerd om duplicaten te voorkomen en maakt de benodigde categorieën automatisch aan bij activatie.
 * Version: 1.0.0
 * Author: SchaakBot
 * License: GPL2
 */

// Voorkom directe toegang.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Chess_Tactics_News_Poster_Plus' ) ) {

    /**
     * Kerklasse voor de schaaktactiek‑autoposter.  Deze implementatie is
     * geïnspireerd op de ODD EU News Auto Poster maar uitgebreid voor
     * schaakeducatie.  Het belangrijkste verschil is dat deze versie
     * ontbrekende categorieën automatisch aanmaakt en ook items plaatst
     * wanneer er geen specifieke tactiek wordt gevonden (ze gaan dan naar
     * de standaardcategorie ‘Uncategorized’).
     */
    class Chess_Tactics_News_Poster_Plus {

        /**
         * Cron‑hooknaam voor dit plugin­event.
         *
         * @var string
         */
        protected static $event_hook = 'chess_tactics_news_poster_plus_event';

        /**
         * Option key voor het opslaan van reeds gepubliceerde links.  Zo
         * voorkomen we dubbele berichten.
         *
         * @var string
         */
        protected static $posted_links_option = 'chess_tactics_posted_links_plus';

        /**
         * Inlognaam voor het botaccount.  Dit account krijgt de rol
         * ‘auteur’ zodat het berichten kan publiceren.
         *
         * @var string
         */
        protected static $username = 'ChessNewsBotPlus';

        /**
         * Feed‑urls om op te halen.  Voeg hier nationale of regionale
         * nieuwsfeeds toe.  De plugin doorloopt elk van deze feeds bij
         * iedere cron‑run.
         *
         * @var array
         */
        protected static $feed_urls = [
            'https://www.euronews.com/rss',
            'https://feeds.bbci.co.uk/news/world/europe/rss.xml',
            'https://www.tagesschau.de/xml/rss2',
            'https://www.lemonde.fr/rss/une.xml',
            'https://www.rtve.es/rss/noticias.xml',
            'https://www.ansa.it/sito/ansait_rss.xml',
        ];

        /**
         * Mapping van categorie‑slugs naar trefwoorden.  Elke slug staat voor
         * een schaaktechniek.  De trefwoorden worden zowel in het Nederlands
         * als in het Engels opgegeven om een zo breed mogelijk scala aan
         * nieuwsartikelen op te vangen.  Je kunt deze lijsten uitbreiden
         * afhankelijk van de nieuwsbronnen die je gebruikt.
         *
         * @var array
         */
        protected static $tactic_mapping = [
            'dubbele-aanval' => [
                'dubbele aanval', 'double attack', 'vork', 'fork', 'paardvork', 'familieschaak', 'dubbele', 'attack', 'forked'
            ],
            'penning' => [
                'penning', 'pin', 'gepend', 'absolute penning', 'relatieve penning', 'pinned'
            ],
            'vork' => [
                'vork', 'fork', 'paardvork', 'pionvork', 'forks', 'familieschaak'
            ],
            'rontgenaanval' => [
                'röntgenaanval', 'rontgenaanval', 'skewer', 'x‑ray attack', 'kopstuk', 'staartstuk', 'skewered'
            ],
            'aftrekaanval' => [
                'aftrekaanval', 'discovered attack', 'aftrekschaak', 'discovered check'
            ],
            'afleiding' => [
                'afleiding', 'decoy', 'deflection', 'lokaas', 'attraction', 'deflect'
            ],
        ];

        /**
         * Beknopte beschrijvingen van elke tactiek.  Deze tekst wordt
         * toegevoegd aan het bericht zodat lezers uitleg krijgen over wat
         * bijvoorbeeld een dubbele aanval of een penning inhoudt.
         *
         * @var array
         */
        protected static $tactic_descriptions = [
            'dubbele-aanval' => 'Een dubbele aanval is een krachtig wapen waarbij één stuk twee vijandelijke stukken tegelijk aanvalt. Dubbele aanvallen leveren vaak materiaalwinst op; typische voorbeelden zijn vorken, zoals paardvorken waarbij zowel de koning als een ander stuk worden aangevallen.',
            'penning'        => 'Een penning ontstaat wanneer een aanvallend stuk een vijandig stuk aanvalt en tegelijk een belangrijk stuk of veld daarachter bedreigt. Het aangevallen stuk staat gepend en kan niet weg zonder het achterliggende stuk bloot te stellen.',
            'vork'           => 'Een vork is een directe aanval op twee of meer vijandelijke stukken door één eigen stuk. Vooral paarden en pionnen worden gebruikt voor vorken. Een paardvork op koning en een ander stuk wordt familieschaak genoemd.',
            'rontgenaanval'  => 'Bij een röntgenaanval valt een stuk een vijandig stuk aan via een ander vijandelijk stuk; het meest waardevolle stuk staat vooraan, met een minder waardevol stuk erachter. Zodra het voorste stuk verdwijnt, valt het achterliggende doelwit.',
            'aftrekaanval'   => 'Een aftrekaanval (discovered attack) treedt op wanneer een achterliggend stuk indirect een vijandelijk stuk aanvalt. Door het voorste eigen stuk te verplaatsen, wordt de aanval direct. De verplaatsing kan zelf een dreiging creëren.',
            'afleiding'      => 'Afleiding (decoy) of deflectie is een tactiek waarbij een vijandig stuk van een belangrijk veld wordt gelokt, meestal door een offer. Het doel is het stuk van zijn verdedigende rol weg te halen. Als de koning wordt gelokt, spreekt men van attractie.',
        ];

        /**
         * Luchtige afsluitingen om de posts mee af te sluiten.  Deze zinnen
         * voegen wat humor toe aan de educatieve inhoud.
         *
         * @var array
         */
        protected static $closings = [
            'Zelfs Magnus Carlsen begon ooit met schaakpuzzels – oefen wat je geleerd hebt!',
            'Wie denkt dat schaken saai is, heeft nog nooit een mooie vork gezien.',
            'Onthoud: één slimme zet kan de hele partij veranderen.',
            'Zoals Capablanca zei: een goede speler kijkt altijd naar tactische kansen.',
            'Houd je stukken actief en je hoofd koel – strategie volgt vanzelf.',
        ];

        /**
         * Initialiseer plugin hooks: activatie, deactivatie, cron
         * planning en callback.
         */
        public static function init() {
            register_activation_hook( __FILE__, [ __CLASS__, 'activate' ] );
            register_deactivation_hook( __FILE__, [ __CLASS__, 'deactivate' ] );
            add_filter( 'cron_schedules', [ __CLASS__, 'add_fifteen_min_schedule' ] );
            add_action( self::$event_hook, [ __CLASS__, 'cron_callback' ] );
        }

        /**
         * Definieer een custom cron‑schema van 15 minuten.  WordPress heeft
         * standaard geen kwartier schema.
         *
         * @param array $schedules Bestaande cron‑schema’s.
         * @return array Aangepaste schema’s inclusief 15 minuten.
         */
        public static function add_fifteen_min_schedule( $schedules ) {
            if ( ! isset( $schedules['fifteen_minutes'] ) ) {
                $schedules['fifteen_minutes'] = [
                    'interval' => 15 * 60,
                    'display'  => __( 'Every 15 Minutes' ),
                ];
            }
            return $schedules;
        }

        /**
         * Activatiehook.  Maakt het botaccount en benodigde
         * schaakcategorieën aan, initialiseert de opslag voor geposte
         * links en plant het cron‑event in.
         */
        public static function activate() {
            self::ensure_user();
            self::ensure_categories();
            if ( false === get_option( self::$posted_links_option ) ) {
                update_option( self::$posted_links_option, [] );
            }
            if ( ! wp_next_scheduled( self::$event_hook ) ) {
                wp_schedule_event( time() + 300, 'fifteen_minutes', self::$event_hook );
            }
        }

        /**
         * Deactivatiehook: schrap het geplande cron‑event.
         */
        public static function deactivate() {
            $timestamp = wp_next_scheduled( self::$event_hook );
            if ( $timestamp ) {
                wp_unschedule_event( $timestamp, self::$event_hook );
            }
        }

        /**
         * Zorg ervoor dat het botaccount bestaat.  Indien niet, maak het
         * account aan met een willekeurig wachtwoord en rol ‘auteur’.
         *
         * @return int|false User ID bij succes, false bij fout.
         */
        protected static function ensure_user() {
            $user = get_user_by( 'login', self::$username );
            if ( $user ) {
                return $user->ID;
            }
            $user_id = wp_create_user( self::$username, wp_generate_password(), strtolower( self::$username ) . '@example.com' );
            if ( is_wp_error( $user_id ) ) {
                return false;
            }
            wp_update_user( [ 'ID' => $user_id, 'display_name' => self::$username, 'role' => 'author' ] );
            return $user_id;
        }

        /**
         * Zorg ervoor dat alle in de mapping gebruikte categorieën bestaan.
         * Als een categorie ontbreekt, maak deze dan aan met de naam die
         * correspondeert met de slug (vervang streepjes door spaties en
         * kapitaliseer eerste letter).
         */
        protected static function ensure_categories() {
            foreach ( self::$tactic_mapping as $slug => $keywords ) {
                $term = get_category_by_slug( $slug );
                if ( ! $term || is_wp_error( $term ) ) {
                    $name = ucwords( str_replace( '-', ' ', $slug ) );
                    wp_insert_category( [ 'cat_name' => $name, 'category_nicename' => $slug ] );
                }
            }
        }

        /**
         * Bepaal aan welke tactiek (categorie) een feeditem wordt gekoppeld.
         * Doorzoekt de titel en beschrijving op trefwoorden en kiest de
         * categorie met de hoogste score.  Als geen enkele trefwoord wordt
         * gevonden, retourneert het ‘uncategorized’ zodat het item toch
         * gepubliceerd wordt in de standaardcategorie.
         *
         * @param string $title       Titel van het feeditem.
         * @param string $description Omschrijving/inhoud van het item.
         * @return string Slug van de best passende categorie of ‘uncategorized’.
         */
        protected static function categorize_item( $title, $description ) {
            $text       = strtolower( wp_strip_all_tags( $title . ' ' . $description ) );
            $best_slug  = 'uncategorized';
            $best_score = 0;
            foreach ( self::$tactic_mapping as $slug => $keywords ) {
                $score = 0;
                foreach ( $keywords as $keyword ) {
                    $keyword = strtolower( $keyword );
                    if ( false !== strpos( $text, $keyword ) ) {
                        $score++;
                    }
                }
                if ( $score > $best_score ) {
                    $best_score = $score;
                    $best_slug  = $slug;
                }
            }
            return $best_score > 0 ? $best_slug : 'uncategorized';
        }

        /**
         * Stel de postdata samen voor publicatie.  Maakt een snippet uit de
         * feedinhoud, voegt de bronlink en uitleg van de tactiek toe en
         * sluit af met een luchtige opmerking.
         *
         * @param object $item        SimplePie_Item van de feed.
         * @param int    $author_id   ID van het botaccount.
         * @param int    $category_id Categorie‑ID.
         * @param string $tactic_slug Slug van de tactiek (voor uitleg).
         * @return array Associatieve array geschikt voor wp_insert_post().
         */
        protected static function build_post_data( $item, $author_id, $category_id, $tactic_slug ) {
            $item_title = wp_strip_all_tags( $item->get_title() );
            $link       = $item->get_link();
            // Verwerk content of description.
            $feed_content = '';
            if ( method_exists( $item, 'get_content' ) ) {
                $feed_content = $item->get_content();
            }
            if ( empty( $feed_content ) && method_exists( $item, 'get_description' ) ) {
                $feed_content = $item->get_description();
            }
            $feed_content = wp_strip_all_tags( $feed_content );
            $words        = preg_split( '/\s+/', $feed_content );
            $snippet      = implode( ' ', array_slice( $words, 0, 80 ) );
            // Uitleg van tactiek indien beschikbaar.
            $explanation = isset( self::$tactic_descriptions[ $tactic_slug ] ) ? self::$tactic_descriptions[ $tactic_slug ] : '';
            // Kies een willekeurige afsluiting.
            $closing = self::$closings[ array_rand( self::$closings ) ];
            $body    = [];
            $body[]  = '<p>' . esc_html( $snippet ) . '…</p>';
            $body[]  = '<p><a href="' . esc_url( $link ) . '" rel="noopener" target="_blank">Lees het volledige artikel bij de bron</a></p>';
            if ( $explanation ) {
                $body[] = '<p><strong>Over deze tactiek:</strong> ' . esc_html( $explanation ) . '</p>';
            }
            $body[] = '<p><em>' . esc_html( $closing ) . '</em></p>';
            return [
                'post_title'    => $item_title,
                'post_content'  => implode( "\n", $body ),
                'post_status'   => 'publish',
                'post_author'   => $author_id,
                'post_type'     => 'post',
                'post_category' => [ $category_id ],
            ];
        }

        /**
         * Cron‑callback: doorloopt alle feeds, zoekt naar een nieuw item
         * (op basis van link), bepaalt de categorie, genereert een post en
         * publiceert deze.  Er wordt per run slechts één bericht geplaatst
         * om spam te voorkomen.
         */
        public static function cron_callback() {
            $user_id = self::ensure_user();
            if ( ! $user_id ) {
                return;
            }
            $posted_links = get_option( self::$posted_links_option, [] );
            if ( ! function_exists( 'fetch_feed' ) ) {
                include_once ABSPATH . WPINC . '/feed.php';
            }
            foreach ( self::$feed_urls as $feed_url ) {
                $feed = fetch_feed( $feed_url );
                if ( is_wp_error( $feed ) ) {
                    continue;
                }
                $max   = $feed->get_item_quantity( 5 );
                $items = $feed->get_items( 0, $max );
                foreach ( $items as $item ) {
                    $link = $item->get_link();
                    if ( empty( $link ) ) {
                        continue;
                    }
                    if ( in_array( $link, $posted_links, true ) ) {
                        continue;
                    }
                    // Bepaal tactiek op basis van trefwoorden.
                    $slug = self::categorize_item( $item->get_title(), $item->get_description() );
                    // Zoek de categorie; indien niet gevonden gebruik 'uncategorized' (ID = 1).
                    $category_id = 1;
                    if ( 'uncategorized' !== $slug ) {
                        $category = get_category_by_slug( $slug );
                        if ( $category && ! is_wp_error( $category ) ) {
                            $category_id = (int) $category->term_id;
                        }
                    }
                    // Bouw en voer post in.
                    $post_data = self::build_post_data( $item, $user_id, $category_id, $slug );
                    $post_id   = wp_insert_post( $post_data );
                    if ( is_wp_error( $post_id ) ) {
                        continue;
                    }
                    // Stel een willekeurige uitgelichte afbeelding in indien beschikbaar.
                    $attachments = get_posts( [
                        'post_type'      => 'attachment',
                        'post_mime_type' => 'image',
                        'posts_per_page' => 1,
                        'orderby'        => 'rand',
                    ] );
                    if ( ! empty( $attachments ) ) {
                        $attachment_id = $attachments[0]->ID;
                        if ( function_exists( 'set_post_thumbnail' ) ) {
                            set_post_thumbnail( $post_id, $attachment_id );
                        } else {
                            update_post_meta( $post_id, '_thumbnail_id', $attachment_id );
                        }
                    }
                    // Registreer de link en beperk de lengte tot de laatste 200.
                    $posted_links[] = $link;
                    if ( count( $posted_links ) > 200 ) {
                        $posted_links = array_slice( $posted_links, -200 );
                    }
                    update_option( self::$posted_links_option, $posted_links );
                    return; // Plaats slechts één bericht per run.
                }
            }
        }
    }
    // Initialise de plugin na definitie.
    Chess_Tactics_News_Poster_Plus::init();
}