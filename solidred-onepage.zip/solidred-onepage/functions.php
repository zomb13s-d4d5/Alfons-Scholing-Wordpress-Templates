<?php
if (!defined('ABSPATH')) {
    exit;
}

function solidred_onepage_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'height'      => 160,
        'width'       => 160,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    add_theme_support('custom-header');
    add_theme_support('custom-background');
    add_theme_support('menus');
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'solidred-onepage'),
    ));
}
add_action('after_setup_theme', 'solidred_onepage_setup');

function solidred_onepage_enqueue_assets() {
    wp_enqueue_style(
        'solidred-onepage-style',
        get_stylesheet_uri(),
        array(),
        wp_get_theme()->get('Version')
    );

    wp_enqueue_script(
        'solidred-onepage-script',
        get_template_directory_uri() . '/assets/js/theme.js',
        array(),
        wp_get_theme()->get('Version'),
        true
    );

    wp_localize_script('solidred-onepage-script', 'solidRedTheme', array(
        'swipeThreshold' => 45,
    ));
}
add_action('wp_enqueue_scripts', 'solidred_onepage_enqueue_assets');

function solidred_onepage_body_classes($classes) {
    $classes[] = 'solidred-onepage-theme';
    return $classes;
}
add_filter('body_class', 'solidred_onepage_body_classes');

function solidred_onepage_trim_excerpt($text = '', $length = 18) {
    $text = wp_strip_all_tags(strip_shortcodes($text));
    $words = preg_split('/\s+/', trim($text));

    if (count($words) <= $length) {
        return $text;
    }

    return implode(' ', array_slice($words, 0, $length)) . '…';
}
