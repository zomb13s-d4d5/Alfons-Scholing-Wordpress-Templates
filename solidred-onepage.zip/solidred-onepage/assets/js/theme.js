(() => {
  const menuToggle = document.querySelector('.sr-menu-toggle');
  const overlay = document.querySelector('.sr-overlay');
  const closeButton = document.querySelector('.sr-overlay__close');
  const focusableSelector = 'a, button, input, textarea, select, [tabindex]:not([tabindex="-1"])';
  let lastFocused = null;

  const openMenu = () => {
    if (!overlay || !menuToggle) return;
    lastFocused = document.activeElement;
    overlay.hidden = false;
    requestAnimationFrame(() => overlay.classList.add('is-open'));
    menuToggle.setAttribute('aria-expanded', 'true');
    const firstFocusable = overlay.querySelector(focusableSelector);
    if (firstFocusable) firstFocusable.focus();
    document.body.style.overflow = 'hidden';
  };

  const closeMenu = () => {
    if (!overlay || !menuToggle) return;
    overlay.classList.remove('is-open');
    menuToggle.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
    window.setTimeout(() => {
      overlay.hidden = true;
      if (lastFocused) lastFocused.focus();
    }, 240);
  };

  if (menuToggle && overlay && closeButton) {
    menuToggle.addEventListener('click', openMenu);
    closeButton.addEventListener('click', closeMenu);

    overlay.addEventListener('click', (event) => {
      if (event.target === overlay) closeMenu();
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && overlay.classList.contains('is-open')) {
        closeMenu();
      }
    });
  }

  const slider = document.querySelector('[data-slider]');
  if (!slider) return;

  const track = slider.querySelector('[data-slider-track]');
  const prevButton = slider.querySelector('[data-slider-prev]');
  const nextButton = slider.querySelector('[data-slider-next]');
  const cards = Array.from(track.children);
  let index = 0;
  let perView = 3;
  let startX = 0;
  let deltaX = 0;

  const getPerView = () => {
    if (window.matchMedia('(max-width: 782px)').matches) return 1;
    if (window.matchMedia('(max-width: 1080px)').matches) return 2;
    return 3;
  };

  const getMaxIndex = () => Math.max(0, cards.length - perView);

  const updateSlider = () => {
    perView = getPerView();
    const cardWidth = cards[0] ? cards[0].getBoundingClientRect().width : 0;
    const style = window.getComputedStyle(track);
    const gap = parseFloat(style.columnGap || style.gap || 0);
    const offset = index * (cardWidth + gap);
    track.style.transform = `translate3d(${-offset}px,0,0)`;

    if (prevButton) prevButton.disabled = index <= 0;
    if (nextButton) nextButton.disabled = index >= getMaxIndex();
  };

  const goNext = () => {
    index = Math.min(index + 1, getMaxIndex());
    updateSlider();
  };

  const goPrev = () => {
    index = Math.max(index - 1, 0);
    updateSlider();
  };

  if (prevButton) prevButton.addEventListener('click', goPrev);
  if (nextButton) nextButton.addEventListener('click', goNext);

  const swipeThreshold = (window.solidRedTheme && window.solidRedTheme.swipeThreshold) || 45;
  const viewport = slider.querySelector('.sr-slider__viewport');

  if (viewport) {
    viewport.addEventListener('touchstart', (event) => {
      startX = event.changedTouches[0].clientX;
      deltaX = 0;
    }, { passive: true });

    viewport.addEventListener('touchmove', (event) => {
      deltaX = event.changedTouches[0].clientX - startX;
    }, { passive: true });

    viewport.addEventListener('touchend', () => {
      if (Math.abs(deltaX) < swipeThreshold) return;
      if (deltaX < 0) goNext();
      if (deltaX > 0) goPrev();
    });
  }

  window.addEventListener('resize', () => {
    index = Math.min(index, getMaxIndex());
    updateSlider();
  });

  updateSlider();
})();
