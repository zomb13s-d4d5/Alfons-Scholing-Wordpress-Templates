Solid Red OnePage WordPress Theme

Installation
1. Upload the ZIP in WordPress via Appearance > Themes > Add New > Upload Theme.
2. Activate the theme.
3. Set your Site Title, Tagline, and Site Icon in Settings / Customizer.
4. Assign a menu to the Primary Menu location.
5. Publish posts. The latest posts appear in the bottom-right slider automatically.

Included
- Portrait background image for upright iPad / iPhone layout
- Landscape background image for rotated iPad / desktop layout
- Popup navigation overlay
- Responsive latest-post slider with touch swipe support
- iOS safe-area spacing using env(safe-area-inset-*)
- One-screen no-scroll composition

Notes
- The homepage is designed as a single-screen theme.
- Internal overlays can scroll if the menu content becomes long.
- Featured images improve the article slider visually.
