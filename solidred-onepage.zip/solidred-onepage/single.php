<?php
if (!defined('ABSPATH')) {
    exit;
}

$site_name        = get_bloginfo('name') ?: 'Solid Red';
$site_description = get_bloginfo('description') ?: __('Subtitle', 'solidred-onepage');
$site_icon_url    = get_site_icon_url(192);
$portrait_bg      = get_template_directory_uri() . '/assets/images/background-portrait.png';
$landscape_bg     = get_template_directory_uri() . '/assets/images/background-landscape.png';
$all_articles_link = get_permalink(get_option('page_for_posts')) ?: home_url('/');
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="sr-site-shell" style="--sr-bg-portrait: url('<?php echo esc_url($portrait_bg); ?>'); --sr-bg-landscape: url('<?php echo esc_url($landscape_bg); ?>');">
    <div class="sr-bg" aria-hidden="true">
        <div class="sr-bg-shade"></div>
        <div class="sr-bg-noise"></div>
    </div>

    <div class="sr-stage">
        <header class="sr-topbar">
            <a class="sr-brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php echo esc_attr($site_name); ?>">
                <div class="sr-brand__icon">
                    <?php if ($site_icon_url) : ?>
                        <img src="<?php echo esc_url($site_icon_url); ?>" alt="<?php echo esc_attr($site_name); ?>">
                    <?php else : ?>
                        <span class="sr-brand__icon-fallback"><?php echo esc_html(mb_strtoupper(mb_substr($site_name, 0, 2))); ?></span>
                    <?php endif; ?>
                </div>
                <div class="sr-brand__panel">
                    <div class="sr-brand__title-wrap">
                        <div class="sr-brand__title"><?php echo esc_html($site_name); ?></div>
                    </div>
                    <div class="sr-brand__subtitle"><?php echo esc_html($site_description); ?></div>
                </div>
            </a>

            <button class="sr-menu-toggle" type="button" aria-expanded="false" aria-controls="sr-menu-overlay">
                <span aria-hidden="true"></span>
                <span class="screen-reader-text"><?php esc_html_e('Open menu', 'solidred-onepage'); ?></span>
            </button>
        </header>

        <main class="sr-article-main">
            <div class="sr-article-wrap">
                <a class="sr-article-back" href="<?php echo esc_url($all_articles_link); ?>">&#8249; <?php esc_html_e('Back to articles', 'solidred-onepage'); ?></a>
                <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                    <article <?php post_class('sr-article'); ?>>
                        <p class="sr-article-meta"><?php echo esc_html(get_the_date()); ?></p>
                        <h1 class="sr-article-title"><?php the_title(); ?></h1>

                        <?php if (has_post_thumbnail()) : ?>
                            <figure class="sr-article-thumb">
                                <?php the_post_thumbnail('large'); ?>
                            </figure>
                        <?php endif; ?>

                        <div class="sr-article-content">
                            <?php the_content(); ?>
                        </div>

                        <nav class="sr-article-nav" aria-label="<?php esc_attr_e('Post navigation', 'solidred-onepage'); ?>">
                            <div><?php previous_post_link('%link', '&#8249; %title'); ?></div>
                            <div><?php next_post_link('%link', '%title &#8250;'); ?></div>
                        </nav>
                    </article>
                <?php endwhile; endif; ?>
            </div>
        </main>

        <footer class="sr-footer">
            <div class="sr-footer__copyright">&copy; <?php echo esc_html(date_i18n('Y')); ?> <?php echo esc_html($site_name); ?></div>
        </footer>
    </div>

    <aside class="sr-overlay" id="sr-menu-overlay" hidden>
        <div class="sr-overlay__panel" role="dialog" aria-modal="true" aria-labelledby="sr-overlay-title">
            <div class="sr-overlay__header">
                <h2 class="sr-overlay__title" id="sr-overlay-title"><?php esc_html_e('Navigation', 'solidred-onepage'); ?></h2>
                <button class="sr-overlay__close" type="button" aria-label="<?php esc_attr_e('Close menu', 'solidred-onepage'); ?>">&#10005;</button>
            </div>

            <nav aria-label="<?php esc_attr_e('Primary menu', 'solidred-onepage'); ?>">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'container'      => false,
                    'fallback_cb'    => function () {
                        echo '<ul>';
                        echo '<li><a href="' . esc_url(home_url('/')) . '">' . esc_html__('Home', 'solidred-onepage') . '</a></li>';
                        echo '<li><a href="' . esc_url($all_articles_link) . '">' . esc_html__('Articles', 'solidred-onepage') . '</a></li>';
                        echo '</ul>';
                    },
                ));
                ?>
            </nav>
        </div>
    </aside>
</div>
<?php wp_footer(); ?>
</body>
</html>
