<?php
if (!defined('ABSPATH')) {
    exit;
}

$site_name        = get_bloginfo('name') ?: 'Solid Red';
$site_description = get_bloginfo('description') ?: __('Subtitle', 'solidred-onepage');
$site_icon_url    = get_site_icon_url(192);
$portrait_bg      = get_template_directory_uri() . '/assets/images/background-portrait.png';
$landscape_bg     = get_template_directory_uri() . '/assets/images/background-landscape.png';

$latest_posts = new WP_Query(array(
    'post_type'           => 'post',
    'posts_per_page'      => 8,
    'ignore_sticky_posts' => true,
    'post_status'         => 'publish',
));

$all_articles_link = get_permalink(get_option('page_for_posts'));
if (!$all_articles_link) {
    $all_articles_link = home_url('/');
}
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="sr-site-shell" style="--sr-bg-portrait: url('<?php echo esc_url($portrait_bg); ?>'); --sr-bg-landscape: url('<?php echo esc_url($landscape_bg); ?>');">
    <div class="sr-bg" aria-hidden="true">
        <div class="sr-bg-shade"></div>
        <div class="sr-bg-noise"></div>
    </div>

    <div class="sr-stage">
        <header class="sr-topbar">
            <a class="sr-brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php echo esc_attr($site_name); ?>">
                <div class="sr-brand__icon">
                    <?php if ($site_icon_url) : ?>
                        <img src="<?php echo esc_url($site_icon_url); ?>" alt="<?php echo esc_attr($site_name); ?>">
                    <?php else : ?>
                        <span class="sr-brand__icon-fallback"><?php echo esc_html(mb_strtoupper(mb_substr($site_name, 0, 2))); ?></span>
                    <?php endif; ?>
                </div>

                <div class="sr-brand__panel">
                    <div class="sr-brand__title-wrap">
                        <h1 class="sr-brand__title"><?php echo esc_html($site_name); ?></h1>
                    </div>
                    <div class="sr-brand__subtitle"><?php echo esc_html($site_description); ?></div>
                </div>
            </a>

            <button class="sr-menu-toggle" type="button" aria-expanded="false" aria-controls="sr-menu-overlay">
                <span aria-hidden="true"></span>
                <span class="screen-reader-text"><?php esc_html_e('Open menu', 'solidred-onepage'); ?></span>
            </button>
        </header>

        <main class="sr-main">
            <section class="sr-slider-zone" aria-label="<?php esc_attr_e('Latest articles', 'solidred-onepage'); ?>">
                <div class="sr-slider" data-slider>
                    <button class="sr-slider__arrow sr-slider__arrow--prev" type="button" data-slider-prev aria-label="<?php esc_attr_e('Previous articles', 'solidred-onepage'); ?>">&#8249;</button>
                    <button class="sr-slider__arrow sr-slider__arrow--next" type="button" data-slider-next aria-label="<?php esc_attr_e('Next articles', 'solidred-onepage'); ?>">&#8250;</button>

                    <div class="sr-slider__viewport">
                        <div class="sr-slider__track" data-slider-track>
                            <?php if ($latest_posts->have_posts()) : ?>
                                <?php while ($latest_posts->have_posts()) : $latest_posts->the_post(); ?>
                                    <article class="sr-card">
                                        <a href="<?php the_permalink(); ?>" class="sr-card__thumb" aria-label="<?php the_title_attribute(); ?>">
                                            <?php if (has_post_thumbnail()) : ?>
                                                <?php the_post_thumbnail('medium_large'); ?>
                                            <?php endif; ?>
                                        </a>
                                        <div class="sr-card__body">
                                            <h2 class="sr-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                            <p class="sr-card__excerpt"><?php echo esc_html(solidred_onepage_trim_excerpt(get_the_excerpt() ?: get_the_content(), 18)); ?></p>
                                        </div>
                                    </article>
                                <?php endwhile; ?>
                                <?php wp_reset_postdata(); ?>
                            <?php else : ?>
                                <?php for ($i = 1; $i <= 3; $i++) : ?>
                                    <article class="sr-card">
                                        <div class="sr-card__thumb"></div>
                                        <div class="sr-card__body">
                                            <h2 class="sr-card__title"><?php echo esc_html(sprintf(__('Latest article %d', 'solidred-onepage'), $i)); ?></h2>
                                            <p class="sr-card__excerpt"><?php esc_html_e('Publish posts in WordPress and they will appear here automatically.', 'solidred-onepage'); ?></p>
                                        </div>
                                    </article>
                                <?php endfor; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="sr-slider__footer">
                        <a class="sr-more-link" href="<?php echo esc_url($all_articles_link); ?>">
                            <?php esc_html_e('More', 'solidred-onepage'); ?> <span aria-hidden="true">&#8250;&#8250;</span>
                        </a>
                    </div>
                </div>
            </section>
        </main>

        <footer class="sr-footer">
            <div class="sr-footer__copyright">
                &copy; <?php echo esc_html(date_i18n('Y')); ?> <?php echo esc_html($site_name); ?>
            </div>
        </footer>
    </div>

    <aside class="sr-overlay" id="sr-menu-overlay" hidden>
        <div class="sr-overlay__panel" role="dialog" aria-modal="true" aria-labelledby="sr-overlay-title">
            <div class="sr-overlay__header">
                <h2 class="sr-overlay__title" id="sr-overlay-title"><?php esc_html_e('Navigation', 'solidred-onepage'); ?></h2>
                <button class="sr-overlay__close" type="button" aria-label="<?php esc_attr_e('Close menu', 'solidred-onepage'); ?>">&#10005;</button>
            </div>

            <nav aria-label="<?php esc_attr_e('Primary menu', 'solidred-onepage'); ?>">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'container'      => false,
                    'fallback_cb'    => function () {
                        echo '<ul>';
                        echo '<li><a href="' . esc_url(home_url('/')) . '">' . esc_html__('Home', 'solidred-onepage') . '</a></li>';
                        echo '<li><a href="' . esc_url(home_url('/category/articles/')) . '">' . esc_html__('Articles', 'solidred-onepage') . '</a></li>';
                        echo '<li><a href="' . esc_url(home_url('/category/news/')) . '">' . esc_html__('News', 'solidred-onepage') . '</a></li>';
                        echo '<li><a href="' . esc_url(home_url('/category/editorial/')) . '">' . esc_html__('Editorial', 'solidred-onepage') . '</a></li>';
                        echo '<li><a href="' . esc_url(home_url('/contact/')) . '">' . esc_html__('Contact', 'solidred-onepage') . '</a></li>';
                        echo '</ul>';
                    },
                ));
                ?>
            </nav>

            <div class="sr-overlay__articles">
                <h3><?php esc_html_e('Recent articles', 'solidred-onepage'); ?></h3>
                <div class="sr-overlay__article-list">
                    <?php
                    $recent_menu_posts = new WP_Query(array(
                        'post_type'           => 'post',
                        'posts_per_page'      => 6,
                        'ignore_sticky_posts' => true,
                        'post_status'         => 'publish',
                    ));
                    ?>
                    <?php if ($recent_menu_posts->have_posts()) : ?>
                        <?php while ($recent_menu_posts->have_posts()) : $recent_menu_posts->the_post(); ?>
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        <?php endwhile; ?>
                        <?php wp_reset_postdata(); ?>
                    <?php else : ?>
                        <a href="<?php echo esc_url(admin_url('post-new.php')); ?>"><?php esc_html_e('Create your first article', 'solidred-onepage'); ?></a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </aside>
</div>
<?php wp_footer(); ?>
</body>
</html>
