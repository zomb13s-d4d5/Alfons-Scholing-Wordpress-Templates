=== One Snack A Day — Democratic Pedagogy Auto-Poster ===
Contributors: osad, notyouagain, chatgpt
Tags: education, news, media literacy, autopost, democratic pedagogy, eu
Requires at least: 5.8
Tested up to: 6.6
Stable tag: 1.1.0
License: GPLv2 or later

EU‑wide news autoposter with democratic pedagogy framing. Scans official national/public-service RSS feeds, flags Red/Green by child-safe triggers, adds light-hearted family prompts, and posts every 15 minutes with Media Library images.

== Highlights ==
- **No backend terminal needed:** auto‑configured on activation.
- **EU‑wide feeds preloaded:** BBC/ARD/ZDF/NOS/VRT/RTBF/RAI/RTVE/RTÉ/SVT/DR/NRK/Yle/RTP/ORF/SRF/ERR/LRT/LSM/TVP/etc., plus EU Commission/Council and Euronews.
- **Democratic pedagogy built‑in:** “Talk it out” prompts, open comments (optional), child‑safe excerpts.
- **Red→Guided Discussion:** by default, Red flags go to the “Guided Discussion” category created on activation.
- **Images:** random pick from your Media Library as Featured Image.
- **Schedule:** every 15 minutes via WP‑Cron (add real cron for precision).

== Install ==
1) Upload ZIP via Plugins → Add New → Upload Plugin.  
2) Activate. Categories “News & Snacks” and “Guided Discussion” are created if missing.  
3) Settings → OSAD Auto‑Poster to review feeds/options.

== Changelog ==
= 1.1.0 =
- Expanded EU feed list
- Child‑safe mode and open‑comments option
- Auto‑create default categories
- Improved language detection & tagging
