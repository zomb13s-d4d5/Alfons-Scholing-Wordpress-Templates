<?php
/**
 * Plugin Name: One Snack A Day — Democratic Pedagogy Auto-Poster
 * Description: EU-wide news autoposter with democratic pedagogy framing. Scans official national/public-service RSS feeds, flags Red/Green by child-safe triggers, adds light-hearted family prompts, and posts every 15 minutes with Media Library images.
 * Version: 1.1.0
 * Author: NotYouAgain Studios (Alfons Scholing) + ChatGPT
 * License: GPLv2 or later
 * Text Domain: osad-dem-ped
 */

if (!defined('ABSPATH')) exit;

class OSAD_DemPed_AutoPoster {
  const OPTION       = 'osad_dem_ped_options';
  const SEEN_OPTION  = 'osad_dem_ped_seen';
  const CRON_HOOK    = 'osad_autopost_event';
  const TAX_LANG_TAG = 'osad_lang_tag';

  public function __construct(){
    add_filter('cron_schedules', [$this,'add_cron_schedule']);
    register_activation_hook(__FILE__, [$this, 'on_activate']);
    register_deactivation_hook(__FILE__, [$this, 'on_deactivate']);
    add_action(self::CRON_HOOK, [$this,'run_autopost']);
    add_action('admin_menu', [$this,'admin_menu']);
    add_action('admin_init', [$this,'register_settings']);
  }

  /** 15-minute schedule */
  public function add_cron_schedule($schedules){
    $schedules['fifteen_minutes'] = ['interval'=>15*60,'display'=>__('Every 15 Minutes','osad-dem-ped')];
    return $schedules;
  }

  /** Activation: seed options, schedule, create default categories if missing */
  public function on_activate(){
    $opts = get_option(self::OPTION, []);
    if (empty($opts)){
      $guided_cat_id = $this->ensure_category('Guided Discussion');
      $news_cat_id   = $this->ensure_category('News & Snacks');
      $opts = [
        'feeds'            => implode("\n", $this->default_feeds()),
        'max_per_run'      => 4,
        'category'         => $news_cat_id,
        'post_status'      => 'publish',
        'language_tags'    => 1,
        'red_visibility'   => 'guided', // send Red to Guided Discussion
        'guided_category'  => $guided_cat_id,
        'tags'             => 'Media Literacy,Democratic Pedagogy,Green Flag,Red Flag',
        'child_safe_mode'  => 1, // remove strong terms from excerpts
        'enable_comments'  => 1  // keep discussion open (student/parent voice)
      ];
      add_option(self::OPTION, $opts);
    }
    if (!wp_next_scheduled(self::CRON_HOOK)){
      wp_schedule_event(time(), 'fifteen_minutes', self::CRON_HOOK);
    }
  }

  public function on_deactivate(){
    $ts = wp_next_scheduled(self::CRON_HOOK);
    if ($ts) wp_unschedule_event($ts, self::CRON_HOOK);
  }

  /** Admin */
  public function admin_menu(){
    add_options_page(__('OSAD Auto-Poster','osad-dem-ped'),__('OSAD Auto-Poster','osad-dem-ped'),'manage_options','osad-dem-ped',[$this,'settings_page']);
  }
  public function register_settings(){
    register_setting('osad_dem_ped_group', self::OPTION, [$this,'sanitize_options']);
    add_settings_section('osad_main', __('Main Settings','osad-dem-ped'), function(){
      echo '<p>'.esc_html__('EU-wide democratic-pedagogy autoposter. Runs every 15 minutes.','osad-dem-ped').'</p>';
    }, 'osad-dem-ped');

    add_settings_field('feeds', __('RSS Feeds (one per line)','osad-dem-ped'), [$this,'field_feeds'],'osad-dem-ped','osad_main');
    add_settings_field('max_per_run', __('Max posts per run','osad-dem-ped'), [$this,'field_max_per_run'],'osad-dem-ped','osad_main');
    add_settings_field('category', __('Default Category','osad-dem-ped'), [$this,'field_category'],'osad-dem-ped','osad_main');
    add_settings_field('guided_category', __('Guided Discussion Category (for Red)','osad-dem-ped'), [$this,'field_guided_category'],'osad-dem-ped','osad_main');
    add_settings_field('red_visibility', __('Red-Flag handling','osad-dem-ped'), [$this,'field_red_visibility'],'osad-dem-ped','osad_main');
    add_settings_field('tags', __('Default Tags','osad-dem-ped'), [$this,'field_tags'],'osad-dem-ped','osad_main');
    add_settings_field('language_tags', __('Add language code tag','osad-dem-ped'), [$this,'field_language_tags'],'osad-dem-ped','osad_main');
    add_settings_field('child_safe_mode', __('Child-safe excerpts (soften strong wording)','osad-dem-ped'), [$this,'field_child_safe'],'osad-dem-ped','osad_main');
    add_settings_field('enable_comments', __('Enable comments on posts','osad-dem-ped'), [$this,'field_comments'],'osad-dem-ped','osad_main');
  }
  public function sanitize_options($in){
    $out = [];
    $out['feeds'] = wp_kses_post($in['feeds'] ?? '');
    $out['max_per_run'] = max(1, intval($in['max_per_run'] ?? 4));
    $out['category'] = intval($in['category'] ?? 0);
    $out['guided_category'] = intval($in['guided_category'] ?? 0);
    $rv = $in['red_visibility'] ?? 'guided';
    $out['red_visibility'] = in_array($rv, ['public','guided']) ? $rv : 'guided';
    $out['tags'] = sanitize_text_field($in['tags'] ?? '');
    $out['language_tags'] = !empty($in['language_tags']) ? 1 : 0;
    $out['child_safe_mode'] = !empty($in['child_safe_mode']) ? 1 : 0;
    $out['enable_comments'] = !empty($in['enable_comments']) ? 1 : 0;
    return $out;
  }

  /** Fields */
  private function get_opts(){ return get_option(self::OPTION, []); }
  public function field_feeds(){ $o=$this->get_opts(); printf('<textarea name="%s[feeds]" rows="14" style="width:100%%">%s</textarea>', self::OPTION, esc_textarea($o['feeds'] ?? '')); }
  public function field_max_per_run(){ $o=$this->get_opts(); printf('<input type="number" min="1" name="%s[max_per_run]" value="%d" />', self::OPTION, intval($o['max_per_run'] ?? 4)); }
  public function field_category(){ $o=$this->get_opts(); wp_dropdown_categories(['show_option_all'=>__('— None —','osad-dem-ped'),'name'=>self::OPTION.'[category]','hide_empty'=>0,'selected'=>intval($o['category'] ?? 0)]); }
  public function field_guided_category(){ $o=$this->get_opts(); wp_dropdown_categories(['show_option_all'=>__('— None —','osad-dem-ped'),'name'=>self::OPTION.'[guided_category]','hide_empty'=>0,'selected'=>intval($o['guided_category'] ?? 0)]); }
  public function field_red_visibility(){ $o=$this->get_opts(); $val=$o['red_visibility'] ?? 'guided';
    echo '<label><input type="radio" name="'.self::OPTION.'[red_visibility]" value="public" '.checked($val,'public',false).'/> '.__('Public (default category)','osad-dem-ped').'</label><br/>';
    echo '<label><input type="radio" name="'.self::OPTION.'[red_visibility]" value="guided" '.checked($val,'guided',false).'/> '.__('Send to Guided Discussion','osad-dem-ped').'</label>';
  }
  public function field_tags(){ $o=$this->get_opts(); printf('<input type="text" style="width:100%%" name="%s[tags]" value="%s" />', self::OPTION, esc_attr($o['tags'] ?? '')); }
  public function field_language_tags(){ $o=$this->get_opts(); printf('<label><input type="checkbox" name="%s[language_tags]" value="1" %s /> %s</label>', self::OPTION, checked(!empty($o['language_tags']), true,false), esc_html__('Tag posts with [lang:xx]','osad-dem-ped')); }
  public function field_child_safe(){ $o=$this->get_opts(); printf('<label><input type="checkbox" name="%s[child_safe_mode]" value="1" %s /> %s</label>', self::OPTION, checked(!empty($o['child_safe_mode']), true,false), esc_html__('Reduce intensity of excerpts','osad-dem-ped')); }
  public function field_comments(){ $o=$this->get_opts(); printf('<label><input type="checkbox" name="%s[enable_comments]" value="1" %s /> %s</label>', self::OPTION, checked(!empty($o['enable_comments']), true,false), esc_html__('Open comments to invite student/parent voice','osad-dem-ped')); }

  public function settings_page(){
    echo '<div class="wrap"><h1>'.esc_html__('One Snack A Day — Auto-Poster','osad-dem-ped').'</h1>';
    echo '<form method="post" action="options.php">';
    settings_fields('osad_dem_ped_group'); do_settings_sections('osad-dem-ped'); submit_button();
    echo '</form>';
    echo '<p><em>'.esc_html__('Tip: For exact timing, add a server cron to ping wp-cron.php every minute.','osad-dem-ped').'</em></p>';
    echo '</div>';
  }

  /** Runner */
  public function run_autopost(){
    $opts = $this->get_opts();
    $feeds = $this->parse_feeds($opts['feeds'] ?? '');
    if (empty($feeds)) $feeds = $this->default_feeds();
    $max   = intval($opts['max_per_run'] ?? 4);
    $posted = 0;

    require_once ABSPATH . WPINC . '/feed.php';
    foreach ($feeds as $feed_url){
      if ($posted >= $max) break;
      $feed = fetch_feed($feed_url);
      if (is_wp_error($feed)) continue;
      $maxitems = $feed->get_item_quantity(10);
      $items = $feed->get_items(0,$maxitems);
      if (!$items) continue;

      foreach ($items as $item){
        if ($posted >= $max) break;
        $guid = $item->get_id(true);
        if ($this->is_seen($guid)) continue;

        $title = wp_strip_all_tags($item->get_title());
        $content = $item->get_content();
        $link = esc_url_raw($item->get_link());
        $lang = $this->detect_language($title.' '.$this->strip_html($content));

        $class = $this->classify($title, $content, $lang);
        $remark = $this->generate_remark($class, $title, $link, $lang);

        $cat_id = intval($opts['category'] ?? 0);
        if ($class['label']==='Red' && ($opts['red_visibility'] ?? 'guided')==='guided' && !empty($opts['guided_category'])){
          $cat_id = intval($opts['guided_category']);
        }

        $tags = $this->normalize_tags($opts['tags'] ?? '');
        if (!empty($opts['language_tags']) && $lang) $tags[] = '[lang:'.$lang.']';

        $postarr = [
          'post_title'   => $this->truncate($title, 110),
          'post_content' => $this->build_post_content($title, $link, $content, $remark, $class, !empty($opts['child_safe_mode'])),
          'post_status'  => $opts['post_status'] ?? 'publish',
          'post_category'=> $cat_id ? [$cat_id] : [],
          'tags_input'   => $tags,
          'comment_status'=> !empty($opts['enable_comments']) ? 'open' : 'closed'
        ];

        $post_id = wp_insert_post($postarr, true);
        if (!is_wp_error($post_id)){
          $this->attach_random_featured_image($post_id);
          add_post_meta($post_id, '_osad_source_link', esc_url_raw($link), true);
          add_post_meta($post_id, '_osad_classification', $class['label'], true);
          $this->mark_seen($guid);
          $posted++;
        }
      }
    }
  }

  /** Helpers */
  private function ensure_category($name){
    $c = get_term_by('name', $name, 'category');
    if ($c && !is_wp_error($c)) return intval($c->term_id);
    $new = wp_insert_term($name, 'category');
    if (!is_wp_error($new)) return intval($new['term_id']);
    return 0;
  }
  private function parse_feeds($txt){
    $arr = array_filter(array_map('trim', explode("\n", (string)$txt)));
    return array_values(array_filter($arr, function($u){ return filter_var($u, FILTER_VALIDATE_URL); }));
  }

  private function default_feeds(){
    // Expanded EU/EEA national public-service feeds (edit as needed)
    return [
      // EU/EEA public broadcasters & gov news portals
      'https://www.bbc.co.uk/news/rss.xml', // UK
      'https://feeds.skynews.com/feeds/rss/home.xml', // UK alt
      'https://feeds.bbci.co.uk/news/world/europe/rss.xml',

      'https://www.nos.nl/nieuws/archief/rss.xml', // NL (NOS)
      'https://rss.omroep.nl/nos/nieuws', // NL alt (if available)
      'https://www.vrt.be/vrtnws/nl.rss.headlines.xml', // BE (VRT NWS)
      'https://www.rtbf.be/rss', // BE (RTBF)

      'https://www.tagesschau.de/xml/rss2', // DE (ARD)
      'https://www.zdf.de/rss/zdf/nachrichten', // DE (ZDF)

      'https://www.francetvinfo.fr/titres.rss', // FR (Franceinfo)
      'https://www.rfi.fr/fr/rss', // FR (RFI)

      'https://www.rte.ie/feeds/rss/?index=/news', // IE
      'https://www.irishtimes.com/cmlink/news-1.1319192', // IE alt

      'https://www.rtve.es/rss/temas/sociedad.xml', // ES (RTVE)
      'https://e00-elmundo.uecdn.es/elmundo/rss/espana.xml', // ES alt

      'https://www.rainews.it/dl/rainews/TGR/regioni/regioni.html?rss', // IT (RAI)
      'https://www.ansa.it/sito/ansait_rss.xml', // IT alt

      'https://www.svt.se/nyheter/rss.xml', // SE
      'https://www.dr.dk/nyheder/service/feeds/allenyheder', // DK
      'https://www.nrk.no/toppsaker.rss', // NO
      'https://yle.fi/uutiset/rss/uutiset.rss', // FI
      'https://www.rtp.pt/noticias/rss', // PT
      'https://www.orf.at/rss', // AT
      'https://www.srf.ch/news/bnf/rss', // CH (SRF)

      'https://www.hrt.hr/rss', // HR
      'https://www.bnt.bg/rss', // BG
      'https://tvp.info/rss', // PL
      'https://polskieradio24.pl/podcastfeed', // PL alt
      'https://www.err.ee/rss', // EE
      'https://www.lrt.lt/rss', // LT
      'https://www.lsm.lv/rss', // LV
      'https://www.ct24.cz/rss/hlavni-zpravy', // CZ
      'https://www.rtvs.sk/rss', // SK
      'https://www.mrt.com.mk/rss', // MK
      'https://www.rts.rs/rss', // RS
      'https://www.bta.bg/en/rss', // BG agency alt
      'https://www.mdr.de/nachrichten/sachsen-anhalt/index.rss', // DE regional example
      'https://feeds.thelocal.com/rss/se', // SE English

      'https://www.euronews.com/rss?level=theme&name=news', // Pan-Europe
      'https://www.politico.eu/feed/', // EU politics (editorial)
      'https://www.consilium.europa.eu/en/press/press-releases/_rss', // EU Council press
      'https://ec.europa.eu/commission/presscorner/home/en/rss.xml' // EU Commission press
    ];
  }

  private function is_seen($guid){
    $seen = get_option(self::SEEN_OPTION, []);
    return !empty($seen[$guid]);
  }
  private function mark_seen($guid){
    $seen = get_option(self::SEEN_OPTION, []);
    $seen[$guid] = time();
    if (count($seen) > 3000){
      asort($seen);
      $seen = array_slice($seen, -2000, null, true);
    }
    update_option(self::SEEN_OPTION, $seen, false);
  }

  private function strip_html($html){ return wp_strip_all_tags( wp_specialchars_decode( (string)$html ) ); }
  private function truncate($txt,$len){ return (mb_strlen($txt)<=$len)?$txt:mb_substr($txt,0,$len-1).'…'; }

  private function soften_text($t){
    // Very light softening for child-safe mode
    $repls = [
      '/\b(terror|terrorism|terrorist)\b/i' => 'serious harm',
      '/\b(attack|assault)\b/i'             => 'harmful act',
      '/\b(hate|racist|racism|xenophob\w*)\b/i' => 'unkind/biased words',
      '/\b(violence|violent)\b/i'           => 'unsafe behavior',
    ];
    foreach ($repls as $k=>$v){ $t = preg_replace($k, $v, $t); }
    return $t;
  }

  private function detect_language($text){
    $t = mb_strtolower($text);
    if (preg_match('/\b(el|la|los|las|un|una|de|para|con|que)\b/u', $t)) return 'es';
    if (preg_match('/\b(le|la|les|des|pour|avec|une|un|que)\b/u', $t)) return 'fr';
    if (preg_match('/\b(der|die|das|und|mit|für|ein|eine|nicht)\b/u', $t)) return 'de';
    if (preg_match('/\b(de|het|een|met|voor|en|niet)\b/u', $t)) return 'nl';
    if (preg_match('/\b(il|la|le|di|per|con|una|un|che)\b/u', $t)) return 'it';
    if (preg_match('/\b(e|o|um|para|com|uma|um|de|que)\b/u', $t)) return 'pt';
    if (preg_match('/\b(og|med|for|en|et|til|ikke)\b/u', $t)) return 'no';
    if (preg_match('/\b(och|med|för|en|ett|till|inte)\b/u', $t)) return 'sv';
    if (preg_match('/\b(ja|i|na|za|od|u|je|nije)\b/u', $t)) return 'hr';
    if (preg_match('/\b(že|a|na|do|po|je|není)\b/u', $t)) return 'cs';
    if (preg_match('/\b(i|ir|ar|is|gan|ag)\b/u', $t)) return 'ga';
    return 'en';
  }

  private function classify($title, $content, $lang){
    $text = mb_strtolower($this->strip_html($title.' '.$content));

    // Core triggers (multilingual keywords)
    $red_kw = [
      'bully','bullying','racist','hate','xenophob','violence','attack','assault','extremist','terror','fake news','misinfo','disinfo','propaganda','panic','fearmong','abuse','harass','threat','hate speech',
      'pesten','haat','racisme','geweld','aanval','nepnieuws','paniek','angstzaaierij','haatspraak',
      'haine','racisme','violence','attaque','terreur','désinformation','propagande','panique','discours de haine',
      'odio','racismo','violencia','ataque','terror','desinformación','pánico','discurso de odio',
      'hass','rassismus','gewalt','angriff','terror','falschmeldung','panikmache','hassrede'
    ];
    $green_kw = [
      'festival','art','music','sports','school project','language day','comic','cartoon','museum','library','volunteer','science fair','community','play','theatre','exhibition','student council','exchange',
      'festival','muziek','kunst','bibliotheek','vrijwilliger','taal','leerlingraad',
      'festival','musique','art','bibliothèque','bénévole','langue','conseil des élèves',
      'festival','música','arte','biblioteca','voluntario','idioma','consejo estudiantil',
      'fest','musik','kunst','bibliothek','ehrenamt','sprache','schülervertretung'
    ];

    $is_red = $this->contains_any($text,$red_kw);
    $is_green = $this->contains_any($text,$green_kw);

    if ($is_red && !$is_green) return ['label'=>'Red','reason'=>'Potentially toxic/biased theme'];
    if ($is_green && !$is_red) return ['label'=>'Green','reason'=>'Harmless/positive community theme'];
    if (preg_match('/\b(alert|warning|urgent|breaking)\b/u', $text)) return ['label'=>'Red','reason'=>'Breaking/urgent tone'];
    return ['label'=>'Green','reason'=>'General/neutral'];
  }
  private function contains_any($text,$kw){ foreach($kw as $k){ if (mb_strpos($text, mb_strtolower($k))!==false) return true; } return false; }

  private function generate_remark($class, $title, $link, $lang){
    $label = $class['label'];
    $jokes_green = [
      "Green flag snack: teamwork tastes great.",
      "Wholesome news: 0% drama, 100% learning fuel.",
      "Parent-approved: light & bright!"
    ];
    $jokes_red = [
      "Red flag snack: handle with care and kindness.",
      "Tricky topic — let’s learn together.",
      "We spotted spicy words; let’s cool them with teamwork."
    ];
    $prompts_green = [
      "What worked well here? How could we try this at school?",
      "Who included others? How do we know?",
      "What’s one small kind action we could do today?"
    ];
    $prompts_red = [
      "Who wasn’t heard here? How could we include them?",
      "If this happened in class, what fair rule could we agree on?",
      "What facts would you double‑check before sharing?"
    ];
    $j = ($label==='Red') ? $jokes_red[array_rand($jokes_red)] : $jokes_green[array_rand($jokes_green)];
    $p1 = ($label==='Red') ? $prompts_red[array_rand($prompts_red)] : $prompts_green[array_rand($prompts_green)];
    $p2 = ($label==='Red') ? $prompts_red[array_rand($prompts_red)] : $prompts_green[array_rand($prompts_green)];

    $out  = "<p><strong>".esc_html($j)."</strong></p>";
    $out .= "<p><em>Talk it out:</em> ".esc_html($p1)."<br/>".esc_html($p2)."</p>";
    $out .= '<p><a href="'.esc_url($link).'" target="_blank" rel="noopener">Source</a></p>';
    return $out;
  }

  private function build_post_content($title, $link, $content, $remark, $class, $child_safe){
    $extract = $this->strip_html($content);
    if ($child_safe) $extract = $this->soften_text($extract);
    if (mb_strlen($extract) > 260) $extract = mb_substr($extract, 0, 259).'…';

    $badge = $class['label']==='Red' ? '🟥 Red Flag' : '🟩 Green Flag';
    $body  = '<p><strong>News:</strong> '.esc_html($title).'</p>';
    if (!empty($extract)){
      $body .= '<div class="osad-news-extract">'.wp_kses_post(wpautop(esc_html($extract))).'</div>';
    }
    $body .= '<p><strong>Status:</strong> '.$badge.' — '.esc_html($class['reason']).'</p>';
    $body .= $remark;
    $body .= '<hr/><p><em>Family note:</em> This post follows a democratic learning style — inviting student and parent voices, respectful debate, and shared decision‑making.</p>';
    return $body;
  }

  private function normalize_tags($csv){
    $tags = array_filter(array_map('trim', explode(',', (string)$csv)));
    return array_values(array_unique($tags));
  }

  private function attach_random_featured_image($post_id){
    $q = new WP_Query([
      'post_type'      => 'attachment',
      'post_status'    => 'inherit',
      'posts_per_page' => 60,
      'post_mime_type' => 'image',
      'fields'         => 'ids',
      'orderby'        => 'rand',
    ]);
    $ids = $q->posts;
    if (!empty($ids)){
      $id = $ids[array_rand($ids)];
      set_post_thumbnail($post_id, $id);
    }
  }
}

new OSAD_DemPed_AutoPoster();
