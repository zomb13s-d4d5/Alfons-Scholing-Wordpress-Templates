<?php
/**
 * Plugin Name: One Shot Article Image
 * Plugin URI: https://example.com/
 * Description: Automatically adds a featured article image to posts that do not have one, using images from the site's default WordPress uploads folder or a chosen uploads subfolder.
 * Version: 1.0.0
 * Author: NotYouAgain.ai / ChatGPT
 * License: GPL-2.0-or-later
 * Text Domain: one-shot-article-image
 */

if (!defined('ABSPATH')) {
    exit;
}

final class One_Shot_Article_Image {
    const OPTION_KEY = 'osai_settings';
    const NONCE_ACTION = 'osai_run_once';

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'admin_menu']);
        add_action('admin_init', [__CLASS__, 'register_settings']);
        add_action('save_post_post', [__CLASS__, 'maybe_add_image_on_save'], 20, 3);
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), [__CLASS__, 'settings_link']);
    }

    public static function defaults() {
        return [
            'uploads_subfolder' => '',
            'selection_mode' => 'random',
            'auto_on_save' => '1',
            'only_published' => '0',
        ];
    }

    public static function get_settings() {
        $saved = get_option(self::OPTION_KEY, []);
        if (!is_array($saved)) {
            $saved = [];
        }
        return wp_parse_args($saved, self::defaults());
    }

    public static function settings_link($links) {
        $url = admin_url('options-general.php?page=one-shot-article-image');
        array_unshift($links, '<a href="' . esc_url($url) . '">' . esc_html__('Settings', 'one-shot-article-image') . '</a>');
        return $links;
    }

    public static function admin_menu() {
        add_options_page(
            __('One Shot Article Image', 'one-shot-article-image'),
            __('One Shot Article Image', 'one-shot-article-image'),
            'manage_options',
            'one-shot-article-image',
            [__CLASS__, 'render_admin_page']
        );
    }

    public static function register_settings() {
        register_setting('osai_settings_group', self::OPTION_KEY, [__CLASS__, 'sanitize_settings']);
    }

    public static function sanitize_settings($input) {
        $defaults = self::defaults();
        $input = is_array($input) ? $input : [];

        $subfolder = isset($input['uploads_subfolder']) ? sanitize_text_field($input['uploads_subfolder']) : '';
        $subfolder = trim(str_replace(['..', '\\'], ['', '/'], $subfolder), '/');

        $selection_mode = isset($input['selection_mode']) && in_array($input['selection_mode'], ['random', 'first'], true)
            ? $input['selection_mode']
            : $defaults['selection_mode'];

        return [
            'uploads_subfolder' => $subfolder,
            'selection_mode' => $selection_mode,
            'auto_on_save' => empty($input['auto_on_save']) ? '0' : '1',
            'only_published' => empty($input['only_published']) ? '0' : '1',
        ];
    }

    public static function maybe_add_image_on_save($post_id, $post, $update) {
        $settings = self::get_settings();
        if ($settings['auto_on_save'] !== '1') {
            return;
        }
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
            return;
        }
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        if ($settings['only_published'] === '1' && get_post_status($post_id) !== 'publish') {
            return;
        }
        self::set_image_if_missing($post_id, $settings);
    }

    public static function render_admin_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $settings = self::get_settings();
        $message = '';

        if (isset($_POST['osai_run_once']) && check_admin_referer(self::NONCE_ACTION)) {
            $result = self::run_once();
            $message = sprintf(
                /* translators: 1: updated count, 2: skipped count */
                __('Finished. Added images to %1$d posts. Skipped %2$d posts.', 'one-shot-article-image'),
                intval($result['updated']),
                intval($result['skipped'])
            );
        }

        $uploads = wp_upload_dir();
        $base = isset($uploads['basedir']) ? $uploads['basedir'] : WP_CONTENT_DIR . '/uploads';
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('One Shot Article Image', 'one-shot-article-image'); ?></h1>
            <p><?php esc_html_e('Adds a featured image to posts that do not already have one, using images from your WordPress uploads folder.', 'one-shot-article-image'); ?></p>

            <?php if ($message) : ?>
                <div class="notice notice-success is-dismissible"><p><?php echo esc_html($message); ?></p></div>
            <?php endif; ?>

            <form method="post" action="options.php">
                <?php settings_fields('osai_settings_group'); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="osai_uploads_subfolder"><?php esc_html_e('Uploads subfolder', 'one-shot-article-image'); ?></label></th>
                        <td>
                            <input id="osai_uploads_subfolder" name="<?php echo esc_attr(self::OPTION_KEY); ?>[uploads_subfolder]" type="text" class="regular-text" value="<?php echo esc_attr($settings['uploads_subfolder']); ?>" placeholder="default-article-images" />
                            <p class="description">
                                <?php echo esc_html(sprintf(__('Leave empty to use all image attachments in %s. Or enter a folder relative to uploads, for example: default-article-images', 'one-shot-article-image'), $base)); ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Selection mode', 'one-shot-article-image'); ?></th>
                        <td>
                            <label><input type="radio" name="<?php echo esc_attr(self::OPTION_KEY); ?>[selection_mode]" value="random" <?php checked($settings['selection_mode'], 'random'); ?> /> <?php esc_html_e('Random image', 'one-shot-article-image'); ?></label><br />
                            <label><input type="radio" name="<?php echo esc_attr(self::OPTION_KEY); ?>[selection_mode]" value="first" <?php checked($settings['selection_mode'], 'first'); ?> /> <?php esc_html_e('First available image', 'one-shot-article-image'); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Automatic mode', 'one-shot-article-image'); ?></th>
                        <td>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::OPTION_KEY); ?>[auto_on_save]" value="1" <?php checked($settings['auto_on_save'], '1'); ?> /> <?php esc_html_e('Add a featured image when a post is saved and has no featured image', 'one-shot-article-image'); ?></label><br />
                            <label><input type="checkbox" name="<?php echo esc_attr(self::OPTION_KEY); ?>[only_published]" value="1" <?php checked($settings['only_published'], '1'); ?> /> <?php esc_html_e('Only process published posts', 'one-shot-article-image'); ?></label>
                        </td>
                    </tr>
                </table>
                <?php submit_button(__('Save Settings', 'one-shot-article-image')); ?>
            </form>

            <hr />
            <h2><?php esc_html_e('Run once now', 'one-shot-article-image'); ?></h2>
            <p><?php esc_html_e('This one-shot action scans existing posts and adds a featured image only where one is missing. Existing featured images are never replaced.', 'one-shot-article-image'); ?></p>
            <form method="post">
                <?php wp_nonce_field(self::NONCE_ACTION); ?>
                <?php submit_button(__('Fill Missing Article Images', 'one-shot-article-image'), 'primary', 'osai_run_once'); ?>
            </form>
        </div>
        <?php
    }

    public static function run_once() {
        $settings = self::get_settings();
        $updated = 0;
        $skipped = 0;
        $paged = 1;

        do {
            $query = new WP_Query([
                'post_type' => 'post',
                'post_status' => $settings['only_published'] === '1' ? ['publish'] : ['publish', 'draft', 'pending', 'future', 'private'],
                'posts_per_page' => 100,
                'paged' => $paged,
                'fields' => 'ids',
                'meta_query' => [
                    'relation' => 'OR',
                    [
                        'key' => '_thumbnail_id',
                        'compare' => 'NOT EXISTS',
                    ],
                    [
                        'key' => '_thumbnail_id',
                        'value' => '',
                        'compare' => '=',
                    ],
                ],
            ]);

            foreach ($query->posts as $post_id) {
                if (self::set_image_if_missing($post_id, $settings)) {
                    $updated++;
                } else {
                    $skipped++;
                }
            }

            $paged++;
        } while ($query->max_num_pages >= $paged);

        return ['updated' => $updated, 'skipped' => $skipped];
    }

    private static function set_image_if_missing($post_id, $settings) {
        if (has_post_thumbnail($post_id)) {
            return false;
        }

        $attachment_id = self::pick_image_attachment($settings);
        if (!$attachment_id) {
            return false;
        }

        return (bool) set_post_thumbnail($post_id, $attachment_id);
    }

    private static function pick_image_attachment($settings) {
        $args = [
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'post_mime_type' => 'image',
            'posts_per_page' => 100,
            'fields' => 'ids',
            'orderby' => 'date',
            'order' => 'DESC',
        ];

        $query = new WP_Query($args);
        $ids = array_map('intval', $query->posts);

        if (!empty($settings['uploads_subfolder'])) {
            $ids = array_values(array_filter($ids, function($id) use ($settings) {
                $file = get_attached_file($id);
                if (!$file) {
                    return false;
                }
                $uploads = wp_upload_dir();
                $needle = trailingslashit(wp_normalize_path($uploads['basedir'])) . trim($settings['uploads_subfolder'], '/') . '/';
                return strpos(wp_normalize_path($file), wp_normalize_path($needle)) === 0;
            }));
        }

        if (empty($ids)) {
            return 0;
        }

        if ($settings['selection_mode'] === 'first') {
            return $ids[0];
        }

        return $ids[array_rand($ids)];
    }
}

One_Shot_Article_Image::init();
