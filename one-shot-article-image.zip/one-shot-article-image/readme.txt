=== One Shot Article Image ===
Contributors: notyouagain
Tags: featured image, articles, posts, default image
Requires at least: 5.8
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Adds a featured image to posts that do not have one, using images from the site's WordPress uploads folder.

== Installation ==
1. Upload the ZIP through WordPress Admin > Plugins > Add New > Upload Plugin.
2. Activate the plugin.
3. Go to Settings > One Shot Article Image.
4. Leave the folder empty to use all images in the Media Library, or enter a folder relative to wp-content/uploads, such as default-article-images.
5. Click "Fill Missing Article Images" to run it once.

== Behavior ==
- Existing featured images are never replaced.
- By default it also runs automatically when a post is saved.
- It uses WordPress image attachments, so images should be visible in the Media Library.
- If you enter a folder, images should be inside wp-content/uploads/YOUR-FOLDER and registered in the Media Library.
