<?php if (!defined('ABSPATH')) { exit; } ?>
</main>
<footer class="sr-site-footer">
  <div class="sr-footer-inner sr-shell">
    <a class="sr-logo" href="<?php echo esc_url(home_url('/')); ?>"><span>solid<span class="red">red.</span></span><small>consulting</small></a>
    <nav class="sr-footer-links" aria-label="<?php esc_attr_e('Footer menu', 'solidred'); ?>">
      <?php
      wp_nav_menu(array(
        'theme_location' => 'footer',
        'container' => false,
        'items_wrap' => '%3$s',
        'fallback_cb' => function(){ echo '<a href="#content">top</a><a href="mailto:zomb13s@protonmail.com">contact</a>'; }
      ));
      ?>
    </nav>
    <a class="sr-top" href="#content" aria-label="<?php esc_attr_e('Back to top', 'solidred'); ?>">↑</a>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
