<?php get_header(); ?>
<header class="sr-archive-header">
  <div class="sr-shell">
    <div class="sr-kicker">category</div>
    <h1 class="sr-section-title"><?php single_cat_title(); ?></h1>
    <div class="sr-note"><?php echo category_description(); ?></div>
  </div>
</header>
<div class="sr-post-grid">
  <?php if (have_posts()) : while (have_posts()) : the_post(); get_template_part('template-parts/content', 'card'); endwhile; else: ?>
    <article class="sr-post-card"><h2><?php esc_html_e('No posts found in this category', 'solidred'); ?></h2></article>
  <?php endif; ?>
</div>
<div class="sr-pagination"><?php the_posts_pagination(array('mid_size'=>1)); ?></div>
<?php get_footer(); ?>
