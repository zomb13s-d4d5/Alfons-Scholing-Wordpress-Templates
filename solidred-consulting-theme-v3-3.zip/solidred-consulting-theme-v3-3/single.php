<?php get_header(); ?>
<?php while (have_posts()) : the_post(); ?>
<header class="sr-single-hero">
  <div class="sr-shell">
    <div class="sr-kicker"><?php the_category(' / '); ?></div>
    <h1><?php the_title(); ?></h1>
    <div class="sr-meta"><?php echo esc_html(get_the_date()); ?> · <?php the_author(); ?></div>
  </div>
  <?php if (has_post_thumbnail()) { the_post_thumbnail('large', array('class'=>'sr-featured')); } else { echo '<img class="sr-featured" src="' . solidred_fallback_image() . '" alt="">'; } ?>
</header>
<div class="sr-content-wrap sr-shell">
  <article <?php post_class('sr-entry'); ?> id="sr-article-content">
    <div class="sr-copy-ai-box">
      <div>
        <div class="sr-kicker">fact-checkable content</div>
        <p>Copy the article text and paste it into an AI tool to check claims, sources, assumptions and logic.</p>
      </div>
      <button class="sr-copy-ai" type="button" data-target="sr-article-content">Copy text for AI</button>
    </div>
    <?php the_content(); ?>
    <?php wp_link_pages(array('before'=>'<div class="sr-pagination">','after'=>'</div>')); ?>
  </article>
  <aside class="sr-sidebar" aria-label="<?php esc_attr_e('Report sidebar', 'solidred'); ?>">
    <div class="sr-kicker">consultant sheet</div>
    <img src="<?php echo solidred_asset('solidred-values.png'); ?>" alt="">
    <div class="sr-diagram-placeholder"><strong>Diagram placeholder</strong>Use this area for future consultant-sheet diagrams, matrices, risk maps, source maps or visual models.</div>
  </aside>
</div>
<?php if (comments_open() || get_comments_number()) { comments_template(); } ?>
<?php endwhile; ?>
<?php get_footer(); ?>
