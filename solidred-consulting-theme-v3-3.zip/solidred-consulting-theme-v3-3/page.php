<?php get_header(); ?>
<?php while (have_posts()) : the_post(); ?>
<header class="sr-single-hero">
  <div class="sr-shell">
    <div class="sr-kicker">page</div>
    <h1><?php the_title(); ?></h1>
  </div>
  <img class="sr-featured" src="<?php echo solidred_asset('solidred-hero.png'); ?>" alt="">
</header>
<div class="sr-content-wrap sr-shell">
  <article <?php post_class('sr-entry'); ?>><?php the_content(); ?></article>
  <aside class="sr-sidebar"><div class="sr-kicker">solidred.consulting</div><img src="<?php echo solidred_asset('solidred-cta.png'); ?>" alt=""><p>Strategy for public futures, adult alternatives and civic imagination.</p></aside>
</div>
<?php endwhile; ?>
<?php get_footer(); ?>
