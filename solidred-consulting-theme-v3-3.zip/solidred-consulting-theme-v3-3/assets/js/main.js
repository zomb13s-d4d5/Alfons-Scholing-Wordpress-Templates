(function(){
  const toggle = document.querySelector('.sr-menu-toggle');
  const logoToggle = document.querySelector('.sr-logo-menu-trigger');
  const overlay = document.querySelector('.sr-menu-overlay');
  const close = document.querySelector('.sr-menu-close');

  const setMenu = (open) => {
    if (!toggle || !overlay) return;
    overlay.classList.toggle('is-open', open);
    document.body.classList.toggle('sr-lock', open);
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    logoToggle?.setAttribute('aria-expanded', open ? 'true' : 'false');
    overlay.setAttribute('aria-hidden', open ? 'false' : 'true');
  };

  if (toggle && overlay) {
    toggle.addEventListener('click', () => setMenu(!overlay.classList.contains('is-open')));
    logoToggle?.addEventListener('click', () => setMenu(!overlay.classList.contains('is-open')));
    close?.addEventListener('click', () => setMenu(false));
    overlay.addEventListener('click', (event) => {
      if (event.target === overlay) setMenu(false);
    });
    overlay.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => setMenu(false));
    });
    window.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') setMenu(false);
    });
  }
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;



  const copyButtons = document.querySelectorAll('.sr-copy-ai[data-target]');
  copyButtons.forEach(button => {
    button.addEventListener('click', async () => {
      const target = document.getElementById(button.getAttribute('data-target'));
      if (!target) return;

      const clone = target.cloneNode(true);
      clone.querySelectorAll('.sr-copy-ai-box, script, style, nav, form').forEach(el => el.remove());
      const title = document.querySelector('.sr-single-hero h1')?.innerText?.trim() || document.title;
      const text = `${title}\n\n${clone.innerText.trim()}`;

      try {
        await navigator.clipboard.writeText(text);
        const original = button.textContent;
        button.textContent = 'Copied for AI';
        window.setTimeout(() => { button.textContent = original; }, 1800);
      } catch (error) {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        textarea.remove();
        const original = button.textContent;
        button.textContent = 'Copied for AI';
        window.setTimeout(() => { button.textContent = original; }, 1800);
      }
    });
  });

  const inquiryForms = document.querySelectorAll('.sr-inquiry-form[data-mailto]');
  inquiryForms.forEach(form => {
    form.addEventListener('submit', function(event){
      event.preventDefault();

      const to = form.getAttribute('data-mailto') || '';
      const data = new FormData(form);
      const name = (data.get('name') || '').toString().trim();
      const email = (data.get('email') || '').toString().trim();
      const project = (data.get('project') || '').toString().trim();
      const message = (data.get('message') || '').toString().trim();

      const subject = project
        ? `SolidRed inquiry: ${project}`
        : 'SolidRed consulting inquiry';

      const body = [
        name ? `Name: ${name}` : '',
        email ? `Email: ${email}` : '',
        project ? `Project: ${project}` : '',
        '',
        message || 'Tell me briefly what you want to build.'
      ].filter((line, index, array) => line || index === 3).join('\n');

      window.location.href = `mailto:${encodeURIComponent(to)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    });
  });


  const heroSlider = document.querySelector('.sr-hero-slider');
  if (heroSlider && !reduce) {
    const slides = Array.from(heroSlider.querySelectorAll('.sr-hero-slide'));
    const dots = Array.from(heroSlider.querySelectorAll('.sr-hero-dots button'));
    let current = 0;

    const setSlide = (index) => {
      slides[current]?.classList.remove('is-active');
      dots[current]?.classList.remove('is-active');
      current = index % slides.length;
      slides[current]?.classList.add('is-active');
      dots[current]?.classList.add('is-active');
    };

    if (slides.length > 1) {
      window.setInterval(() => setSlide(current + 1), 6200);
    }
  }

  const revealEls = document.querySelectorAll('.sr-card, .sr-post-card, .sr-entry > *, .sr-band');
  if ('IntersectionObserver' in window && !reduce) {
    revealEls.forEach(el => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(18px)';
      el.style.transition = 'opacity .55s ease, transform .55s ease';
    });
    const io = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
          io.unobserve(entry.target);
        }
      });
    }, {threshold:0.12});
    revealEls.forEach(el => io.observe(el));
  }
})();
