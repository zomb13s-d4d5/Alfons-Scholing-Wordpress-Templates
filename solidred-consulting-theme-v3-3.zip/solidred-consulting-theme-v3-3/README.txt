SolidRed Consulting iOS First - WordPress Theme

Install:
1. Upload solidred-consulting-theme.zip in WordPress > Appearance > Themes > Add New > Upload Theme.
2. Activate it.
3. Create a menu and assign it to Primary menu.
4. Set your homepage to a static page if desired, or use the included front-page.php as the home template.

Included:
- Google typography: Syne for headings, Inter for body.
- iOS-first responsive layout using 100svh, sticky glass header, large tap targets and compact mobile menu.
- Animated hero illustration and reveal animations with prefers-reduced-motion support.
- Front page sections: hero, manifesto, services, public values, network, latest sheets and contact.
- Category/archive grid.
- Single consultant sheet layout with diagram placeholder sidebar.
- Styled comments.
- Included visual assets in /assets/img/.

Notes:
The included images are generated wireframe placeholders. They are PNG assets with transparency-processing and are intended to be replaced or refined later with final exported illustrations/diagrams.


v1.2: Lighter homepage to match selected template board: white/paper hero, light header, reduced black, iOS viewport tuning.


v2.3: Front-page copy professionalised toward socialist, streetwise, anti-false-authority positioning while keeping the existing design and animation system intact.
