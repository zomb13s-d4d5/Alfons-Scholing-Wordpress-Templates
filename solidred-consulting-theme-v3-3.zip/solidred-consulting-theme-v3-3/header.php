<?php if (!defined('ABSPATH')) { exit; } ?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="sr-site-header">
  <div class="sr-header-inner sr-shell">
    <button class="sr-logo sr-logo-menu-trigger" type="button" aria-expanded="false" aria-controls="site-navigation" aria-label="<?php esc_attr_e('Open menu', 'solidred'); ?>">
      <span>solid<span class="red">red.</span></span><small>consulting</small>
    </button>
    <button class="sr-menu-toggle" type="button" aria-expanded="false" aria-controls="site-navigation"><span>menu</span><span><i></i><i></i><i></i></span></button>
  </div>

</header>
  <div id="site-navigation" class="sr-menu-overlay" aria-hidden="true">
    <div class="sr-menu-panel sr-shell" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e('Site menu', 'solidred'); ?>">
      <div class="sr-menu-panel-head">
        <a class="sr-logo sr-menu-logo" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php bloginfo('name'); ?> home">
          <span>solid<span class="red">red.</span></span><small>consulting</small>
        </a>
        <button class="sr-menu-close" type="button" aria-label="<?php esc_attr_e('Close menu', 'solidred'); ?>">×</button>
      </div>

      <nav class="sr-main-nav" aria-label="<?php esc_attr_e('Primary menu', 'solidred'); ?>">
        <?php
        wp_nav_menu(array(
          'theme_location' => 'primary',
          'container' => false,
          'items_wrap' => '%3$s',
          'fallback_cb' => function(){
            echo '<a href="' . esc_url(home_url('/#manifesto')) . '">Manifesto</a>';
            echo '<a href="' . esc_url(home_url('/#services')) . '">Services</a>';
            echo '<a href="' . esc_url(home_url('/#values')) . '">Public values</a>';
            echo '<a href="' . esc_url(home_url('/#latest')) . '">Reports</a>';
            echo '<a href="' . esc_url(home_url('/#contact')) . '">Start a project</a>';
          }
        ));
        ?>
      </nav>

      <div class="sr-menu-latest">
        <div class="sr-kicker">latest sheets</div>
        <div class="sr-menu-posts">
          <?php
          $menu_q = new WP_Query(array('posts_per_page'=>3));
          if ($menu_q->have_posts()) :
            while ($menu_q->have_posts()) : $menu_q->the_post(); ?>
              <a class="sr-menu-post" href="<?php the_permalink(); ?>">
                <span><?php echo esc_html(get_the_date()); ?></span>
                <strong><?php the_title(); ?></strong>
              </a>
            <?php endwhile; wp_reset_postdata();
          else: ?>
            <a class="sr-menu-post" href="<?php echo esc_url(home_url('/#latest')); ?>"><span>reports</span><strong>Latest consultant sheets appear here.</strong></a>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
  </div>

<main id="content" class="site-main">
