<?php get_header(); ?>
<header class="sr-archive-header">
  <div class="sr-shell">
    <div class="sr-kicker">archive</div>
    <h1 class="sr-section-title"><?php single_post_title('', true); ?></h1>
    <p class="sr-note">Reports, notes, consultant sheets and visual frameworks.</p>
  </div>
</header>
<div class="sr-post-grid">
  <?php if (have_posts()) : while (have_posts()) : the_post(); get_template_part('template-parts/content', 'card'); endwhile; else: ?>
    <article class="sr-post-card"><h2><?php esc_html_e('No posts found', 'solidred'); ?></h2></article>
  <?php endif; ?>
</div>
<div class="sr-pagination"><?php the_posts_pagination(array('mid_size'=>1)); ?></div>
<?php get_footer(); ?>
