<?php get_header(); ?>
<section class="sr-hero sr-grid-bg">
  <div class="sr-hero-inner sr-shell">
    <div><div class="sr-kicker">404</div><h1 class="sr-h1">page not found</h1><p class="sr-lede">The system lost this route. Return to the public future.</p><a class="sr-button" href="<?php echo esc_url(home_url('/')); ?>">home</a></div>
    <div class="sr-hero-art"><img src="<?php echo solidred_asset('solidred-cta.png'); ?>" alt=""></div>
  </div>
</section>
<?php get_footer(); ?>
