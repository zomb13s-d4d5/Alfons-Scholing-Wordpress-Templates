<?php
if (!defined('ABSPATH')) { exit; }

function solidred_setup() {
  load_theme_textdomain('solidred', get_template_directory() . '/languages');
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
  add_theme_support('responsive-embeds');
  add_theme_support('editor-styles');
  add_theme_support('align-wide');
  add_editor_style('style.css');
  register_nav_menus(array(
    'primary' => __('Primary menu', 'solidred'),
    'footer'  => __('Footer menu', 'solidred'),
  ));
}
add_action('after_setup_theme', 'solidred_setup');

function solidred_assets() {
  wp_enqueue_style('solidred-google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700;800;900&family=Syne:wght@600;700;800&display=swap', array(), null);
  wp_enqueue_style('solidred-style', get_stylesheet_uri(), array('solidred-google-fonts'), '3.3.0');
  wp_enqueue_script('solidred-main', get_template_directory_uri() . '/assets/js/main.js', array(), '3.3.0', true);
}
add_action('wp_enqueue_scripts', 'solidred_assets');

function solidred_excerpt_length($length) { return 22; }
add_filter('excerpt_length', 'solidred_excerpt_length');
function solidred_excerpt_more($more) { return '…'; }
add_filter('excerpt_more', 'solidred_excerpt_more');

function solidred_asset($name) {
  return esc_url(get_template_directory_uri() . '/assets/img/' . $name);
}

function solidred_fallback_image() {
  return solidred_asset('solidred-hero.png');
}

function solidred_post_image($size = 'large') {
  if (has_post_thumbnail()) {
    the_post_thumbnail($size);
  } else {
    echo '<img src="' . solidred_fallback_image() . '" alt="" loading="lazy">';
  }
}

function solidred_body_classes($classes) {
  $classes[] = 'solidred-theme';
  return $classes;
}
add_filter('body_class', 'solidred_body_classes');

function solidred_comment($comment, $args, $depth) {
  $tag = ('div' === $args['style']) ? 'div' : 'li';
  ?>
  <<?php echo $tag; ?> id="comment-<?php comment_ID(); ?>" <?php comment_class(empty($args['has_children']) ? '' : 'parent'); ?>>
    <article id="div-comment-<?php comment_ID(); ?>" class="comment-body">
      <footer class="comment-meta">
        <div class="comment-author vcard">
          <?php echo get_avatar($comment, 54); ?>
          <?php printf('<b class="fn">%s</b>', get_comment_author_link()); ?>
        </div>
        <div class="comment-metadata">
          <a href="<?php echo esc_url(get_comment_link($comment->comment_ID)); ?>">
            <time datetime="<?php comment_time('c'); ?>"><?php printf(esc_html__('%1$s at %2$s', 'solidred'), get_comment_date(), get_comment_time()); ?></time>
          </a>
        </div>
      </footer>
      <div class="comment-content"><?php comment_text(); ?></div>
      <div class="reply">
        <?php comment_reply_link(array_merge($args, array('add_below' => 'div-comment', 'depth' => $depth, 'max_depth' => $args['max_depth']))); ?>
      </div>
    </article>
  <?php
}
