<?php get_header(); ?>
<section class="sr-hero sr-hero-slider sr-grid-bg" id="top" aria-label="SolidRed homepage hero slider">
  <div class="sr-hero-slide is-active">
    <div class="sr-hero-inner sr-shell">
      <div class="sr-hero-copy">
        <div class="sr-kicker">consulting for public futures</div>
        <h1 class="sr-h1">adult alternatives<br><span class="red">for</span> a child-friendly<br>society</h1>
        <p class="sr-lede">We are the suit for everyone who does not wear one: clear consulting, public strategy and visual frameworks for people who need power explained, systems challenged and better alternatives built.</p>
        <div class="sr-actions">
          <a class="sr-button" href="#contact">Start a project</a>
          <a class="sr-button is-outline" href="#manifesto">Our manifesto</a>
        </div>
      </div>
      <div class="sr-hero-art" aria-hidden="true">
        <img class="sr-floating" src="<?php echo solidred_asset('solidred-hero.png'); ?>" alt="">
      </div>
    </div>
  </div>

  <div class="sr-hero-slide">
    <div class="sr-hero-inner sr-shell">
      <div class="sr-hero-copy">
        <div class="sr-kicker">systems advice / public value</div>
        <h1 class="sr-h1">strategy<br><span class="red">for</span> public<br>systems</h1>
        <p class="sr-lede">We translate difficult realities into usable reports, systems, diagrams and decisions. Socialist in values, pragmatic in delivery, allergic to false authority.</p>
        <div class="sr-actions">
          <a class="sr-button" href="#latest">View reports</a>
          <a class="sr-button is-outline" href="#services">Services</a>
        </div>
      </div>
      <div class="sr-hero-art" aria-hidden="true">
        <img class="sr-floating" src="<?php echo solidred_asset('solidred-services.png'); ?>" alt="">
      </div>
    </div>
  </div>

  <div class="sr-hero-slide">
    <div class="sr-hero-inner sr-shell">
      <div class="sr-hero-copy">
        <div class="sr-kicker">plain language / serious advice</div>
        <h1 class="sr-h1">design<br><span class="red">the</span> better<br>alternative</h1>
        <p class="sr-lede">The tone is simple: respect people, test claims, document sources and do not pretend dysfunction is normal just because it is official.</p>
        <div class="sr-actions">
          <a class="sr-button" href="#network">View network</a>
          <a class="sr-button is-outline" href="#contact">Contact</a>
        </div>
      </div>
      <div class="sr-hero-art" aria-hidden="true">
        <img class="sr-floating" src="<?php echo solidred_asset('solidred-manifesto.png'); ?>" alt="">
      </div>
    </div>
  </div>

  <div class="sr-hero-dots" aria-hidden="true">
    <button class="is-active" type="button" tabindex="-1"></button>
    <button type="button" tabindex="-1"></button>
    <button type="button" tabindex="-1"></button>
  </div>
  <a class="sr-scroll-cue" href="#manifesto" aria-label="Scroll to manifesto">↓</a>
</section>

<div class="sr-marquee" aria-hidden="true"><div class="sr-marquee-track"><span>public strategy · socialist values · practical alternatives · fact-checkable advice · clear systems · </span><span>public strategy · socialist values · practical alternatives · fact-checkable advice · clear systems · </span></div></div>

<section class="sr-section sr-section-light" id="manifesto">
  <div class="sr-shell">
    <div class="sr-section-head">
      <h2 class="sr-section-title">manifesto</h2>
      <p class="sr-note">Our politics are practical: care, freedom, solidarity and responsible systems without fake authority.</p>
    </div>
    <div class="sr-card-grid">
      <article class="sr-card sr-card-overlay"><span class="sr-num">01</span><div><h3>care is infrastructure</h3><p>Public systems should protect people before profit, status or institutional theatre.</p></div><img class="sr-card-art" src="<?php echo solidred_asset('solidred-manifesto.png'); ?>" alt=""></article>
      <article class="sr-card sr-card-overlay"><span class="sr-num">02</span><div><h3>freedom is collective</h3><p>Freedom becomes real when systems are understandable, usable, shared and safe.</p></div><img class="sr-card-art" src="<?php echo solidred_asset('solidred-values.png'); ?>" alt=""></article>
      <article class="sr-card sr-card-overlay"><span class="sr-num">03</span><div><h3>solidarity is design</h3><p>Solidarity is design, policy, logistics and the courage to describe reality clearly.</p></div><img class="sr-card-art" src="<?php echo solidred_asset('solidred-services.png'); ?>" alt=""></article>
      <article class="sr-card sr-card-overlay"><span class="sr-num">04</span><div><h3>autonomy needs structure</h3><p>Autonomy needs structure: tools, governance, public imagination and the right to question authority.</p></div><img class="sr-card-art" src="<?php echo solidred_asset('solidred-cta.png'); ?>" alt=""></article>
    </div>
  </div>
</section>

<section class="sr-section" id="services">
  <div class="sr-shell">
    <div class="sr-section-head">
      <h2 class="sr-section-title"><span class="red">services</span></h2>
      <p class="sr-note">Consultant sheets, civic strategy, platform design, cultural analysis and systems architecture for people and organisations that need clear advice without theatre.</p>
    </div>
    <div class="sr-card-grid">
      <article class="sr-card"><span class="sr-num">A</span><div><h3>strategy reports</h3><p>Fact-checkable consultant sheets: signal, system, risk, source logic and practical alternatives.</p></div></article>
      <article class="sr-card"><span class="sr-num">B</span><div><h3>public systems</h3><p>Concept architecture for public platforms, educational media, cooperative systems and democratic tools.</p></div></article>
      <article class="sr-card"><span class="sr-num">C</span><div><h3>visual frameworks</h3><p>Diagrams, narratives and editorial formats that make complex systems understandable.</p></div></article>
      <article class="sr-card"><span class="sr-num">D</span><div><h3>capacity building</h3><p>Workshops, roadmaps and implementation logic for teams, municipalities, movements and mission-driven groups.</p></div></article>
    </div>
  </div>
</section>

<section class="sr-section sr-section-light" id="values">
  <div class="sr-shell">
    <div class="sr-section-head">
      <h2 class="sr-section-title">public <span class="red">values</span></h2>
      <p class="sr-note">A compact values line for the work: public, practical, accountable and source-aware.</p>
    </div>
    <div class="sr-value-row">
      <div class="sr-value">Democracy<br>is participation</div>
      <div class="sr-value">Freedom<br>is collective</div>
      <div class="sr-value">Responsibility<br>is material</div>
      <div class="sr-value">Justice<br>is non-negotiable</div>
      <div class="sr-value">Authority<br>must explain itself</div>
    </div>
  </div>
</section>

<section class="sr-section" id="network">
  <div class="sr-shell sr-band sr-band-overlay">
    <div>
      <div class="sr-kicker">NYA-network / public intelligence</div>
      <h2>a network for civic imagination.</h2>
      <p>solidred.consulting is the strategic layer of an independent creative network: reports, systems, brand logic and visual frameworks for publishing, design, education, civic media and European alternatives.</p>
    </div>
    <img class="sr-spin-slow" src="<?php echo solidred_asset('solidred-cta.png'); ?>" alt="">
  </div>
</section>

<section class="sr-section sr-section-light" id="latest">
  <div class="sr-shell">
    <div class="sr-section-head">
      <h2 class="sr-section-title">latest <span class="red">sheets</span></h2>
      <a class="sr-button" href="<?php echo esc_url(get_permalink(get_option('page_for_posts')) ?: home_url('/?post_type=post')); ?>">View reports</a>
    </div>
  </div>
  <div class="sr-post-grid">
    <?php $q = new WP_Query(array('posts_per_page'=>6)); if ($q->have_posts()) : while($q->have_posts()) : $q->the_post(); get_template_part('template-parts/content', 'card'); endwhile; wp_reset_postdata(); else: ?>
      <article class="sr-post-card"><img src="<?php echo solidred_asset('solidred-hero.png'); ?>" alt=""><div><div class="sr-meta">placeholder</div><h2>Consultant sheet title</h2><p class="sr-excerpt">Create posts to populate this grid with report previews.</p></div></article>
      <article class="sr-post-card"><img src="<?php echo solidred_asset('solidred-services.png'); ?>" alt=""><div><div class="sr-meta">placeholder</div><h2>Public systems brief</h2><p class="sr-excerpt">Featured images can be diagrams or the provided wireframe assets.</p></div></article>
      <article class="sr-post-card"><img src="<?php echo solidred_asset('solidred-values.png'); ?>" alt=""><div><div class="sr-meta">placeholder</div><h2>Values framework</h2><p class="sr-excerpt">Designed for longform reports, categories and consultation notes.</p></div></article>
    <?php endif; ?>
  </div>
</section>

<section class="sr-section" id="contact">
  <div class="sr-shell sr-band sr-band-overlay">
    <div>
      <div class="sr-kicker">start a project</div>
      <h2>let’s build adult alternatives.</h2>
      <p>For reports, collaborations, systems, public-interest strategy and serious conversations about difficult problems.</p>

      <form class="sr-inquiry-form" data-mailto="zomb13s@protonmail.com">
        <div class="sr-inquiry-row">
          <label>Name
            <input type="text" name="name" autocomplete="name" placeholder="Your name">
          </label>
          <label>Email
            <input type="email" name="email" autocomplete="email" placeholder="Your email">
          </label>
        </div>
        <label>Project
          <input type="text" name="project" placeholder="Consultant sheet, strategy, platform, collaboration…">
        </label>
        <label>Message
          <textarea name="message" placeholder="Tell me what is happening, what needs checking, and what you need to build."></textarea>
        </label>
        <button class="sr-button" type="submit">Send inquiry</button>
        <p class="sr-inquiry-help">This opens your email app with a prefilled message.</p>
      </form>
    </div>
    <img src="<?php echo solidred_asset('solidred-cta.png'); ?>" alt="">
  </div>
</section>
<?php get_footer(); ?>
