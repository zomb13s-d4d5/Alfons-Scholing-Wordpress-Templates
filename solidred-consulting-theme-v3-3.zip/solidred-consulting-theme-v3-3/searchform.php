<form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>">
  <label><span class="screen-reader-text"><?php esc_html_e('Search for:', 'solidred'); ?></span><input type="search" class="search-field" placeholder="<?php esc_attr_e('Search reports…', 'solidred'); ?>" value="<?php echo get_search_query(); ?>" name="s"></label>
  <button type="submit" class="sr-button"><?php esc_html_e('Search', 'solidred'); ?></button>
</form>
