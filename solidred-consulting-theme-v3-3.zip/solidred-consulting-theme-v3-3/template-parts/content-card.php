<article <?php post_class('sr-post-card'); ?>>
  <a href="<?php the_permalink(); ?>" aria-label="<?php the_title_attribute(); ?>">
    <?php solidred_post_image('medium_large'); ?>
  </a>
  <div>
    <div class="sr-meta"><?php echo esc_html(get_the_date()); ?> · <?php the_category(' / '); ?></div>
    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
    <p class="sr-excerpt"><?php echo esc_html(get_the_excerpt()); ?></p>
  </div>
</article>
