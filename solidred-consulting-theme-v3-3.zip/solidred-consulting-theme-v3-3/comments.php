<?php if (post_password_required()) { return; } ?>
<section id="comments" class="comments-area">
  <div class="sr-shell">
    <?php if (have_comments()) : ?>
      <h2 class="comments-title"><?php printf(esc_html(_nx('one response', '%1$s responses', get_comments_number(), 'comments title', 'solidred')), number_format_i18n(get_comments_number())); ?></h2>
      <ol class="comment-list">
        <?php wp_list_comments(array('style'=>'ol','short_ping'=>true,'callback'=>'solidred_comment')); ?>
      </ol>
      <div class="sr-pagination"><?php paginate_comments_links(); ?></div>
    <?php endif; ?>
    <?php comment_form(array(
      'title_reply' => __('Join the discussion', 'solidred'),
      'title_reply_before' => '<h2 id="reply-title" class="comment-reply-title">',
      'title_reply_after' => '</h2>',
      'class_submit' => 'submit sr-button',
    )); ?>
  </div>
</section>
