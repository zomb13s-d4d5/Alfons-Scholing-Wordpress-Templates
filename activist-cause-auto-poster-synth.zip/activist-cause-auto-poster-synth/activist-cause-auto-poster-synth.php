<?php
/**
 * Plugin Name: Activist Cause Auto Poster Synth
 * Description: Imports activism-relevant news from RSS feeds, generates structured activist context, rotates toolkit posts, and includes logging/manual run tools for reliable operation.
 * Version: 1.1.0
 * Author: OpenAI + Alfons Scholing workflow synthesis
 * License: GPLv2 or later
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'ACAPS_Activator' ) ) {
class ACAPS_Activator {
    const OPTION_SETTINGS = 'acaps_settings';
    const OPTION_SEEN     = 'acaps_seen_items';
    const OPTION_LOG      = 'acaps_log';
    const OPTION_QUEUE    = 'acaps_toolkit_queue';
    const OPTION_LAST_RUN = 'acaps_last_run';
    const TRANSIENT_LOCK  = 'acaps_run_lock';
    const CRON_HOOK       = 'acaps_cron_run';
    const NONCE_ACTION    = 'acaps_admin_action';

    public function __construct() {
        add_filter( 'cron_schedules', [ $this, 'cron_schedules' ] );
        register_activation_hook( __FILE__, [ $this, 'activate' ] );
        register_deactivation_hook( __FILE__, [ $this, 'deactivate' ] );
        add_action( self::CRON_HOOK, [ $this, 'run' ] );
        add_action( 'admin_menu', [ $this, 'admin_menu' ] );
        add_action( 'admin_init', [ $this, 'register_settings' ] );
        add_action( 'admin_post_acaps_run_now', [ $this, 'handle_run_now' ] );
        add_action( 'admin_post_acaps_reset_seen', [ $this, 'handle_reset_seen' ] );
        add_action( 'init', [ $this, 'soft_cron_fallback' ] );
    }

    public function cron_schedules( $schedules ) {
        $schedules['five_minutes'] = [
            'interval' => 300,
            'display'  => __( 'Every 5 Minutes', 'acaps' ),
        ];
        $schedules['fifteen_minutes'] = [
            'interval' => 900,
            'display'  => __( 'Every 15 Minutes', 'acaps' ),
        ];
        return $schedules;
    }

    public function activate() {
        if ( false === get_option( self::OPTION_SETTINGS ) ) {
            add_option( self::OPTION_SETTINGS, $this->default_settings() );
        }
        if ( false === get_option( self::OPTION_SEEN ) ) {
            add_option( self::OPTION_SEEN, [] );
        }
        if ( false === get_option( self::OPTION_LOG ) ) {
            add_option( self::OPTION_LOG, [] );
        }
        if ( false === get_option( self::OPTION_QUEUE ) ) {
            add_option( self::OPTION_QUEUE, $this->default_toolkit_posts() );
        }
        $this->ensure_categories();
        $this->schedule_event();
        $this->log( 'Plugin activated and cron scheduled.' );
    }

    public function deactivate() {
        $ts = wp_next_scheduled( self::CRON_HOOK );
        if ( $ts ) {
            wp_unschedule_event( $ts, self::CRON_HOOK );
        }
        delete_transient( self::TRANSIENT_LOCK );
        $this->log( 'Plugin deactivated and cron unscheduled.' );
    }

    private function default_settings() {
        $news_cat    = $this->ensure_category( 'Activism News' );
        $toolkit_cat = $this->ensure_category( 'Campaign Toolkit' );
        return [
            'feeds'            => implode( "\n", [
                'https://www.euronews.com/rss?level=theme&name=news',
                'https://www.politico.eu/feed/',
                'https://feeds.bbci.co.uk/news/world/rss.xml',
                'https://feeds.bbci.co.uk/news/world/europe/rss.xml',
                'https://ec.europa.eu/commission/presscorner/home/en/rss.xml',
                'https://www.amnesty.org/en/latest/feed/',
            ] ),
            'post_status'      => 'draft',
            'max_per_run'      => 3,
            'schedule'         => 'fifteen_minutes',
            'default_category' => $news_cat,
            'toolkit_category' => $toolkit_cat,
            'append_toolkit'   => 1,
            'rotate_toolkit'   => 1,
            'enable_soft_cron' => 1,
            'comment_status'   => 'closed',
        ];
    }

    private function ensure_categories() {
        $this->ensure_category( 'Activism News' );
        $this->ensure_category( 'Campaign Toolkit' );
    }

    private function ensure_category( $name ) {
        $term = get_term_by( 'name', $name, 'category' );
        if ( $term && ! is_wp_error( $term ) ) {
            return (int) $term->term_id;
        }
        $result = wp_insert_term( $name, 'category' );
        if ( ! is_wp_error( $result ) && ! empty( $result['term_id'] ) ) {
            return (int) $result['term_id'];
        }
        return 0;
    }

    private function schedule_event() {
        $settings = $this->get_settings();
        $schedule = ! empty( $settings['schedule'] ) ? $settings['schedule'] : 'fifteen_minutes';
        $existing = wp_next_scheduled( self::CRON_HOOK );
        if ( $existing ) {
            wp_unschedule_event( $existing, self::CRON_HOOK );
        }
        wp_schedule_event( time() + 120, $schedule, self::CRON_HOOK );
    }

    private function get_settings() {
        return wp_parse_args( get_option( self::OPTION_SETTINGS, [] ), $this->default_settings() );
    }

    public function register_settings() {
        register_setting( 'acaps_group', self::OPTION_SETTINGS, [ $this, 'sanitize_settings' ] );

        add_settings_section( 'acaps_main', __( 'Main Settings', 'acaps' ), function () {
            echo '<p>Reliable activist/news auto-poster with RSS import, toolkit templates, logs, and a manual run button.</p>';
        }, 'acaps' );

        add_settings_field( 'feeds', 'RSS Feeds (one per line)', [ $this, 'field_feeds' ], 'acaps', 'acaps_main' );
        add_settings_field( 'post_status', 'Post Status', [ $this, 'field_post_status' ], 'acaps', 'acaps_main' );
        add_settings_field( 'max_per_run', 'Max Posts Per Run', [ $this, 'field_max_per_run' ], 'acaps', 'acaps_main' );
        add_settings_field( 'schedule', 'Schedule', [ $this, 'field_schedule' ], 'acaps', 'acaps_main' );
        add_settings_field( 'default_category', 'News Category', [ $this, 'field_default_category' ], 'acaps', 'acaps_main' );
        add_settings_field( 'toolkit_category', 'Toolkit Category', [ $this, 'field_toolkit_category' ], 'acaps', 'acaps_main' );
        add_settings_field( 'append_toolkit', 'Append Activist Toolkit', [ $this, 'field_append_toolkit' ], 'acaps', 'acaps_main' );
        add_settings_field( 'rotate_toolkit', 'Rotate Standalone Toolkit Posts', [ $this, 'field_rotate_toolkit' ], 'acaps', 'acaps_main' );
        add_settings_field( 'enable_soft_cron', 'Fallback Runner', [ $this, 'field_enable_soft_cron' ], 'acaps', 'acaps_main' );
        add_settings_field( 'comment_status', 'Comments', [ $this, 'field_comment_status' ], 'acaps', 'acaps_main' );
    }

    public function sanitize_settings( $input ) {
        $out = $this->get_settings();
        $out['feeds']            = isset( $input['feeds'] ) ? wp_kses_post( $input['feeds'] ) : $out['feeds'];
        $out['post_status']      = in_array( $input['post_status'] ?? 'draft', [ 'draft', 'publish', 'pending' ], true ) ? $input['post_status'] : 'draft';
        $out['max_per_run']      = max( 1, min( 10, (int) ( $input['max_per_run'] ?? 3 ) ) );
        $out['schedule']         = in_array( $input['schedule'] ?? 'fifteen_minutes', [ 'five_minutes', 'fifteen_minutes', 'hourly', 'twicedaily' ], true ) ? $input['schedule'] : 'fifteen_minutes';
        $out['default_category'] = (int) ( $input['default_category'] ?? 0 );
        $out['toolkit_category'] = (int) ( $input['toolkit_category'] ?? 0 );
        $out['append_toolkit']   = empty( $input['append_toolkit'] ) ? 0 : 1;
        $out['rotate_toolkit']   = empty( $input['rotate_toolkit'] ) ? 0 : 1;
        $out['enable_soft_cron'] = empty( $input['enable_soft_cron'] ) ? 0 : 1;
        $out['comment_status']   = in_array( $input['comment_status'] ?? 'closed', [ 'open', 'closed' ], true ) ? $input['comment_status'] : 'closed';

        $existing = wp_next_scheduled( self::CRON_HOOK );
        if ( $existing ) {
            wp_unschedule_event( $existing, self::CRON_HOOK );
        }
        wp_schedule_event( time() + 120, $out['schedule'], self::CRON_HOOK );
        $this->log( 'Settings saved. Cron rescheduled to ' . $out['schedule'] . '.' );

        return $out;
    }

    public function admin_menu() {
        add_options_page( 'Activist Cause Auto Poster', 'Activist Auto Poster', 'manage_options', 'acaps', [ $this, 'settings_page' ] );
    }

    public function settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $settings = $this->get_settings();
        $next_run = wp_next_scheduled( self::CRON_HOOK );
        $last_run = get_option( self::OPTION_LAST_RUN );
        $log      = array_reverse( (array) get_option( self::OPTION_LOG, [] ) );
        echo '<div class="wrap"><h1>Activist Cause Auto Poster</h1>';
        echo '<p><strong>Last run:</strong> ' . esc_html( $last_run ? gmdate( 'Y-m-d H:i:s', (int) $last_run ) . ' UTC' : 'Never' ) . '<br>';
        echo '<strong>Next scheduled run:</strong> ' . esc_html( $next_run ? gmdate( 'Y-m-d H:i:s', (int) $next_run ) . ' UTC' : 'Not scheduled' ) . '</p>';
        echo '<p>';
        echo '<a class="button button-primary" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=acaps_run_now' ), self::NONCE_ACTION ) ) . '">Run now</a> ';
        echo '<a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=acaps_reset_seen' ), self::NONCE_ACTION ) ) . '">Reset seen items</a>';
        echo '</p>';
        echo '<form method="post" action="options.php">';
        settings_fields( 'acaps_group' );
        do_settings_sections( 'acaps' );
        submit_button();
        echo '</form>';
        echo '<h2>Recent log</h2><div style="background:#fff;border:1px solid #ccd0d4;padding:12px;max-width:1000px;">';
        if ( empty( $log ) ) {
            echo '<p>No log entries yet.</p>';
        } else {
            echo '<ol>';
            foreach ( array_slice( $log, 0, 30 ) as $entry ) {
                echo '<li><code>' . esc_html( $entry ) . '</code></li>';
            }
            echo '</ol>';
        }
        echo '</div>';
        echo '<p><em>Important: WP-Cron only fires when WordPress is visited. For true overnight posting, add a real server cron that hits wp-cron.php every 5 minutes.</em></p>';
        echo '</div>';
    }

    public function field_feeds() {
        $s = $this->get_settings();
        printf( '<textarea name="%1$s[feeds]" rows="8" style="width:100%%">%2$s</textarea>', esc_attr( self::OPTION_SETTINGS ), esc_textarea( $s['feeds'] ) );
    }
    public function field_post_status() {
        $s = $this->get_settings();
        echo '<select name="' . esc_attr( self::OPTION_SETTINGS ) . '[post_status]">';
        foreach ( [ 'draft' => 'Draft', 'pending' => 'Pending Review', 'publish' => 'Publish' ] as $k => $label ) {
            echo '<option value="' . esc_attr( $k ) . '" ' . selected( $s['post_status'], $k, false ) . '>' . esc_html( $label ) . '</option>';
        }
        echo '</select>';
    }
    public function field_max_per_run() {
        $s = $this->get_settings();
        printf( '<input type="number" min="1" max="10" name="%1$s[max_per_run]" value="%2$d">', esc_attr( self::OPTION_SETTINGS ), (int) $s['max_per_run'] );
    }
    public function field_schedule() {
        $s = $this->get_settings();
        echo '<select name="' . esc_attr( self::OPTION_SETTINGS ) . '[schedule]">';
        foreach ( [ 'five_minutes' => 'Every 5 minutes', 'fifteen_minutes' => 'Every 15 minutes', 'hourly' => 'Hourly', 'twicedaily' => 'Twice daily' ] as $k => $label ) {
            echo '<option value="' . esc_attr( $k ) . '" ' . selected( $s['schedule'], $k, false ) . '>' . esc_html( $label ) . '</option>';
        }
        echo '</select>';
    }
    public function field_default_category() {
        $s = $this->get_settings();
        wp_dropdown_categories( [
            'hide_empty'       => 0,
            'name'             => self::OPTION_SETTINGS . '[default_category]',
            'selected'         => (int) $s['default_category'],
            'show_option_none' => '— None —',
        ] );
    }
    public function field_toolkit_category() {
        $s = $this->get_settings();
        wp_dropdown_categories( [
            'hide_empty'       => 0,
            'name'             => self::OPTION_SETTINGS . '[toolkit_category]',
            'selected'         => (int) $s['toolkit_category'],
            'show_option_none' => '— None —',
        ] );
    }
    public function field_append_toolkit() {
        $s = $this->get_settings();
        printf( '<label><input type="checkbox" name="%1$s[append_toolkit]" value="1" %2$s> Add activist action guidance under imported news posts</label>', esc_attr( self::OPTION_SETTINGS ), checked( ! empty( $s['append_toolkit'] ), true, false ) );
    }
    public function field_rotate_toolkit() {
        $s = $this->get_settings();
        printf( '<label><input type="checkbox" name="%1$s[rotate_toolkit]" value="1" %2$s> Publish standalone campaign toolkit posts when nothing new arrives</label>', esc_attr( self::OPTION_SETTINGS ), checked( ! empty( $s['rotate_toolkit'] ), true, false ) );
    }
    public function field_enable_soft_cron() {
        $s = $this->get_settings();
        printf( '<label><input type="checkbox" name="%1$s[enable_soft_cron]" value="1" %2$s> Trigger a fallback run on normal site visits when cron is overdue</label>', esc_attr( self::OPTION_SETTINGS ), checked( ! empty( $s['enable_soft_cron'] ), true, false ) );
    }
    public function field_comment_status() {
        $s = $this->get_settings();
        echo '<select name="' . esc_attr( self::OPTION_SETTINGS ) . '[comment_status]">';
        foreach ( [ 'closed' => 'Comments closed', 'open' => 'Comments open' ] as $k => $label ) {
            echo '<option value="' . esc_attr( $k ) . '" ' . selected( $s['comment_status'], $k, false ) . '>' . esc_html( $label ) . '</option>';
        }
        echo '</select>';
    }

    public function handle_run_now() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Forbidden' );
        }
        check_admin_referer( self::NONCE_ACTION );
        $this->run( true );
        wp_safe_redirect( admin_url( 'options-general.php?page=acaps' ) );
        exit;
    }

    public function handle_reset_seen() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Forbidden' );
        }
        check_admin_referer( self::NONCE_ACTION );
        update_option( self::OPTION_SEEN, [] );
        $this->log( 'Seen items reset by admin.' );
        wp_safe_redirect( admin_url( 'options-general.php?page=acaps' ) );
        exit;
    }

    public function soft_cron_fallback() {
        if ( is_admin() ) {
            return;
        }
        $settings = $this->get_settings();
        if ( empty( $settings['enable_soft_cron'] ) ) {
            return;
        }
        $last_run = (int) get_option( self::OPTION_LAST_RUN, 0 );
        if ( $last_run > 0 && ( time() - $last_run ) < 1200 ) {
            return;
        }
        if ( get_transient( self::TRANSIENT_LOCK ) ) {
            return;
        }
        $this->run();
    }

    public function run( $manual = false ) {
        if ( get_transient( self::TRANSIENT_LOCK ) ) {
            $this->log( 'Run skipped because another run is in progress.' );
            return;
        }
        set_transient( self::TRANSIENT_LOCK, 1, 300 );
        update_option( self::OPTION_LAST_RUN, time() );

        $settings  = $this->get_settings();
        $feeds     = $this->parse_feeds( $settings['feeds'] );
        $max_posts = max( 1, (int) $settings['max_per_run'] );
        $posted    = 0;

        if ( ! function_exists( 'fetch_feed' ) ) {
            require_once ABSPATH . WPINC . '/feed.php';
        }

        foreach ( $feeds as $feed_url ) {
            if ( $posted >= $max_posts ) {
                break;
            }

            $feed = fetch_feed( $feed_url );
            if ( is_wp_error( $feed ) ) {
                $this->log( 'Feed error: ' . $feed_url . ' :: ' . $feed->get_error_message() );
                continue;
            }

            $items = $feed->get_items( 0, 10 );
            if ( empty( $items ) ) {
                $this->log( 'No items found in feed: ' . $feed_url );
                continue;
            }

            foreach ( $items as $item ) {
                if ( $posted >= $max_posts ) {
                    break;
                }

                $guid = (string) $item->get_id( true );
                if ( $this->is_seen( $guid ) ) {
                    continue;
                }

                $title   = wp_strip_all_tags( (string) $item->get_title() );
                $link    = esc_url_raw( (string) $item->get_link() );
                $summary = wp_strip_all_tags( (string) ( $item->get_description() ?: $item->get_content() ) );
                if ( empty( $title ) || empty( $link ) ) {
                    continue;
                }

                $issue       = $this->detect_issue( $title . ' ' . $summary );
                $post_title   = $this->truncate( $title, 140 );
                $post_content = $this->build_news_post_content( $title, $summary, $link, $issue, ! empty( $settings['append_toolkit'] ) );

                $postarr = [
                    'post_title'     => $post_title,
                    'post_content'   => $post_content,
                    'post_status'    => $settings['post_status'],
                    'post_type'      => 'post',
                    'post_category'  => ! empty( $settings['default_category'] ) ? [ (int) $settings['default_category'] ] : [],
                    'comment_status' => $settings['comment_status'],
                    'meta_input'     => [
                        '_acaps_source_url' => $link,
                        '_acaps_issue'      => $issue,
                        '_acaps_feed_url'   => $feed_url,
                    ],
                ];

                $post_id = wp_insert_post( $postarr, true );
                if ( is_wp_error( $post_id ) ) {
                    $this->log( 'Post insert failed for "' . $title . '": ' . $post_id->get_error_message() );
                    continue;
                }

                $this->mark_seen( $guid );
                $posted++;
                $this->log( 'Posted news item #' . $post_id . ' from ' . $feed_url . ' with issue ' . $issue . '.' );
            }
        }

        if ( 0 === $posted && ! empty( $settings['rotate_toolkit'] ) ) {
            $this->post_next_toolkit();
        } elseif ( 0 === $posted ) {
            $this->log( $manual ? 'Manual run completed with no new feed items.' : 'Scheduled run completed with no new feed items.' );
        }

        delete_transient( self::TRANSIENT_LOCK );
    }

    private function parse_feeds( $feeds_text ) {
        $lines = array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $feeds_text ) ) );
        $urls  = [];
        foreach ( $lines as $line ) {
            if ( filter_var( $line, FILTER_VALIDATE_URL ) ) {
                $urls[] = $line;
            }
        }
        return array_values( array_unique( $urls ) );
    }

    private function detect_issue( $text ) {
        $text = strtolower( $text );
        $map  = [
            'housing'        => [ 'housing', 'rent', 'tenant', 'eviction', 'shelter', 'property' ],
            'labor-rights'   => [ 'labour', 'labor', 'union', 'strike', 'wages', 'worker', 'workers', 'employment' ],
            'climate'        => [ 'climate', 'emissions', 'carbon', 'pollution', 'environment', 'green' ],
            'health'         => [ 'health', 'hospital', 'care', 'medicine', 'patient', 'public health' ],
            'education'      => [ 'education', 'school', 'student', 'teacher', 'university' ],
            'migration'      => [ 'migration', 'migrant', 'refugee', 'asylum', 'border' ],
            'democracy'      => [ 'democracy', 'election', 'voting', 'civic', 'rights', 'constitution', 'parliament' ],
            'gender-equality'=> [ 'gender', 'women', 'feminist', 'equality', 'lgbt', 'trans' ],
        ];
        foreach ( $map as $issue => $keywords ) {
            foreach ( $keywords as $keyword ) {
                if ( false !== strpos( $text, $keyword ) ) {
                    return $issue;
                }
            }
        }
        return 'public-interest';
    }

    private function build_news_post_content( $title, $summary, $link, $issue, $append_toolkit ) {
        $content  = '<p><strong>Source headline:</strong> ' . esc_html( $title ) . '</p>';
        $content .= '<p>' . esc_html( $this->truncate( $summary, 900 ) ) . '</p>';
        $content .= '<p><a href="' . esc_url( $link ) . '" target="_blank" rel="noopener noreferrer">Read the source article</a></p>';
        $content .= '<h2>Why this matters for activism</h2>';
        $content .= '<p>This development connects to the issue area of <strong>' . esc_html( ucwords( str_replace( '-', ' ', $issue ) ) ) . '</strong>. Activism in this area means turning public concern into organized civic pressure through research, testimony, coalition building, public communication, legal advocacy, local meetings, visible protest, and policy demands.</p>';

        if ( $append_toolkit ) {
            $content .= $this->build_toolkit_section( $issue );
        }
        return wp_kses_post( $content );
    }

    private function build_toolkit_section( $issue ) {
        $section  = '<h2>What engaging in this activism involves</h2>';
        $section .= '<p>Effective activism usually starts with documenting the problem, identifying who has decision-making power, collecting stories from affected people, checking the law and local rules, and defining one or two concrete demands. It also includes outreach, poster or flyer design, social media messaging, coalition building, media contact, volunteer roles, and follow-up after the action.</p>';
        $section .= '<h3>Activities people can organize</h3>';
        $section .= '<ul>';
        $section .= '<li>public information campaigns and teach-ins</li>';
        $section .= '<li>peaceful demonstrations, rallies, vigils, and assemblies</li>';
        $section .= '<li>petition drives, signature collection, and open letters</li>';
        $section .= '<li>community meetings, press briefings, and testimony collection</li>';
        $section .= '<li>mutual-aid support tied to a policy demand</li>';
        $section .= '</ul>';
        $section .= '<h3>How to organize a peaceful protest</h3>';
        $section .= '<ol>';
        $section .= '<li>Choose one clear demand connected to the issue.</li>';
        $section .= '<li>Pick a symbolic location linked to the institution or policy-maker.</li>';
        $section .= '<li>Check permit, assembly, accessibility, and safety requirements in your municipality.</li>';
        $section .= '<li>Assign roles: organizers, marshals, speakers, media contact, legal observer, and accessibility support.</li>';
        $section .= '<li>Prepare signs, chants, a press note, and a short public statement.</li>';
        $section .= '<li>Tell participants the plan, meeting point, code of conduct, and de-escalation approach.</li>';
        $section .= '<li>Document turnout, press response, and the authority response after the action.</li>';
        $section .= '</ol>';
        $section .= '<h3>How to organize a petition campaign</h3>';
        $section .= '<ol>';
        $section .= '<li>State the target clearly: council, ministry, landlord, school board, employer, or parliament.</li>';
        $section .= '<li>Write a short explanation of the problem and the exact requested change.</li>';
        $section .= '<li>Set a realistic signature goal and a hand-in date.</li>';
        $section .= '<li>Collect signatures online and offline with the same message.</li>';
        $section .= '<li>Use testimonies, visuals, and regular updates to keep people engaged.</li>';
        $section .= '<li>Plan the delivery moment as a public event with speakers and press outreach.</li>';
        $section .= '</ol>';
        $section .= '<h3>After the action</h3>';
        $section .= '<p>Send follow-up emails, publish a recap, thank participants, invite new volunteers into a next step, and keep pressure on the decision-maker with meetings, letters, and repeat actions if necessary.</p>';
        $section .= '<p><em>Editorial note:</em> Keep actions lawful, nonviolent, accessible, and grounded in verified information.</p>';
        return $section;
    }

    private function default_toolkit_posts() {
        return [
            [
                'title'   => 'How to build a local petition campaign',
                'content' => '<p>A petition campaign works best when it names a decision-maker, a practical policy change, and a deadline. Start by writing a one-sentence demand, then explain why it matters, whose lives are affected, and what should change now. Build momentum with a launch statement, a simple signature form, public updates, local outreach, and a public hand-in moment.</p>' . $this->build_toolkit_section( 'public-interest' ),
            ],
            [
                'title'   => 'How to organize a peaceful protest with clear goals',
                'content' => '<p>A protest is most effective when it is visible, focused, and disciplined. Organizers should define the message, choose the right place and time, coordinate legal and accessibility needs, and prepare speakers, marshals, and media materials. The event should communicate one clear demand and lead participants toward a next action.</p>' . $this->build_toolkit_section( 'public-interest' ),
            ],
            [
                'title'   => 'Turning breaking news into a sustained civic campaign',
                'content' => '<p>Breaking news can create urgency, but lasting change usually requires more than one news cycle. A campaign should move from reaction to structure: verify the facts, identify the accountable institution, collect stories, develop demands, plan a public action, and keep supporters engaged through updates, meetings, and repeated contact with decision-makers.</p>' . $this->build_toolkit_section( 'public-interest' ),
            ],
        ];
    }

    private function post_next_toolkit() {
        $queue = get_option( self::OPTION_QUEUE, [] );
        if ( empty( $queue ) || ! is_array( $queue ) ) {
            $queue = $this->default_toolkit_posts();
        }

        $next = array_shift( $queue );
        update_option( self::OPTION_QUEUE, $queue );

        $settings = $this->get_settings();
        $post_id  = wp_insert_post( [
            'post_title'     => sanitize_text_field( $next['title'] ),
            'post_content'   => wp_kses_post( $next['content'] ),
            'post_status'    => $settings['post_status'],
            'post_type'      => 'post',
            'post_category'  => ! empty( $settings['toolkit_category'] ) ? [ (int) $settings['toolkit_category'] ] : [],
            'comment_status' => $settings['comment_status'],
            'meta_input'     => [ '_acaps_toolkit' => 1 ],
        ], true );

        if ( is_wp_error( $post_id ) ) {
            $this->log( 'Toolkit post failed: ' . $post_id->get_error_message() );
            return;
        }

        $this->log( 'Published toolkit post #' . $post_id . '.' );
    }

    private function truncate( $text, $length = 140 ) {
        $text = trim( (string) $text );
        if ( strlen( $text ) <= $length ) {
            return $text;
        }
        return rtrim( substr( $text, 0, $length - 1 ) ) . '…';
    }

    private function is_seen( $guid ) {
        $seen = (array) get_option( self::OPTION_SEEN, [] );
        return ! empty( $seen[ $guid ] );
    }

    private function mark_seen( $guid ) {
        $seen          = (array) get_option( self::OPTION_SEEN, [] );
        $seen[ $guid ] = time();
        if ( count( $seen ) > 5000 ) {
            $seen = array_slice( $seen, -4000, null, true );
        }
        update_option( self::OPTION_SEEN, $seen );
    }

    private function log( $message ) {
        $log   = (array) get_option( self::OPTION_LOG, [] );
        $log[] = gmdate( 'Y-m-d H:i:s' ) . ' UTC :: ' . $message;
        if ( count( $log ) > 200 ) {
            $log = array_slice( $log, -200 );
        }
        update_option( self::OPTION_LOG, $log );
    }
}

new ACAPS_Activator();
}
