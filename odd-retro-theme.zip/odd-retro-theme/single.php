<?php get_header(); ?>
<main class="odd-main">
    <section>
        <?php while (have_posts()) : the_post(); ?>
            <article class="odd-box odd-article">
                <h1 class="odd-title"><?php the_title(); ?></h1>
                <div class="odd-meta"><?php echo esc_html(get_the_date()); ?></div>
                <div class="odd-content"><?php the_content(); ?></div>
            </article>

            <?php
            if (comments_open() || get_comments_number()) {
                comments_template();
            }
            ?>
        <?php endwhile; ?>
    </section>
    <?php get_sidebar(); ?>
</main>
<?php get_footer(); ?>
