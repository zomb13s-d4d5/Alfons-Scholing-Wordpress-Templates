<?php if (!defined('ABSPATH')) { exit; } ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="odd-shell">
    <div class="odd-frame">
        <header class="odd-header">
            <div class="odd-brand">
                <a class="odd-logo odd-logo-ascii" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php bloginfo('name'); ?>">
                    <pre aria-hidden="true">  ____   ____   ____
 / __ \ |  _ \ |  _ \
| |  | || | | || | | |
| |  | || | | || | | |
| |__| || |_| || |_| |
 \____/ |____/ |____/</pre>
                    <span class="screen-reader-text"><?php bloginfo('name'); ?></span>
                </a>
                <div class="odd-subtitle">
                    <?php echo esc_html(get_bloginfo('description') ?: 'Discuss. Participate. Decide together.'); ?>
                </div>
            </div>

            <nav class="odd-nav" aria-label="<?php esc_attr_e('Primary menu', 'odd-retro'); ?>">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'container'      => false,
                    'fallback_cb'    => 'odd_retro_menu_fallback',
                    'menu_class'     => '',
                ));
                ?>
            </nav>
        </header>
