<?php
if (!defined('ABSPATH')) {
    exit;
}

function odd_retro_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));

    register_nav_menus(array(
        'primary' => __('Primary Menu', 'odd-retro'),
        'footer'  => __('Footer Menu', 'odd-retro'),
    ));
}
add_action('after_setup_theme', 'odd_retro_setup');

function odd_retro_widgets_init() {
    register_sidebar(array(
        'name'          => __('Sidebar', 'odd-retro'),
        'id'            => 'sidebar-1',
        'description'   => __('Main sidebar widgets.', 'odd-retro'),
        'before_widget' => '<section class="odd-box widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));
}
add_action('widgets_init', 'odd_retro_widgets_init');

function odd_retro_enqueue_assets() {
    wp_enqueue_style(
        'odd-retro-fonts',
        'https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap',
        array(),
        null
    );

    wp_enqueue_style(
        'odd-retro-style',
        get_stylesheet_uri(),
        array('odd-retro-fonts'),
        wp_get_theme()->get('Version')
    );
}
add_action('wp_enqueue_scripts', 'odd_retro_enqueue_assets');

function odd_retro_menu_fallback() {
    echo '<ul>';
    wp_list_pages(array(
        'title_li' => '',
        'depth'    => 1,
    ));
    echo '</ul>';
}
