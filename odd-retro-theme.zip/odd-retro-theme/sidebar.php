<aside class="odd-sidebar">
    <?php if (is_active_sidebar('sidebar-1')) : ?>
        <?php dynamic_sidebar('sidebar-1'); ?>
    <?php else : ?>
        <section class="odd-box">
            <h2><?php esc_html_e('Categories', 'odd-retro'); ?></h2>
            <ul>
                <?php wp_list_categories(array('title_li' => '')); ?>
            </ul>
        </section>

        <section class="odd-box">
            <h2><?php esc_html_e('News', 'odd-retro'); ?></h2>
            <ul>
                <li><?php esc_html_e('Welcome to ODD Debate.', 'odd-retro'); ?></li>
                <li><?php esc_html_e('Join the conversation.', 'odd-retro'); ?></li>
                <li><?php esc_html_e('Your voice matters.', 'odd-retro'); ?></li>
            </ul>
        </section>
    <?php endif; ?>
</aside>
