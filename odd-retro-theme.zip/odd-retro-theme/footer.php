        <footer class="odd-footer">
            <div class="odd-footer-brand">ODD</div>
            <div>Free. Open. Democratic.</div>
            <nav aria-label="<?php esc_attr_e('Footer menu', 'odd-retro'); ?>">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'footer',
                    'container'      => false,
                    'fallback_cb'    => false,
                    'menu_class'     => '',
                ));
                ?>
            </nav>
        </footer>
    </div>
</div>
<?php wp_footer(); ?>
</body>
</html>
