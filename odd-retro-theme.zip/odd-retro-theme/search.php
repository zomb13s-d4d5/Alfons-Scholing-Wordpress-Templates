<?php get_header(); ?>
<main class="odd-main">
    <section>
        <h1 class="odd-title"><?php printf(esc_html__('Search Results: %s', 'odd-retro'), get_search_query()); ?></h1>
        <?php if (have_posts()) : ?>
            <ul class="odd-postlist">
                <?php while (have_posts()) : the_post(); ?>
                    <li class="odd-post">
                        <div>
                            <a class="odd-postlink" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </div>
                        <a class="odd-readmore" href="<?php the_permalink(); ?>"><?php esc_html_e('Read More', 'odd-retro'); ?></a>
                    </li>
                <?php endwhile; ?>
            </ul>
            <div class="odd-pagination"><?php echo paginate_links(array('type' => 'plain')); ?></div>
        <?php else : ?>
            <section class="odd-box"><p><?php esc_html_e('No results found.', 'odd-retro'); ?></p></section>
        <?php endif; ?>
    </section>
    <?php get_sidebar(); ?>
</main>
<?php get_footer(); ?>
