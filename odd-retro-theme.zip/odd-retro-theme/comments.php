<?php
if (post_password_required()) {
    return;
}
?>
<section id="comments" class="odd-box odd-comments">
    <?php if (have_comments()) : ?>
        <h2 class="odd-comments-title">
            <?php
            $comment_count = get_comments_number();
            if ('1' === (string) $comment_count) {
                esc_html_e('1 Comment', 'odd-retro');
            } else {
                printf(
                    /* translators: %s: number of comments */
                    esc_html(_nx('%s Comment', '%s Comments', $comment_count, 'comments title', 'odd-retro')),
                    esc_html(number_format_i18n($comment_count))
                );
            }
            ?>
        </h2>

        <ol class="odd-comment-list">
            <?php
            wp_list_comments(array(
                'style'      => 'ol',
                'short_ping' => true,
                'avatar_size'=> 48,
            ));
            ?>
        </ol>

        <?php the_comments_navigation(); ?>
    <?php endif; ?>

    <?php if (!comments_open() && get_comments_number() && post_type_supports(get_post_type(), 'comments')) : ?>
        <p class="odd-comments-closed"><?php esc_html_e('Comments are closed.', 'odd-retro'); ?></p>
    <?php endif; ?>

    <?php
    comment_form(array(
        'class_submit'         => 'odd-comment-submit',
        'title_reply_before'   => '<h2 id="reply-title" class="comment-reply-title odd-comments-title">',
        'title_reply_after'    => '</h2>',
        'comment_notes_before' => '<p class="comment-notes">' . esc_html__('Your email address will not be published.', 'odd-retro') . '</p>',
        'comment_field'        => '<p class="comment-form-comment"><label for="comment">' . esc_html_x('Comment', 'noun', 'odd-retro') . '</label><textarea id="comment" name="comment" cols="45" rows="8" maxlength="65525" required></textarea></p>',
    ));
    ?>
</section>
