<?php
if (!defined('ABSPATH')) exit;
define('PA_THEME_VERSION', '1.0.3');
function pa_setup() {
  add_theme_support('title-tag'); add_theme_support('post-thumbnails');
  add_theme_support('custom-logo', array('height'=>300,'width'=>300,'flex-height'=>true,'flex-width'=>true));
  add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
  register_nav_menus(array('primary' => __('Bottom Menu', 'pawn-army')));
  add_image_size('pa_tile', 900, 620, true);
}
add_action('after_setup_theme', 'pa_setup');
function pa_assets() {
  wp_enqueue_style('pawn-army-style', get_stylesheet_uri(), array(), PA_THEME_VERSION);
  wp_enqueue_script('pawn-army-js', get_template_directory_uri() . '/assets/js/pawnarmy.js', array(), PA_THEME_VERSION, true);
  $base = get_template_directory_uri() . '/assets/images/';
  wp_localize_script('pawn-army-js', 'PawnArmyTheme', array('backgrounds' => array($base.'bg-01.webp',$base.'bg-02.webp',$base.'bg-03.webp')));
}
add_action('wp_enqueue_scripts', 'pa_assets');
function pa_fallback_image() { return get_template_directory_uri() . '/assets/images/fallback-post.webp'; }
function pa_logo_image() { return get_template_directory_uri() . '/assets/images/pawn-army-logo.png'; }
function pa_excerpt($limit = 22) { $txt = get_the_excerpt() ?: wp_strip_all_tags(get_the_content()); return wp_trim_words($txt, $limit, '…'); }
