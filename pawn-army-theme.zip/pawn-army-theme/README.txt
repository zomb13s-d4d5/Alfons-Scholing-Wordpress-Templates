Pawn Army WordPress Theme 1.0.0

Install:
1. Upload pawn-army-theme.zip in WordPress Appearance > Themes > Add New > Upload Theme.
2. Activate Pawn Army.
3. Add four or more posts with featured images. Missing featured images use the included default image.
4. Set Appearance > Menus > Bottom Menu for the bottom hooded menu.

Included: three rotating Pawn Army backgrounds, iOS-first 100svh viewport layout, four latest-post image tiles, bottom logo menu, lightbox, comments, single/page/archive/category templates.
