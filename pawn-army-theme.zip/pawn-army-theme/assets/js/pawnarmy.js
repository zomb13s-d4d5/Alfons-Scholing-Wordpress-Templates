(function(){
  const cfg=window.PawnArmyTheme||{},bgs=cfg.backgrounds||[],rotator=document.querySelector('.pa-bg-rotator');
  if(rotator&&bgs.length){
    bgs.forEach((src,i)=>{const s=document.createElement('div');s.className='pa-bg-slide'+(i===0?' is-active':'');s.style.backgroundImage=`url("${src}")`;rotator.appendChild(s)});
    let i=0,slides=[...rotator.querySelectorAll('.pa-bg-slide')];
    setInterval(()=>{slides[i].classList.remove('is-active');i=(i+1)%slides.length;slides[i].classList.add('is-active')},7000);
  }

  document.querySelectorAll('[data-pa-slider]').forEach(slider=>{
    const track=slider.querySelector('.pa-slider-track');
    const slides=[...slider.querySelectorAll('.pa-slide')];
    const dots=[...slider.querySelectorAll('.pa-dot')];
    const prev=slider.querySelector('.pa-slider-prev');
    const next=slider.querySelector('.pa-slider-next');
    if(!track||slides.length<1)return;
    let current=0,timer=null,startX=0,dragging=false;
    function go(n,userAction){
      current=(n+slides.length)%slides.length;
      track.style.transform=`translate3d(${-current*100}%,0,0)`;
      slides.forEach((s,i)=>s.classList.toggle('is-active',i===current));
      dots.forEach((d,i)=>{d.classList.toggle('is-active',i===current);d.setAttribute('aria-selected',i===current?'true':'false')});
      if(userAction)restart();
    }
    function restart(){clearInterval(timer); if(slides.length>1) timer=setInterval(()=>go(current+1,false),9000);}
    dots.forEach((d,i)=>d.addEventListener('click',()=>go(i,true)));
    prev&&prev.addEventListener('click',()=>go(current-1,true));
    next&&next.addEventListener('click',()=>go(current+1,true));
    slider.addEventListener('pointerdown',e=>{dragging=true;startX=e.clientX;slider.setPointerCapture&&slider.setPointerCapture(e.pointerId)});
    slider.addEventListener('pointerup',e=>{if(!dragging)return;dragging=false;const dx=e.clientX-startX;if(Math.abs(dx)>45)go(current+(dx<0?1:-1),true)});
    slider.addEventListener('pointercancel',()=>{dragging=false});
    slider.addEventListener('mouseenter',()=>clearInterval(timer));
    slider.addEventListener('mouseleave',restart);
    go(0,false);restart();
  });

  const btn=document.querySelector('.pa-bottom-menu'),panel=document.querySelector('#pa-menu-panel');
  if(btn&&panel){btn.addEventListener('click',()=>{const open=panel.classList.toggle('is-open');btn.setAttribute('aria-expanded',open?'true':'false')})}

  const lb=document.querySelector('.pa-lightbox');
  if(lb){
    const img=lb.querySelector('img'),close=lb.querySelector('button');
    document.addEventListener('click',e=>{const a=e.target.closest('a');if(!a)return;const href=a.getAttribute('href')||'';if(a.classList.contains('pa-lightbox-link')||/\.(png|jpe?g|gif|webp|avif)(\?.*)?$/i.test(href)){e.preventDefault();img.src=href;lb.classList.add('is-open');lb.setAttribute('aria-hidden','false');document.body.classList.add('pa-lock')}});
    function shut(){lb.classList.remove('is-open');lb.setAttribute('aria-hidden','true');img.src='';document.body.classList.remove('pa-lock')}
    close.addEventListener('click',shut);lb.addEventListener('click',e=>{if(e.target===lb)shut()});document.addEventListener('keydown',e=>{if(e.key==='Escape')shut()});
  }
})();
