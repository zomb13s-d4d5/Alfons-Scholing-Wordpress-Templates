<?php get_header(); ?>
<main class="pa-site">
  <section class="pa-frame" aria-label="<?php esc_attr_e('Latest Pawn Army articles','pawn-army'); ?>">
    <header class="pa-brandline"><strong>Pawn Army</strong><span>Real World Chess Tactics</span></header>

    <div class="pa-article-slider" data-pa-slider aria-roledescription="carousel" aria-label="<?php esc_attr_e('Latest articles slider','pawn-army'); ?>">
      <div class="pa-slider-track">
        <?php
        $q = new WP_Query(array('posts_per_page'=>12,'ignore_sticky_posts'=>true));
        $cards = array();
        ob_start();
        if ($q->have_posts()) :
          while ($q->have_posts()) : $q->the_post();
            $img = get_the_post_thumbnail_url(get_the_ID(), 'pa_tile') ?: pa_fallback_image(); ?>
            <article <?php post_class('pa-card'); ?>>
              <a href="<?php the_permalink(); ?>" aria-label="<?php the_title_attribute(); ?>">
                <div class="pa-card__image"><img src="<?php echo esc_url($img); ?>" alt="" loading="lazy"></div>
                <div class="pa-card__shade"></div>
                <div class="pa-card__body"><h2 class="pa-card__title"><?php the_title(); ?></h2><p class="pa-card__excerpt"><?php echo esc_html(pa_excerpt()); ?></p></div>
              </a>
            </article>
          <?php endwhile; wp_reset_postdata();
        else:
          for($i=1;$i<=8;$i++): ?>
            <article class="pa-card">
              <div class="pa-card__image"><img src="<?php echo esc_url(pa_fallback_image()); ?>" alt=""></div>
              <div class="pa-card__shade"></div>
              <div class="pa-card__body"><h2 class="pa-card__title">One smart move changes the board</h2><p class="pa-card__excerpt">Add posts with featured images to populate this tactical slider.</p></div>
            </article>
          <?php endfor;
        endif;
        $html = trim(ob_get_clean());
        preg_match_all('/<article[\s\S]*?<\/article>/', $html, $matches);
        $chunks = array_chunk($matches[0], 4);
        foreach ($chunks as $si => $chunk): ?>
          <div class="pa-slide<?php echo $si === 0 ? ' is-active' : ''; ?>" role="group" aria-roledescription="slide" aria-label="<?php echo esc_attr(($si+1) . ' / ' . count($chunks)); ?>">
            <div class="pa-grid"><?php echo implode('', $chunk); ?></div>
          </div>
        <?php endforeach; ?>
      </div>

      <button class="pa-slider-arrow pa-slider-prev" type="button" aria-label="<?php esc_attr_e('Previous articles','pawn-army'); ?>">‹</button>
      <button class="pa-slider-arrow pa-slider-next" type="button" aria-label="<?php esc_attr_e('Next articles','pawn-army'); ?>">›</button>
      <div class="pa-dots" role="tablist" aria-label="<?php esc_attr_e('Article pages','pawn-army'); ?>">
        <?php for($i=0;$i<count($chunks);$i++): ?>
          <button class="pa-dot<?php echo $i === 0 ? ' is-active' : ''; ?>" type="button" data-pa-slide="<?php echo esc_attr($i); ?>" aria-label="<?php echo esc_attr__('Show article page ','pawn-army') . esc_attr($i+1); ?>" aria-selected="<?php echo $i === 0 ? 'true' : 'false'; ?>"></button>
        <?php endfor; ?>
      </div>
    </div>
  </section>
</main>
<?php get_footer(); ?>
