<?php
/*
Plugin Name: Go Weekly Lesson Scheduler Plus
Description: Posts hourly Go lessons for an entire week (168 lessons) and repeats indefinitely. Each lesson is English with original terms in Japanese (kanji/kana/romaji), includes real-world news analogies pulled from the same RSS sources, and is tagged by Skill Level, Game Phase, Playing Color, and Tactic Category.
Version: 1.0.0
Author: NotYouAgain.ai Studio
License: GPL2+
*/

if (!defined('ABSPATH')) { exit; }

class Go_Weekly_Lesson_Scheduler_Plus {

    const OPT_STATE     = 'go_weekly_lesson_state_plus';   // ['index'=>int]
    const CRON_HOOK     = 'go_weekly_lesson_scheduler_plus_hourly';
    const BOT_USERNAME  = 'GoWeeklyLessonBot';
    const BOT_DISPLAY   = 'Go Weekly Lesson Bot';
    const BOT_EMAIL     = 'go-weekly-bot@example.com';

    private $feed_urls = array(
        // Same sources as other plugin (filterable)
        'https://www.euronews.com/rss?format=mrss',
        'https://feeds.bbci.co.uk/news/rss.xml',
        'https://www.reuters.com/rssFeed/worldNews',
        'https://rss.nytimes.com/services/xml/rss/nyt/World.xml',
        'https://www.aljazeera.com/xml/rss/all.xml'
    );

    // Day themes (Mon..Sun) and base tactics/skill focus
    private $day_themes = array(
        0 => array('name'=>'Monday','focus'=>'Fundamentals','skill'=>'Beginner','phase'=>'Opening','tactic'=>'shape','keywords'=>array('resource','water','local','governance','safety')),
        1 => array('name'=>'Tuesday','focus'=>'Shape & Connection','skill'=>'Beginner','phase'=>'Middle Game','tactic'=>'shape','keywords'=>array('infrastructure','network','cooperation','data','bridge')),
        2 => array('name'=>'Wednesday','focus'=>'Local Tactics','skill'=>'Intermediate','phase'=>'Middle Game','tactic'=>'tesuji','keywords'=>array('crisis','negotiation','conflict','rescue','tactics')),
        3 => array('name'=>'Thursday','focus'=>'Whole-Board Vision','skill'=>'Intermediate','phase'=>'Opening','tactic'=>'fuseki','keywords'=>array('policy','planning','strategy','geopolitics','balance')),
        4 => array('name'=>'Friday','focus'=>'Joseki & Habit','skill'=>'Advanced','phase'=>'Opening','tactic'=>'joseki','keywords'=>array('playbook','pattern','routine','innovation','design system')),
        5 => array('name'=>'Saturday','focus'=>'Endgame Precision','skill'=>'Advanced','phase'=>'Endgame','tactic'=>'yose','keywords'=>array('election','market','deadline','count','margin')),
        6 => array('name'=>'Sunday','focus'=>'Philosophy & Ko','skill'=>'Professional','phase'=>'Middle Game','tactic'=>'life-and-death','keywords'=>array('ethics','art','debate','policy','loop'))
    );

    // Japanese original terms (kanji/kana + romaji) for references
    private $jp_terms = array(
        'tesuji' => '手筋 (tesuji)',
        'life-and-death' => '詰碁 / 死活 (tsumego / shikatsu)',
        'joseki' => '定石 (joseki)',
        'fuseki' => '布石 (fuseki)',
        'yose' => '寄せ (yose)',
        'shape' => '形 (katachi)'
    );

    private $closings = array(
        'Even pros revisit basics weekly — repetition hardens intuition.',
        'Read one move deeper this hour than you did last hour.',
        'Strong connections, light shape, and steady rhythm win long games.',
        'Fuseki frames the story; yose writes the final line.',
        'Small endgame points decide big outcomes — count carefully.'
    );

    public function __construct() {
        add_action('init', array($this, 'register_taxonomies'));
        add_action('plugins_loaded', array($this, 'maybe_init_state'));
        add_action('admin_init', array($this, 'maybe_schedule_hourly'));
        add_filter('cron_schedules', array($this, 'ensure_hourly_exists'));
        add_action(self::CRON_HOOK, array($this, 'cron_post_lesson'));

        // Filters for feeds/themes
        $this->feed_urls  = apply_filters('go_weekly_feed_urls', $this->feed_urls);
        $this->day_themes = apply_filters('go_weekly_day_themes', $this->day_themes);
    }

    public static function activate() {
        $self = new self();
        $self->ensure_bot_user();
        $self->register_taxonomies();
        $self->ensure_terms_and_categories();
        $self->maybe_init_state();
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + 60, 'hourly', self::CRON_HOOK);
        }
    }

    public static function deactivate() {
        $ts = wp_next_scheduled(self::CRON_HOOK);
        if ($ts) wp_unschedule_event($ts, self::CRON_HOOK);
    }

    public function ensure_hourly_exists($schedules) {
        // WP already has 'hourly', but ensure exists
        if (empty($schedules['hourly'])) {
            $schedules['hourly'] = array('interval'=>3600,'display'=>__('Once Hourly','go-weekly'));
        }
        return $schedules;
    }

    public function maybe_schedule_hourly() {
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + 60, 'hourly', self::CRON_HOOK);
        }
    }

    public function maybe_init_state() {
        $state = get_option(self::OPT_STATE);
        if (!is_array($state) || !isset($state['index'])) {
            $state = array('index'=>0);
            add_option(self::OPT_STATE, $state, '', 'no');
        }
    }

    public function register_taxonomies() {
        register_taxonomy('go_color', 'post', array(
            'labels'=>array('name'=>'Playing Color','singular_name'=>'Playing Color'),
            'public'=>true,'show_ui'=>true,'show_in_rest'=>true,'hierarchical'=>false
        ));
        register_taxonomy('go_phase', 'post', array(
            'labels'=>array('name'=>'Game Phase','singular_name'=>'Game Phase'),
            'public'=>true,'show_ui'=>true,'show_in_rest'=>true,'hierarchical'=>false
        ));
        register_taxonomy('go_skill', 'post', array(
            'labels'=>array('name'=>'Skill Level','singular_name'=>'Skill Level'),
            'public'=>true,'show_ui'=>true,'show_in_rest'=>true,'hierarchical'=>false
        ));
    }

    private function ensure_terms_and_categories() {
        $tactics = array('tesuji','life-and-death','joseki','fuseki','yose','shape');
        foreach ($tactics as $slug) {
            if (!term_exists($slug,'category')) {
                wp_insert_term(ucwords(str_replace(array('-', '_'), ' ', $slug)), 'category', array('slug'=>$slug));
            }
        }
        foreach (array('Black','White') as $t) if (!term_exists($t,'go_color')) wp_insert_term($t,'go_color');
        foreach (array('Opening','Middle Game','Endgame') as $t) if (!term_exists($t,'go_phase')) wp_insert_term($t,'go_phase');
        foreach (array('Beginner','Intermediate','Advanced','Professional') as $t) if (!term_exists($t,'go_skill')) wp_insert_term($t,'go_skill');
    }

    private function ensure_bot_user() {
        if (username_exists(self::BOT_USERNAME)) return;
        $uid = wp_create_user(self::BOT_USERNAME, wp_generate_password(18), self::BOT_EMAIL);
        if (!is_wp_error($uid)) {
            wp_update_user(array('ID'=>$uid,'display_name'=>self::BOT_DISPLAY,'role'=>'author'));
        }
    }

    private function bot_user_id() {
        $u = get_user_by('login', self::BOT_USERNAME);
        if ($u) return $u->ID;
        $this->ensure_bot_user();
        $u = get_user_by('login', self::BOT_USERNAME);
        return $u ? $u->ID : get_current_user_id();
    }

    public function cron_post_lesson() {
        $state = get_option(self::OPT_STATE, array('index'=>0));
        $i = isset($state['index']) ? intval($state['index']) : 0;
        $i = $i % 168; // 168 lessons in a weekly loop
        $lesson = $this->compose_lesson($i);

        $post_id = wp_insert_post(array(
            'post_title'   => $lesson['title'],
            'post_content' => $lesson['content'],
            'post_status'  => 'publish',
            'post_author'  => $this->bot_user_id()
        ));
        if (!is_wp_error($post_id)) {
            // Assign taxonomies
            if (!empty($lesson['category'])) wp_set_post_terms($post_id, array($lesson['category']), 'category', false);
            if (!empty($lesson['phase']))    wp_set_post_terms($post_id, array($lesson['phase']), 'go_phase', false);
            if (!empty($lesson['skill']))    wp_set_post_terms($post_id, array($lesson['skill']), 'go_skill', false);
            // Alternate color each hour for variety
            $color = ($i % 2 === 0) ? 'Black' : 'White';
            wp_set_post_terms($post_id, array($color), 'go_color', false);
            $this->attach_featured_image_random($post_id);
        }
        // Advance the pointer
        $state['index'] = ($i + 1) % 168;
        update_option(self::OPT_STATE, $state);
    }

    private function attach_featured_image_random($post_id) {
        $q = new WP_Query(array(
            'post_type'=>'attachment','post_status'=>'inherit',
            'posts_per_page'=>1,'orderby'=>'rand','post_mime_type'=>'image'
        ));
        if ($q->have_posts()) {
            $img = $q->posts[0]->ID;
            if (function_exists('set_post_thumbnail')) set_post_thumbnail($post_id, $img);
        }
        wp_reset_postdata();
    }

    private function compose_lesson($index) {
        // Determine day/hour
        $day   = intval(floor($index / 24)) % 7; // 0..6
        $hour  = $index % 24;                    // 0..23

        $theme = $this->day_themes[$day];
        $skill = $this->derive_skill($theme['skill'], $hour);
        $phase = $this->derive_phase($theme['phase'], $hour);
        $tactic= $this->derive_tactic($theme['tactic'], $hour);

        $title = sprintf('Lesson %d — %s: %s (%s, %s)',
            $index + 1,
            esc_html($theme['name']),
            esc_html($this->hour_topic_name($tactic, $hour)),
            esc_html($skill),
            esc_html($phase)
        );

        $jp = isset($this->jp_terms[$tactic]) ? $this->jp_terms[$tactic] : '';
        $news = $this->find_news_snippet($theme['keywords']);

        $body_intro = $this->hour_intro($tactic, $skill, $phase, $theme);
        $about = $this->about_tactic($tactic);
        $closing = $this->closings[array_rand($this->closings)];
        $weekly_notice = '<p><strong>Weekly Course Notice:</strong> This lesson is part of a 7‑day course that repeats every week. Follow the hourly sequence from Monday to Sunday, then loop again next week to reinforce skills.</p>';

        $content = ''
            . '<p>' . esc_html($body_intro) . '</p>'
            . ($news ? '<p><em>Real‑world analogy:</em> ' . $news . '</p>' : '')
            . '<p><strong>Original term:</strong> ' . esc_html($jp) . '</p>'
            . '<p><strong>About this tactic:</strong> ' . esc_html($about) . '</p>'
            . $weekly_notice
            . '<p><em>' . esc_html($closing) . '</em></p>';

        return array(
            'title'    => $title,
            'content'  => $content,
            'skill'    => $skill,
            'phase'    => $phase,
            'category' => $tactic
        );
    }

    private function derive_skill($base, $hour) {
        // Progress within the day slightly, but keep weekly arc overall
        $order = array('Beginner','Intermediate','Advanced','Professional');
        $base_i = array_search($base, $order);
        if ($base_i === false) $base_i = 0;
        $offset = intval(floor($hour / 8)); // bump every 8 hours within a day
        $idx = min(3, $base_i + $offset);
        return $order[$idx];
    }

    private function derive_phase($base, $hour) {
        if ($base === 'Endgame') return 'Endgame';
        if ($base === 'Opening') {
            return ($hour < 8) ? 'Opening' : (($hour < 16) ? 'Middle Game' : 'Endgame');
        }
        // Middle game base
        return ($hour < 8) ? 'Middle Game' : (($hour < 16) ? 'Opening' : 'Endgame');
    }

    private function derive_tactic($base, $hour) {
        // Rotate tactics over the day while biasing to base
        $tactics = array('shape','life-and-death','tesuji','joseki','fuseki','yose');
        // simple rotation seeded by base
        $seed = array_search($base, $tactics);
        if ($seed === false) $seed = 0;
        return $tactics[ ($seed + intval($hour/4)) % count($tactics) ];
    }

    private function hour_topic_name($tactic, $hour) {
        $names = array(
            'shape' => array('Efficient Shape','Light vs Heavy','Connection vs Cut','Avoiding Empty Triangles','Thick vs Thin','Peeping & Fixing','Hane and Extend','Liberty Awareness'),
            'life-and-death' => array('Eye Space Basics','Vital Points','Seki vs Life','Corner Life','False Eye Detection','Killing Shapes','Saving a Group','Ko in Life & Death'),
            'tesuji' => array('Snapback','Throw‑in (Uchi‑komi)','Sacrifice Tesuji','Under‑the‑stones','Miai Concepts','Squeeze','Placement Tesuji','Aji Keshi Awareness'),
            'joseki' => array('3‑4 Approaches','Avalanche Family','High/Low Extensions','Pincer Choices','Double Approach','Joseki Traps (Don’t!)','When to Tenuki','Corner Enclosures'),
            'fuseki' => array('Corner‑Side‑Center','Frameworks (Moyo)','Approach Timing','Direction of Play','Reducing vs Invading','Overconcentration','Balance of Territory/Influence','Whole‑board Sabaki'),
            'yose' => array('Counting Basics','Sente vs Gote','Reverse Sente','Double Sente','Endgame Tesuji','Securing Borders','Large vs Small Moves','Half‑point Games')
        );
        $lst = isset($names[$tactic]) ? $names[$tactic] : array('Core Topic');
        return $lst[$hour % max(1, count($lst))];
    }

    private function hour_intro($tactic, $skill, $phase, $theme) {
        $map = array(
            'shape' => 'Shape is efficiency: build connections with minimal stones and avoid heavy groups.',
            'life-and-death' => 'Life & Death reading trains your eyes to find vital points and secure two eyes under pressure.',
            'tesuji' => 'Tesuji are precise tactical moves that turn local fights in your favor.',
            'joseki' => 'Joseki are opening sequences that aim for balanced results — tools, not rules.',
            'fuseki' => 'Fuseki is whole‑board strategy: claim corners, extend to sides, and coordinate towards the center.',
            'yose' => 'Yose is endgame precision: counting, sente/gote judgment, and extracting maximum points from borders.'
        );
        $base = isset($map[$tactic]) ? $map[$tactic] : 'Study fundamentals and apply them patiently.';
        return $theme['focus'] . ' — ' . $base . ' Today we work at ' . $skill . ' level in the ' . $phase . '.';
    }

    private function about_tactic($tactic) {
        $desc = array(
            'tesuji' => 'A skillful tactical move at the vital point that yields the best local result. Reading and shape sense reveal tesuji. (手筋 tesuji)',
            'life-and-death' => 'Determining whether a group lives (two eyes) or dies. Practicing tsumego builds deep reading under time pressure. (詰碁 / 死活 tsumego/shikatsu)',
            'joseki' => 'Established corner sequences in the opening; useful patterns when understood — but beware rote play. (定石 joseki)',
            'fuseki' => 'Whole‑board opening strategy balancing territory and influence through direction of play. (布石 fuseki)',
            'yose' => 'Endgame calculations involving sente, gote, and reverse sente to maximize points. (寄せ yose)',
            'shape' => 'Efficient stone arrangement that stays connected, light, and flexible. Exploit overconcentration and bad shape. (形 katachi)'
        );
        return isset($desc[$tactic]) ? $desc[$tactic] : 'Core Go concept applied at appropriate level and phase.';
    }

    private function find_news_snippet($keywords) {
        if (!function_exists('fetch_feed')) { require_once ABSPATH . WPINC . '/feed.php'; }
        foreach ($this->feed_urls as $url) {
            $feed = fetch_feed($url);
            if (is_wp_error($feed)) { continue; }
            $maxitems = $feed->get_item_quantity(5);
            $items = $feed->get_items(0, $maxitems);
            foreach ($items as $item) {
                $text = strtolower(wp_strip_all_tags($item->get_title().' '.$item->get_description().' '.$item->get_content()));
                foreach ($keywords as $kw) {
                    if (strpos($text, strtolower($kw)) !== false) {
                        $title = esc_html($item->get_title());
                        $link  = esc_url($item->get_link());
                        return $title . ' — <a href="' . $link . '" target="_blank" rel="nofollow noopener">source</a>';
                    }
                }
            }
        }
        return '';
    }
}

register_activation_hook(__FILE__, array('Go_Weekly_Lesson_Scheduler_Plus','activate'));
register_deactivation_hook(__FILE__, array('Go_Weekly_Lesson_Scheduler_Plus','deactivate'));

new Go_Weekly_Lesson_Scheduler_Plus();
