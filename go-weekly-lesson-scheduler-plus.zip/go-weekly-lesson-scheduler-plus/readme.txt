=== Go Weekly Lesson Scheduler Plus ===
Contributors: notyouagain.ai
Tags: go, baduk, weiqi, lessons, hourly, education, cron
Requires at least: 5.2
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Posts hourly Go lessons for a full week (168 total), then repeats weekly forever. Lessons are in English with original Japanese terms (kanji/kana/romaji) shown for reference, include a real-world news analogy pulled from RSS, and are tagged by Skill, Phase, Color, and Tactic Category.

== Description ==
- 7-day curriculum, 24 lessons per day, cycles forever.
- Skill progression within each day (Beginner → Intermediate → Advanced → Professional).
- Tactic categories: Tesuji, Life & Death (Tsumego), Joseki, Fuseki, Yose, Shape.
- Weekly notice added to every post so learners know it repeats.
- Optional real-world analogy from RSS (same sources as your other plugin); filterable via `go_weekly_feed_urls`.
- Bot author, random featured image from your Media Library.

== Installation ==
1. Upload the ZIP in Plugins → Add New → Upload Plugin.
2. Activate. The first lesson posts within the next hour (cron).

== Filters ==
- `go_weekly_feed_urls` to change RSS sources.
- `go_weekly_day_themes` to customize day themes, tactics, and keywords.
