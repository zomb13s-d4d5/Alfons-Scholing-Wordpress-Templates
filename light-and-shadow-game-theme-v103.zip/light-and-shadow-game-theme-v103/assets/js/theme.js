(function(){
  const slides=[...document.querySelectorAll('.lsg-bg__slide')];
  let i=0; if(slides.length>1){ setInterval(()=>{slides[i].classList.remove('is-active'); i=(i+1)%slides.length; slides[i].classList.add('is-active');}, (window.LSG&&LSG.interval)||7000); }
  const toggle=document.querySelector('.menu-toggle'), nav=document.querySelector('.main-nav');
  if(toggle&&nav){ toggle.addEventListener('click',()=>{const open=nav.classList.toggle('is-open'); toggle.setAttribute('aria-expanded',open?'true':'false');}); }
  const lb=document.getElementById('lsg-lightbox'); if(lb){ const img=lb.querySelector('img'), btn=lb.querySelector('button'); document.querySelectorAll('.entry-content img, .wp-block-image img, .gallery img').forEach(el=>{ el.addEventListener('click',()=>{ img.src=el.currentSrc||el.src; img.alt=el.alt||''; lb.classList.add('is-open'); lb.setAttribute('aria-hidden','false'); }); }); const close=()=>{lb.classList.remove('is-open'); lb.setAttribute('aria-hidden','true'); img.src='';}; btn.addEventListener('click',close); lb.addEventListener('click',e=>{if(e.target===lb) close();}); document.addEventListener('keydown',e=>{if(e.key==='Escape') close();}); }

  document.querySelectorAll('[data-slider]').forEach(slider=>{
    const track=slider.querySelector('.post-slider__track');
    const slides=[...slider.querySelectorAll('.post-slider__slide')];
    const prev=slider.querySelector('[data-slider-prev]');
    const next=slider.querySelector('[data-slider-next]');
    const dotsWrap=slider.querySelector('[data-slider-dots]');
    if(!track||!slides.length) return;
    let page=0,pages=1,perView=1;
    const dotMarkup=(n)=>'<button type="button" class="go-dot'+(n===0?' is-active':'')+'" data-page="'+n+'" aria-label="Go to slide '+(n+1)+'"></button>';
    const calc=()=>{
      const vw=window.innerWidth;
      perView = vw<=900 ? 1 : (vw<=1100 ? 2 : 3);
      pages = Math.max(1, Math.ceil(slides.length / perView));
      if(dotsWrap){ dotsWrap.innerHTML = Array.from({length: pages}, (_,n)=>dotMarkup(n)).join(''); }
      if(page>pages-1) page=pages-1;
      update();
    };
    const update=()=>{
      const firstIndex = page * perView;
      const target = slides[firstIndex];
      const x = target ? target.offsetLeft : 0;
      track.style.transform = 'translateX(' + (-x) + 'px)';
      if(dotsWrap){ [...dotsWrap.querySelectorAll('.go-dot')].forEach((dot,i)=>dot.classList.toggle('is-active', i===page)); }
      if(prev) prev.disabled = page===0;
      if(next) next.disabled = page>=pages-1;
    };
    if(prev) prev.addEventListener('click',()=>{ page=Math.max(0,page-1); update(); });
    if(next) next.addEventListener('click',()=>{ page=Math.min(pages-1,page+1); update(); });
    if(dotsWrap) dotsWrap.addEventListener('click',e=>{ const btn=e.target.closest('[data-page]'); if(!btn) return; page=parseInt(btn.getAttribute('data-page'),10)||0; update(); });
    let startX=0, diffX=0, down=false;
    slider.querySelector('.post-slider__viewport').addEventListener('touchstart',e=>{ down=true; startX=e.touches[0].clientX; diffX=0; }, {passive:true});
    slider.querySelector('.post-slider__viewport').addEventListener('touchmove',e=>{ if(!down) return; diffX = e.touches[0].clientX - startX; }, {passive:true});
    slider.querySelector('.post-slider__viewport').addEventListener('touchend',()=>{ if(!down) return; if(diffX<-40 && page<pages-1) page++; if(diffX>40 && page>0) page--; down=false; update(); });
    window.addEventListener('resize',calc);
    calc();
  });
})();
