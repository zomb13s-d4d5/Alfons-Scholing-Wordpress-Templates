<?php
if (!defined('ABSPATH')) { exit; }

define('LSG_VERSION', '1.0.3');

function lsg_setup() {
  load_theme_textdomain('light-shadow-game', get_template_directory() . '/languages');
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_theme_support('custom-logo', array('height'=>120,'width'=>420,'flex-width'=>true,'flex-height'=>true));
  add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
  add_theme_support('automatic-feed-links');
  add_theme_support('align-wide');
  register_nav_menus(array('primary' => __('Primary Menu', 'light-shadow-game')));
  add_image_size('lsg-card', 900, 640, true);
  add_image_size('lsg-hero', 1800, 1000, true);
}
add_action('after_setup_theme','lsg_setup');

function lsg_assets() {
  wp_enqueue_style('lsg-style', get_stylesheet_uri(), array(), LSG_VERSION);
  wp_enqueue_script('lsg-script', get_template_directory_uri() . '/assets/js/theme.js', array(), LSG_VERSION, true);
  wp_localize_script('lsg-script', 'LSG', array('interval' => 7000));
  if (is_singular() && comments_open() && get_option('thread_comments')) wp_enqueue_script('comment-reply');
}
add_action('wp_enqueue_scripts','lsg_assets');

function lsg_default_image_uri() { return get_template_directory_uri() . '/assets/images/default-missing.webp'; }
function lsg_featured_url($post_id = null, $size='lsg-card') {
  $post_id = $post_id ?: get_the_ID();
  if (has_post_thumbnail($post_id)) return get_the_post_thumbnail_url($post_id, $size);
  return lsg_default_image_uri();
}

function lsg_backgrounds() {
  $base = get_template_directory_uri() . '/assets/images/backgrounds/';
  $custom = array_filter(array(
    get_theme_mod('lsg_bg_one'), get_theme_mod('lsg_bg_two'), get_theme_mod('lsg_bg_three')
  ));
  if (!empty($custom)) return $custom;
  return array($base.'black-stone-player.webp', $base.'white-stone-player.webp', $base.'atari-player.webp');
}

function lsg_render_backgrounds() {
  $bgs = lsg_backgrounds();
  echo '<div class="lsg-bg" aria-hidden="true">';
  foreach ($bgs as $i=>$bg) {
    printf('<div class="lsg-bg__slide %s" style="background-image:url(%s)"></div>', $i===0?'is-active':'', esc_url($bg));
  }
  echo '</div><div class="lsg-paper" aria-hidden="true"></div>';
}

function lsg_excerpt($length=22) {
  return wp_trim_words(get_the_excerpt() ?: wp_strip_all_tags(get_the_content()), $length, '…');
}

function lsg_customize($wp_customize) {
  $wp_customize->add_section('lsg_city', array('title'=>__('Light & Shadow — City of Go','light-shadow-game'), 'priority'=>30));
  foreach (array('one'=>'Black Stone Player', 'two'=>'White Stone Player', 'three'=>'Atari Player') as $key=>$label) {
    $setting = 'lsg_bg_'.$key;
    $wp_customize->add_setting($setting, array('sanitize_callback'=>'esc_url_raw'));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, $setting, array('label'=>__('Rotating background: ','light-shadow-game') . $label, 'section'=>'lsg_city', 'settings'=>$setting)));
  }
  $wp_customize->add_setting('lsg_hero_title', array('default'=>'Light & Shadow', 'sanitize_callback'=>'sanitize_text_field'));
  $wp_customize->add_control('lsg_hero_title', array('label'=>__('Hero title','light-shadow-game'), 'section'=>'lsg_city', 'type'=>'text'));
  $wp_customize->add_setting('lsg_hero_subtitle', array('default'=>'City of Go', 'sanitize_callback'=>'sanitize_text_field'));
  $wp_customize->add_control('lsg_hero_subtitle', array('label'=>__('Hero subtitle','light-shadow-game'), 'section'=>'lsg_city', 'type'=>'text'));
  $wp_customize->add_setting('lsg_hero_text', array('default'=>'Learn Go / Baduk through light, shadow, pressure, territory, and silence.', 'sanitize_callback'=>'sanitize_textarea_field'));
  $wp_customize->add_control('lsg_hero_text', array('label'=>__('Hero text','light-shadow-game'), 'section'=>'lsg_city', 'type'=>'textarea'));
}
add_action('customize_register','lsg_customize');

function lsg_register_types() {
  register_post_type('lesson', array(
    'labels'=>array('name'=>'Lessons','singular_name'=>'Lesson'), 'public'=>true, 'show_in_rest'=>true,
    'menu_icon'=>'dashicons-welcome-learn-more', 'supports'=>array('title','editor','excerpt','thumbnail','comments'),
    'has_archive'=>true, 'rewrite'=>array('slug'=>'lessons')
  ));
  register_taxonomy('difficulty', array('lesson','post'), array(
    'labels'=>array('name'=>'Difficulty'), 'public'=>true, 'show_in_rest'=>true, 'hierarchical'=>true,
    'rewrite'=>array('slug'=>'difficulty')
  ));
}
add_action('init','lsg_register_types');
