<?php get_header(); ?>
<section class="hero">
  <div class="hero__inner">
    <div class="hero__copy">
      <div class="kicker">lightandshadowgame.com</div>
      <h1><?php echo esc_html(get_theme_mod('lsg_hero_title','Light & Shadow')); ?></h1>
      <div class="subtitle"><?php echo esc_html(get_theme_mod('lsg_hero_subtitle','City of Go')); ?> · How to Play Go / Baduk</div>
      <p><?php echo esc_html(get_theme_mod('lsg_hero_text','Learn Go / Baduk through light, shadow, pressure, territory, and silence.')); ?></p>
      <div class="button-row"><a class="btn" href="#lessons">Start Training</a><a class="btn btn--ghost" href="#paths">Choose Path</a></div>
    </div>
    <aside class="hero__panel" aria-label="How to play Go quotes">
      <div class="rule-list">
        <div class="rule"><strong>Play on the intersections.</strong><span>Jouez sur les intersections.</span></div>
        <div class="rule"><strong>Keep your stones connected.</strong><span>Halte deine Steine verbunden.</span></div>
        <div class="rule"><strong>Make two eyes to live.</strong><span>Fai due occhi per vivere.</span></div>
        <div class="rule"><strong>Capture by removing liberties.</strong><span>Captura eliminando libertades.</span></div>
      </div>
    </aside>
  </div>
</section>
<section id="paths" class="section">
  <div class="section__inner">
    <div class="kicker">discipline paths</div><h2 class="section-title">Choose your stone</h2><div class="brush-line"></div>
    <div class="grid grid--paths">
      <?php $cards = array(
        array('Black Stone Player','Attack with shape. Build influence from shadow.','black-stone-player.webp'),
        array('White Stone Player','Balance territory, patience, and quiet support.','white-stone-player.webp'),
        array('Atari Player','See the one liberty. Strike before the group escapes.','atari-player.webp'),
      ); foreach($cards as $c): ?>
      <article class="card card--large"><div class="card__image"><img src="<?php echo esc_url(get_template_directory_uri().'/assets/images/backgrounds/'.$c[2]); ?>" alt=""></div><div class="card__overlay"></div><div class="card__content"><div class="meta">City of Go</div><h3><?php echo esc_html($c[0]); ?></h3><p><?php echo esc_html($c[1]); ?></p></div></article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<section id="lessons" class="section">
  <div class="section__inner">
    <div class="kicker">latest missions</div><h2 class="section-title">Train the board</h2><div class="brush-line"></div>
    <?php $q = new WP_Query(array('post_type'=>array('lesson','post'),'posts_per_page'=>9)); if($q->have_posts()): ?>
    <div class="post-slider" data-slider>
      <div class="post-slider__viewport">
        <div class="post-slider__track">
          <?php while($q->have_posts()): $q->the_post(); ?>
          <article class="card card--mission post-slider__slide"><div class="card__image"><img src="<?php echo esc_url(lsg_featured_url(get_the_ID(),'lsg-card')); ?>" alt=""></div><div class="card__overlay"></div><div class="card__content"><div class="meta"><?php echo esc_html(get_post_type()); ?></div><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3><p><?php echo esc_html(lsg_excerpt(18)); ?></p></div></article>
          <?php endwhile; wp_reset_postdata(); ?>
        </div>
      </div>
      <div class="slider-controls">
        <div class="slider-arrows">
          <button class="slider-arrow" type="button" data-slider-prev aria-label="Previous slide">&#8592;</button>
          <button class="slider-arrow" type="button" data-slider-next aria-label="Next slide">&#8594;</button>
        </div>
        <div class="go-dots go-dots--slider" data-slider-dots></div>
      </div>
    </div>
    <?php else: ?>
    <article class="entry"><h3>No lessons yet.</h3><p>Create posts or Lessons and they will appear here as tactical mission cards.</p></article>
    <?php endif; ?>
  </div>
</section>
<?php get_footer(); ?>
