<?php if (post_password_required()) return; ?>
<section id="comments" class="comments-area">
<?php if (have_comments()) : ?><h2><?php comments_number('No comments','One comment','% comments'); ?></h2><ol class="comment-list"><?php wp_list_comments(array('style'=>'ol','short_ping'=>true)); ?></ol><?php the_comments_navigation(); endif; ?>
<?php if (!comments_open() && get_comments_number()) : ?><p>Comments are closed.</p><?php endif; ?>
<?php comment_form(); ?>
</section>
