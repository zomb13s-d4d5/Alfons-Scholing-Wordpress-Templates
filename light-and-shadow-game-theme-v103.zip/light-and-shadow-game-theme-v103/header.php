<?php if (!defined('ABSPATH')) exit; ?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); lsg_render_backgrounds(); ?>
<div class="site-shell">
<header class="site-header">
  <div class="site-header__inner">
    <a class="brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php bloginfo('name'); ?> home">
      <?php if (has_custom_logo()) { the_custom_logo(); } else { ?><span class="brand__mark"></span><?php } ?>
      <span><?php echo esc_html(parse_url(home_url(), PHP_URL_HOST) ?: get_bloginfo('name')); ?></span>
    </a>
    <button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">Menu</button>
    <nav id="primary-menu" class="main-nav" aria-label="Primary">
      <?php wp_nav_menu(array('theme_location'=>'primary','container'=>false,'fallback_cb'=>'lsg_fallback_menu','items_wrap'=>'%3$s')); ?>
    </nav>
  </div>
</header>
<main id="content" class="site-main">
<?php
function lsg_fallback_menu(){
  echo '<a href="'.esc_url(home_url('/')).'">Start</a>';
  echo '<a href="'.esc_url(get_post_type_archive_link('lesson')).'">Lessons</a>';
  echo '<a href="'.esc_url(home_url('/category/stories/')).'">Stories</a>';
  echo '<a href="'.esc_url(home_url('/?s=')).'">Search</a>';
}
?>
