<?php if (!defined('ABSPATH')) exit; ?>
</main>
<footer class="site-footer">
  <div class="site-footer__inner">
    <div class="brand"><span class="brand__mark"></span><span><?php bloginfo('name'); ?> · city of go</span></div>
    <div>Every stone casts a shadow. <?php echo esc_html(date('Y')); ?></div>
  </div>
</footer>
<div class="lightbox" id="lsg-lightbox" aria-hidden="true"><button type="button">Close</button><img alt=""></div>
</div>
<?php wp_footer(); ?>
</body></html>
