Light & Shadow Game — City of Go
Version 1.0.0

Install:
1. WordPress Admin > Appearance > Themes > Add New > Upload Theme.
2. Upload light-and-shadow-game-theme.zip.
3. Activate.

Included:
- iOS-first responsive layout.
- Rotating background system using three included City of Go wallpapers: Black Stone Player, White Stone Player, Atari Player.
- Customizer support for replacing the three rotating backgrounds.
- Homepage with hero, rules/quotes panel, path cards, latest lessons/posts.
- Custom Lesson post type and Difficulty taxonomy.
- Single post/page/category/archive/search templates.
- Comments enabled where WordPress comments are enabled.
- Lightbox for images in posts/pages/galleries.
- Default missing image fallback.
- Full-width featured images.

Recommended setup:
- Create a Primary Menu under Appearance > Menus.
- Add Lesson posts for Go/Baduk training content.
- Use featured images for article cards; missing images fall back automatically.

Image optimization notes:
- Rotating background images are delivered as WebP for fast iOS/mobile loading.
- Pixel dimensions are preserved at 1672 x 941 for all three background worlds.
- Heavy PNG source copies were removed from the installable theme package because the theme only uses the optimized WebP versions.
- Featured-image sizes are registered for responsive WordPress-generated thumbnails.
