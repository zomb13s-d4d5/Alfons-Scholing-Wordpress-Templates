<?php get_header(); if(have_posts()): while(have_posts()): the_post(); ?>
<div class="featured"><img src="<?php echo esc_url(lsg_featured_url(get_the_ID(),'lsg-hero')); ?>" alt="<?php echo esc_attr(get_the_title()); ?>"></div>
<section class="content-wrap"><article <?php post_class('entry'); ?>><div class="kicker"><?php echo esc_html(get_the_date()); ?></div><h1><?php the_title(); ?></h1><div class="entry-content"><?php the_content(); wp_link_pages(); ?></div></article><?php the_post_navigation(); if(comments_open() || get_comments_number()) comments_template(); ?></section>
<?php endwhile; endif; get_footer(); ?>
