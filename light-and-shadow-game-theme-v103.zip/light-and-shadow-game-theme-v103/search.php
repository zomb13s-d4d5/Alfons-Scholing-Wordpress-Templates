<?php get_header(); ?>
<section class="content-wrap"><div class="entry"><div class="kicker">Search the board</div><h1><?php printf('Search: %s', esc_html(get_search_query())); ?></h1><?php get_search_form(); ?></div></section>
<section class="section"><div class="section__inner"><div class="archive-grid">
<?php if(have_posts()): while(have_posts()): the_post(); ?>
<article <?php post_class('card'); ?>><div class="card__image"><img src="<?php echo esc_url(lsg_featured_url()); ?>" alt=""></div><div class="card__overlay"></div><div class="card__content"><div class="meta"><?php echo esc_html(get_the_date()); ?></div><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3><p><?php echo esc_html(lsg_excerpt()); ?></p></div></article>
<?php endwhile; else: ?><div class="entry"><p>No result. Try a different stone.</p></div><?php endif; ?>
</div><?php the_posts_pagination(); ?></div></section><?php get_footer(); ?>
