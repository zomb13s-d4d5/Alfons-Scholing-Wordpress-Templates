<?php
/*
Plugin Name: 074KU Programming Handbook Creator
Plugin URI:  https://074ku.eu/
Description: Creates a single comprehensive programming handbook page covering topics van beginner tot pro.  Deze plugin publiceert alleen het handboek en bevat geen automatische postfunctie.
Version:     1.0
Author:      NotYouAgain.ai Studio
License:     GPLv2 or later
*/

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function k074_handbook_activation() {
    $slug  = 'programmeergids-beginners-tot-pro';
    $title = 'Programmeerhandboek: van beginner tot professional';
    // Controleer of de pagina al bestaat
    if ( get_page_by_path( $slug ) ) {
        return;
    }
    $content = '<h2>Over dit handboek</h2>';
    $content .= '<p>Dit document is bedoeld als een uitgebreid overzicht van de fundamenten van programmeren en cyber security. Het is samengesteld om zowel beginners als ervaren ontwikkelaars te begeleiden van de basisprincipes tot geavanceerde concepten.</p>';
    $content .= '<h3>1. Grondbeginselen van programmeren</h3>';
    $content .= '<p>Om te beginnen met programmeren moet je vertrouwd raken met variabelen, datatypes, controlestromen (condities en lussen) en foutafhandeling. Dit vormt de basis voor elke taal, of je nu Python, C of JavaScript leert.</p>';
    $content .= '<h3>2. Programmeertalen</h3>';
    $content .= '<p>Er zijn talloze talen beschikbaar, elk met een eigen doel. Python is ideaal voor beginners en datawetenschap; JavaScript is cruciaal voor webontwikkeling; C en C++ worden gebruikt voor systeemsoftware en games; Java en C# blinken uit in bedrijfstoepassingen. Kies een taal die past bij je project en blijf de basisprincipes toepassen.</p>';
    $content .= '<h3>3. Structuur en algoritmen</h3>';
    $content .= '<p>Datastructuren (arrays, lijsten, stacks, queues, bomen, grafen) bepalen hoe informatie wordt opgeslagen en benaderd. Algoritmen zijn stappenplannen om problemen op te lossen, zoals sorteren, zoeken en pathfinding. Efficiënte algoritmen en structuren maken software sneller en zuiniger.</p>';
    $content .= '<h3>4. Objectgeoriënteerd ontwerp</h3>';
    $content .= '<p>Het OOP‑paradigma draait om klassen en objecten. Encapsulatie beschermt gegevens, overerving bevordert hergebruik en polymorfisme laat objecten op consistente wijze reageren. Goed OOP‑ontwerp leidt tot onderhoudbare en uitbreidbare code.</p>';
    $content .= '<h3>5. Versiebeheer en samenwerking</h3>';
    $content .= '<p>Met versiebeheersystemen zoals Git kun je veilig experimenteren en bijdragen in teamverband. Gebruik branches voor nieuwe features, voer code reviews uit en combineer veranderingen via pull requests. Repositories op platforms als GitHub en GitLab bieden daarnaast CI/CD‑pijplijnen.</p>';
    $content .= '<h3>6. Cyber security</h3>';
    $content .= '<p>Cyber security beschermt je code en data. Begrepen onderwerpen omvatten authentificatie, encryptie, kwetsbaarheden (zoals XSS en SQL‑injecties) en basisprincipes van netwerkbeveiliging. Security by design betekent dat je vanaf het begin veilige keuzes maakt en regelmatig updates installeert.</p>';
    $content .= '<h3>7. Verdieping en specialisatie</h3>';
    $content .= '<p>Nadat je de basis onder de knie hebt, kun je je specialiseren. Webontwikkelaars verdiepen zich in frameworks (React, Laravel); datawetenschappers focussen op machine learning (scikit‑learn, TensorFlow); systeemprogrammeurs duiken in microcontrollers en besturingssystemen. Blijf voortdurend leren via documentatie, open source projecten en communities.</p>';
    $postarr = [
        'post_title'   => $title,
        'post_name'    => $slug,
        'post_content' => $content,
        'post_status'  => 'publish',
        'post_type'    => 'page',
    ];
    wp_insert_post( $postarr );
}

register_activation_hook( __FILE__, 'k074_handbook_activation' );