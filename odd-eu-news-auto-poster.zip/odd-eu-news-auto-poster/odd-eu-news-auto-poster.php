<?php
/*
 * Plugin Name: ODD EU News Auto Poster
 * Description: Automatically pulls in news from a set of European‐focused RSS feeds and publishes short summaries into the appropriate categories on your ODD (Open Democratic Debate) WordPress site.  The plugin scans a collection of feeds covering culture, economics, education, health, the environment and more.  Each new item is matched against a list of keywords to determine which of your site’s categories (Health, Environment, Economics and markets, etc.) it belongs in.  Once a match is found the plugin creates a new post under a dedicated bot account, assigns the category, generates a short snippet from the feed description and finishes with a playful pop‑culture warning.  It also avoids posting duplicate links by keeping a record of what has already been published.
 * Version: 1.0.0
 * Author: Community Bot
 * License: GPL2
 *
 * This plugin is designed specifically for the Open Democratic Debate site.  It
 * defines a custom cron schedule (every 15 minutes), creates a bot user for
 * publishing, fetches content from a predefined list of European news feeds and
 * categorises each item using a simple keyword‑based scoring system.  To
 * update the feeds or keyword mappings you can edit the static arrays
 * `$feed_urls` and `$category_mapping` below.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'ODD_EU_News_Auto_Poster' ) ) {

    /**
     * Core class implementing the ODD EU News auto‑blogging logic.
     */
    class ODD_EU_News_Auto_Poster {

        /**
         * Cron event hook identifier.
         *
         * @var string
         */
        protected static $event_hook = 'odd_eu_news_auto_poster_event';

        /**
         * Option name used to store posted links.  Keeps track of previously
         * published URLs so we don’t duplicate content.
         *
         * @var string
         */
        protected static $posted_links_option = 'odd_eu_news_posted_links';

        /**
         * Username for the bot’s WordPress account.
         *
         * @var string
         */
        protected static $username = 'ODDNewsBot';

        /**
         * RSS feed URLs to scan.  Feel free to add or remove sources here.
         * The plugin will iterate through these feeds on each cron run.
         *
         * @var array
         */
        protected static $feed_urls = [
            // General European news
            'https://www.euronews.com/rss',
            // European Parliament topics
            'https://www.europarl.europa.eu/rss/topic/906/en.xml', // culture & education
            'https://www.europarl.europa.eu/rss/topic/907/en.xml', // economic & monetary affairs
            'https://www.europarl.europa.eu/rss/topic/911/en.xml', // health & environment
            // Environment Agency press releases
            'https://www.eea.europa.eu/en/newsroom/rss-feeds/eeas-press-releases-rss/rss.xml',
            // EU Commission press releases
            'https://ec.europa.eu/commission/presscorner/home/en/rss.xml',
            // BBC Europe news
            'https://feeds.bbci.co.uk/news/world/europe/rss.xml',
        ];

        /**
         * Mapping of WordPress category slugs to keywords.  Each key is the
         * slug of a category defined on the ODD site (e.g. “health” or
         * “environment”), and each value is an array of keywords that will
         * trigger assignment to that category.  Keywords are matched against the
         * lower‑cased title and description of each feed item.
         *
         * @var array
         */
        protected static $category_mapping = [
            'health' => [
                'health', 'medicine', 'medical', 'pharmaceutical', 'public health',
                'hospital', 'doctor', 'vaccine', 'disease', 'pandemic', 'epidemic'
            ],
            'environment' => [
                'environment', 'climate', 'ecology', 'sustainability', 'pollution',
                'green', 'biodiversity', 'air quality', 'water quality',
                'nature', 'weather', 'extreme weather', 'carbon', 'energy', 'bio'
            ],
            'economics-and-markets' => [
                'economy', 'economic', 'monetary', 'finance', 'market', 'business',
                'trade', 'inflation', 'budget', 'industry', 'investment',
                'growth', 'money', 'employment', 'eu governance'
            ],
            'education-and-facilitating' => [
                'education', 'school', 'college', 'university', 'student',
                'learning', 'training', 'teacher', 'scholarship', 'youth',
                'facilitating', 'innovation in education'
            ],
            'entertainment' => [
                'entertainment', 'movie', 'film', 'music', 'concert', 'festival',
                'show', 'tv', 'games', 'gaming', 'theatre', 'cinema'
            ],
            'culture' => [
                'culture', 'art', 'heritage', 'tradition', 'museum', 'exhibition',
                'literature', 'dance', 'theater', 'performance'
            ],
            'housing' => [
                'housing', 'home', 'property', 'real estate', 'rent', 'mortgage',
                'construction', 'building', 'accommodation'
            ],
            'knowledge-resources' => [
                'research', 'science', 'knowledge', 'technology', 'innovation',
                'data', 'resources', 'library', 'book', 'study', 'information'
            ],
            'licences-and-legal-obligation' => [
                'law', 'legal', 'legislation', 'regulation', 'permit', 'license',
                'compliance', 'policy', 'obligation', 'court', 'justice'
            ],
            'minorities' => [
                'minority', 'minorities', 'diversity', 'ethnic', 'rights', 'gender',
                'discrimination', 'inequality', 'immigration', 'inclusion'
            ],
            'safety' => [
                'safety', 'security', 'crime', 'police', 'fire', 'emergency',
                'disaster', 'accident', 'protection', 'risk', 'cybersecurity',
                'public safety'
            ],
            'trade-agreement' => [
                'trade agreement', 'trade', 'agreement', 'tariff', 'export',
                'import', 'commerce', 'deal', 'market access', 'negotiation'
            ],
        ];

        /**
         * A small collection of pop‑culture analogies used to conclude each post.
         * These are reused from the original Miss Violette bot and add a fun
         * cautionary note at the end of each article.
         *
         * @var array
         */
        protected static $analogies = [
            'Just as Peter Parker never blindly trusted J. Jonah Jameson because he was Spider‑Man, remember that flashy announcements don’t replace due diligence.',
            'Like Clark Kent hiding his cape under a suit, sometimes it’s wiser to stay incognito while you build your future – true love and fair critique thrive when appearances don’t get in the way.',
            'Tony Stark learnt the hard way that untested tech can explode – always test your code before unleashing it on the world.',
            'In The Matrix, Neo chose the red pill and embraced uncertainty; similarly, open‑source may be messy but often reveals the truth behind the hype.',
            'Yoda said, “Do or do not, there is no try,” yet even a Jedi Master values proper documentation.  Don’t skip the docs.',
            'Bruce Wayne wears many masks; innovation does too.  Strip back the mask before you place your trust in it.',
            'Remember that Tony Stark built his first suit in a cave with scraps – constraints breed creativity, but they also demand caution.',
            'Like Frodo carrying the One Ring, powerful tools can corrupt; use them wisely or they may consume you.',
            'Even the Doctor knows that time travel gets messy.  Don’t introduce features you can’t foresee; the timeline may fracture.',
            'As the X‑Men know, extraordinary powers attract extraordinary enemies; think about the side effects before you unleash yours.',
        ];

        /**
         * Initialise hooks for activation, deactivation and cron scheduling.
         */
        public static function init() {
            register_activation_hook( __FILE__, [ __CLASS__, 'activate' ] );
            register_deactivation_hook( __FILE__, [ __CLASS__, 'deactivate' ] );
            add_filter( 'cron_schedules', [ __CLASS__, 'add_fifteen_min_schedule' ] );
            add_action( self::$event_hook, [ __CLASS__, 'cron_callback' ] );
        }

        /**
         * Adds a custom 15‑minute schedule to WP Cron.  WordPress does not
         * include a quarter‑hourly schedule by default, so we define one here.
         *
         * @param array $schedules Existing schedules.
         * @return array Modified schedules including the new 15‑minute entry.
         */
        public static function add_fifteen_min_schedule( $schedules ) {
            if ( ! isset( $schedules['fifteen_minutes'] ) ) {
                $schedules['fifteen_minutes'] = [
                    'interval' => 15 * 60, // 900 seconds
                    'display'  => __( 'Every 15 Minutes' ),
                ];
            }
            return $schedules;
        }

        /**
         * Activation hook.  Ensures the bot user exists, initialises the
         * posted links option and schedules the cron event to run every
         * 15 minutes.
         */
        public static function activate() {
            self::ensure_user();
            if ( false === get_option( self::$posted_links_option ) ) {
                update_option( self::$posted_links_option, [] );
            }
            if ( ! wp_next_scheduled( self::$event_hook ) ) {
                wp_schedule_event( time() + 300, 'fifteen_minutes', self::$event_hook );
            }
        }

        /**
         * Deactivation hook.  Unschedules the cron event.
         */
        public static function deactivate() {
            $timestamp = wp_next_scheduled( self::$event_hook );
            if ( $timestamp ) {
                wp_unschedule_event( $timestamp, self::$event_hook );
            }
        }

        /**
         * Ensure the bot user exists.  Creates it if necessary.  The
         * account uses the author role to allow publishing.
         *
         * @return int|false User ID on success, false on failure.
         */
        protected static function ensure_user() {
            $user = get_user_by( 'login', self::$username );
            if ( $user ) {
                return $user->ID;
            }
            $user_id = wp_create_user( self::$username, wp_generate_password(), strtolower( self::$username ) . '@example.com' );
            if ( is_wp_error( $user_id ) ) {
                return false;
            }
            wp_update_user( [ 'ID' => $user_id, 'display_name' => self::$username, 'role' => 'author' ] );
            return $user_id;
        }

        /**
         * Categorise a feed item into one of the site’s categories.  The
         * algorithm converts the title and description to lowercase and counts
         * keyword matches for each predefined slug.  The slug with the
         * highest score is returned.  If no keywords match, returns
         * 'uncategorized'.
         *
         * @param string $title       Feed item title.
         * @param string $description Feed item description/content.
         * @return string Category slug.
         */
        protected static function categorize_item( $title, $description ) {
            $text = strtolower( wp_strip_all_tags( $title . ' ' . $description ) );
            $best_slug = 'uncategorized';
            $best_score = 0;
            foreach ( self::$category_mapping as $slug => $keywords ) {
                $score = 0;
                foreach ( $keywords as $keyword ) {
                    $keyword = strtolower( $keyword );
                    if ( false !== strpos( $text, $keyword ) ) {
                        $score++;
                    }
                }
                if ( $score > $best_score ) {
                    $best_score = $score;
                    $best_slug = $slug;
                }
            }
            return $best_score > 0 ? $best_slug : 'uncategorized';
        }

        /**
         * Build a new post’s data array based on a SimplePie_Item object.  It
         * extracts the title and content, generates a snippet, chooses an
         * analogy and assembles the post array for insertion.
         *
         * @param object $item        SimplePie_Item representing the feed entry.
         * @param int    $author_id   User ID of the bot account.
         * @param int    $category_id Category ID for this post.
         * @return array Associative array suitable for wp_insert_post().
         */
        protected static function build_post_data( $item, $author_id, $category_id ) {
            $item_title = wp_strip_all_tags( $item->get_title() );
            $link       = $item->get_link();
            // Extract content or description.
            $feed_content = '';
            if ( method_exists( $item, 'get_content' ) ) {
                $feed_content = $item->get_content();
            }
            if ( empty( $feed_content ) && method_exists( $item, 'get_description' ) ) {
                $feed_content = $item->get_description();
            }
            $feed_content = wp_strip_all_tags( $feed_content );
            // Create snippet (first 80 words).
            $words = preg_split( '/\s+/', $feed_content );
            $snippet = implode( ' ', array_slice( $words, 0, 80 ) );
            // Pick a random analogy.
            $analogy = self::$analogies[ array_rand( self::$analogies ) ];
            // Compose HTML body.
            $body   = [];
            $body[] = '<p>' . esc_html( $snippet ) . '…</p>';
            $body[] = '<p><a href="' . esc_url( $link ) . '" rel="noopener" target="_blank">Read the full article at the source</a></p>';
            $body[] = '<p><em>' . esc_html( $analogy ) . '</em></p>';
            return [
                'post_title'   => $item_title,
                'post_content' => implode( "\n", $body ),
                'post_status'  => 'publish',
                'post_author'  => $author_id,
                'post_type'    => 'post',
                'post_category' => [ $category_id ],
            ];
        }

        /**
         * Cron callback.  Iterates through configured feeds and publishes the
         * first new item found that hasn’t been posted yet.  Assigns the
         * category based on keywords and attaches a random featured image if
         * available.  Only one post is published per cron run to avoid
         * overwhelming the site.
         */
        public static function cron_callback() {
            $user_id = self::ensure_user();
            if ( ! $user_id ) {
                return;
            }
            $posted_links = get_option( self::$posted_links_option, [] );
            if ( ! function_exists( 'fetch_feed' ) ) {
                include_once ABSPATH . WPINC . '/feed.php';
            }
            foreach ( self::$feed_urls as $feed_url ) {
                $feed = fetch_feed( $feed_url );
                if ( is_wp_error( $feed ) ) {
                    continue;
                }
                $max   = $feed->get_item_quantity( 5 );
                $items = $feed->get_items( 0, $max );
                foreach ( $items as $item ) {
                    $link = $item->get_link();
                    if ( empty( $link ) ) {
                        continue;
                    }
                    if ( in_array( $link, $posted_links, true ) ) {
                        continue;
                    }
                    // Determine category.
                    $slug = self::categorize_item( $item->get_title(), $item->get_description() );
                    // Resolve category ID by slug.
                    $category_id = 1; // default to “Uncategorized” if not found
                    $category = get_category_by_slug( $slug );
                    if ( $category && ! is_wp_error( $category ) ) {
                        $category_id = (int) $category->term_id;
                    }
                    // Build and insert post.
                    $post_data = self::build_post_data( $item, $user_id, $category_id );
                    $post_id   = wp_insert_post( $post_data );
                    if ( is_wp_error( $post_id ) ) {
                        continue;
                    }
                    // Assign a random featured image if there is at least one image in the media library.
                    $attachments = get_posts( [
                        'post_type'      => 'attachment',
                        'post_mime_type' => 'image',
                        'posts_per_page' => 1,
                        'orderby'        => 'rand',
                    ] );
                    if ( ! empty( $attachments ) ) {
                        $attachment_id = $attachments[0]->ID;
                        if ( function_exists( 'set_post_thumbnail' ) ) {
                            set_post_thumbnail( $post_id, $attachment_id );
                        } else {
                            update_post_meta( $post_id, '_thumbnail_id', $attachment_id );
                        }
                    }
                    // Record the link and trim list to last 200 items.
                    $posted_links[] = $link;
                    if ( count( $posted_links ) > 200 ) {
                        $posted_links = array_slice( $posted_links, -200 );
                    }
                    update_option( self::$posted_links_option, $posted_links );
                    return; // Post only one item per run.
                }
            }
        }
    }
    // Initialise the plugin.
    ODD_EU_News_Auto_Poster::init();
}