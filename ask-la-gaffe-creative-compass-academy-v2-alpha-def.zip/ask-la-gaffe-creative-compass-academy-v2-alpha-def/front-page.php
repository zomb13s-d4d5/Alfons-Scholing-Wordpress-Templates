<?php get_header(); $worlds=function_exists('lgu_profession_worlds')?lgu_profession_worlds():lgu_worlds(); $dean=function_exists('lgu_dean_profile')?lgu_dean_profile():array('image'=>'assets/images/dean-grey-wizard-alien.webp','title'=>'The Grey Old Alien Dean','role'=>'Career Guide','desc'=>'A friendly guide for choosing creative paths.'); ?>
<main>
<?php
$hero_slides = array(
  array('image'=>'assets/images/hero-slider/la-gaffe-explains-welcome.webp','kicker'=>'Ask La Gaffe explains','title'=>'Welcome to your Creative Compass','desc'=>'A magical free-access orientation system for learning the words, tools, questions and survival habits of creative work before the industry asks for them.','cta'=>'Start Here','url'=>cca_url('start-here')),
  array('image'=>'assets/images/hero-slider/la-gaffe-explains-professions.webp','kicker'=>'22 Creative Paths','title'=>'Meet the professors of the Academy','desc'=>'Each profession has its own studio, character, terminology, software basics, starter assignment and tutorial route.','cta'=>'Explore Professions','url'=>cca_url('creative-paths')),
  array('image'=>'assets/images/hero-slider/la-gaffe-explains-compass-cards.webp','kicker'=>'AI Compass Cards','title'=>'Ask better questions with better words','desc'=>'Use short cue cards to talk with AI, teachers, clients and collaborators using real creative-industry terminology.','cta'=>'Open Compass Cards','url'=>cca_url('ai-career-cheat-cards')),
  array('image'=>'assets/images/hero-slider/la-gaffe-explains-open-tutorials.webp','kicker'=>'Open Tutorial Feeds','title'=>'Free learning routes, gathered in one place','desc'=>'Follow open tutorials, academy notes and industry signals as a friendly learning feed instead of hunting blindly around the web.','cta'=>'View Tutorials','url'=>cca_url('open-tutorial-feeds')),
  array('image'=>'assets/images/hero-slider/la-gaffe-explains-academy-os.webp','kicker'=>'Personal Academy OS','title'=>'Register, pick paths, build your inbox','desc'=>'Choose the creative fields you care about and turn the website into a personal learning dashboard without installing extra plugins.','cta'=>'Register / Pick Paths','url'=>cca_url('academy-register')),
);
?>
<section class="adlg-hero-slider" data-adlg-hero aria-label="Ask La Gaffe hero slider">
  <div class="adlg-slides">
    <?php foreach($hero_slides as $i=>$slide): ?>
      <article class="adlg-slide <?php echo $i===0?'is-active':''; ?>" data-adlg-slide="<?php echo esc_attr($i); ?>" aria-hidden="<?php echo $i===0?'false':'true'; ?>">
        <img src="<?php echo esc_url(lgu_asset($slide['image'])); ?>" alt="<?php echo esc_attr($slide['kicker'].' — '.$slide['title']); ?>">
        <div class="adlg-slide-shade"></div>
        <div class="wrap adlg-slide-inner">
          <div class="adlg-slide-copy">
            <span class="eyebrow"><?php echo esc_html($slide['kicker']); ?></span>
            <h1>Ask La Gaffe <span>Creative Compass Academy</span></h1>
            <h2><?php echo esc_html($slide['title']); ?></h2>
            <p><?php echo esc_html($slide['desc']); ?></p>
            <div class="adlg-actions">
              <a class="btn" href="<?php echo esc_url($slide['url']); ?>"><?php echo esc_html($slide['cta']); ?></a>
              <a class="btn ghost" href="<?php echo esc_url(cca_url('career-compass')); ?>">Ask the Dean</a>
            </div>
          </div>
        </div>
      </article>
    <?php endforeach; ?>
  </div>
  <button class="adlg-hero-arrow adlg-prev" type="button" data-adlg-prev aria-label="Previous hero slide">‹</button>
  <button class="adlg-hero-arrow adlg-next" type="button" data-adlg-next aria-label="Next hero slide">›</button>
  <div class="adlg-dots" role="tablist" aria-label="Hero slides">
    <?php foreach($hero_slides as $i=>$slide): ?><button type="button" class="<?php echo $i===0?'is-active':''; ?>" data-adlg-dot="<?php echo esc_attr($i); ?>" aria-label="Show <?php echo esc_attr($slide['title']); ?>"></button><?php endforeach; ?>
  </div>
  <div class="wrap adlg-feature-rail" aria-label="Academy features">
    <a href="<?php echo esc_url(cca_url('creative-paths')); ?>"><span>▣</span><b>22 Creative Paths</b></a>
    <a href="<?php echo esc_url(cca_url('career-compass')); ?>"><span>✦</span><b>1 Dean Guide</b></a>
    <a href="<?php echo esc_url(cca_url('ai-career-cheat-cards')); ?>"><span>▱</span><b>AI Compass Cards</b></a>
    <a href="<?php echo esc_url(cca_url('open-tutorial-feeds')); ?>"><span>☰</span><b>Open Tutorial Feeds</b></a>
    <a href="<?php echo esc_url(cca_url('my-academy')); ?>"><span>◈</span><b>Personal Academy OS</b></a>
  </div>
</section>
<section class="cca-section"><div class="wrap"><div class="section-head-inline"><div><p class="kicker">Creative Paths</p><h2>Choose a professor, open a studio, build a start.</h2><p class="muted">Each profession gets a character, page, tutorial feed, AI cards and software basics. Register to turn selected paths into your website inbox.</p></div><a class="btn" href="<?php echo esc_url(cca_url('creative-paths')); ?>">View all paths</a></div><div class="cca-grid"><?php $i=0; foreach($worlds as $slug=>$w): if($i++>=8) break; ?><a class="cca-path-card" href="<?php echo esc_url(lgu_world_category_url($slug)); ?>"><img src="<?php echo esc_url(lgu_asset($w['poster'])); ?>" alt="<?php echo esc_attr($w['title']); ?>"><div><b><?php echo esc_html($w['edition']); ?></b><h3><?php echo esc_html($w['title']); ?></h3><p><?php echo esc_html($w['desc']); ?></p></div></a><?php endforeach; ?></div></div></section>
<section class="cca-section cca-system-section" aria-label="Academy operating system and AI Compass Cards">
  <div class="wrap cca-os-grid cca-os-grid--visual">
    <div class="cca-os-card cca-os-card--image cca-os-card--academy" style="--panel-bg:url('<?php echo esc_url(lgu_asset('assets/images/hero-slider/la-gaffe-explains-welcome.webp')); ?>')">
      <div class="cca-os-card__copy">
        <p class="kicker">Personal learning system</p>
        <h2>Your Academy OS</h2>
        <p>Students can register, pick professions, and receive a filtered website inbox of tutorials, articles and academy posts. It uses WordPress users, categories and user meta, so it does not require extra plugins.</p>
        <a class="btn" href="<?php echo esc_url(cca_url('my-academy')); ?>">Open My Academy</a>
      </div>
    </div>
    <div class="cca-os-card cca-os-card--image cca-os-card--compass" style="--panel-bg:url('<?php echo esc_url(lgu_asset('assets/images/hero-slider/la-gaffe-explains-welcome.webp')); ?>')">
      <div class="cca-os-card__copy">
        <p class="kicker">Better language with AI</p>
        <h2>Compass Cards</h2>
        <p>The cheat-card system teaches beginners how to ask the right questions using industry terminology: software, briefs, portfolio proof, ethics, collaboration and career next steps.</p>
        <a class="btn ghost" href="<?php echo esc_url(cca_url('ai-career-cheat-cards')); ?>">Open AI Compass Cards</a>
      </div>
    </div>
  </div>
</section>
<section class="cca-section latest-feed-section">
  <div class="wrap">
    <div class="latest-feed-head">
      <div>
        <p class="kicker">Open Tutorial Feeds</p>
        <h2>Latest Open Learning Feed</h2>
        <p class="muted">Fresh academy signals, tutorials and industry notes styled as a visual learning magazine.</p>
      </div>
      <a class="btn ghost" href="<?php echo esc_url(cca_url('open-tutorial-feeds')); ?>">Open all feeds</a>
    </div>
    <div class="latest-feed-grid">
      <?php $q=new WP_Query(array('posts_per_page'=>6,'post_status'=>'publish','ignore_sticky_posts'=>1,'orderby'=>'date','order'=>'DESC')); if($q->have_posts()): $feed_i=0; while($q->have_posts()): $q->the_post(); $feed_i++; $feed_world=lgu_world_from_post(get_the_ID()); ?>
        <a class="latest-feed-card <?php echo $feed_i===1?'latest-feed-card--lead':''; ?>" href="<?php the_permalink(); ?>" style="--feed-accent:<?php echo esc_attr($feed_world && !empty($feed_world['color']) ? $feed_world['color'] : '#8f4cff'); ?>">
          <figure>
            <img src="<?php echo esc_url(lgu_post_image_url(get_the_ID(), 'large')); ?>" alt="<?php echo esc_attr(lgu_post_image_alt(get_the_ID())); ?>">
          </figure>
          <div class="latest-feed-card__body">
            <span class="latest-feed-card__kicker"><?php echo esc_html($feed_world ? $feed_world['title'] : 'Ask La Gaffe'); ?></span>
            <h3><?php the_title(); ?></h3>
            <p><?php echo esc_html(wp_trim_words(get_the_excerpt(), $feed_i===1?24:14)); ?></p>
          </div>
        </a>
      <?php endwhile; wp_reset_postdata(); else: ?>
        <div class="panel panel-pad"><p class="muted">The RSS importer will place tutorials and academy notes here after activation.</p></div>
      <?php endif; ?>
    </div>
  </div>
</section>
<section class="cca-section"><div class="wrap"><div class="panel panel-pad cca-alpha-principles" style="--principles-bg:url('<?php echo esc_url(lgu_asset('assets/images/panels/academy-system-cards-wide.webp')); ?>')"><div class="cca-alpha-principles__inner"><p class="kicker">Ask La Gaffe system</p><h2>Alpha DEF principles</h2><div class="stats"><div class="stat"><b>Free</b>access</div><div class="stat"><b>Right</b>terms</div><div class="stat"><b>Real</b>tools</div><div class="stat"><b>Better</b>questions</div><div class="stat"><b>Lifelong</b>survival</div></div><p class="muted">The beta proved the universe. This Alpha rebuild turns it into a career-orientation operating system: free access, better language, real tools, better questions and lifelong creative survival.</p></div></div></div></section>
</main><?php get_footer(); ?>
