v2.0.9 Full RSS backend restore

This build restores the full backend language and controls:
- Tools menu label: Auto Poster + RSS Feeds
- Manual button: Auto Post Now / Fetch RSS Now
- Add RSS Feed panel
- Restore Built-In RSS Sources panel
- Full source table with more blank rows for adding feeds
- Settings retain publish/draft/pending choices
- Hourly auto-poster and Dean Career Compass feed/category remain active

Install, then open: WordPress Admin → Tools → Auto Poster + RSS Feeds.
