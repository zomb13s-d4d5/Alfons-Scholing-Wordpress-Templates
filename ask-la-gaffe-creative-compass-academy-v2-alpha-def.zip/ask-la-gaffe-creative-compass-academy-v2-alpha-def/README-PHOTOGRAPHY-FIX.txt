Photography category artwork mapping fix:
- Photography now uses the fox camera studio image for poster and concept artwork.
This build also preserves previous fixes: logo 75%, film-video penguin, animation bunny, illustration bunny.
