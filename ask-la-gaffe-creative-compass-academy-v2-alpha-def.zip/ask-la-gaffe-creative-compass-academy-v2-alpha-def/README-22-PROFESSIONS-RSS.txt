Ask La Gaffe v1337 OPT DEF — 22 Professions + RSS expansion

Changes in this build:
- Added 21 Podcast & Radio — On Air Studio with the new frog podcast/radio producer mascot.
- Added 22 Production Management — Coordination Desk with the new mouse production manager mascot.
- Added new poster, concept and icon webp assets for both new professions.
- Updated the home page labels from 20 to 22 category studios/professions.
- Updated the auto-poster world classifier so Podcast & Radio and Production Management are their own target categories.
- Expanded default RSS sources with more tutorial/learning feeds for coding, front-end, web, design, interface work, animation/3D and game design.
- Added more European academy page-monitor entries in the source list for design, art, communication and media education.

Note:
Some European design academies do not expose a clean RSS URL on their public news pages. Those academy entries are included as disabled page monitors so they are visible in the source list without causing broken RSS-import logs. Enable only after confirming a clean RSS/Atom endpoint or adapting the importer to parse monitored pages.
