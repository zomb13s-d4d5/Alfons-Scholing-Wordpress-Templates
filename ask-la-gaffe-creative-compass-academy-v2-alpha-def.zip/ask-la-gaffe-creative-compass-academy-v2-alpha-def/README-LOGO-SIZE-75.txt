Reduced integrated header logo to 75% of the previous v3.1.2 final logo size. Desktop: 293x54, tablet: 240x45, mobile: 188x38.
