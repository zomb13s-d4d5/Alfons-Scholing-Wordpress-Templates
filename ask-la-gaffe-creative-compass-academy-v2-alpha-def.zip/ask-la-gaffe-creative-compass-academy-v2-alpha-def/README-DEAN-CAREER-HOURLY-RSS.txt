v2.0.7 Dean Career Compass + hourly RSS

- Adds a dedicated category: 00 Dean La Gaffe — Career Compass.
- The Dean category is for career paths, creative jobs, portfolio proof, interviews, internships, freelancing, client work, studio roles and improving career chances.
- Adds Dean Career Compass RSS sources for creative practice/careers and job/career advice signals.
- Changes the importer from daily scheduling to hourly scheduling.
- Clears legacy daily cron events on theme activation and schedules the importer every hour.
- Adds a self-healing schedule check on init so the hourly event is recreated if missing.
- Note: WordPress cron only runs when the site receives traffic unless a real server cron calls wp-cron.php.
