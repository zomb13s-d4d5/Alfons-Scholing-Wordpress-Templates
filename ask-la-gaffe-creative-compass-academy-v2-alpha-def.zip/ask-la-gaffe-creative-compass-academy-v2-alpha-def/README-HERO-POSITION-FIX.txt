v2.0.4 hero position fix

- Moves the hero text block higher, directly below the sticky header/menu.
- Adds iPad/landscape-specific sizing so headline, description and buttons stay aligned above the feature rail.
- Keeps the bottom feature rail independent from the CTA buttons.
