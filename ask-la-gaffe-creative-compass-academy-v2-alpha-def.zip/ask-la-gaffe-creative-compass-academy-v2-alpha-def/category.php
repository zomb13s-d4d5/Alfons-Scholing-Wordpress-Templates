<?php
get_header();
$term = get_queried_object();
$world = lgu_world_from_term($term);
$worlds = lgu_worlds();
if (!$world) {
    $world = reset($worlds);
    $world['slug'] = 'actual';
}
$category_title = single_cat_title('', false);
$category_desc = category_description();
?>
<main class="category-world-page" style="--world-accent:<?php echo esc_attr($world['color']); ?>;--category-hero:url('<?php echo esc_url(lgu_asset($world['poster'])); ?>')">
  <section class="category-hero">
    <div class="wrap category-hero__inner">
      <div class="category-hero__copy">
        <span class="eyebrow">Studio NotYouAgain.ai / Creative Media Academy</span>
        <h1><?php echo esc_html($category_title ?: $world['title']); ?></h1>
        <?php if ($category_desc): ?><div class="category-description"><?php echo wp_kses_post($category_desc); ?></div><?php else: ?><p><?php echo esc_html($world['desc']); ?></p><?php endif; ?>
      </div>
      <div class="category-hero__badge">
        <img src="<?php echo esc_url(lgu_asset($world['poster'])); ?>" alt="<?php echo esc_attr($world['title']); ?> category thumbnail">
        <b><?php echo esc_html($world['edition']); ?></b>
        <span><?php echo esc_html($world['title']); ?></span>
      </div>
    </div>
  </section>

  <section class="section category-articles">
    <div class="wrap">
      <div class="category-section-head">
        <h2>Lessons <span>(<?php echo esc_html((string) $term->count); ?>)</span></h2>
        <p class="muted">Lessons in this studio use the matching Creative Media Academy category visual as their fallback image when no featured training visual is set.</p>
      </div>

      <?php if (have_posts()): ?>
        <div class="category-card-grid">
          <?php while (have_posts()): the_post(); ?>
            <article <?php post_class('category-post-card'); ?>>
              <a class="category-post-card__image js-lgu-lightbox" href="<?php echo esc_url(lgu_post_image_url(get_the_ID(), 'full')); ?>" data-lgu-lightbox="category-<?php echo esc_attr($term->slug); ?>" data-lgu-title="<?php echo esc_attr(get_the_title()); ?>">
                <img src="<?php echo esc_url(lgu_post_image_url(get_the_ID(), 'large')); ?>" alt="<?php echo esc_attr(lgu_post_image_alt(get_the_ID())); ?>">
              </a>
              <div class="category-post-card__body">
                <span class="eyebrow"><?php echo esc_html($world['title']); ?></span>
                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                <p><?php echo esc_html(wp_trim_words(get_the_excerpt(), 22)); ?></p>
                <a class="read-more" href="<?php the_permalink(); ?>">Open lesson →</a>
              </div>
            </article>
          <?php endwhile; ?>
        </div>
        <?php the_posts_pagination(); ?>
      <?php else: ?>
        <div class="panel panel-pad"><h2>No lessons yet</h2><p class="muted">Add lessons, notes or training articles to this studio and they will appear here with the matching academy visual as the default fallback image.</p></div>
      <?php endif; ?>
    </div>
  </section>
</main>
<?php get_footer(); ?>
