Ask La Gaffe Creative Media Academy — v23 Dean / AI Cheat Cards / Software Manual

Added:
- 23rd character: The Grey Old Alien Dean, used as the academy career guide.
- Two new generated pages on activation/admin load:
  /ai-career-cheat-cards/ — renders 220 AI professor talk cards: 10 cards for each of the 22 professions.
  /industry-software-basics-manual/ — renders a 35-page starter manual for learning basics of industry-standard creative software and studio habits.
- Shortcodes:
  [lgu_ai_cheat_cards]
  [lgu_software_manual]
- Updated podcast and production management assets with the latest individual characters.
- Added homepage guidance buttons linking to the cheat card deck and manual.

Purpose:
The cheat cards are not random prompt filler. They are career-conversation cue cards: career signal, first skill, tool basics, portfolio proof, AI partner, ethics, feedback, collaboration, beginner mission and next career step.
