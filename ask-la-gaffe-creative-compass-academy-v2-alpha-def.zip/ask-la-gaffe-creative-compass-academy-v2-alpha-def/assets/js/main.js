document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('.world-tile').forEach(tile=>{
    tile.addEventListener('mouseenter',()=>{
      document.documentElement.style.setProperty('--violet',getComputedStyle(tile).getPropertyValue('--accent')||'#7b2cff');
    });
  });

  document.querySelectorAll('[data-menu-slider]').forEach(slider=>{
    const track=slider.querySelector('[data-menu-track]');
    const prev=slider.querySelector('.menu-prev');
    const next=slider.querySelector('.menu-next');
    if(!track||!prev||!next) return;
    const amount=()=>Math.max(260, Math.round(track.clientWidth*.72));
    prev.addEventListener('click',()=>track.scrollBy({left:-amount(),behavior:'smooth'}));
    next.addEventListener('click',()=>track.scrollBy({left:amount(),behavior:'smooth'}));
    track.addEventListener('wheel',e=>{
      if(Math.abs(e.deltaY)>Math.abs(e.deltaX)){
        e.preventDefault();
        track.scrollBy({left:e.deltaY,behavior:'auto'});
      }
    },{passive:false});
  });
});


(function(){
  function ready(fn){ if(document.readyState !== 'loading'){ fn(); } else { document.addEventListener('DOMContentLoaded', fn); } }

  ready(function(){
    var selector = 'a.js-lgu-lightbox, .entry-content a[href$=".jpg"], .entry-content a[href$=".jpeg"], .entry-content a[href$=".png"], .entry-content a[href$=".webp"], .entry-content a[href$=".gif"]';
    var links = Array.prototype.slice.call(document.querySelectorAll(selector));
    if(!links.length) return;

    links.forEach(function(link){
      if(!link.classList.contains('js-lgu-lightbox')) link.classList.add('js-lgu-lightbox');
      link.setAttribute('aria-haspopup', 'dialog');
    });

    var lightbox = document.createElement('div');
    lightbox.className = 'lgu-lightbox';
    lightbox.setAttribute('role', 'dialog');
    lightbox.setAttribute('aria-modal', 'true');
    lightbox.setAttribute('aria-label', 'Image lightbox');
    lightbox.innerHTML = '<button class="lgu-lightbox__close" type="button" aria-label="Close">×</button><button class="lgu-lightbox__prev" type="button" aria-label="Previous image">‹</button><div class="lgu-lightbox__frame"><img class="lgu-lightbox__img" alt=""><div class="lgu-lightbox__caption"></div></div><button class="lgu-lightbox__next" type="button" aria-label="Next image">›</button>';
    document.body.appendChild(lightbox);

    var img = lightbox.querySelector('.lgu-lightbox__img');
    var caption = lightbox.querySelector('.lgu-lightbox__caption');
    var closeBtn = lightbox.querySelector('.lgu-lightbox__close');
    var prevBtn = lightbox.querySelector('.lgu-lightbox__prev');
    var nextBtn = lightbox.querySelector('.lgu-lightbox__next');
    var current = 0;

    function setImage(index){
      current = (index + links.length) % links.length;
      var link = links[current];
      var title = link.getAttribute('data-lgu-title') || (link.querySelector('img') ? link.querySelector('img').getAttribute('alt') : '') || '';
      img.src = link.href;
      img.alt = title;
      caption.textContent = title;
      prevBtn.style.display = links.length > 1 ? 'grid' : 'none';
      nextBtn.style.display = links.length > 1 ? 'grid' : 'none';
    }

    function open(index){
      setImage(index);
      lightbox.classList.add('is-open');
      document.documentElement.style.overflow = 'hidden';
      closeBtn.focus();
    }

    function close(){
      lightbox.classList.remove('is-open');
      document.documentElement.style.overflow = '';
      img.removeAttribute('src');
    }

    links.forEach(function(link, index){
      link.addEventListener('click', function(event){
        event.preventDefault();
        open(index);
      });
    });

    closeBtn.addEventListener('click', close);
    prevBtn.addEventListener('click', function(){ setImage(current - 1); });
    nextBtn.addEventListener('click', function(){ setImage(current + 1); });
    lightbox.addEventListener('click', function(event){ if(event.target === lightbox) close(); });
    document.addEventListener('keydown', function(event){
      if(!lightbox.classList.contains('is-open')) return;
      if(event.key === 'Escape') close();
      if(event.key === 'ArrowLeft') setImage(current - 1);
      if(event.key === 'ArrowRight') setImage(current + 1);
    });
  });
})();


(function(){
  function ready(fn){ if(document.readyState !== 'loading'){ fn(); } else { document.addEventListener('DOMContentLoaded', fn); } }
  ready(function(){
    document.querySelectorAll('[data-lgu-slider]').forEach(function(slider){
      var track = slider.querySelector('[data-lgu-slider-track]');
      var prev = slider.querySelector('.slider-prev');
      var next = slider.querySelector('.slider-next');
      if(!track || !prev || !next) return;
      function amount(){
        var first = track.children[0];
        if(!first) return Math.max(260, Math.round(track.clientWidth * .82));
        var gap = parseFloat(getComputedStyle(track).gap || '0') || 0;
        return Math.max(180, Math.round((first.getBoundingClientRect().width + gap) * 2));
      }
      prev.addEventListener('click', function(){ track.scrollBy({left:-amount(), behavior:'smooth'}); });
      next.addEventListener('click', function(){ track.scrollBy({left:amount(), behavior:'smooth'}); });
      track.addEventListener('wheel', function(e){
        if(Math.abs(e.deltaY) > Math.abs(e.deltaX)){
          e.preventDefault();
          track.scrollBy({left:e.deltaY, behavior:'auto'});
        }
      }, {passive:false});
    });
  });
})();


(function(){
  function ready(fn){ if(document.readyState !== 'loading'){ fn(); } else { document.addEventListener('DOMContentLoaded', fn); } }
  ready(function(){
    document.querySelectorAll('[data-slide-prev],[data-slide-next]').forEach(function(button){
      if(button.dataset.lguSliderBound === '1') return;
      button.dataset.lguSliderBound = '1';
      button.addEventListener('click', function(){
        var name = button.getAttribute('data-slide-prev') || button.getAttribute('data-slide-next');
        var slider = document.querySelector('[data-slider="'+name+'"]');
        if(!slider) return;
        var first = slider.querySelector(':scope > *');
        var gap = parseFloat(getComputedStyle(slider).gap || '0') || 0;
        var amount = first ? first.getBoundingClientRect().width + gap : Math.round(slider.clientWidth * 0.85);
        if(button.hasAttribute('data-slide-prev')) amount = -amount;
        slider.scrollBy({left: amount, behavior: 'smooth'});
      });
    });
  });
})();


/* v2.1.4 — autoplay for the Featured Options carousel */
(function(){
  function ready(fn){ if(document.readyState !== 'loading'){ fn(); } else { document.addEventListener('DOMContentLoaded', fn); } }

  ready(function(){
    document.querySelectorAll('[data-lgu-autoplay]').forEach(function(slider){
      var track = slider.querySelector('[data-lgu-slider-track]');
      if(!track || track.children.length < 2) return;

      var interval = parseInt(slider.getAttribute('data-lgu-autoplay'), 10);
      if(!interval || interval < 2500) interval = 6500;

      var paused = false;
      var timer = null;

      function slideWidth(){
        var first = track.children[0];
        if(!first) return track.clientWidth;
        var rect = first.getBoundingClientRect();
        return Math.max(1, Math.round(rect.width));
      }

      function maxScroll(){
        return Math.max(0, track.scrollWidth - track.clientWidth - 4);
      }

      function next(){
        if(paused) return;
        var width = slideWidth();
        var target = track.scrollLeft + width;
        if(target >= maxScroll()) target = 0;
        track.scrollTo({left: target, behavior: 'smooth'});
      }

      function start(){
        stop();
        timer = window.setInterval(next, interval);
      }

      function stop(){
        if(timer) window.clearInterval(timer);
        timer = null;
      }

      function pauseTemporarily(){
        paused = true;
        window.clearTimeout(slider._lguAutoResume);
        slider._lguAutoResume = window.setTimeout(function(){ paused = false; }, interval * 1.4);
      }

      slider.addEventListener('mouseenter', function(){ paused = true; });
      slider.addEventListener('mouseleave', function(){ paused = false; });
      slider.addEventListener('focusin', function(){ paused = true; });
      slider.addEventListener('focusout', function(){ paused = false; });
      track.addEventListener('touchstart', pauseTemporarily, {passive:true});
      track.addEventListener('pointerdown', pauseTemporarily, {passive:true});
      track.addEventListener('wheel', pauseTemporarily, {passive:true});

      slider.querySelectorAll('button,a').forEach(function(el){
        el.addEventListener('click', pauseTemporarily);
      });

      document.addEventListener('visibilitychange', function(){
        if(document.hidden) stop(); else start();
      });

      start();
    });
  });
})();


/* v2.1.5 — subtle menu autoplay, reveal motion and functional hover feedback */
(function(){
  function ready(fn){ if(document.readyState !== 'loading'){ fn(); } else { document.addEventListener('DOMContentLoaded', fn); } }
  function reducedMotion(){ return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches; }

  ready(function(){
    /* Menu auto-nudge: only moves when there is overflow and pauses during user interaction. */
    document.querySelectorAll('[data-menu-slider][data-menu-autoplay]').forEach(function(slider){
      var track = slider.querySelector('[data-menu-track]');
      if(!track) return;

      var interval = parseInt(slider.getAttribute('data-menu-autoplay'), 10) || 4200;
      var paused = false;
      var direction = 1;
      var timer = null;

      function hasOverflow(){ return track.scrollWidth > track.clientWidth + 20; }
      function amount(){ return Math.max(120, Math.round(track.clientWidth * .38)); }
      function setPaused(value){
        paused = value;
        slider.classList.toggle('is-paused', value);
      }
      function step(){
        if(paused || reducedMotion() || !hasOverflow()) return;
        var max = Math.max(0, track.scrollWidth - track.clientWidth - 2);
        if(track.scrollLeft >= max) direction = -1;
        if(track.scrollLeft <= 2) direction = 1;
        slider.classList.add('is-moving');
        track.scrollBy({left: amount() * direction, behavior: 'smooth'});
        window.setTimeout(function(){ slider.classList.remove('is-moving'); }, 900);
      }
      function start(){
        if(timer) window.clearInterval(timer);
        timer = window.setInterval(step, interval);
      }
      function pauseTemporarily(){
        setPaused(true);
        window.clearTimeout(slider._lguMenuResume);
        slider._lguMenuResume = window.setTimeout(function(){ setPaused(false); }, interval * 1.6);
      }

      slider.addEventListener('mouseenter', function(){ setPaused(true); });
      slider.addEventListener('mouseleave', function(){ setPaused(false); });
      slider.addEventListener('focusin', function(){ setPaused(true); });
      slider.addEventListener('focusout', function(){ setPaused(false); });
      track.addEventListener('touchstart', pauseTemporarily, {passive:true});
      track.addEventListener('pointerdown', pauseTemporarily, {passive:true});
      track.addEventListener('wheel', pauseTemporarily, {passive:true});
      slider.querySelectorAll('button,a').forEach(function(el){ el.addEventListener('click', pauseTemporarily); });
      document.addEventListener('visibilitychange', function(){ if(document.hidden && timer) window.clearInterval(timer); else start(); });
      start();
    });

    /* Reveal-on-scroll: useful motion, not decorative overload. */
    var revealTargets = '.cca-section,.section-head-inline,.cca-path-card,.cca-os-card,.latest-feed-head,.latest-feed-card,.cca-alpha-principles,.panel,.feature-slide,.world-tile,.poster-wall-card,.category-post-card,.collectibles-faculty-card,.roster-slide,.article,.stat,.entry-content,.lgu-card-profession,.lgu-cheat-card,.lgu-cheat-jump,.lgu-manual-page';
    var nodes = Array.prototype.slice.call(document.querySelectorAll(revealTargets));
    nodes.forEach(function(el, index){
      if(el.classList.contains('site-header')) return;
      el.classList.add('lgu-motion-reveal');
      el.style.setProperty('--lgu-delay', (index % 6) * 45 + 'ms');
    });

    if('IntersectionObserver' in window && !reducedMotion()){
      var observer = new IntersectionObserver(function(entries){
        entries.forEach(function(entry){
          if(entry.isIntersecting){
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      }, {threshold: .12, rootMargin: '0px 0px -8% 0px'});
      nodes.forEach(function(el){ observer.observe(el); });
    } else {
      nodes.forEach(function(el){ el.classList.add('is-visible'); });
    }

    /* Small magnetic tilt for cards that benefit from clickable feedback. */
    if(!reducedMotion()){
      document.querySelectorAll('.feature-slide,.world-tile,.poster-wall-card,.collectibles-faculty-card,.category-post-card').forEach(function(card, index){
        card.classList.add('lgu-tilt');
        card.style.setProperty('--lgu-rotate', (index % 2 ? '.45deg' : '-.45deg'));
        card.addEventListener('pointermove', function(event){
          var rect = card.getBoundingClientRect();
          if(!rect.width || !rect.height) return;
          var x = (event.clientX - rect.left) / rect.width - .5;
          var y = (event.clientY - rect.top) / rect.height - .5;
          card.style.transform = 'translateY(-5px) rotateX(' + (-y * 3).toFixed(2) + 'deg) rotateY(' + (x * 4).toFixed(2) + 'deg)';
        });
        card.addEventListener('pointerleave', function(){ card.style.transform = ''; });
      });
    }
  });
})();


/* Ask La Gaffe five-slide hero autoplay */
(function(){
  function ready(fn){ if(document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  ready(function(){
    document.querySelectorAll('[data-adlg-hero]').forEach(function(hero){
      var slides = Array.prototype.slice.call(hero.querySelectorAll('[data-adlg-slide]'));
      var dots = Array.prototype.slice.call(hero.querySelectorAll('[data-adlg-dot]'));
      var prev = hero.querySelector('[data-adlg-prev]');
      var next = hero.querySelector('[data-adlg-next]');
      if(slides.length < 2) return;
      var index = 0, timer = null, paused = false;
      function show(i){
        index = (i + slides.length) % slides.length;
        slides.forEach(function(slide, n){
          var active = n === index;
          slide.classList.toggle('is-active', active);
          slide.setAttribute('aria-hidden', active ? 'false' : 'true');
        });
        dots.forEach(function(dot, n){ dot.classList.toggle('is-active', n === index); });
      }
      function advance(){ if(!paused) show(index + 1); }
      function start(){ stop(); timer = window.setInterval(advance, 7200); }
      function stop(){ if(timer) window.clearInterval(timer); timer = null; }
      function pauseSoon(){ paused = true; window.clearTimeout(hero._adlgResume); hero._adlgResume = window.setTimeout(function(){ paused = false; }, 9000); }
      if(prev) prev.addEventListener('click', function(){ show(index - 1); pauseSoon(); });
      if(next) next.addEventListener('click', function(){ show(index + 1); pauseSoon(); });
      dots.forEach(function(dot, n){ dot.addEventListener('click', function(){ show(n); pauseSoon(); }); });
      hero.addEventListener('mouseenter', function(){ paused = true; });
      hero.addEventListener('mouseleave', function(){ paused = false; });
      hero.addEventListener('focusin', function(){ paused = true; });
      hero.addEventListener('focusout', function(){ paused = false; });
      hero.addEventListener('touchstart', pauseSoon, {passive:true});
      document.addEventListener('visibilitychange', function(){ if(document.hidden) stop(); else start(); });
      show(0); start();
    });
  });
})();
