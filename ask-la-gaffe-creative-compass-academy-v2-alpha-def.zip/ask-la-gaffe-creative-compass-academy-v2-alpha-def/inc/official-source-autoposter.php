<?php

if (!defined('ABSPATH')) { exit; }

// HOTFIX: avoid a fatal error if the standalone Auto Poster plugin is still active.
if (class_exists('ALG_Official_Source_Auto_Poster')) { return; }

final class ALG_Official_Source_Auto_Poster {
    const VERSION = '1.2.5-rss-limit-500';
    const CRON_HOOK = 'alg_osap_hourly_fetch';
    const OPTION_SETTINGS = 'alg_osap_settings';
    const OPTION_SOURCES = 'alg_osap_sources';
    const OPTION_LOG = 'alg_osap_log';
    const META_SOURCE_URL = '_alg_osap_source_url';
    const META_SOURCE_NAME = '_alg_osap_source_name';
    const META_SOURCE_HASH = '_alg_osap_source_hash';
    const META_CONFIDENCE = '_alg_category_confidence';
    const META_PRIMARY = '_alg_primary_category';
    const META_REASON = '_alg_category_reason';
    const META_SOURCE_DATE = '_alg_osap_source_date';

    private static $instance = null;
    private $category_ids = array();

    public static function instance(): self {
        if (self::$instance === null) { self::$instance = new self(); }
        return self::$instance;
    }

    private function __construct() {
        add_filter('cron_schedules', array($this, 'cron_schedules'));
        add_action(self::CRON_HOOK, array($this, 'daily_fetch'));
        add_action('init', array($this, 'runtime_maintenance'), 20);
        add_action('admin_init', array($this, 'runtime_maintenance'), 20);
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_post_alg_osap_run_fetch', array($this, 'handle_run_fetch'));
        add_action('admin_post_alg_osap_save_settings', array($this, 'handle_save_settings'));
        add_action('admin_post_alg_osap_save_sources', array($this, 'handle_save_sources'));
        add_action('admin_post_alg_osap_add_source', array($this, 'handle_add_source'));
        add_action('admin_post_alg_osap_restore_sources', array($this, 'handle_restore_sources'));
        add_action('admin_enqueue_scripts', array($this, 'admin_styles'));
        add_action('init', array($this, 'ensure_taxonomy_terms')); // Keep the 1337 / La Gaffe world categories present after updates.
    }

    public function cron_schedules(array $schedules): array {
        if (!isset($schedules['alg_osap_hourly'])) {
            $schedules['alg_osap_hourly'] = array(
                'interval' => HOUR_IN_SECONDS,
                'display'  => __('Every hour — Ask La Gaffe importer', 'ask-la-gaffe-creative-compass-academy'),
            );
        }
        return $schedules;
    }

    public function ensure_hourly_schedule(): void {
        $next = wp_next_scheduled(self::CRON_HOOK);
        if (!$next) {
            wp_schedule_event(time() + 5 * MINUTE_IN_SECONDS, 'alg_osap_hourly', self::CRON_HOOK);
        }
    }

    public function runtime_maintenance(): void {
        // Theme ZIP updates do not always trigger after_switch_theme, so the importer
        // must keep its backend sources, categories, publish status and hourly cron healthy at runtime.
        $this->ensure_default_settings();
        $this->force_publish_status();
        $this->ensure_default_sources();
        $this->ensure_taxonomy_terms();

        // Clear only the legacy daily hook; keep the current hourly hook intact.
        while ($timestamp = wp_next_scheduled('alg_osap_daily_fetch')) {
            wp_unschedule_event($timestamp, 'alg_osap_daily_fetch');
        }

        $this->ensure_hourly_schedule();
    }

    private static function clear_legacy_cron(): void {
        $legacy_hooks = array('alg_osap_daily_fetch', self::CRON_HOOK);
        foreach ($legacy_hooks as $hook) {
            while ($timestamp = wp_next_scheduled($hook)) {
                wp_unschedule_event($timestamp, $hook);
            }
        }
    }

    public static function activate(): void {
        $plugin = self::instance();
        $plugin->ensure_default_settings();
        $plugin->force_publish_status();
        $plugin->ensure_default_sources();
        $plugin->ensure_taxonomy_terms();
        self::clear_legacy_cron();
        wp_schedule_event(time() + 5 * MINUTE_IN_SECONDS, 'alg_osap_hourly', self::CRON_HOOK);
    }

    public static function deactivate(): void {
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        if ($timestamp) { wp_unschedule_event($timestamp, self::CRON_HOOK); }
    }

    private function default_settings(): array {
        return array(
            'post_status' => 'publish',
            'items_per_source' => 4,
            'max_posts_per_run' => 500,
            'excerpt_words' => 70,
            'confidence_threshold' => 60,
            'add_tags' => 1,
            'prepend_lagaffe_note' => 1,
            'taxonomy_mode' => 'hierarchy',
        );
    }

    private function default_sources(): array {
        return array(
            // Dean Career Compass: creative careers, jobs, portfolios and professional survival.
            array('enabled'=>1,'name'=>'The Creative Independent','group'=>'Dean Career Compass / Creative Practice','url'=>'https://thecreativeindependent.com/feed/','default_category'=>'00 Dean La Gaffe — Career Compass'),
            array('enabled'=>1,'name'=>'Creative Boom','group'=>'Dean Career Compass / Creative Industry','url'=>'https://www.creativeboom.com/feed/','default_category'=>'00 Dean La Gaffe — Career Compass'),
            array('enabled'=>1,'name'=>'Creative Lives in Progress','group'=>'Dean Career Compass / Emerging Talent','url'=>'https://creativelivesinprogress.com/feed/','default_category'=>'00 Dean La Gaffe — Career Compass'),
            array('enabled'=>1,'name'=>'Jobs.ac.uk Career Advice','group'=>'Dean Career Compass / Career Advice','url'=>'https://career-advice.jobs.ac.uk/feed/','default_category'=>'00 Dean La Gaffe — Career Compass'),
            array('enabled'=>1,'name'=>'Games-Career.com RSS','group'=>'Dean Career Compass / Games Jobs','url'=>'https://www.games-career.com/FeedsRss/','default_category'=>'00 Dean La Gaffe — Career Compass'),

            // Core academy / research / standards signals.
            array('enabled'=>1,'name'=>'MIT News — Artificial Intelligence','group'=>'Academy / Research Lab','url'=>'https://news.mit.edu/topic/mitartificial-intelligence2-rss.xml','default_category'=>'16 Science & Innovation — Discovery Lab'),
            array('enabled'=>1,'name'=>'MIT News — Architecture','group'=>'Academy / Design School','url'=>'https://news.mit.edu/rss/topic/architecture','default_category'=>'06 Design & Branding — Identity Studio'),
            array('enabled'=>1,'name'=>'MIT News — Media Lab','group'=>'Academy / Creative Technology Lab','url'=>'https://news.mit.edu/rss/topic/media-lab','default_category'=>'12 Coding & Web — Web Lab'),
            array('enabled'=>1,'name'=>'AIGA Eye on Design','group'=>'Professional Body / Design Culture','url'=>'https://eyeondesign.aiga.org/feed/','default_category'=>'06 Design & Branding — Identity Studio'),
            array('enabled'=>0,'name'=>'AIGA — Standards and Professional Practice page monitor','group'=>'Professional Body / Design Ethics','url'=>'https://www.aiga.org/resources/aiga-standards-of-professional-practice','default_category'=>'06 Design & Branding — Identity Studio'),
            array('enabled'=>1,'name'=>'Nielsen Norman Group','group'=>'UX Industry Leader','url'=>'https://www.nngroup.com/feed/rss/','default_category'=>'12 Coding & Web — Web Lab'),
            array('enabled'=>1,'name'=>'Interaction Design Foundation','group'=>'Design Education / Industry Leader','url'=>'https://www.interaction-design.org/rss/site_news.xml','default_category'=>'12 Coding & Web — Web Lab'),
            array('enabled'=>1,'name'=>'W3C News','group'=>'Official Web Standards Body','url'=>'https://www.w3.org/blog/news/feed/','default_category'=>'12 Coding & Web — Web Lab'),

            // Tutorial feeds: more practical lessons, guides and how-to material.
            array('enabled'=>1,'name'=>'MDN Web Docs Blog','group'=>'Tutorial / Web Development','url'=>'https://developer.mozilla.org/en-US/blog/rss.xml','default_category'=>'12 Coding & Web — Web Lab'),
            array('enabled'=>1,'name'=>'web.dev Articles','group'=>'Tutorial / Web Development','url'=>'https://web.dev/feed.xml','default_category'=>'12 Coding & Web — Web Lab'),
            array('enabled'=>1,'name'=>'freeCodeCamp News','group'=>'Tutorial / Coding Education','url'=>'https://www.freecodecamp.org/news/rss/','default_category'=>'12 Coding & Web — Web Lab'),
            array('enabled'=>1,'name'=>'Smashing Magazine','group'=>'Tutorial / Design and Front-End','url'=>'https://www.smashingmagazine.com/feed/','default_category'=>'12 Coding & Web — Web Lab'),
            array('enabled'=>1,'name'=>'CSS-Tricks','group'=>'Tutorial / Front-End Craft','url'=>'https://css-tricks.com/feed/','default_category'=>'12 Coding & Web — Web Lab'),
            array('enabled'=>1,'name'=>'Figma Blog','group'=>'Tutorial / Product and Interface Design','url'=>'https://www.figma.com/blog/feed/','default_category'=>'06 Design & Branding — Identity Studio'),
            array('enabled'=>1,'name'=>'Blender News','group'=>'Tutorial / 3D and Animation','url'=>'https://www.blender.org/feed/','default_category'=>'05 Animation — Motion Studio'),

            // Design / visual culture / packaging / photography.
            array('enabled'=>1,'name'=>'The Dieline','group'=>'Packaging Design Industry Leader','url'=>'https://thedieline.com/feed/','default_category'=>'06 Design & Branding — Identity Studio'),
            array('enabled'=>1,'name'=>'Creative Bloq','group'=>'Design Publishing / Tutorials','url'=>'https://www.creativebloq.com/feed','default_category'=>'06 Design & Branding — Identity Studio'),
            array('enabled'=>1,'name'=>'It’s Nice That','group'=>'Design, Illustration, Animation & Photography Publication','url'=>'https://www.itsnicethat.com/feed','default_category'=>'17 Illustration & Painting — Art Studio'),
            array('enabled'=>1,'name'=>'Dezeen','group'=>'Design and Architecture Publication','url'=>'https://www.dezeen.com/feed/','default_category'=>'06 Design & Branding — Identity Studio'),
            array('enabled'=>1,'name'=>'Designboom','group'=>'Design, Art and Architecture Publication','url'=>'https://www.designboom.com/feed/','default_category'=>'06 Design & Branding — Identity Studio'),
            array('enabled'=>1,'name'=>'Source Magazine — Photography Graduate Feed','group'=>'Photography / Academy Signal','url'=>'https://www.source.ie/feeds/graduate.xml','default_category'=>'03 Photography — Image Studio'),

            // Animation / motion / game / 3D.
            array('enabled'=>1,'name'=>'Animation Magazine','group'=>'Animation Industry Publication','url'=>'https://www.animationmagazine.net/feed/','default_category'=>'05 Animation — Motion Studio'),
            array('enabled'=>1,'name'=>'Cartoon Brew','group'=>'Animation Industry Publication','url'=>'https://www.cartoonbrew.com/feed','default_category'=>'05 Animation — Motion Studio'),
            array('enabled'=>1,'name'=>'Animation World Network','group'=>'Animation Industry Publication','url'=>'https://www.awn.com/news/rss.xml','default_category'=>'05 Animation — Motion Studio'),
            array('enabled'=>1,'name'=>'Skwigly Animation Magazine','group'=>'Animation Industry Publication','url'=>'https://www.skwigly.co.uk/feed/','default_category'=>'05 Animation — Motion Studio'),
            array('enabled'=>1,'name'=>'Motionographer','group'=>'Motion Design Publication','url'=>'https://motionographer.com/feed/','default_category'=>'05 Animation — Motion Studio'),
            array('enabled'=>1,'name'=>'Animation Obsessive','group'=>'Animation Criticism / Newsletter','url'=>'https://animationobsessive.substack.com/feed','default_category'=>'05 Animation — Motion Studio'),
            array('enabled'=>1,'name'=>'Game Developer','group'=>'Game Design Industry Publication','url'=>'https://www.gamedeveloper.com/rss.xml','default_category'=>'14 Game Design — Play Lab'),

            // Radio / podcast / sound / music.
            array('enabled'=>1,'name'=>'Limelight','group'=>'Classical Music / Arts Publication','url'=>'https://limelight-arts.com.au/feed/','default_category'=>'09 Music Production — Melody Studio'),
            array('enabled'=>1,'name'=>'Radio World','group'=>'Radio Broadcast Industry Publication','url'=>'https://www.radioworld.com/feed','default_category'=>'21 Podcast & Radio — On Air Studio'),
            array('enabled'=>1,'name'=>'Radio Ink','group'=>'Radio Broadcast Industry Publication','url'=>'https://radioink.com/feed/','default_category'=>'21 Podcast & Radio — On Air Studio'),
            array('enabled'=>1,'name'=>'Transom','group'=>'Radio Storytelling / Audio Craft','url'=>'https://transom.org/feed/','default_category'=>'21 Podcast & Radio — On Air Studio'),
            array('enabled'=>1,'name'=>'Current','group'=>'Public Media / Radio Industry Publication','url'=>'https://current.org/feed/','default_category'=>'21 Podcast & Radio — On Air Studio'),
            array('enabled'=>1,'name'=>'Podnews','group'=>'Podcast / Audio Industry Publication','url'=>'https://podnews.net/rss','default_category'=>'21 Podcast & Radio — On Air Studio'),
            array('enabled'=>1,'name'=>'Gramophone','group'=>'Classical Music Publication','url'=>'https://www.gramophone.co.uk/feed','default_category'=>'09 Music Production — Melody Studio'),
            array('enabled'=>1,'name'=>'Bachtrack','group'=>'Classical Music / Performance Publication','url'=>'https://bachtrack.com/feed','default_category'=>'09 Music Production — Melody Studio'),
            array('enabled'=>1,'name'=>'Classical Music','group'=>'Classical Music Industry Publication','url'=>'https://www.classical-music.com/feed','default_category'=>'09 Music Production — Melody Studio'),
            array('enabled'=>1,'name'=>'OperaWire','group'=>'Opera / Classical Music Publication','url'=>'https://operawire.com/feed/','default_category'=>'09 Music Production — Melody Studio'),

            // Film / television / production management.
            array('enabled'=>1,'name'=>'TV Technology','group'=>'Television Broadcast Technology Publication','url'=>'https://www.tvtechnology.com/rss','default_category'=>'22 Production Management — Coordination Desk'),
            array('enabled'=>1,'name'=>'NewscastStudio','group'=>'Broadcast Production / TV Design Publication','url'=>'https://www.newscaststudio.com/feed/','default_category'=>'22 Production Management — Coordination Desk'),
            array('enabled'=>1,'name'=>'Rapid TV News','group'=>'Television Industry Publication','url'=>'https://www.rapidtvnews.com/news/rss.html','default_category'=>'02 Film & Video — Cinema Studio'),
            array('enabled'=>1,'name'=>'TBI Vision','group'=>'Television Business / Production Publication','url'=>'https://tbivision.com/feed/','default_category'=>'02 Film & Video — Cinema Studio'),
            array('enabled'=>1,'name'=>'TVBEurope','group'=>'Broadcast Technology Publication','url'=>'https://www.tvbeurope.com/feed','default_category'=>'22 Production Management — Coordination Desk'),

            // European design / art academy monitors. Disabled when they are page monitors rather than clean RSS feeds.
            array('enabled'=>0,'name'=>'Design Academy Eindhoven — News page monitor','group'=>'European Academy / Design School','url'=>'https://www.designacademy.nl/page/6701/news','default_category'=>'06 Design & Branding — Identity Studio'),
            array('enabled'=>0,'name'=>'Royal College of Art — News page monitor','group'=>'European Academy / Art and Design School','url'=>'https://www.rca.ac.uk/news-and-events/news/','default_category'=>'06 Design & Branding — Identity Studio'),
            array('enabled'=>0,'name'=>'Aalto ARTS — News page monitor','group'=>'European Academy / Art, Design and Architecture','url'=>'https://www.aalto.fi/en/school-of-arts-design-and-architecture/news','default_category'=>'16 Science & Innovation — Discovery Lab'),
            array('enabled'=>0,'name'=>'UAL London College of Communication — Stories page monitor','group'=>'European Academy / Communication, Media and Screen','url'=>'https://www.arts.ac.uk/colleges/london-college-of-communication/stories','default_category'=>'07 Writing & Journalism — Editorial Studio'),
            array('enabled'=>0,'name'=>'ECAL — News page monitor','group'=>'European Academy / Design and Visual Arts','url'=>'https://ecal.ch/en/news/','default_category'=>'06 Design & Branding — Identity Studio'),
            array('enabled'=>0,'name'=>'KABK — News page monitor','group'=>'European Academy / Art and Design','url'=>'https://www.kabk.nl/en/news','default_category'=>'17 Illustration & Painting — Art Studio'),
            array('enabled'=>0,'name'=>'Gerrit Rietveld Academie — News page monitor','group'=>'European Academy / Art and Design','url'=>'https://rietveldacademie.nl/en/page/1544/news','default_category'=>'17 Illustration & Painting — Art Studio'),
            array('enabled'=>0,'name'=>'Politecnico di Milano School of Design — News page monitor','group'=>'European Academy / Product, Industrial and Communication Design','url'=>'https://www.polimi.it/en/','default_category'=>'06 Design & Branding — Identity Studio'),
            array('enabled'=>0,'name'=>'ENSCI Les Ateliers — News page monitor','group'=>'European Academy / Industrial Design','url'=>'https://www.ensci.com/actualites/','default_category'=>'06 Design & Branding — Identity Studio'),
            array('enabled'=>0,'name'=>'Zurich University of the Arts — News page monitor','group'=>'European Academy / Arts, Design, Music and Media','url'=>'https://www.zhdk.ch/en/news','default_category'=>'06 Design & Branding — Identity Studio')
        );
    }

    private function ensure_default_settings(): void {
        if (!get_option(self::OPTION_SETTINGS)) { add_option(self::OPTION_SETTINGS, $this->default_settings()); }
    }

    private function force_publish_status(): void {
        $settings = wp_parse_args((array)get_option(self::OPTION_SETTINGS, array()), $this->default_settings());
        if (($settings['post_status'] ?? '') !== 'publish') {
            $settings['post_status'] = 'publish';
            update_option(self::OPTION_SETTINGS, $settings);
        }
    }

    private function settings(): array {
        // Default is publish, but the backend must keep the full control panel:
        // admins may choose Publish immediately, Draft, or Pending review.
        return wp_parse_args((array)get_option(self::OPTION_SETTINGS, array()), $this->default_settings());
    }

    private function ensure_default_sources(): void {
        $existing = get_option(self::OPTION_SOURCES);
        if (!$existing) { add_option(self::OPTION_SOURCES, $this->default_sources()); return; }
        $sources = is_array($existing) ? $existing : array();
        $legacy_category_map = array(
            '01 Deep Blue — Digital World' => '12 Coding & Web — Web Lab',
            '02 White — Animation World' => '05 Animation — Motion Studio',
            '03 Yellow — Packaging World' => '06 Design & Branding — Identity Studio',
            '04 Pink — Branding World' => '06 Design & Branding — Identity Studio',
            '05 Red — Radio World' => '21 Podcast & Radio — On Air Studio',
            '06 Green — Television World' => '22 Production Management — Coordination Desk',
            '07 Orange — Cinema World' => '02 Film & Video — Cinema Studio',
            '08 Brown — Theatre World' => '02 Film & Video — Cinema Studio',
            '09 Silver Metallic — Orchestra World' => '09 Music Production — Melody Studio'
        );
        $changed = false;
        foreach ($sources as &$source_row) {
            $old_cat = (string)($source_row['default_category'] ?? '');
            if (isset($legacy_category_map[$old_cat])) { $source_row['default_category'] = $legacy_category_map[$old_cat]; $changed = true; }
        }
        unset($source_row);
        $known = array();
        foreach ($sources as $s) {
            $key = !empty($s['url']) ? strtolower((string)$s['url']) : strtolower((string)($s['name'] ?? ''));
            if ($key !== '') { $known[$key] = true; }
        }
        foreach ($this->default_sources() as $default) {
            $key = !empty($default['url']) ? strtolower((string)$default['url']) : strtolower((string)$default['name']);
            if (!isset($known[$key])) { $sources[] = $default; $changed = true; }
        }
        if ($changed) { update_option(self::OPTION_SOURCES, $sources); }
    }
    private function sources(): array { return (array)get_option(self::OPTION_SOURCES, $this->default_sources()); }

    private function lagaffe_worlds(): array {
        return array(
            array(
                'code'=>'00', 'color'=>'Gold', 'world'=>'Ask La Gaffe', 'category'=>'00 Dean La Gaffe — Career Compass',
                'theme'=>'career paths, creative jobs, portfolio proof, internships, interviews, freelance survival, studio roles and lifelong creative career chances.',
                'visual'=>'Grey old alien Dean, magical career compass, academy office, cards, dashboards and professional guidance',
                'props'=>'Career Compass Office',
                'keywords'=>array('career','careers','job','jobs','hiring','hire','interview','portfolio','cv','resume','résumé','internship','graduate','freelance','freelancer','client','salary','income','money','making a living','creative practice','creative career','emerging talent','opportunities','networking','mentor','studio role','application','job search','professional development','career advice','work','workplace')
            ),
            array(
                'code'=>'01', 'color'=>'Purple', 'world'=>'Storytelling', 'category'=>'01 Storytelling — Imagination Studio',
                'theme'=>'Narrative thinking, story structure, worldbuilding and idea development for public media.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Imagination Studio',
                'keywords'=>array('story','storytelling','narrative','script','worldbuilding','plot','characters','fiction','book','imagination','writing')
            ),
            array(
                'code'=>'02', 'color'=>'Purple', 'world'=>'Film & Video', 'category'=>'02 Film & Video — Cinema Studio',
                'theme'=>'Filmmaking, video formats, camera language, scenes, shorts, trailers and creator video.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Cinema Studio',
                'keywords'=>array('film','video','cinema','movie','camera','clapperboard','filmmaking','trailer','director','shoot','cinematic')
            ),
            array(
                'code'=>'03', 'color'=>'Purple', 'world'=>'Photography', 'category'=>'03 Photography — Image Studio',
                'theme'=>'Photography, image culture, visual essays, lenses and public visual storytelling.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Image Studio',
                'keywords'=>array('photo','photography','photographer','camera','lens','image','portrait','documentary','visual essay','snapshot')
            ),
            array(
                'code'=>'04', 'color'=>'Purple', 'world'=>'Sound & Voice', 'category'=>'04 Sound & Voice — Audio Studio',
                'theme'=>'Sound design, voice performance, sonic identity, foley, microphones, audio texture and recording confidence.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Audio Studio',
                'keywords'=>array('sound','audio','voice','voice acting','sonic','foley','microphone','mic','headphones','speaker','sound design')
            ),
            array(
                'code'=>'05', 'color'=>'Purple', 'world'=>'Animation', 'category'=>'05 Animation — Motion Studio',
                'theme'=>'Animation, motion design, storyboards, timing, frames, characters and visual rhythm.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Motion Studio',
                'keywords'=>array('animation','animated','motion','storyboard','cartoon','animator','vfx','timing','frame','character','motion graphics')
            ),
            array(
                'code'=>'06', 'color'=>'Purple', 'world'=>'Design & Branding', 'category'=>'06 Design & Branding — Identity Studio',
                'theme'=>'Graphic design, identity systems, logo logic, brand voice, colour and campaign clarity.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Identity Studio',
                'keywords'=>array('design','branding','brand','identity','logo','palette','campaign','strategy','graphic','layout','typography','swatch')
            ),
            array(
                'code'=>'07', 'color'=>'Purple', 'world'=>'Writing & Journalism', 'category'=>'07 Writing & Journalism — Editorial Studio',
                'theme'=>'Writing, publishing, editorial thinking, explainers, interviews, articles and zines.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Editorial Studio',
                'keywords'=>array('writing','journalism','editorial','publishing','article','press','newsletter','zine','newspaper','copywriting','writer')
            ),
            array(
                'code'=>'08', 'color'=>'Purple', 'world'=>'Editing & Post-Production', 'category'=>'08 Editing & Post-Production — Edit Studio',
                'theme'=>'Editing, timelines, cuts, post-production, captions, rhythm, polishing and delivery.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Edit Studio',
                'keywords'=>array('editing','edit','post-production','post production','timeline','cut','cuts','scissors','subtitle','caption','render','sequence')
            ),
            array(
                'code'=>'09', 'color'=>'Purple', 'world'=>'Music Production', 'category'=>'09 Music Production — Melody Studio',
                'theme'=>'Music, jingles, composition, rhythm, sonic branding and performance-based production.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Melody Studio',
                'keywords'=>array('music','jingle','song','composition','composer','keyboard','midi','instrument','melody','soundtrack','beat')
            ),
            array(
                'code'=>'10', 'color'=>'Purple', 'world'=>'Streaming & Social Media', 'category'=>'10 Streaming & Social — Broadcast Studio',
                'theme'=>'Streaming, creator formats, social broadcasting, community signals and live presence.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Broadcast Studio',
                'keywords'=>array('streaming','stream','social media','creator','live','broadcast','tiktok','youtube','instagram','community','ring light')
            ),
            array(
                'code'=>'11', 'color'=>'Purple', 'world'=>'Reporting & Research', 'category'=>'11 Reporting — Source Lab',
                'theme'=>'Source checking, public-interest reporting, interviews, research trails and fact-aware publishing.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Source Lab',
                'keywords'=>array('reporting','reporter','source','sources','research','investigation','investigate','fact check','microphone','news','journalist')
            ),
            array(
                'code'=>'12', 'color'=>'Purple', 'world'=>'Coding & Web Creation', 'category'=>'12 Coding & Web — Web Lab',
                'theme'=>'Websites, code, interfaces, interaction, creative technology and digital craft.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Web Lab',
                'keywords'=>array('code','coding','web','website','websites','wordpress','html','css','javascript','interface','ux','ui','software','app')
            ),
            array(
                'code'=>'13', 'color'=>'Purple', 'world'=>'Presenting & Public Speaking', 'category'=>'13 Presenting — Stage Studio',
                'theme'=>'Presenting, public speaking, lectures, confidence, demos, stage presence and audience communication.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Stage Studio',
                'keywords'=>array('presenting','presentation','public speaking','speaking','stage','pitch','lecture','speaker','chart','podium','demo')
            ),
            array(
                'code'=>'14', 'color'=>'Purple', 'world'=>'Game Design', 'category'=>'14 Game Design — Play Lab',
                'theme'=>'Game storytelling, interactive media, play systems, levels, mechanics and creative prototypes.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Play Lab',
                'keywords'=>array('game','games','gaming','game design','controller','interactive','level','mechanic','pixel','play','prototype')
            ),
            array(
                'code'=>'15', 'color'=>'Purple', 'world'=>'Fashion & Styling', 'category'=>'15 Fashion & Styling — Costume Studio',
                'theme'=>'Fashion media, costume design, styling, fabric, wardrobe, character looks and visual identity.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Costume Studio',
                'keywords'=>array('fashion','styling','costume','wardrobe','fabric','textile','sewing','mannequin','tailor','outfit','style')
            ),
            array(
                'code'=>'16', 'color'=>'Purple', 'world'=>'Science & Innovation', 'category'=>'16 Science & Innovation — Discovery Lab',
                'theme'=>'Science communication, innovation, technology, labs, experiments and research-driven media.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Discovery Lab',
                'keywords'=>array('science','innovation','research','lab','laboratory','microscope','technology','experiment','ai','robot','biology','climate')
            ),
            array(
                'code'=>'17', 'color'=>'Purple', 'world'=>'Illustration & Painting', 'category'=>'17 Illustration & Painting — Art Studio',
                'theme'=>'Illustration, painting, drawing, visual arts, character art, comics and expressive mark-making.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Art Studio',
                'keywords'=>array('illustration','painting','drawing','artist','visual art','canvas','brush','comic','zine','character art','sketch')
            ),
            array(
                'code'=>'18', 'color'=>'Purple', 'world'=>'Event Production', 'category'=>'18 Event Production — Live Control',
                'theme'=>'Events, live production, stage management, cue sheets, lighting and creative coordination.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Live Control',
                'keywords'=>array('event','events','live','stage management','stage manager','production','lighting','spotlight','cue','clipboard','festival','conference')
            ),
            array(
                'code'=>'19', 'color'=>'Purple', 'world'=>'Marketing & Social Media', 'category'=>'19 Marketing — Growth Studio',
                'theme'=>'Marketing, strategy, community growth, social messaging, campaigns, metrics and creative reach.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Growth Studio',
                'keywords'=>array('marketing','market','growth','strategy','campaign','social media','analytics','audience','community','megaphone','reach')
            ),
            array(
                'code'=>'20', 'color'=>'Purple', 'world'=>'Documentary & Exploration', 'category'=>'20 Documentary — Exploration Desk',
                'theme'=>'Documentary, fieldwork, travel stories, research, place-based media and discovery-led production.',
                'visual'=>'Playful academy visuals, rounded character shapes and friendly creative energy',
                'props'=>'Exploration Desk',
                'keywords'=>array('documentary','exploration','explore','fieldwork','travel','place','map','globe','camera','compass','research')
            ),
            array(
                'code'=>'21', 'color'=>'Purple', 'world'=>'Podcast & Radio', 'category'=>'21 Podcast & Radio — On Air Studio',
                'theme'=>'Podcast production, radio formats, interviews, cue cards, voice recording, audio publishing and on-air confidence.',
                'visual'=>'Green frog mascot, purple studio, broadcast microphone, mixer and on-air signs',
                'props'=>'On Air Studio',
                'keywords'=>array('podcast','podcasting','radio','on air','audio publishing','cue cards','broadcast mic','microphone','interview','episode','listener','recording')
            ),
            array(
                'code'=>'22', 'color'=>'Purple', 'world'=>'Production Management', 'category'=>'22 Production Management — Coordination Desk',
                'theme'=>'Production planning, schedules, shot lists, call sheets, coordination, crews, reviews and delivery management.',
                'visual'=>'Mouse production manager mascot, headset, clipboard, production board and multi-camera monitors',
                'props'=>'Coordination Desk',
                'keywords'=>array('production manager','production management','producer','production plan','schedule','shot list','call sheet','crew','talent','b-roll','camera feed','deliver','coordination')
            )
        );
    }

    public function ensure_taxonomy_terms(): void {
        $this->category_ids = array();
        $settings = $this->settings();
        $parents = array(
            'News & Society' => array('World Affairs','Local & Society','Crime & Justice','Economy & Work'),
            'Culture' => array('Culture & Entertainment','Sports','Travel & Places','Media & Internet'),
            'Design Culture' => array('Design & Creativity','Design Policy & Ethics','UI & UX Design','Graphic Design & Typography','Brand & Identity','Packaging Design','Product & Industrial Design','Architecture & Urban Design','Motion & Animation','Photography & Image Culture','Visual Arts & Illustration','Publishing & Editorial','Creative Technology','Design Schools & Academies'),
            'Knowledge' => array('Technology & AI','Health & Science'),
            'La Gaffe Voice' => array('Uncle’s Wisdom','Philosopher’s Note','La Gaffe Reacts','Mistakes & Mayhem','Ask The Uncle'),
        );
        foreach ($parents as $parent_name=>$children) {
            $parent_id = 0;
            if ($settings['taxonomy_mode'] === 'hierarchy') { $parent_id = $this->ensure_category($parent_name, 0); }
            foreach ($children as $child) { $this->category_ids[$child] = $this->ensure_category($child, $parent_id); }
        }

        // 1337 / Ask La Gaffe Creative Media Academy categories. These are always created as a clear world tree.
        $universe_id = $this->ensure_category('1337 / Ask La Gaffe Creative Media Academy', 0, 'The purple academy universe where creative stories, lessons and discoveries are gathered into friendly media studios.');
        foreach ($this->lagaffe_worlds() as $world) {
            $description = $world['world'].' is a friendly Ask La Gaffe studio for '.lcfirst($world['theme']).' Explore the '.$world['props'].' through playful lessons, creative challenges and character-led academy stories.';
            $cat_id = $this->ensure_category($world['category'], $universe_id, $description);
            $this->category_ids[$world['category']] = $cat_id;
            update_term_meta($cat_id, 'alg_1337_color_edition', $world['color']);
            update_term_meta($cat_id, 'alg_1337_world', $world['world']);
            update_term_meta($cat_id, 'alg_1337_core_theme', $world['theme']);
            update_term_meta($cat_id, 'alg_1337_visual_language', $world['visual']);
            update_term_meta($cat_id, 'alg_1337_key_props', $world['props']);
            update_term_meta($cat_id, 'alg_1337_universal_outline_color', 'Deep purple / violet');
        }
        $this->category_ids['Needs Review'] = $this->ensure_category('Needs Review', 0);
    }

    private function ensure_category(string $name, int $parent=0, string $description=''): int {
        $term = get_term_by('name', $name, 'category');
        if ($term && !is_wp_error($term)) {
            $updates = array();
            if ($parent > 0 && (int)$term->parent !== $parent) { $updates['parent'] = $parent; }
            if ($description !== '' && (string)$term->description !== $description) { $updates['description'] = $description; }
            if ($updates) { wp_update_term((int)$term->term_id, 'category', $updates); }
            return (int)$term->term_id;
        }
        $args = array('parent'=>$parent);
        if ($description !== '') { $args['description'] = $description; }
        $result = wp_insert_term($name, 'category', $args);
        if (is_wp_error($result)) { return (int)get_option('default_category', 1); }
        return (int)$result['term_id'];
    }

    public function admin_menu(): void {
        add_menu_page(
            'Ask La Gaffe RSS Feed Editor',
            'La Gaffe RSS',
            'manage_options',
            'alg-official-source-autoposter',
            array($this,'render_admin_page'),
            'dashicons-rss',
            59
        );
        add_management_page(
            'Ask La Gaffe RSS Feed Editor',
            'Auto Poster + RSS Feeds',
            'manage_options',
            'alg-official-source-autoposter',
            array($this,'render_admin_page')
        );
    }

    public function admin_styles(string $hook): void {
        if ($hook !== 'tools_page_alg-official-source-autoposter' && $hook !== 'toplevel_page_alg-official-source-autoposter') { return; }
        $css = '.alg-card{background:#fff;border:1px solid #ccd0d4;border-radius:8px;padding:18px;margin:16px 0;max-width:1080px}.alg-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}.alg-log{max-height:340px;overflow:auto;background:#111;color:#f4f4f4;padding:12px;border-radius:6px;font-family:monospace;font-size:12px}.alg-muted{color:#646970}.alg-source-table td,.alg-source-table th{vertical-align:top}.alg-source-table input[type=text],.alg-source-table input[type=url]{width:100%}.alg-badge{display:inline-block;background:#111;color:#fff;border-radius:999px;padding:2px 8px;font-size:12px}.alg-world-card{border:2px solid #5b19b7;border-radius:14px;padding:12px;background:linear-gradient(135deg,#fff,#f7f2ff);box-shadow:4px 4px 0 #5b19b7}.alg-world-card strong{color:#1d102b}.alg-world-card span{color:#5b19b7;font-weight:700}.alg-world-card small{display:block;margin-top:6px;color:#3c3544}';
        wp_add_inline_style('wp-admin', $css);
    }

    public function render_admin_page(): void {
        if (!current_user_can('manage_options')) { return; }
        $settings = $this->settings();
        $sources = $this->sources();
        $log = (array)get_option(self::OPTION_LOG, array());
        $next = wp_next_scheduled(self::CRON_HOOK);
        ?>
        <div class="wrap">
            <h1>Ask La Gaffe Auto Poster + RSS Feeds</h1>
            <p class="alg-muted">Theme-integrated RSS backend: official academy, research, tutorials, career, jobs and industry-leader RSS feeds. Creates attributed <?php echo esc_html($settings['post_status']); ?> posts, then assigns Ask La Gaffe categories.</p>
            <?php if (!empty($_GET['alg_notice'])): ?><div class="notice notice-success is-dismissible"><p><?php echo esc_html(wp_unslash($_GET['alg_notice'])); ?></p></div><?php endif; ?>
            <div class="alg-card"><h2>Status</h2><div class="alg-grid">
                <p><strong>Next hourly fetch:</strong><br><?php echo $next ? esc_html(date_i18n(get_option('date_format').' '.get_option('time_format'), $next)) : 'Not scheduled'; ?></p>
                <p><strong>Post status:</strong><br><span class="alg-badge"><?php echo esc_html($settings['post_status']); ?></span></p>
                <p><strong>Max posts/run:</strong><br><?php echo esc_html((string)$settings['max_posts_per_run']); ?></p>
                <p><strong>Enabled sources:</strong><br><?php echo esc_html((string)count(array_filter($sources, function($s){ return !empty($s['enabled']); }))); ?></p>
            </div></div>

            <div class="alg-card"><h2>1337 / La Gaffe world categories</h2>
                <p class="alg-muted"><strong>Brand rule:</strong> 1337 is the elite creative academy brand. La Gaffe is the deep purple/violet outline spirit connecting every world. Purple/violet is used as outline, glow, shadow, academy signal and attitude color.</p>
                <div class="alg-grid">
                    <?php foreach ($this->lagaffe_worlds() as $world): ?>
                        <div class="alg-world-card">
                            <strong><?php echo esc_html($world['code'].' '.$world['color']); ?></strong><br>
                            <span><?php echo esc_html($world['world']); ?></span><br>
                            <small><?php echo esc_html($world['theme']); ?></small>
                        </div>
                    <?php endforeach; ?>
                </div>
                <p class="alg-muted">These categories are created automatically under <strong>1337 / Ask La Gaffe Creative Media Academy</strong> and the importer can classify posts into them by world keywords.</p>
            </div>

            <div class="alg-card"><h2>Manual fetch</h2>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <?php wp_nonce_field('alg_osap_run_fetch'); ?><input type="hidden" name="action" value="alg_osap_run_fetch">
                    <?php submit_button('Auto Post Now / Fetch RSS Now', 'primary', 'submit', false); ?>
                </form>
                <p class="alg-muted">The backend skips duplicates by original source URL. Broken/non-RSS source URLs are logged and ignored. WordPress cron needs traffic or a real server cron to run hourly.</p>
            </div>

            <div class="alg-card"><h2>Settings</h2>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('alg_osap_save_settings'); ?><input type="hidden" name="action" value="alg_osap_save_settings">
                <table class="form-table" role="presentation">
                    <tr><th>Post status</th><td><select name="post_status"><option value="publish" <?php selected($settings['post_status'],'publish'); ?>>Publish immediately</option><option value="draft" <?php selected($settings['post_status'],'draft'); ?>>Draft, safest</option><option value="pending" <?php selected($settings['post_status'],'pending'); ?>>Pending review</option></select></td></tr>
                    <tr><th>Items per source</th><td><input type="number" name="items_per_source" min="1" max="20" value="<?php echo esc_attr((string)$settings['items_per_source']); ?>"></td></tr>
                    <tr><th>Max posts per run</th><td><input type="number" name="max_posts_per_run" min="1" max="500" value="<?php echo esc_attr((string)$settings['max_posts_per_run']); ?>"></td></tr>
                    <tr><th>Excerpt length</th><td><input type="number" name="excerpt_words" min="20" max="200" value="<?php echo esc_attr((string)$settings['excerpt_words']); ?>"> words</td></tr>
                    <tr><th>Confidence threshold</th><td><input type="number" name="confidence_threshold" min="1" max="100" value="<?php echo esc_attr((string)$settings['confidence_threshold']); ?>"> %</td></tr>
                    <tr><th>Tags</th><td><label><input type="checkbox" name="add_tags" value="1" <?php checked($settings['add_tags'],1); ?>> Add source/category/topic tags</label></td></tr>
                    <tr><th>La Gaffe note</th><td><label><input type="checkbox" name="prepend_lagaffe_note" value="1" <?php checked($settings['prepend_lagaffe_note'],1); ?>> Add a short branded curation note above the source excerpt</label></td></tr>
                </table><?php submit_button('Save settings'); ?></form>
            </div>

            <div class="alg-card"><h2>Add RSS feed</h2>
                <p class="alg-muted">Add a new RSS/Atom source directly into the backend. It will be saved into the theme importer source list and can be auto-posted hourly or with the button above.</p>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="alg-add-source-form">
                    <?php wp_nonce_field('alg_osap_add_source'); ?><input type="hidden" name="action" value="alg_osap_add_source">
                    <div class="alg-grid">
                        <p><label><strong>Name</strong><br><input type="text" name="source_name" class="widefat" placeholder="Example: Creative Career Feed" required></label></p>
                        <p><label><strong>Group</strong><br><input type="text" name="source_group" class="widefat" placeholder="Dean Career Compass / Jobs"></label></p>
                        <p><label><strong>Feed URL</strong><br><input type="url" name="source_url" class="widefat" placeholder="https://example.com/feed/" required></label></p>
                        <p><label><strong>Default category</strong><br><input type="text" name="source_category" class="widefat" value="00 Dean La Gaffe — Career Compass"></label></p>
                    </div>
                    <p><label><input type="checkbox" name="source_enabled" value="1" checked> Enable this source immediately</label></p>
                    <?php submit_button('Add RSS Feed', 'secondary', 'submit', false); ?>
                </form>
            </div>

            <div class="alg-card"><h2>Restore built-in RSS backend</h2>
                <p class="alg-muted">Use this if a theme update, cache, or older source table removed the built-in feeds. Existing custom feeds are kept; missing built-in feeds are added back.</p>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <?php wp_nonce_field('alg_osap_restore_sources'); ?><input type="hidden" name="action" value="alg_osap_restore_sources">
                    <?php submit_button('Restore Built-In RSS Sources', 'secondary', 'submit', false); ?>
                </form>
            </div>

            <div class="alg-card"><h2>Official RSS sources</h2>
                <p class="alg-muted">Full backend source table. Turn feeds on/off, rename them, edit the feed URL, or assign a default academy category.</p>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('alg_osap_save_sources'); ?><input type="hidden" name="action" value="alg_osap_save_sources">
                <table class="widefat striped alg-source-table"><thead><tr><th>On</th><th>Name</th><th>Group</th><th>Feed URL</th><th>Default category</th></tr></thead><tbody>
                <?php for ($i=0; $i<max(24, count($sources)+10); $i++): $s = isset($sources[$i]) ? $sources[$i] : array('enabled'=>0,'name'=>'','group'=>'','url'=>'','default_category'=>''); ?>
                    <tr>
                        <td><input type="checkbox" name="sources[<?php echo esc_attr((string)$i); ?>][enabled]" value="1" <?php checked(!empty($s['enabled']), true); ?>></td>
                        <td><input type="text" name="sources[<?php echo esc_attr((string)$i); ?>][name]" value="<?php echo esc_attr((string)($s['name'] ?? '')); ?>"></td>
                        <td><input type="text" name="sources[<?php echo esc_attr((string)$i); ?>][group]" value="<?php echo esc_attr((string)($s['group'] ?? '')); ?>"></td>
                        <td><input type="url" name="sources[<?php echo esc_attr((string)$i); ?>][url]" value="<?php echo esc_attr((string)($s['url'] ?? '')); ?>"></td>
                        <td><input type="text" name="sources[<?php echo esc_attr((string)$i); ?>][default_category]" value="<?php echo esc_attr((string)($s['default_category'] ?? '')); ?>"></td>
                    </tr>
                <?php endfor; ?></tbody></table><?php submit_button('Save sources'); ?></form>
                <p class="alg-muted">Use RSS/Atom feeds whenever possible. Plain news pages are kept disabled by default because they require a scraper, not a clean RSS pull.</p>
            </div>

            <div class="alg-card"><h2>Recent log</h2><div class="alg-log"><?php if (!$log) { echo 'No log yet.'; } else { foreach (array_slice(array_reverse($log),0,80) as $entry) { echo esc_html($entry)."\n"; } } ?></div></div>
        </div>
        <?php
    }

    public function handle_save_settings(): void {
        if (!current_user_can('manage_options') || !check_admin_referer('alg_osap_save_settings')) { wp_die('Forbidden'); }
        $old = $this->settings();
        $settings = array(
            'post_status' => in_array($_POST['post_status'] ?? 'publish', array('draft','pending','publish'), true) ? sanitize_key($_POST['post_status']) : 'publish',
            'items_per_source' => max(1, min(20, absint($_POST['items_per_source'] ?? $old['items_per_source']))),
            'max_posts_per_run' => max(1, min(500, absint($_POST['max_posts_per_run'] ?? $old['max_posts_per_run']))),
            'excerpt_words' => max(20, min(200, absint($_POST['excerpt_words'] ?? $old['excerpt_words']))),
            'confidence_threshold' => max(1, min(100, absint($_POST['confidence_threshold'] ?? $old['confidence_threshold']))),
            'add_tags' => isset($_POST['add_tags']) ? 1 : 0,
            'prepend_lagaffe_note' => isset($_POST['prepend_lagaffe_note']) ? 1 : 0,
            'taxonomy_mode' => $old['taxonomy_mode'],
        );
        update_option(self::OPTION_SETTINGS, $settings);
        $this->redirect('Settings saved.');
    }

    public function handle_add_source(): void {
        if (!current_user_can('manage_options') || !check_admin_referer('alg_osap_add_source')) { wp_die('Forbidden'); }
        $name = sanitize_text_field($_POST['source_name'] ?? '');
        $url = esc_url_raw($_POST['source_url'] ?? '');
        if ($name === '' || $url === '') { $this->redirect('RSS source was not added: name and feed URL are required.'); }
        $sources = $this->sources();
        $sources[] = array(
            'enabled' => !empty($_POST['source_enabled']) ? 1 : 0,
            'name' => $name,
            'group' => sanitize_text_field($_POST['source_group'] ?? ''),
            'url' => $url,
            'default_category' => sanitize_text_field($_POST['source_category'] ?? '00 Dean La Gaffe — Career Compass'),
        );
        update_option(self::OPTION_SOURCES, $sources);
        $this->redirect('RSS source added.');
    }

    public function handle_restore_sources(): void {
        if (!current_user_can('manage_options') || !check_admin_referer('alg_osap_restore_sources')) { wp_die('Forbidden'); }
        $this->ensure_default_sources();
        $this->ensure_taxonomy_terms();
        $this->ensure_hourly_schedule();
        $this->redirect('Built-in RSS backend restored and hourly auto-poster checked.');
    }

    public function handle_save_sources(): void {
        if (!current_user_can('manage_options') || !check_admin_referer('alg_osap_save_sources')) { wp_die('Forbidden'); }
        $clean = array();
        $rows = isset($_POST['sources']) && is_array($_POST['sources']) ? $_POST['sources'] : array();
        foreach ($rows as $row) {
            $name = sanitize_text_field($row['name'] ?? '');
            $url = esc_url_raw($row['url'] ?? '');
            if ($name === '' && $url === '') { continue; }
            $clean[] = array(
                'enabled' => !empty($row['enabled']) ? 1 : 0,
                'name' => $name,
                'group' => sanitize_text_field($row['group'] ?? ''),
                'url' => $url,
                'default_category' => sanitize_text_field($row['default_category'] ?? ''),
            );
        }
        update_option(self::OPTION_SOURCES, $clean);
        $this->redirect('Sources saved.');
    }

    public function handle_run_fetch(): void {
        if (!current_user_can('manage_options') || !check_admin_referer('alg_osap_run_fetch')) { wp_die('Forbidden'); }
        $count = $this->daily_fetch(true);
        $this->redirect(sprintf('Auto Post Now complete. Created %d new post(s).', $count));
    }

    public function daily_fetch(bool $manual=false): int {
        $this->ensure_taxonomy_terms();
        include_once ABSPATH . WPINC . '/feed.php';
        $settings = $this->settings();
        $created = 0;
        foreach ($this->sources() as $source) {
            if (empty($source['enabled']) || empty($source['url'])) { continue; }
            if ($created >= (int)$settings['max_posts_per_run']) { break; }
            $feed = fetch_feed($source['url']);
            if (is_wp_error($feed)) { $this->log('Feed error: '.$source['name'].' — '.$feed->get_error_message()); continue; }
            $max = min((int)$settings['items_per_source'], $feed->get_item_quantity((int)$settings['items_per_source']));
            $items = $feed->get_items(0, $max);
            foreach ($items as $item) {
                if ($created >= (int)$settings['max_posts_per_run']) { break; }
                $url = esc_url_raw($item->get_permalink());
                if (!$url || $this->already_imported($url)) { continue; }
                $post_id = $this->create_post_from_item($item, $source, $settings);
                if ($post_id) { $created++; }
            }
        }
        $this->log(($manual ? 'Manual' : 'Hourly').' official source fetch created '.$created.' post(s).');
        return $created;
    }

    private function already_imported(string $url): bool {
        $hash = md5(strtolower(trim($url)));
        $q = new WP_Query(array('post_type'=>'post','post_status'=>'any','posts_per_page'=>1,'meta_key'=>self::META_SOURCE_HASH,'meta_value'=>$hash,'fields'=>'ids','no_found_rows'=>true));
        return $q->have_posts();
    }

    private function create_post_from_item($item, array $source, array $settings): int {
        $title = wp_strip_all_tags(html_entity_decode($item->get_title(), ENT_QUOTES, get_bloginfo('charset')));
        $url = esc_url_raw($item->get_permalink());
        $summary_raw = $item->get_description() ?: $item->get_content();
        $summary = wp_trim_words(wp_strip_all_tags($summary_raw), (int)$settings['excerpt_words']);
        $date = $item->get_date('Y-m-d H:i:s');
        $text_for_classification = $title.' '.$summary.' '.($source['group'] ?? '').' '.($source['name'] ?? '');
        $classification = $this->classify($text_for_classification, (string)($source['default_category'] ?? ''));
        $category_name = $classification['confidence'] < (int)$settings['confidence_threshold'] ? 'Needs Review' : $classification['primary'];
        $cat_id = $this->category_ids[$category_name] ?? $this->ensure_category($category_name, 0);

        $note = '';
        if (!empty($settings['prepend_lagaffe_note'])) {
            $note = '<p><strong>Ask La Gaffe source note:</strong> Official signal from '.esc_html($source['name'] ?? 'an official source').'. Filed under <em>'.esc_html($category_name).'</em> for the 1337 / Ask La Gaffe Creative Media Academy.</p>';
        }
        $content = $note;
        $content .= '<blockquote>'.esc_html($summary).'</blockquote>';
        $content .= '<p><strong>Original source:</strong> <a href="'.esc_url($url).'" target="_blank" rel="nofollow noopener">'.esc_html($source['name'] ?? parse_url($url, PHP_URL_HOST)).'</a></p>';
        $content .= '<p class="alg-source-disclaimer"><em>This post is an attributed source pointer and short excerpt, not a full republication of the original article.</em></p>';

        $postarr = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'post_title' => $title,
            'post_content' => $content,
            'post_excerpt' => $summary,
            'post_category' => array($cat_id),
        );
        // Use the import time as the WordPress publish date so newly imported RSS items
        // actually appear at the top of Latest Open Learning Feed. Keep original source date in post meta.
        $post_id = wp_insert_post(wp_slash($postarr), true);
        if (is_wp_error($post_id) || !$post_id) { $this->log('Post insert failed for '.$title); return 0; }

        update_post_meta($post_id, self::META_SOURCE_URL, $url);
        update_post_meta($post_id, self::META_SOURCE_NAME, sanitize_text_field($source['name'] ?? ''));
        update_post_meta($post_id, self::META_SOURCE_HASH, md5(strtolower(trim($url))));
        update_post_meta($post_id, self::META_CONFIDENCE, (int)$classification['confidence']);
        update_post_meta($post_id, self::META_PRIMARY, sanitize_text_field($category_name));
        update_post_meta($post_id, self::META_REASON, sanitize_text_field($classification['reason']));
        if ($date) { update_post_meta($post_id, self::META_SOURCE_DATE, sanitize_text_field($date)); }

        if (!empty($settings['add_tags'])) {
            $tags = array('Official Source', '1337', 'Ask La Gaffe', sanitize_text_field($source['group'] ?? ''), sanitize_text_field($source['name'] ?? ''), $category_name);
            foreach ($this->lagaffe_worlds() as $world) {
                if ($world['category'] === $category_name) {
                    $tags[] = $world['color'];
                    $tags[] = $world['world'];
                    break;
                }
            }
            $tags = array_filter(array_unique($tags));
            wp_set_post_terms($post_id, $tags, 'post_tag', true);
        }
        $this->log('Created #'.$post_id.' — '.$category_name.' — '.$title);
        return (int)$post_id;
    }

    private function classify(string $text, string $default_category=''): array {
        $t = mb_strtolower($text);

        // First pass: the 1337 / Ask La Gaffe Creative Media Academy. These categories win when a world signal is clear.
        $world_scores = array();
        foreach ($this->lagaffe_worlds() as $world) {
            $world_scores[$world['category']] = 0;
            foreach ($world['keywords'] as $kw) {
                if (strpos($t, mb_strtolower($kw)) !== false) { $world_scores[$world['category']] += (strlen($kw) > 6 ? 2 : 1); }
            }
            if ($default_category === $world['category']) { $world_scores[$world['category']] += 3; }
        }
        arsort($world_scores);
        $world_top = key($world_scores);
        $world_score = (int)current($world_scores);
        if ($world_score > 0) {
            $confidence = min(98, max(55, 50 + ($world_score * 10)));
            return array('primary'=>$world_top, 'confidence'=>$confidence, 'reason'=>'Matched '.$world_score.' La Gaffe world signal(s).');
        }

        // Second pass: legacy/news/design categories retained for general official-source coverage.
        $rules = array(
            'World Affairs' => array('nato','eu ','european union','government','election','war','ukraine','russia','china','iran','israel','gaza','diplomacy','sanctions','minister','parliament'),
            'Crime & Justice' => array('crime','police','court','lawsuit','arrest','fraud','trial','security breach','investigation','sentenced'),
            'Economy & Work' => array('economy','business','market','startup','start-up','workplace','jobs','labor','trade','investment','company','leadership','management','productivity','supply chain'),
            'Culture & Entertainment' => array('music','film','tv','celebrity','artist','festival','exhibition','museum','performance','culture','book'),
            'Design Policy & Ethics' => array('design ethics','ethical design','responsibility','accessibility','inclusive design','privacy','dark patterns','policy','standards','professional practice','governance','regulation','sustainability','human rights','w3c','wcag'),
            'UI & UX Design' => array('ux','ui','user experience','user interface','interaction design','usability','user research','prototype','wireframe','human-centered','human centred','journey map','service design','information architecture'),
            'Graphic Design & Typography' => array('graphic design','typography','typeface','font','layout','poster','print','grid','lettering','computer arts'),
            'Brand & Identity' => array('brand','branding','identity','campaign','strategy','copywriting','tone of voice','rebrand','brand system'),
            'Packaging Design' => array('packaging','package design','label design','bottle','can','box','carton','materials','material innovation','shelf impact','dieline','fmcg'),
            'Product & Industrial Design' => array('industrial design','furniture','object','product design','consumer product','hardware','materials','prototype','manufacturing','ceramic','lighting'),
            'Architecture & Urban Design' => array('architecture','architect','building','urban','city','housing','interior','space','spatial','landscape architecture'),
            'Motion & Animation' => array('animation','motion graphics','motion design','vfx','stop-motion','stop motion','anime','shorts','streaming','storyboard','claymation'),
            'Photography & Image Culture' => array('photography','photographer','photo','camera','image culture','portrait','documentary','lens','exhibition','visual essay'),
            'Visual Arts & Illustration' => array('illustration','illustrator','drawing','painting','digital art','artist','visual arts','comic','zine','poster art'),
            'Publishing & Editorial' => array('publishing','magazine','book design','editorial','print magazine','newspaper','cover design','zine','press','newsletter'),
            'Creative Technology' => array('creative technology','ai art','digital art','generative','ar','vr','xr','interactive','media lab','creative coding','webgl'),
            'Design & Creativity' => array('design','visual','creative','creativity','branding','illustration','studio'),
            'Technology & AI' => array('ai','artificial intelligence','machine learning','algorithm','robot','robotics','software','data','digital','cyber','platform','web standard','computer','automation','internet'),
            'Travel & Places' => array('travel','tourism','city','airport','flight','destination','hotel','place','landscape'),
            'Health & Science' => array('health','medical','science','research','climate','environment','biology','brain','disease','medicine','energy'),
            'Sports' => array('sport','football','soccer','match','league','tournament','athlete'),
            'Media & Internet' => array('media','journalism','press','social media','podcast','internet culture','creator'),
            'Uncle’s Wisdom' => array('wisdom','lesson','philosophy','human condition'),
            'Ask The Uncle' => array('how to','guide','explainer','what is','why','learn','education','course'),
        );
        $scores = array();
        foreach ($rules as $cat=>$keywords) {
            $scores[$cat] = 0;
            foreach ($keywords as $kw) {
                if (strpos($t, $kw) !== false) { $scores[$cat] += (strlen($kw) > 6 ? 2 : 1); }
            }
        }
        arsort($scores);
        $top = key($scores);
        $score = (int)current($scores);
        if ($score <= 0 && $default_category !== '') { $top = $default_category; $score = 2; }
        if (!$top) { $top = 'Needs Review'; }
        $confidence = min(95, max(35, 45 + ($score * 10)));
        return array('primary'=>$top, 'confidence'=>$confidence, 'reason'=>'Matched '.$score.' source/title/excerpt signal(s).');
    }

    private function log(string $message): void {
        $log = (array)get_option(self::OPTION_LOG, array());
        $log[] = '['.current_time('mysql').'] '.$message;
        if (count($log) > 500) { $log = array_slice($log, -500); }
        update_option(self::OPTION_LOG, $log, false);
    }

    private function redirect(string $notice): void {
        wp_safe_redirect(add_query_arg(array('page'=>'alg-official-source-autoposter','alg_notice'=>rawurlencode($notice)), admin_url('tools.php')));
        exit;
    }
}

ALG_Official_Source_Auto_Poster::instance();
