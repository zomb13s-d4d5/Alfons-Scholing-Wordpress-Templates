<?php
if (!defined('ABSPATH')) exit;

function lgu_dean_profile() {
    return array(
        'slug' => 'dean-grey-wizard-alien',
        'title' => 'The Grey Old Alien Dean',
        'role' => 'Career Choices, Creative Direction & Academy Guidance',
        'image' => 'assets/images/dean-grey-wizard-alien.webp',
        'desc' => 'A cute undefinable old alien wizard who helps students choose a path, compare professions, ask better AI questions and turn curiosity into a realistic portfolio plan.',
    );
}

function lgu_ai_card_schema() {
    return array(
        array('kicker'=>'Career Signal','title'=>'Why this path?', 'body'=>'Ask the professor what kind of person enjoys this profession, what problems they solve, and what daily work really feels like.'),
        array('kicker'=>'First Skill','title'=>'What should I learn first?', 'body'=>'Ask for the one foundation skill that makes the biggest difference before buying tools or chasing trends.'),
        array('kicker'=>'Tool Basics','title'=>'Which software matters?', 'body'=>'Ask which industry tools are worth learning now, which free alternatives are acceptable, and what output standards matter.'),
        array('kicker'=>'Portfolio Proof','title'=>'What should I show?', 'body'=>'Ask for three portfolio pieces that prove beginner competence without pretending to be senior-level.'),
        array('kicker'=>'AI Partner','title'=>'How can AI help me?', 'body'=>'Ask how to use AI for research, drafts, structure, planning and feedback while keeping the human idea and taste in control.'),
        array('kicker'=>'Ethics Check','title'=>'What must I respect?', 'body'=>'Ask about consent, copyright, credits, source checking, privacy, representation and when not to automate.'),
        array('kicker'=>'Feedback Loop','title'=>'How do I improve faster?', 'body'=>'Ask for a critique checklist: what to measure, what to simplify, what to redo, and what to stop overthinking.'),
        array('kicker'=>'Collaboration','title'=>'Who do I work with?', 'body'=>'Ask how this role cooperates with directors, designers, editors, developers, producers, clients and audiences.'),
        array('kicker'=>'Beginner Mission','title'=>'What can I make this week?', 'body'=>'Ask for a small seven-day exercise with a clear brief, deadline, file format and reflection question.'),
        array('kicker'=>'Career Next Step','title'=>'How do I move forward?', 'body'=>'Ask what junior role, internship, freelance offer, school route, or self-directed project is the most realistic next move.'),
    );
}

function lgu_dean_ai_card_schema() {
    return array(
        array('kicker'=>'Career Compass','title'=>'Which path fits me?', 'body'=>'Ask the Dean to compare creative fields by daily work, stress, collaboration, money pressure, learning curve and portfolio proof.'),
        array('kicker'=>'Job Map','title'=>'What jobs exist?', 'body'=>'Ask for junior, freelance, studio, agency, school, nonprofit and independent career routes connected to creative media.'),
        array('kicker'=>'Portfolio Direction','title'=>'What proof do I need?', 'body'=>'Ask which beginner portfolio pieces prove taste, discipline, thinking, craft and reliability before you apply anywhere.'),
        array('kicker'=>'Learning Plan','title'=>'What should I study first?', 'body'=>'Ask for a 30-day plan with terminology, tools, exercises, critique moments and one small finished project.'),
        array('kicker'=>'Opportunity Check','title'=>'Where can I start?', 'body'=>'Ask for realistic first opportunities: internships, volunteering, small clients, open calls, school routes, community projects and online publishing.'),
        array('kicker'=>'Interview Prep','title'=>'How do I explain myself?', 'body'=>'Ask how to describe your work, process, role, strengths and limits clearly without pretending to be senior.'),
        array('kicker'=>'Freelance Survival','title'=>'How do I avoid chaos?', 'body'=>'Ask about briefs, scope, deadlines, invoices, feedback rounds, files, rights, credits and polite boundaries.'),
        array('kicker'=>'Industry Language','title'=>'Which words unlock rooms?', 'body'=>'Ask for the ten terms you must know before talking to teachers, clients, studios, developers, producers or art directors.'),
        array('kicker'=>'AI Boundary','title'=>'How do I use AI well?', 'body'=>'Ask how AI can help with research, structure, references and critique while keeping your authorship, ethics and taste intact.'),
        array('kicker'=>'Next Move','title'=>'What should I do this week?', 'body'=>'Ask the Dean for one concrete action, one person to talk to, one thing to publish and one thing to improve.'),
    );
}

function lgu_render_ai_cheat_cards() {
    $all_worlds = function_exists('lgu_worlds') ? lgu_worlds() : array();
    $profession_worlds = function_exists('lgu_profession_worlds') ? lgu_profession_worlds() : array_filter($all_worlds, function($world){ return empty($world['dean']); });
    $dean_world = function_exists('lgu_dean_world') ? lgu_dean_world() : ($all_worlds['dean-career-compass'] ?? null);
    $schema = lgu_ai_card_schema();
    $dean_schema = lgu_dean_ai_card_schema();
    $dean = lgu_dean_profile();

    ob_start();
    ?>
    <section class="lgu-guidance-hero panel panel-pad">
      <div class="lgu-guidance-hero__text">
        <p class="kicker">Ask La Gaffe / AI Compass Cards</p>
        <h1>230 AI Career Cheat Cards</h1>
        <p><strong>10 cards for the Career Compass</strong> plus <strong>10 cards for each of the 22 creative categories</strong>. These are short cue cards for students, talks, workshops and professor conversations: what to ask, what to learn, what to make, what to show, and how to choose a future without panic.</p>
        <p>The career guide helps with direction. The 22 professors help with the profession-specific words, tools, portfolio proof and next actions.</p>
      </div>
      <img src="<?php echo esc_url(lgu_asset($dean['image'])); ?>" alt="<?php echo esc_attr($dean['title']); ?>">
    </section>

    <nav class="lgu-cheat-jump panel panel-pad" aria-label="Cheat card categories">
      <strong>Jump to category</strong>
      <div>
        <?php if($dean_world): ?><a href="#cheat-dean-career-compass">Career Compass</a><?php endif; ?>
        <?php foreach($profession_worlds as $slug=>$world): ?><a href="#cheat-<?php echo esc_attr($slug); ?>"><?php echo esc_html($world['title']); ?></a><?php endforeach; ?>
      </div>
    </nav>

    <?php if($dean_world): ?>
      <section id="cheat-dean-career-compass" class="lgu-card-profession lgu-card-profession--career panel panel-pad" style="--accent:<?php echo esc_attr($dean_world['color']); ?>">
        <header class="lgu-card-profession__head">
          <img src="<?php echo esc_url(lgu_asset($dean_world['poster'])); ?>" alt="Career Compass category image">
          <div>
            <p class="kicker"><?php echo esc_html($dean_world['edition']); ?></p>
            <h2>Career Compass — 10 Dean talk cards</h2>
            <p><?php echo esc_html($dean_world['desc']); ?></p>
          </div>
        </header>
        <div class="lgu-cheat-grid">
          <?php $i=1; foreach($dean_schema as $card): ?>
            <article class="lgu-cheat-card">
              <span><?php echo esc_html(sprintf('%02d', $i)); ?></span>
              <b><?php echo esc_html($card['kicker']); ?></b>
              <h3><?php echo esc_html($card['title']); ?></h3>
              <p><?php echo esc_html($card['body']); ?></p>
              <em>Dean prompt: “Help me make a realistic creative career choice based on my current skills, time, tools and portfolio.”</em>
            </article>
          <?php $i++; endforeach; ?>
        </div>
      </section>
    <?php endif; ?>

    <?php foreach($profession_worlds as $slug => $world): ?>
      <section id="cheat-<?php echo esc_attr($slug); ?>" class="lgu-card-profession panel panel-pad" style="--accent:<?php echo esc_attr($world['color']); ?>">
        <header class="lgu-card-profession__head">
          <img src="<?php echo esc_url(lgu_asset($world['poster'])); ?>" alt="<?php echo esc_attr($world['title']); ?> category image">
          <div>
            <p class="kicker"><?php echo esc_html($world['edition']); ?></p>
            <h2><?php echo esc_html($world['title']); ?> — 10 professor talk cards</h2>
            <p><?php echo esc_html($world['desc']); ?></p>
          </div>
        </header>
        <div class="lgu-cheat-grid">
          <?php $i=1; foreach($schema as $card):
            $body = $card['body'];
            $body .= ' For this category, connect the answer to ' . strtolower($world['title']) . ', a realistic student portfolio, and one concrete next action.';
          ?>
            <article class="lgu-cheat-card">
              <span><?php echo esc_html(sprintf('%02d', $i)); ?></span>
              <b><?php echo esc_html($card['kicker']); ?></b>
              <h3><?php echo esc_html($card['title']); ?></h3>
              <p><?php echo esc_html($body); ?></p>
              <em>Professor prompt: “For <?php echo esc_html($world['title']); ?>, what would you tell a beginner who wants a real career path?”</em>
            </article>
          <?php $i++; endforeach; ?>
        </div>
      </section>
    <?php endforeach; ?>
    <?php
    return ob_get_clean();
}
add_shortcode('lgu_ai_cheat_cards', 'lgu_render_ai_cheat_cards');

function lgu_manual_pages() {
    return array(
        array('01','Creative Software Mindset','Learn the interface slowly: menus, panels, shortcuts, file formats, save habits and export settings before chasing advanced effects.'),
        array('02','Adobe Photoshop Basics','Use layers, masks, selections, adjustment layers, retouching, smart objects and non-destructive edits for images, posters and campaign visuals.'),
        array('03','Adobe Illustrator Basics','Build vector logos with shapes, paths, type, artboards, symbols, colour swatches and clean export settings for SVG, PDF and print.'),
        array('04','Adobe InDesign Basics','Understand pages, master layouts, paragraph styles, grids, linked images, packaging and PDF export for zines, books and editorial systems.'),
        array('05','Figma Interface Design','Practice frames, components, auto layout, variants, styles, comments and clickable prototypes for UI, UX and design-system thinking.'),
        array('06','Canva / Express Layout Basics','Use templates as training wheels: improve hierarchy, spacing, contrast, brand consistency and export choices without pretending templates are strategy.'),
        array('07','Blender 3D Basics','Start with navigation, primitives, modelling, materials, lights, cameras, collections, rendering and simple animation before complex character rigs.'),
        array('08','Maya / Cinema 4D Orientation','Learn professional 3D concepts: modelling discipline, topology, scene organization, animation curves, lighting and render pipeline handoff.'),
        array('09','ZBrush / Digital Sculpting','Think in forms: large shape first, secondary detail second, texture last. Keep reference boards and export clean meshes for other tools.'),
        array('10','Adobe After Effects Basics','Learn compositions, keyframes, masks, text animation, parenting, precomps and render settings for motion graphics and animated explainers.'),
        array('11','Premiere Pro Basics','Practice bins, sequences, trims, audio levels, captions, colour basics, proxies and export presets for social, web and broadcast-style video.'),
        array('12','DaVinci Resolve Basics','Understand media, cut, edit, fusion, colour, Fairlight and deliver pages; focus first on clean edits and readable colour correction.'),
        array('13','Final Cut / Mobile Editing','Learn fast assembly, magnetic timeline thinking, titles, sound balance, basic grading and export settings for creator-friendly workflows.'),
        array('14','Audition / Pro Tools Basics','Record clean voice, remove noise carefully, edit breaths, normalize loudness, organize takes and export proper WAV/MP3 deliverables.'),
        array('15','Ableton Live / Logic Pro Basics','Build rhythm, melody, loops, arrangement, mixing and simple mastering while naming tracks and saving reusable project templates.'),
        array('16','OBS / Streaming Basics','Set scenes, sources, microphones, cameras, overlays, recording settings and stream health before going live with an audience.'),
        array('17','Unity Basics','Understand scenes, game objects, components, prefabs, scripts, cameras, physics, UI and build settings for small playable prototypes.'),
        array('18','Unreal Engine Basics','Learn projects, levels, assets, blueprints, materials, lighting, camera work and packaging for real-time worlds and cinematic scenes.'),
        array('19','VS Code / Code Editor Basics','Use folders, tabs, extensions, terminal, search, formatting, snippets and version control to keep code readable and recoverable.'),
        array('20','HTML & CSS Basics','Build semantic structure, responsive layouts, typography, colour, spacing and accessibility before adding heavy scripts or animations.'),
        array('21','JavaScript Basics','Practice variables, functions, events, DOM changes, arrays, objects, fetch, error messages and small interface behaviours.'),
        array('22','React / Front-End Components','Think in components, props, state, routes and reusable UI patterns; document decisions and keep interfaces testable.'),
        array('23','WordPress Basics','Learn themes, posts, pages, categories, menus, templates, plugins, media library, child themes, backups and staging before live edits.'),
        array('24','Webflow / Visual Web Basics','Understand boxes, classes, breakpoints, CMS collections, interactions and export limits so visual building stays disciplined.'),
        array('25','Git / GitHub Basics','Commit small changes, write clear messages, use branches, pull requests, issues and releases to protect collaborative work.'),
        array('26','Notion / Documentation Basics','Create project hubs, briefs, task boards, meeting notes, content calendars and knowledge bases for teams and solo practice.'),
        array('27','Miro / FigJam Basics','Map ideas, user journeys, moodboards, critique notes and workshop flows without confusing sticky notes for final decisions.'),
        array('28','AI Prompting for Creatives','Ask for options, constraints, critique, checklists, rewrites and production plans; never outsource taste, ethics or final responsibility.'),
        array('29','Portfolio Website Basics','Show selected work, your role, the problem, process images, outcome, reflection and contact route. Make it fast and readable.'),
        array('30','File Naming & Delivery','Use dates, version numbers, project names, exports, source files, licences and readme notes so collaborators can trust your archive.'),
        array('31','Accessibility Basics','Check contrast, alt text, captions, keyboard navigation, readable type, motion sensitivity and plain-language explanations.'),
        array('32','Copyright & Credits Basics','Track sources, licences, model releases, fonts, music rights, image rights and collaborator credits before publishing.'),
        array('33','Client Brief Basics','Clarify goal, audience, deadline, budget, deliverables, revision rounds, references, approval process and final file formats.'),
        array('34','Critique Method Basics','Separate taste from function: ask what works, what confuses, what repeats, what is missing and what one change matters most.'),
        array('35','Career Roadmap Basics','Choose a direction, build three small proofs, ask for critique, publish carefully, apply consistently and revise the path every month.'),
    );
}

function lgu_render_software_manual() {
    $pages = lgu_manual_pages();
    $dean = lgu_dean_profile();
    ob_start(); ?>
    <section class="lgu-guidance-hero panel panel-pad">
      <div class="lgu-guidance-hero__text">
        <p class="kicker">Academy Manual / Industry Software Basics</p>
        <h1>35-Page Starter Manual</h1>
        <p>A compact manual for learning the basics of industry-standard creative software packages and professional studio habits. It is not a replacement for full documentation; it is the academy map that tells students what to learn first and why.</p>
        <p>The Grey Old Alien Dean frames the manual around career choices: learn enough software to make work, then use the work to decide which profession fits.</p>
      </div>
      <img src="<?php echo esc_url(lgu_asset($dean['image'])); ?>" alt="<?php echo esc_attr($dean['title']); ?>">
    </section>
    <section class="panel panel-pad lgu-manual">
      <?php foreach($pages as $p): ?>
        <article class="lgu-manual-page">
          <span>Page <?php echo esc_html($p[0]); ?></span>
          <h2><?php echo esc_html($p[1]); ?></h2>
          <p><?php echo esc_html($p[2]); ?></p>
          <ul>
            <li><strong>Learn:</strong> interface, core actions, file discipline and export logic.</li>
            <li><strong>Practice:</strong> make one tiny finished exercise before moving to the next tool.</li>
            <li><strong>Ask AI:</strong> “Give me a beginner exercise, common mistakes, and a checklist for <?php echo esc_html($p[1]); ?>.”</li>
          </ul>
        </article>
      <?php endforeach; ?>
    </section>
    <?php return ob_get_clean();
}
add_shortcode('lgu_software_manual', 'lgu_render_software_manual');

function lgu_guidance_page_specs() {
    return array(
        array('ai-career-cheat-cards', 'AI Career Cheat Cards — Ask the Professors', '<!-- wp:shortcode -->[lgu_ai_cheat_cards]<!-- /wp:shortcode -->'),
        array('industry-software-basics-manual', 'Industry Software Basics Manual', '<!-- wp:shortcode -->[lgu_software_manual]<!-- /wp:shortcode -->'),
    );
}

function lgu_ensure_guidance_pages() {
    if (!function_exists('wp_insert_post')) return;
    foreach (lgu_guidance_page_specs() as $spec) {
        list($slug, $title, $content) = $spec;
        $page = get_page_by_path($slug, OBJECT, 'page');
        if ($page && !is_wp_error($page)) {
            if (strpos((string)$page->post_content, '[lgu_') === false) {
                wp_update_post(array('ID'=>(int)$page->ID, 'post_content'=>$content));
            }
            continue;
        }
        wp_insert_post(array(
            'post_title'=>$title,
            'post_name'=>$slug,
            'post_status'=>'publish',
            'post_type'=>'page',
            'post_content'=>$content,
            'post_author'=>get_current_user_id() ?: 1,
        ), true);
    }
}
add_action('after_switch_theme', 'lgu_ensure_guidance_pages');
add_action('admin_init', 'lgu_ensure_guidance_pages');
add_action('init', 'lgu_ensure_guidance_pages', 20);

function lgu_guidance_links_markup() {
    $cards = get_page_by_path('ai-career-cheat-cards', OBJECT, 'page');
    $manual = get_page_by_path('industry-software-basics-manual', OBJECT, 'page');
    $cards_url = $cards ? get_permalink($cards->ID) : home_url('/ai-career-cheat-cards/');
    $manual_url = $manual ? get_permalink($manual->ID) : home_url('/industry-software-basics-manual/');
    return '<div class="account-actions guidance-actions"><a class="btn" href="' . esc_url($cards_url) . '">Open 220 AI Cheat Cards</a><a class="btn ghost" href="' . esc_url($manual_url) . '">Open 35-Page Software Manual</a></div>';
}
