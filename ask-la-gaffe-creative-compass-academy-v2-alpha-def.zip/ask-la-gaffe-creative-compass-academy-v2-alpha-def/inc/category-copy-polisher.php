<?php
/**
 * Ask La Gaffe Category Copy Polisher
 *
 * Theme-embedded module that keeps public category descriptions audience-facing.
 * It refreshes the parent academy category and all 20 child studio categories,
 * then filters stale technical copy on category archive pages.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('ALG_Theme_Category_Copy_Polisher')) {
    final class ALG_Theme_Category_Copy_Polisher {
        const OPTION_LAST_RUN = 'alg_theme_category_copy_polisher_last_run';
        const OPTION_VERSION = 'alg_theme_category_copy_polisher_version';
        const VERSION = '1.0.1';
        const PARENT_SLUG = '1337-ask-la-gaffe-creative-media-academy';
        const PARENT_NAME = '1337 / Ask La Gaffe Creative Media Academy';

        public static function init(): void {
            add_action('after_switch_theme', array(__CLASS__, 'polish_categories'));
            add_action('admin_init', array(__CLASS__, 'maybe_polish_categories'));
            add_filter('get_the_archive_description', array(__CLASS__, 'filter_archive_description'), 20);
            add_filter('category_description', array(__CLASS__, 'filter_category_description'), 20, 2);
        }

        public static function maybe_polish_categories(): void {
            if (!current_user_can('manage_categories')) {
                return;
            }

            $version = get_option(self::OPTION_VERSION, '');
            if ($version !== self::VERSION) {
                self::polish_categories();
            }
        }

        public static function worlds(): array {
            return array(
                'storytelling' => array(
                    'name' => '01 Storytelling — Imagination Studio',
                    'title' => 'Storytelling',
                    'description' => 'Step into the Imagination Studio, where ideas become characters, worlds, scenes and stories. Learn how to shape a spark into a beginning, a middle, an ending and a voice people remember.',
                ),
                'film-video' => array(
                    'name' => '02 Film & Video — Cinema Studio',
                    'title' => 'Film & Video',
                    'description' => 'Welcome to the Cinema Studio, where camera confidence, scenes, shorts, trailers and creator video come to life. Explore how images, movement and timing turn everyday ideas into screen stories.',
                ),
                'photography' => array(
                    'name' => '03 Photography — Image Studio',
                    'title' => 'Photography',
                    'description' => 'The Image Studio is all about seeing the magic in every frame. Learn lenses, light, composition, portraits, visual essays and the art of capturing moments with care and imagination.',
                ),
                'sound-voice' => array(
                    'name' => '04 Sound & Voice — Audio Studio',
                    'title' => 'Sound & Voice',
                    'description' => 'In the Audio Studio, voices become stories and sounds become worlds. Discover podcasting, radio, interviews, microphones, sound design and the confidence to speak with warmth and clarity.',
                ),
                'animation' => array(
                    'name' => '05 Animation — Motion Studio',
                    'title' => 'Animation',
                    'description' => 'The Motion Studio is where drawings start moving. Explore animation, motion design, storyboards, timing, frames, characters and visual rhythm through playful lessons that make movement feel fun, creative and full of life.',
                ),
                'design-branding' => array(
                    'name' => '06 Design & Branding — Identity Studio',
                    'title' => 'Design & Branding',
                    'description' => 'The Identity Studio helps creators turn ideas into recognizable worlds. Explore logos, colors, shapes, layouts, campaigns and visual systems that make a message feel clear, friendly and memorable.',
                ),
                'writing-journalism' => array(
                    'name' => '07 Writing & Journalism — Editorial Studio',
                    'title' => 'Writing & Journalism',
                    'description' => 'The Editorial Studio is for curious minds and careful words. Practice articles, interviews, explainers, zines, headlines and public storytelling that helps people understand the world around them.',
                ),
                'editing-post-production' => array(
                    'name' => '08 Editing & Post-Production — Edit Studio',
                    'title' => 'Editing & Post-Production',
                    'description' => 'The Edit Studio is where rough material becomes polished media. Learn cuts, rhythm, timelines, captions, sequencing, finishing and the quiet magic that makes creative work feel complete.',
                ),
                'music-production' => array(
                    'name' => '09 Music Production — Melody Studio',
                    'title' => 'Music Production',
                    'description' => 'The Melody Studio celebrates rhythm, mood and sound. Create jingles, themes, songs, beats, sonic identities and musical ideas that give stories extra heart and movement.',
                ),
                'streaming-social' => array(
                    'name' => '10 Streaming & Social — Broadcast Studio',
                    'title' => 'Streaming & Social Media',
                    'description' => 'The Broadcast Studio is for sharing, streaming and building community with kindness. Explore live formats, creator presence, chat culture, short social stories and positive digital connection.',
                ),
                'reporting-research' => array(
                    'name' => '11 Reporting — Source Lab',
                    'title' => 'Reporting & Research',
                    'description' => 'The Source Lab teaches curiosity with responsibility. Follow clues, compare sources, prepare interviews, organize research trails and turn questions into clear public-interest stories.',
                ),
                'coding-web' => array(
                    'name' => '12 Coding & Web — Web Lab',
                    'title' => 'Coding & Web Creation',
                    'description' => 'The Web Lab is where creative ideas become interactive places. Explore pages, interfaces, playful layouts, buttons, digital tools and the craft of building experiences people can use.',
                ),
                'presenting' => array(
                    'name' => '13 Presenting — Stage Studio',
                    'title' => 'Presenting & Public Speaking',
                    'description' => 'The Stage Studio helps creators speak with courage and clarity. Practice presenting, explaining ideas, showing work, using your voice and connecting with an audience in a friendly way.',
                ),
                'game-design' => array(
                    'name' => '14 Game Design — Play Lab',
                    'title' => 'Game Design',
                    'description' => 'The Play Lab turns stories into choices, levels and systems. Explore game worlds, rules, characters, challenges, prototypes and the creative joy of making experiences people can play.',
                ),
                'fashion-styling' => array(
                    'name' => '15 Fashion & Styling — Costume Studio',
                    'title' => 'Fashion & Styling',
                    'description' => 'The Costume Studio explores how clothing, color, fabric and styling tell stories. Create looks for characters, shoots, stages, campaigns and expressive visual identities.',
                ),
                'science-innovation' => array(
                    'name' => '16 Science & Innovation — Discovery Lab',
                    'title' => 'Science & Innovation',
                    'description' => 'The Discovery Lab makes science and innovation feel exciting, visual and understandable. Explore experiments, ideas, technology, research stories and creative ways to explain big discoveries.',
                ),
                'illustration-painting' => array(
                    'name' => '17 Illustration & Painting — Art Studio',
                    'title' => 'Illustration & Painting',
                    'description' => 'The Art Studio is for drawing, painting, characters, comics and expressive marks. Learn how sketches become images and how images can carry emotion, humor, story and style.',
                ),
                'event-production' => array(
                    'name' => '18 Event Production — Live Control',
                    'title' => 'Event Production',
                    'description' => 'Live Control is where teamwork keeps the show moving. Explore stages, cues, lights, schedules, roles, audience moments and the behind-the-scenes craft of making events feel magical.',
                ),
                'marketing-social' => array(
                    'name' => '19 Marketing — Growth Studio',
                    'title' => 'Marketing & Social Media',
                    'description' => 'The Growth Studio helps ideas find their people. Explore campaigns, community messages, launches, thumbnails, social storytelling and the friendly strategy behind creative reach.',
                ),
                'documentary-exploration' => array(
                    'name' => '20 Documentary — Exploration Desk',
                    'title' => 'Documentary & Exploration',
                    'description' => 'The Exploration Desk is for real places, real questions and meaningful journeys. Discover documentary thinking, field notes, travel stories, research, observation and respectful storytelling.',
                ),
            );
        }

        public static function parent_description(): string {
            return 'Welcome to Ask La Gaffe Creative Media Academy: a purple, friendly learning universe where curious creators explore twenty playful media studios, meet lovable characters and turn imagination into stories, images, sounds, games, events and ideas.';
        }

        public static function polish_categories(): void {
            $parent_id = self::ensure_category(self::PARENT_NAME, self::PARENT_SLUG, 0, self::parent_description());

            foreach (self::worlds() as $slug => $world) {
                self::ensure_category($world['name'], $slug, $parent_id, $world['description']);
            }

            update_option(self::OPTION_LAST_RUN, current_time('mysql'), false);
            update_option(self::OPTION_VERSION, self::VERSION, false);
        }

        private static function ensure_category(string $name, string $slug, int $parent_id, string $description): int {
            $term = get_term_by('slug', $slug, 'category');

            if (!$term || is_wp_error($term)) {
                $created = wp_insert_term($name, 'category', array(
                    'slug' => $slug,
                    'parent' => $parent_id,
                    'description' => $description,
                ));

                if (is_wp_error($created)) {
                    return 0;
                }

                return (int) $created['term_id'];
            }

            wp_update_term((int) $term->term_id, 'category', array(
                'name' => $name,
                'slug' => $slug,
                'parent' => $parent_id,
                'description' => $description,
            ));

            return (int) $term->term_id;
        }

        public static function filter_archive_description($description) {
            if (!is_category()) {
                return $description;
            }

            $term = get_queried_object();
            if (!$term || is_wp_error($term)) {
                return $description;
            }

            return self::clean_or_replace_description($description, $term);
        }

        public static function filter_category_description($description, $category_id = 0) {
            $term = null;
            if ($category_id) {
                $term = get_term((int) $category_id, 'category');
            }

            return self::clean_or_replace_description($description, $term);
        }

        private static function clean_or_replace_description($description, $term = null) {
            $raw = wp_strip_all_tags((string) $description);

            $technical_words = array(
                'backend',
                'back-end',
                'maintainer',
                'editor',
                'autoposter',
                'auto poster',
                'RSS',
                'WordPress theme',
                'theme bundle',
                'widgets',
                'Customizer',
                'source settings',
                'official-source',
                'module',
                'installable',
                'ZIP',
                'admin',
                'plugin',
                'template',
                'Purple' . ' edition',
                'Core' . ' theme:',
                'Visual' . ' language:',
                'Key props',
                'Key props' . ' / symbols',
                'Cute purple monster' . ' media-academy iconography',
                'friendly public' . ' college energy',
            );

            $contains_technical = false;
            foreach ($technical_words as $word) {
                if (stripos($raw, $word) !== false) {
                    $contains_technical = true;
                    break;
                }
            }

            if ($term && !is_wp_error($term)) {
                $replacement = self::description_for_term($term);
                if ($replacement && ($contains_technical || trim($raw) === '')) {
                    return wpautop(esc_html($replacement));
                }
            }

            if ($contains_technical) {
                return wpautop(esc_html(self::parent_description()));
            }

            return $description;
        }

        private static function description_for_term($term): string {
            if (!$term || is_wp_error($term)) {
                return '';
            }

            if ($term->slug === self::PARENT_SLUG || $term->name === self::PARENT_NAME) {
                return self::parent_description();
            }

            $worlds = self::worlds();
            if (isset($worlds[$term->slug])) {
                return $worlds[$term->slug]['description'];
            }

            foreach ($worlds as $world) {
                if ($term->name === $world['name'] || stripos($term->name, $world['title']) !== false) {
                    return $world['description'];
                }
            }

            return '';
        }
    }

    ALG_Theme_Category_Copy_Polisher::init();
}
