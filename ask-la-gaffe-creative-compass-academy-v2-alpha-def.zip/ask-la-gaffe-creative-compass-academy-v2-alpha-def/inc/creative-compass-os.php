<?php
if (!defined('ABSPATH')) exit;

function cca_theme_label() { return 'Ask La Gaffe — Creative Compass Academy'; }
function cca_copyright_line() { return '© ' . date('Y') . ' NotYouAgain Studio. ChatGPT co-production concept support. All creative direction, characters and academy universe reserved by NotYouAgain Studio.'; }

function cca_page_specs() {
    return array(
        array('start-here', 'Start Here — Creative Compass Academy', '<!-- wp:shortcode -->[cca_start_here]<!-- /wp:shortcode -->'),
        array('my-academy', 'My Academy Operating System', '<!-- wp:shortcode -->[cca_account_os]<!-- /wp:shortcode -->'),
        array('academy-login', 'Academy Login', '<!-- wp:shortcode -->[cca_login]<!-- /wp:shortcode -->'),
        array('academy-register', 'Academy Registration', '<!-- wp:shortcode -->[cca_register]<!-- /wp:shortcode -->'),
        array('career-compass', 'Ask the Dean — Career Compass', '<!-- wp:shortcode -->[cca_dean_compass]<!-- /wp:shortcode -->'),
        array('creative-paths', 'Creative Paths — 22 Professions', '<!-- wp:shortcode -->[cca_profession_wall]<!-- /wp:shortcode -->'),
        array('open-tutorial-feeds', 'Open Tutorial Feeds — Free Learning Routes', '<!-- wp:shortcode -->[cca_open_tutorial_feeds]<!-- /wp:shortcode -->'),
    );
}

function cca_ensure_pages() {
    if (!function_exists('wp_insert_post')) return;
    foreach (cca_page_specs() as $spec) {
        list($slug,$title,$content)=$spec;
        $page=get_page_by_path($slug, OBJECT, 'page');
        if ($page && !is_wp_error($page)) {
            if (strpos((string)$page->post_content, '[cca_') === false) {
                wp_update_post(array('ID'=>(int)$page->ID, 'post_content'=>$content));
            }
            continue;
        }
        wp_insert_post(array('post_title'=>$title,'post_name'=>$slug,'post_status'=>'publish','post_type'=>'page','post_content'=>$content,'post_author'=>get_current_user_id() ?: 1), true);
    }
}
add_action('after_switch_theme','cca_ensure_pages');
add_action('admin_init','cca_ensure_pages');

function cca_url($slug){ $p=get_page_by_path($slug,OBJECT,'page'); return $p ? get_permalink($p->ID) : home_url('/'.$slug.'/'); }
function cca_selected_professions($user_id=0){ $user_id=$user_id?:get_current_user_id(); $v=get_user_meta($user_id,'cca_selected_professions',true); return is_array($v)?array_values(array_filter($v)):array(); }
function cca_sanitize_professions($items){ $worlds=lgu_worlds(); $clean=array(); foreach((array)$items as $x){ $x=sanitize_key($x); if(isset($worlds[$x])) $clean[]=$x; } return array_values(array_unique($clean)); }


function cca_frontend_registration_enabled(){
    // Site-native registration is controlled by the theme instead of the global wp-login.php screen.
    // Developers can disable it with: add_filter('cca_frontend_registration_enabled', '__return_false');
    return (bool) apply_filters('cca_frontend_registration_enabled', true);
}

function cca_auth_rate_key($action){
    $ip = isset($_SERVER['REMOTE_ADDR']) ? preg_replace('/[^0-9a-fA-F:\.]/', '', (string) $_SERVER['REMOTE_ADDR']) : 'unknown';
    return 'cca_' . sanitize_key($action) . '_' . md5($ip);
}

function cca_auth_rate_limited($action, $limit = 8, $window = 900){
    $key = cca_auth_rate_key($action);
    $hits = (int) get_transient($key);
    if ($hits >= $limit) return true;
    set_transient($key, $hits + 1, $window);
    return false;
}

function cca_frontend_login_url($login_url, $redirect = '', $force_reauth = false){
    return function_exists('cca_url') ? cca_url('academy-login') : $login_url;
}
add_filter('login_url','cca_frontend_login_url',10,3);

function cca_frontend_register_url($register_url){
    return function_exists('cca_url') ? cca_url('academy-register') : $register_url;
}
add_filter('register_url','cca_frontend_register_url');

function cca_frontend_logout_url($logout_url, $redirect = ''){
    return wp_nonce_url(site_url('wp-login.php?action=logout&redirect_to=' . rawurlencode($redirect ?: home_url('/'))), 'log-out');
}
add_filter('logout_url','cca_frontend_logout_url',10,2);

function cca_redirect_core_login_screens(){
    $action = isset($_REQUEST['action']) ? sanitize_key($_REQUEST['action']) : 'login';
    if (in_array($action, array('logout','postpass','rp','resetpass','lostpassword'), true)) return;
    if (is_user_logged_in()) { wp_safe_redirect(cca_url('my-academy')); exit; }
    wp_safe_redirect($action === 'register' ? cca_url('academy-register') : cca_url('academy-login'));
    exit;
}
add_action('login_init','cca_redirect_core_login_screens');

function cca_account_links($class='cca-account-mini'){
    if (is_user_logged_in()) {
        return '<div class="'.esc_attr($class).'"><a class="solid" href="'.esc_url(cca_url('my-academy')).'">My Academy</a><a href="'.esc_url(cca_url('creative-paths')).'">Creative Paths</a><a href="'.esc_url(wp_logout_url(home_url('/'))).'">Log out</a></div>';
    }
    return '<div class="'.esc_attr($class).'"><a class="solid" href="'.esc_url(cca_url('academy-register')).'">Register</a><a href="'.esc_url(cca_url('academy-login')).'">Log in</a><a href="'.esc_url(cca_url('career-compass')).'">Ask the Dean</a></div>';
}

function cca_handle_register(){
    if (empty($_POST['cca_register_submit']) || !wp_verify_nonce($_POST['cca_nonce'] ?? '', 'cca_register')) return '';
    if (!cca_frontend_registration_enabled()) return '<div class="cca-notice">Academy registration is temporarily closed.</div>';
    if (!empty($_POST['cca_website'])) return '<div class="cca-notice">Registration could not be completed.</div>';
    if (cca_auth_rate_limited('register')) return '<div class="cca-notice">Too many account attempts from this connection. Try again later.</div>';

    $username=sanitize_user($_POST['cca_username'] ?? '', true);
    $email=sanitize_email($_POST['cca_email'] ?? '');
    $pass=(string)($_POST['cca_password'] ?? '');
    if (!$username || !$email || !$pass) return '<div class="cca-notice">Please fill in username, email and password.</div>';
    if (strlen($pass) < 8) return '<div class="cca-notice">Please use a password of at least 8 characters.</div>';
    if (!is_email($email)) return '<div class="cca-notice">Please enter a valid email address.</div>';

    $uid=wp_create_user($username,$pass,$email);
    if (is_wp_error($uid)) return '<div class="cca-notice">'.esc_html($uid->get_error_message()).'</div>';
    wp_update_user(array('ID'=>$uid,'role'=>'subscriber','display_name'=>$username));
    update_user_meta($uid,'cca_selected_professions',cca_sanitize_professions($_POST['cca_professions'] ?? array()));
    update_user_meta($uid,'cca_learning_level',sanitize_text_field($_POST['cca_learning_level'] ?? 'beginner'));
    update_user_meta($uid,'cca_learning_goal',sanitize_textarea_field($_POST['cca_learning_goal'] ?? ''));
    wp_new_user_notification($uid, null, 'admin');
    wp_set_current_user($uid); wp_set_auth_cookie($uid,true);
    return '<div class="cca-notice cca-notice--success">Welcome to the Academy. Your website account and learning inbox are ready. <a href="'.esc_url(cca_url('my-academy')).'">Open My Academy</a>.</div>';
}

function cca_handle_login(){
    if (empty($_POST['cca_login_submit']) || !wp_verify_nonce($_POST['cca_nonce'] ?? '', 'cca_login')) return '';
    if (cca_auth_rate_limited('login', 12, 900)) return '<div class="cca-notice">Too many login attempts from this connection. Try again later.</div>';
    $creds=array('user_login'=>sanitize_user($_POST['cca_username'] ?? ''),'user_password'=>(string)($_POST['cca_password'] ?? ''),'remember'=>!empty($_POST['cca_remember']));
    $user=wp_signon($creds,is_ssl());
    if (is_wp_error($user)) return '<div class="cca-notice">'.esc_html($user->get_error_message()).'</div>';
    wp_set_current_user($user->ID);
    return '<div class="cca-notice cca-notice--success">You are logged in. <a href="'.esc_url(cca_url('my-academy')).'">Open My Academy</a>.</div>';
}

function cca_handle_profile(){
    if (!is_user_logged_in() || empty($_POST['cca_profile_submit']) || !wp_verify_nonce($_POST['cca_nonce'] ?? '', 'cca_profile')) return '';
    $uid=get_current_user_id();
    update_user_meta($uid,'cca_selected_professions',cca_sanitize_professions($_POST['cca_professions'] ?? array()));
    update_user_meta($uid,'cca_learning_level',sanitize_text_field($_POST['cca_learning_level'] ?? 'beginner'));
    update_user_meta($uid,'cca_learning_goal',sanitize_textarea_field($_POST['cca_learning_goal'] ?? ''));
    return '<div class="cca-notice">Your Creative Compass preferences were saved.</div>';
}

function cca_profession_checkbox_grid($selected=array()){
    $worlds=lgu_worlds(); ob_start(); echo '<div class="cca-check-grid">';
    foreach($worlds as $slug=>$w){ $checked=in_array($slug,$selected,true)?' checked':''; echo '<label class="cca-check"><input type="checkbox" name="cca_professions[]" value="'.esc_attr($slug).'"'.$checked.'> <span>'.esc_html($w['title']).'</span></label>'; }
    echo '</div>'; return ob_get_clean();
}

function cca_register_shortcode(){
    if (is_user_logged_in()) return '<section class="cca-section"><div class="wrap cca-form-card"><h1>You are already registered.</h1>'.cca_account_links().'</div></section>';
    $msg=cca_handle_register(); ob_start(); ?>
    <section class="cca-section"><div class="wrap cca-form-card"><p class="kicker">Creative Compass Academy</p><h1>Register for your Academy OS</h1><p>Choose the creative paths you want in your website inbox. No extra plugin required: this website handles the account screen itself and stores your preferences in your Academy profile.</p><?php echo $msg; ?>
    <form method="post" class="cca-form-grid"><?php wp_nonce_field('cca_register','cca_nonce'); ?><label class="cca-hp" aria-hidden="true">Website<input name="cca_website" tabindex="-1" autocomplete="off"></label><label>Username<input name="cca_username" autocomplete="username" required></label><label>Email<input type="email" name="cca_email" autocomplete="email" required></label><label>Password<input type="password" name="cca_password" autocomplete="new-password" required></label><label>Current level<select name="cca_learning_level"><option value="beginner">Beginner / before I started</option><option value="student">Student</option><option value="junior">Junior / early career</option><option value="switching">Switching careers</option><option value="professional">Professional sharpening skills</option></select></label><label>What do you want help with?<textarea name="cca_learning_goal" rows="4" placeholder="Example: I want to learn the right words, build a portfolio, and discover whether film, design or web fits me."></textarea></label><h2>Pick your profession feeds</h2><?php echo cca_profession_checkbox_grid(); ?><button class="btn" type="submit" name="cca_register_submit" value="1">Create Academy account</button></form></div></section><?php return ob_get_clean(); }
add_shortcode('cca_register','cca_register_shortcode');

function cca_login_shortcode(){
    if (is_user_logged_in()) return '<section class="cca-section"><div class="wrap cca-form-card"><h1>You are logged in.</h1>'.cca_account_links().'</div></section>';
    $msg=cca_handle_login(); ob_start(); ?>
    <section class="cca-section"><div class="wrap cca-form-card"><p class="kicker">Academy Access</p><h1>Login</h1><?php echo $msg; ?><form method="post" class="cca-form-grid"><?php wp_nonce_field('cca_login','cca_nonce'); ?><label>Username<input name="cca_username" autocomplete="username" required></label><label>Password<input type="password" name="cca_password" autocomplete="current-password" required></label><label class="cca-check"><input type="checkbox" name="cca_remember" value="1"> Remember me</label><button class="btn" type="submit" name="cca_login_submit" value="1">Enter My Academy</button></form><p><a href="<?php echo esc_url(cca_url('academy-register')); ?>">Need an academy account?</a></p></div></section><?php return ob_get_clean(); }
add_shortcode('cca_login','cca_login_shortcode');

function cca_profile_form_shortcode(){
    if (!is_user_logged_in()) return '<section class="cca-section"><div class="wrap cca-form-card"><h1>Register to build your Academy OS.</h1>'.cca_account_links().'</div></section>';
    $msg=cca_handle_profile(); $uid=get_current_user_id(); $selected=cca_selected_professions($uid); $level=get_user_meta($uid,'cca_learning_level',true) ?: 'beginner'; $goal=get_user_meta($uid,'cca_learning_goal',true); ob_start(); ?>
    <div class="cca-form-card"><h2>My Creative Compass</h2><?php echo $msg; ?><form method="post" class="cca-form-grid"><?php wp_nonce_field('cca_profile','cca_nonce'); ?><label>Current level<select name="cca_learning_level"><?php foreach(array('beginner'=>'Beginner / before I started','student'=>'Student','junior'=>'Junior / early career','switching'=>'Switching careers','professional'=>'Professional sharpening skills') as $k=>$v) echo '<option value="'.esc_attr($k).'" '.selected($level,$k,false).'>'.esc_html($v).'</option>'; ?></select></label><label>Learning goal<textarea name="cca_learning_goal" rows="4"><?php echo esc_textarea($goal); ?></textarea></label><h3>My profession feeds</h3><?php echo cca_profession_checkbox_grid($selected); ?><button class="btn" type="submit" name="cca_profile_submit" value="1">Save my compass</button></form></div><?php return ob_get_clean(); }
add_shortcode('cca_profession_picker','cca_profile_form_shortcode');

function cca_learning_inbox_shortcode(){
    if (!is_user_logged_in()) return '<div class="cca-inbox-card"><h2>Your learning inbox appears after registration.</h2>'.cca_account_links().'</div>';
    $selected=cca_selected_professions(); $worlds=lgu_worlds(); ob_start(); echo '<div class="cca-inbox-card"><h2>My Learning Inbox</h2><p>Articles and imported tutorials are filtered through your selected professions.</p>';
    if (!$selected) { echo '<div class="cca-notice">No paths selected yet. Pick a few below to activate your inbox.</div>'; echo do_shortcode('[cca_profession_picker]'); echo '</div>'; return ob_get_clean(); }
    $cat_ids=array(); foreach($selected as $slug){ $term=lgu_world_category_term($slug); if($term && !is_wp_error($term)) $cat_ids[]=(int)$term->term_id; }
    echo '<div class="cca-pills">'; foreach($selected as $slug){ if(isset($worlds[$slug])) echo '<span class="cca-pill">'.esc_html($worlds[$slug]['title']).'</span>'; } echo '</div>';
    $args=array('posts_per_page'=>12,'ignore_sticky_posts'=>true); if($cat_ids) $args['category__in']=$cat_ids; $q=new WP_Query($args);
    echo '<div class="cca-inbox-list">';
    if($q->have_posts()){ while($q->have_posts()){ $q->the_post(); echo '<a class="cca-inbox-item" href="'.esc_url(get_permalink()).'"><img src="'.esc_url(lgu_post_image_url(get_the_ID(),'medium')).'" alt=""><span><b>'.esc_html(get_the_title()).'</b><br><small>'.esc_html(wp_trim_words(get_the_excerpt(),18)).'</small></span></a>'; } wp_reset_postdata(); }
    else { foreach($selected as $slug){ if(!isset($worlds[$slug])) continue; $w=$worlds[$slug]; echo '<a class="cca-inbox-item" href="'.esc_url(lgu_world_category_url($slug)).'"><img src="'.esc_url(lgu_asset($w['poster'])).'" alt=""><span><b>'.esc_html($w['title']).' starter feed</b><br><small>Open this studio while the RSS importer gathers tutorials.</small></span></a>'; } }
    echo '</div></div>'; return ob_get_clean(); }
add_shortcode('cca_learning_inbox','cca_learning_inbox_shortcode');

function cca_account_os_shortcode(){
    if (!is_user_logged_in()) return do_shortcode('[cca_register]');
    ob_start(); ?><section class="cca-section"><div class="wrap"><p class="kicker">Personal Creative Education OS</p><h1>My Academy</h1><div class="cca-os-grid"><div><?php echo do_shortcode('[cca_profession_picker]'); ?></div><div><?php echo do_shortcode('[cca_learning_inbox]'); ?></div></div></div></section><?php return ob_get_clean(); }
add_shortcode('cca_account_os','cca_account_os_shortcode');

function cca_profession_wall_shortcode(){ $worlds=function_exists('lgu_profession_worlds')?lgu_profession_worlds():lgu_worlds(); ob_start(); ?><section class="cca-section"><div class="wrap"><p class="kicker">Creative Paths</p><h1>22 profession studios</h1><div class="cca-grid"><?php foreach($worlds as $slug=>$w): ?><a class="cca-path-card" href="<?php echo esc_url(lgu_world_category_url($slug)); ?>"><img src="<?php echo esc_url(lgu_asset($w['poster'])); ?>" alt="<?php echo esc_attr($w['title']); ?>"><div><b><?php echo esc_html($w['edition']); ?></b><h3><?php echo esc_html($w['title']); ?></h3><p><?php echo esc_html($w['desc']); ?></p></div></a><?php endforeach; ?></div></div></section><?php return ob_get_clean(); }
add_shortcode('cca_profession_wall','cca_profession_wall_shortcode');

function cca_dean_cards(){
    return array(
        array('Visual, technical, social or story?','Do you enjoy shaping images, solving systems, helping people communicate, or building narrative worlds? Your first path should match your energy, not only your taste.'),
        array('Solo craft or team production?','Some careers reward quiet focus; others demand coordination, feedback and deadlines. Choose a path that matches how you work under pressure.'),
        array('Tool curiosity versus tool panic','You do not need every program. Start with one tool that proves one skill, then add tools only when the project requires them.'),
        array('Portfolio proof beats big promises','A small finished project with clear thinking is stronger than a huge unfinished dream. Make three proofs: one fast, one polished, one experimental.'),
        array('AI as translator, not replacement','Use AI to learn terms, ask checklists, draft briefs and compare workflows. Keep taste, ethics, decisions and final authorship human.'),
        array('Industry survival basics','Learn naming, backups, deadlines, invoices, credits, copyright, revisions and communication early. These skills protect lifelong creative careers.'),
        array('Mentor question','Ask: “What would you expect from a beginner portfolio, and what mistakes instantly reveal I do not understand the field yet?”'),
        array('First month plan','Pick one path, study terminology, finish one tiny assignment per week, publish carefully, ask critique, then revise your compass.'),
    );
}
function cca_dean_compass_shortcode(){ $dean=function_exists('lgu_dean_profile')?lgu_dean_profile():array('image'=>'assets/images/dean-grey-wizard-alien.webp','title'=>'The Dean'); ob_start(); ?><section class="cca-section"><div class="wrap"><div class="lgu-guidance-hero panel panel-pad"><div><p class="kicker">Ask the Dean</p><h1>Career Compass</h1><p>The grey old alien Dean helps students choose a direction before they spend years learning the wrong words, tools or expectations. Start here when you are not sure which creative profession fits.</p><?php echo cca_account_links(); ?></div><img src="<?php echo esc_url(lgu_asset($dean['image'])); ?>" alt="<?php echo esc_attr($dean['title']); ?>"></div><div class="cca-deck"><?php $i=1; foreach(cca_dean_cards() as $c): ?><article class="cca-compass-card"><span>Dean Card <?php echo esc_html(sprintf('%02d',$i++)); ?></span><h3><?php echo esc_html($c[0]); ?></h3><p><?php echo esc_html($c[1]); ?></p></article><?php endforeach; ?></div></div></section><?php return ob_get_clean(); }
add_shortcode('cca_dean_compass','cca_dean_compass_shortcode');

function cca_start_here_shortcode(){ ob_start(); ?><section class="cca-section"><div class="wrap"><p class="kicker">Before you begin</p><h1>Learn the words, tools and systems before the industry asks for them.</h1><p class="muted">Creative Compass Academy gives future creators a free starting map: terminology, tutorial feeds, software basics, AI conversation cards, portfolio starters and career direction.</p><div class="cca-os-grid"><div class="cca-os-card"><h2>1. Pick paths</h2><p>Choose the professions you want to follow. Your account becomes a personal learning inbox.</p><a class="btn" href="<?php echo esc_url(cca_url('academy-register')); ?>">Register & pick paths</a></div><div class="cca-os-card"><h2>2. Ask better</h2><p>Use Compass Cards to talk to AI, teachers, clients and collaborators with the right terminology.</p><a class="btn ghost" href="<?php echo esc_url(cca_url('ai-career-cheat-cards')); ?>">Open Compass Cards</a></div><div class="cca-os-card"><h2>3. Learn tools</h2><p>Open the software basics manual and learn what each industry-standard package is for.</p><a class="btn ghost" href="<?php echo esc_url(cca_url('industry-software-basics-manual')); ?>">Open Tool Library</a></div><div class="cca-os-card"><h2>4. Ask the Dean</h2><p>Use the Dean’s career compass when you need direction, confidence or a realistic first step.</p><a class="btn" href="<?php echo esc_url(cca_url('career-compass')); ?>">Ask the Dean</a></div></div></div></section><?php return ob_get_clean(); }
add_shortcode('cca_start_here','cca_start_here_shortcode');


function cca_open_tutorial_feeds_shortcode(){
    ob_start(); ?>
    <section class="cca-section"><div class="wrap">
      <p class="kicker">Open Learning</p>
      <h1>Open Tutorial Feeds</h1>
      <p class="muted">A living feed of tutorials, academy notes and imported learning signals. Register and choose paths to filter this into your personal Academy OS.</p>
      <div class="panel panel-pad latest-lessons-panel"><h2>Latest Open Learning Feed</h2><div class="article-list">
      <?php $q=new WP_Query(array('posts_per_page'=>16,'ignore_sticky_posts'=>true)); if($q->have_posts()): while($q->have_posts()): $q->the_post(); ?>
        <a class="article" href="<?php the_permalink(); ?>"><img src="<?php echo esc_url(lgu_post_image_url(get_the_ID(), 'medium')); ?>" alt="<?php echo esc_attr(lgu_post_image_alt(get_the_ID())); ?>"><span><h3><?php the_title(); ?></h3><p><?php echo esc_html(wp_trim_words(get_the_excerpt(),22)); ?></p></span></a>
      <?php endwhile; wp_reset_postdata(); else: ?>
        <p class="muted">The RSS importer will place tutorials and academy notes here after activation.</p>
      <?php endif; ?></div></div>
      <p style="margin-top:1rem"><a class="btn" href="<?php echo esc_url(cca_url('academy-register')); ?>">Register & filter this feed</a></p>
    </div></section><?php return ob_get_clean();
}
add_shortcode('cca_open_tutorial_feeds','cca_open_tutorial_feeds_shortcode');

function cca_admin_notice_registration(){ if(current_user_can('manage_options') && !cca_frontend_registration_enabled()) echo '<div class="notice notice-info"><p><strong>Creative Compass Academy:</strong> front-end account pages are installed, but the theme-level public registration filter is currently disabled.</p></div>'; }
add_action('admin_notices','cca_admin_notice_registration');
