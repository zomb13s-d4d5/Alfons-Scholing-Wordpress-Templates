<?php
get_header();
?>
<main class="entry page-entry">
<?php while(have_posts()): the_post(); ?>
  <?php
    $adlg_title = strtolower(get_the_title());
    $adlg_slug  = get_post_field('post_name', get_the_ID());
    $is_cheat_cards = (
      $adlg_slug === 'ai-career-cheat-cards' ||
      $adlg_slug === 'ai-career-cheat-cards-ask-the-professors' ||
      strpos($adlg_title, 'cheat cards') !== false ||
      strpos($adlg_title, 'compass cards') !== false
    );
    $is_manual = (
      $adlg_slug === 'industry-software-basics-manual' ||
      strpos($adlg_title, 'software basics manual') !== false
    );
  ?>
  <?php if ($is_cheat_cards && function_exists('lgu_render_ai_cheat_cards')): ?>
    <?php echo lgu_render_ai_cheat_cards(); ?>
  <?php elseif ($is_manual && function_exists('lgu_render_software_manual')): ?>
    <?php echo lgu_render_software_manual(); ?>
  <?php else: ?>
    <article <?php post_class(); ?>>
      <h1><?php the_title(); ?></h1>
      <?php if(has_post_thumbnail()) the_post_thumbnail('large'); ?>
      <div class="entry-content"><?php the_content(); ?></div>
    </article>
    <?php comments_template(); ?>
  <?php endif; ?>
<?php endwhile; ?>
</main>
<?php get_footer(); ?>
