<?php
/**
 * Template Name: Collectible Pre-order
 * Description: Default Studio NotYouAgain.ai collectible toy pre-order landing page.
 */
get_header();
$worlds = lgu_worlds();
$slides = lgu_default_featured_slides();
$hero = isset($slides[0]) ? $slides[0] : array('image' => lgu_asset('assets/images/hero-ask-la-gaffe.webp'));
?>
<main class="collectibles-page">
  <section class="collectibles-hero" style="--collectibles-hero:url('<?php echo esc_url($hero['image']); ?>')">
    <div class="wrap collectibles-hero__inner">
      <div class="collectibles-hero__copy">
        <span class="eyebrow">Sticky / Collector Drop</span>
        <h1>Pre-order the <span>Creative Faculty</span></h1>
        <p>Eleven colour-coded collectible toys from Ask La Gaffe Creative Media Academy. A Studio NotYouAgain.ai universe drop for creative professionals, media trainers, collectors and studio weirdos who want the whole faculty on the shelf.</p>
        <div class="hero-actions">
          <a class="btn" href="#preorder">Reserve a Set</a>
          <a class="btn ghost" href="#faculty">View the 11 Colours</a>
        </div>
      </div>
    </div>
  </section>

  <section class="section section-tight" id="preorder">
    <div class="wrap collectibles-grid">
      <article class="panel panel-pad collectibles-intro">
        <span class="eyebrow">Collector Drop</span>
        <h2>Reserve the 11-colour faculty set</h2>
        <p class="muted">A clean pre-order landing page for the La Gaffe collectible toy line.</p>
        <div class="collectibles-cta-row">
          <?php echo lgu_account_actions_markup('account-actions account-actions--inline'); ?>
          <a class="btn ghost" href="<?php echo esc_url(home_url('/')); ?>">Back to College</a>
        </div>
      </article>
      <aside class="panel panel-pad collectibles-order-card">
        <h2>Drop Setup</h2>
        <ul>
          <li><b>11</b> colour variants</li>
          <li><b>1</b> complete faculty set</li>
          <li><b>Reserve</b> future academy drops</li>
          <li><b>Studio drop</b> character showcase</li>
        </ul>
      </aside>
    </div>
  </section>

  <section class="section" id="faculty">
    <div class="wrap panel panel-pad lgu-slider collectibles-faculty-slider" data-lgu-slider>
      <div class="slider-head">
        <div><h2>The 11-Colour Faculty</h2><p class="muted">Every collectible is also a course world in the media-training universe.</p></div>
        <div class="slider-controls"><button type="button" class="slider-arrow slider-prev" aria-label="Previous collectible">‹</button><button type="button" class="slider-arrow slider-next" aria-label="Next collectible">›</button></div>
      </div>
      <div class="lgu-slider__viewport">
        <div class="collectibles-faculty-track lgu-slider__track" data-lgu-slider-track>
          <?php foreach($worlds as $slug => $world): ?>
            <article class="collectibles-faculty-card" style="--accent:<?php echo esc_attr($world['color']); ?>">
              <img src="<?php echo esc_url(lgu_asset($world['concept'])); ?>" alt="<?php echo esc_attr($world['title']); ?> collectible concept">
              <div>
                <span class="eyebrow"><?php echo esc_html($world['edition']); ?></span>
                <h3><?php echo esc_html($world['title']); ?></h3>
                <p><?php echo esc_html($world['desc']); ?></p>
              </div>
            </article>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </section>

  <?php if (have_posts()): while(have_posts()): the_post(); ?>
    <?php if (trim(wp_strip_all_tags(get_the_content()))): ?>
      <section class="section section-tight">
        <div class="wrap panel panel-pad collectibles-terms">
          <div class="entry-content"><?php the_content(); ?></div>
        </div>
      </section>
    <?php endif; ?>
  <?php endwhile; endif; ?>
</main>
<?php get_footer(); ?>
