<?php
/* Template for the Industry Software Basics Manual page. Forces the manual to render even if saved content is empty/stale. */
get_header();
?>
<main class="entry page-entry guidance-page guidance-page--manual">
  <?php
  if (function_exists('lgu_render_software_manual')) {
      echo lgu_render_software_manual();
  } else {
      echo '<article class="panel panel-pad"><h1>Industry Software Basics Manual</h1><p>The guidance module is not loaded yet. Reinstall or reactivate the theme.</p></article>';
  }
  ?>
</main>
<?php get_footer(); ?>
