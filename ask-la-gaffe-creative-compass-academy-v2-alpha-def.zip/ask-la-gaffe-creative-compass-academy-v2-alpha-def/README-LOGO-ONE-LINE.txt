v2.1.9 Logo/title lockup fix

- Header brand is no longer stacked vertically as separate words.
- Logo sits on the left.
- Title is one line: Ask La Gaffe.
- Subtitle sits underneath the title: Creative Compass Academy.
