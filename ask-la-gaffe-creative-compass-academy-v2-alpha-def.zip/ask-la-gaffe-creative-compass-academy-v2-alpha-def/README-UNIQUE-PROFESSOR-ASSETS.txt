Creative Compass Academy v2 Alpha DEF Unique Asset Fix

- Replaced duplicated profession imagery for Film & Video vs Documentary.
- Replaced duplicated profession imagery for Design & Branding vs Marketing & Communication.
- Regenerated concept/poster/icon fallbacks for the main profession set from individual character renders.
- Added asset cache-busting version 2.0.1-alpha-unique so Safari/WordPress stops showing old cached duplicate images.
- Added front-end guidance page repair so AI Cheat Cards and Software Manual pages self-heal if an older blank page already existed.
