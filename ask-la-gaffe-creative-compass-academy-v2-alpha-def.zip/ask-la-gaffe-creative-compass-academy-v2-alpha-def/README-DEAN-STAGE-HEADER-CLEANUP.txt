v2 Alpha DEF Dean Stage + Header Cleanup

- Header changed from large transparent beta overlay into compact sticky glass academy navigation.
- Removed the old storyteller-monster hero background from the Creative Compass homepage.
- The Grey Old Alien Dean is now the single centre-stage hero image, not a small duplicate card over another character.
- Improved iPad/mobile spacing so menu text does not sit under or inside the hero department.
