v2.0.8 Backend RSS sync

You were right: there is a whole backend with RSS feeds.

This build keeps the RSS backend alive after theme ZIP updates, not only after first activation:
- runtime maintenance refreshes default settings, sources, categories and publish status
- legacy daily cron hook is cleared
- hourly backend cron hook is recreated if missing
- imported posts remain publish status
- Dean Career Compass category/feed remains active
- old OPT/DEF backend source Limelight is retained and remapped to Music Production
- admin button wording now says “Fetch backend RSS sources now”

Important: WordPress cron only runs when the site receives traffic unless a real server cron calls wp-cron.php.
If no new articles appear, open Tools → Ask La Gaffe Auto Poster and press “Fetch backend RSS sources now”, then check the backend log.
