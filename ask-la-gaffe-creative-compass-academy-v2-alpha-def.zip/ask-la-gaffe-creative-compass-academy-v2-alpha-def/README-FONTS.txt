Ask La Gaffe Creative Media Academy — Font Update v3.1

Integrated child-friendly Google Fonts stack:
- Fredoka for big headings and hero/category titles
- Baloo 2 for playful labels, buttons and studio/category tags
- Nunito for readable body copy, menus, forms and UI text

This build keeps:
- the autoposter collision hotfix
- transparent logo/icon asset fixes
- Creative Media Academy copy fixes
- Courses / Studios background-image fix
- optimized assets
