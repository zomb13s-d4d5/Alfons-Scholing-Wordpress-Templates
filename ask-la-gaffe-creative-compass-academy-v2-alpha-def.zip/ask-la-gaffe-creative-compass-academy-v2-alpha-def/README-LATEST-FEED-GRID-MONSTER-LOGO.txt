v2.0.6 latest feed and brand correction

- Restores the purple one-eye storytelling monster as the header brand mark using the existing Ask La Gaffe logo asset.
- Rebuilds the Latest Open Learning Feed from a plain list into a stylish visual magazine grid.
- Uses category/profession fallback imagery per article, with the Dean as fallback for uncategorized/general posts.
- Keeps the first article as a large lead feature card and shows up to six latest posts.
