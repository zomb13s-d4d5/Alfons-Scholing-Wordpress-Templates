v2.1.6 Cheat Cards visible fix

- Adds forced page template for /ai-career-cheat-cards/ so the 220-card deck renders even if the saved page content is empty/stale.
- Adds forced page template for /industry-software-basics-manual/.
- Hardens page.php to render these modules by slug.
- Cheat-card profession headers now use actual category poster images instead of old icons.
- Adds complete responsive styling for the AI Compass Card deck.
