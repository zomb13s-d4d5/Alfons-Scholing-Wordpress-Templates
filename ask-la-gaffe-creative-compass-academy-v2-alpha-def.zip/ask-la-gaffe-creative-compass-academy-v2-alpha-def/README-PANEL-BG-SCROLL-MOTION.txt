v2.1.8 Panel background + scroll motion fix

- Homepage Academy OS and Compass Cards panels now use the clean hero slider image instead of special panel artwork that contains typography/lettering.
- Expanded reveal-on-scroll targeting so main-page sections, profession cards, OS panels, feed cards, cheat cards and manual pages animate into view while scrolling.
- Strengthened the reveal motion so it is visible but still smooth and premium.
