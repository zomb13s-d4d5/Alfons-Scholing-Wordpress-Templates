<?php if (!defined('ABSPATH')) exit; ?><!doctype html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class(); ?>><?php wp_body_open(); ?>
<header class="site-header" aria-label="Ask La Gaffe Creative Media Academy navigation">
  <div class="nav-float">
    <a class="brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="Home">
      <span class="brand-text">Ask La Gaffe</span><em>Creative Compass Academy</em>
    </a>
    <div class="menu-slider" data-menu-slider data-menu-autoplay="4200">
      <button class="menu-arrow menu-prev" type="button" aria-label="Previous menu items">‹</button>
      <nav class="menu-track" aria-label="Primary" data-menu-track>
        <?php wp_nav_menu(array(
          'theme_location'=>'primary',
          'container'=>false,
          'fallback_cb'=>function(){
            $items = '<a href="'.esc_url(home_url('/')).'">Home</a>';
            foreach (lgu_worlds() as $slug => $w) {
              $items .= '<a href="'.esc_url(lgu_world_category_url($slug)).'">'.esc_html($w['title']).'</a>';
            }
            $items .= '<a href="'.esc_url(home_url('/posters/')).'">Posters</a><a href="'.esc_url(home_url('/characters/')).'">Faculty</a><a href="'.esc_url(lgu_account_url('register')).'">Register</a>';
            echo $items;
          },
          'items_wrap'=>'%3$s'
        )); ?>
      </nav>
      <button class="menu-arrow menu-next" type="button" aria-label="Next menu items">›</button>
      <span class="menu-slider-progress" aria-hidden="true"><i></i></span>
    </div>
    <?php if (is_user_logged_in()): ?><a class="join" href="<?php echo esc_url(lgu_account_url()); ?>">My Academy</a><?php else: ?><a class="join" href="<?php echo esc_url(lgu_account_url('register')); ?>">Login / Register</a><?php endif; ?>
  </div>
</header>
