Image optimization update:
All theme images were recompressed/optimized to reduce file size while preserving original pixel dimensions.
