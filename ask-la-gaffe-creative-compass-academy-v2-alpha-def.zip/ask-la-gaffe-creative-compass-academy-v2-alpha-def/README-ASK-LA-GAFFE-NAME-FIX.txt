v2.1.3 Ask La Gaffe name fix

Public branding is now Ask La Gaffe, matching asklagaffe.com.
Removed 'Dean' from the site/product name and admin RSS naming.
The Dean can still exist as the career-guide character/category, but the brand name is Ask La Gaffe.
