Category visual thumbnail update

- Replaced the old small icon in the category hero badge with the actual category poster/thumbnail image.
- This keeps category sections visually aligned with the real profession artwork instead of the legacy icon set.
- Theme version: 2.1.5-alpha-def-category-thumbnails
