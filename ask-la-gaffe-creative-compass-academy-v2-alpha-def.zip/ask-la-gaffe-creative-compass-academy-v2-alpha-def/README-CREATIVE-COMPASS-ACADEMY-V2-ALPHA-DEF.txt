Ask La Gaffe — Creative Compass Academy v2 Alpha DEF

Departure point: the old Creative Media Academy beta.
New purpose: a login-friendly creative education operating system by NotYouAgain Studio with ChatGPT co-production concept support.

Included in this Alpha DEF build:
- New theme name and mission language.
- 23-character structure: 22 profession professors plus the grey old alien Dean.
- Dean-led homepage makeover.
- Front-end registration and login pages using WordPress core users, no extra plugins.
- User profession preferences stored in user meta.
- Website learning inbox filtered by selected professions/categories.
- Creative Paths page.
- Start Here orientation page.
- Ask the Dean career compass page.
- Existing 220 AI cheat cards and software basics manual retained.
- Copyright/footer line for NotYouAgain Studio x ChatGPT co-production concept support.

Important WordPress setting:
To allow public student registration, enable Settings > General > Anyone can register.

Generated pages/shortcodes:
/start-here/ -> [cca_start_here]
/my-academy/ -> [cca_account_os]
/academy-login/ -> [cca_login]
/academy-register/ -> [cca_register]
/career-compass/ -> [cca_dean_compass]
/creative-paths/ -> [cca_profession_wall]

Existing guidance shortcodes retained:
[lgu_ai_cheat_cards]
[lgu_software_manual]
