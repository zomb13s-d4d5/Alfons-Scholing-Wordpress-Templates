v2.1.2 Guaranteed RSS Admin

Adds a theme-direct RSS editor page that is guaranteed to appear in WordPress Admin as:
- La Gaffe RSS
- Tools → La Gaffe RSS Feed Editor

This page is independent from the embedded importer class menu registration, but uses the same options, sources, logs and importer.
