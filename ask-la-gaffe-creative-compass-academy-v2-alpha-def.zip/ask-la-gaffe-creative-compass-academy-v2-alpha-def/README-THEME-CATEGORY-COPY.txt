Theme category copy integration:
- Embedded the Category Copy Polisher directly into the theme.
- On theme activation and admin load, the parent category and all 20 child studio category descriptions are refreshed.
- Category archive descriptions are filtered so stale backend/maintainer wording is replaced with audience-facing academy copy.
- The separate plugin is no longer required for this behavior, though it can be kept deactivated.
