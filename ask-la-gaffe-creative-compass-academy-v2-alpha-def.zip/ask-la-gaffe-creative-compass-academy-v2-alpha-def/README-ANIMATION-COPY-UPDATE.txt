Animation category copy update:
- Updated the Animation / Motion Studio category description in the theme-embedded category copy polisher.
- New copy emphasizes purple edition, animation, motion design, storyboards, timing, frames, characters, visual rhythm, cute purple monster media-academy iconography, rounded shapes and friendly public college energy.
