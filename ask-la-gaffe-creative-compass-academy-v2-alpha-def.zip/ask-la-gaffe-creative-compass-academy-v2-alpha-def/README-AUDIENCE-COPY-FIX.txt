Audience copy pass:
- Replaced maintainer/editor language on the homepage with promotional academy language.
- Removed frontend references to backend editing, widgets, autoposter, RSS and WordPress theme mechanics.
- Reworded generated page text for visitors/consumers.
- Preserves v3.1.5 photography/category artwork fixes and logo 75% sizing.
