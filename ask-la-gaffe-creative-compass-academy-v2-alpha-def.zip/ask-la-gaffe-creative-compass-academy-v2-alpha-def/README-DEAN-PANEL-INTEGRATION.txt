Ask La Gaffe — v2 Alpha DEF Dean Panel Integration

This build integrates the new Dean-backed visual panels into the homepage template:

- The "Your Academy OS" panel now has a Dean + dashboard background.
- The "Compass Cards" panel now has a Dean + AI question-card background.
- The "Alpha DEF principles" panel now has a subtle system-card background treatment.
- The panels remain readable with text overlays, glow borders, and iPad/mobile responsive fallbacks.
- Theme version bumped to 2.0.3-alpha-def-dean-panels.

Copyright: © 2026 NotYouAgain Studio. ChatGPT co-production concept support.
