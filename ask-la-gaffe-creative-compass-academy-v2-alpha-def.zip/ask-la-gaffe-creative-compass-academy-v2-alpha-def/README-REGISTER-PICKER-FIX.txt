Register picker fix v3.2.1
- Fixes the Academy Register / My Academy profession picker on iPad and mobile.
- Checkbox controls are no longer affected by the broad form input width rule.
- Labels now stay next to their checkbox inside each option tile.
