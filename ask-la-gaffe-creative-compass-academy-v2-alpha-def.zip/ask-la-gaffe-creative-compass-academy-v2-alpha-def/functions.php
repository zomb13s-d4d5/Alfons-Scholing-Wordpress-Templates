<?php
if (!defined('ABSPATH')) exit;

function lgu_worlds() {
    return array(
        'dean-career-compass' => array('category'=>'00 Dean La Gaffe — Career Compass','title'=>'Ask La Gaffe','edition'=>'Career Compass Office','color'=>'#f8d98a','poster'=>'assets/images/dean-grey-wizard-alien.webp','icon'=>'assets/images/icons/dean-grey-wizard-alien.webp','concept'=>'assets/images/hero-slider/la-gaffe-explains-academy-os.webp','desc'=>'Career paths, creative jobs, portfolio proof, interviews, internships, freelancing, studio survival and lifelong creative chances.','dean'=>1),
        'storytelling' => array('category'=>'01 Storytelling — Imagination Studio','title'=>'Storytelling','edition'=>'Imagination Studio','color'=>'#a86bff','poster'=>'assets/images/posters/storytelling.webp','icon'=>'assets/images/icons/storytelling.webp','concept'=>'assets/images/concepts/storytelling.webp','desc'=>'Narrative thinking, story structure, worldbuilding and idea development for public media.'),
        'film-video' => array('category'=>'02 Film & Video — Cinema Studio','title'=>'Film & Video','edition'=>'Cinema Studio','color'=>'#9b5cff','poster'=>'assets/images/posters/film-video.webp','icon'=>'assets/images/icons/film-video.webp','concept'=>'assets/images/concepts/film-video.webp','desc'=>'Filmmaking, video formats, camera language, scenes, shorts, trailers and creator video.'),
        'photography' => array('category'=>'03 Photography — Image Studio','title'=>'Photography','edition'=>'Image Studio','color'=>'#8d5cff','poster'=>'assets/images/posters/photography.webp','icon'=>'assets/images/icons/photography.webp','concept'=>'assets/images/concepts/photography.webp','desc'=>'Photography, image culture, visual essays, lenses and public visual storytelling.'),
        'sound-voice' => array('category'=>'04 Sound & Voice — Audio Studio','title'=>'Sound & Voice','edition'=>'Audio Studio','color'=>'#7c5cff','poster'=>'assets/images/posters/sound-voice.webp','icon'=>'assets/images/icons/sound-voice.webp','concept'=>'assets/images/concepts/sound-voice.webp','desc'=>'Sound design, voice performance, sonic identity, foley, microphones, audio texture and recording confidence.'),
        'animation' => array('category'=>'05 Animation — Motion Studio','title'=>'Animation','edition'=>'Motion Studio','color'=>'#b169ff','poster'=>'assets/images/posters/animation.webp','icon'=>'assets/images/icons/animation.webp','concept'=>'assets/images/concepts/animation.webp','desc'=>'Animation, motion design, storyboards, timing, frames, characters and visual rhythm.'),
        'design-branding' => array('category'=>'06 Design & Branding — Identity Studio','title'=>'Design & Branding','edition'=>'Identity Studio','color'=>'#c061ff','poster'=>'assets/images/posters/design-branding.webp','icon'=>'assets/images/icons/design-branding.webp','concept'=>'assets/images/concepts/design-branding.webp','desc'=>'Graphic design, identity systems, logo logic, brand voice, colour and campaign clarity.'),
        'writing-journalism' => array('category'=>'07 Writing & Journalism — Editorial Studio','title'=>'Writing & Journalism','edition'=>'Editorial Studio','color'=>'#b76cff','poster'=>'assets/images/posters/writing-journalism.webp','icon'=>'assets/images/icons/writing-journalism.webp','concept'=>'assets/images/concepts/writing-journalism.webp','desc'=>'Writing, publishing, editorial thinking, explainers, interviews, articles and zines.'),
        'editing-post-production' => array('category'=>'08 Editing & Post-Production — Edit Studio','title'=>'Editing & Post-Production','edition'=>'Edit Studio','color'=>'#9666ff','poster'=>'assets/images/posters/editing-post-production.webp','icon'=>'assets/images/icons/editing-post-production.webp','concept'=>'assets/images/concepts/editing-post-production.webp','desc'=>'Editing, timelines, cuts, post-production, captions, rhythm, polishing and delivery.'),
        'music-production' => array('category'=>'09 Music Production — Melody Studio','title'=>'Music Production','edition'=>'Melody Studio','color'=>'#8e62ff','poster'=>'assets/images/posters/music-production.webp','icon'=>'assets/images/icons/music-production.webp','concept'=>'assets/images/concepts/music-production.webp','desc'=>'Music, jingles, composition, rhythm, sonic branding and performance-based production.'),
        'streaming-social' => array('category'=>'10 Streaming & Social — Broadcast Studio','title'=>'Streaming & Social Media','edition'=>'Broadcast Studio','color'=>'#ba63ff','poster'=>'assets/images/posters/streaming-social.webp','icon'=>'assets/images/icons/streaming-social.webp','concept'=>'assets/images/concepts/streaming-social.webp','desc'=>'Streaming, creator formats, social broadcasting, community signals and live presence.'),
        'reporting-research' => array('category'=>'11 Reporting — Source Lab','title'=>'Reporting & Research','edition'=>'Source Lab','color'=>'#a35cff','poster'=>'assets/images/posters/reporting-research.webp','icon'=>'assets/images/icons/reporting-research.webp','concept'=>'assets/images/concepts/reporting-research.webp','desc'=>'Source checking, public-interest reporting, interviews, research trails and fact-aware publishing.'),
        'coding-web' => array('category'=>'12 Coding & Web — Web Lab','title'=>'Coding & Web Creation','edition'=>'Web Lab','color'=>'#884cff','poster'=>'assets/images/posters/coding-web.webp','icon'=>'assets/images/icons/coding-web.webp','concept'=>'assets/images/concepts/coding-web.webp','desc'=>'Websites, code, interfaces, interaction, creative technology and digital craft.'),
        'presenting' => array('category'=>'13 Presenting — Stage Studio','title'=>'Presenting & Public Speaking','edition'=>'Stage Studio','color'=>'#9f5cff','poster'=>'assets/images/posters/presenting.webp','icon'=>'assets/images/icons/presenting.webp','concept'=>'assets/images/concepts/presenting.webp','desc'=>'Presenting, public speaking, lectures, confidence, demos, stage presence and audience communication.'),
        'game-design' => array('category'=>'14 Game Design — Play Lab','title'=>'Game Design','edition'=>'Play Lab','color'=>'#a25bff','poster'=>'assets/images/posters/game-design.webp','icon'=>'assets/images/icons/game-design.webp','concept'=>'assets/images/concepts/game-design.webp','desc'=>'Game storytelling, interactive media, play systems, levels, mechanics and creative prototypes.'),
        'fashion-styling' => array('category'=>'15 Fashion & Styling — Costume Studio','title'=>'Fashion & Styling','edition'=>'Costume Studio','color'=>'#c56bff','poster'=>'assets/images/posters/fashion-styling.webp','icon'=>'assets/images/icons/fashion-styling.webp','concept'=>'assets/images/concepts/fashion-styling.webp','desc'=>'Fashion media, costume design, styling, fabric, wardrobe, character looks and visual identity.'),
        'science-innovation' => array('category'=>'16 Science & Innovation — Discovery Lab','title'=>'Science & Innovation','edition'=>'Discovery Lab','color'=>'#8f6cff','poster'=>'assets/images/posters/science-innovation.webp','icon'=>'assets/images/icons/science-innovation.webp','concept'=>'assets/images/concepts/science-innovation.webp','desc'=>'Science communication, innovation, technology, labs, experiments and research-driven media.'),
        'illustration-painting' => array('category'=>'17 Illustration & Painting — Art Studio','title'=>'Illustration & Painting','edition'=>'Art Studio','color'=>'#bd65ff','poster'=>'assets/images/posters/illustration-painting.webp','icon'=>'assets/images/icons/illustration-painting.webp','concept'=>'assets/images/concepts/illustration-painting.webp','desc'=>'Illustration, painting, drawing, visual arts, character art, comics and expressive mark-making.'),
        'event-production' => array('category'=>'18 Event Production — Live Control','title'=>'Event Production','edition'=>'Live Control','color'=>'#985cff','poster'=>'assets/images/posters/event-production.webp','icon'=>'assets/images/icons/event-production.webp','concept'=>'assets/images/concepts/event-production.webp','desc'=>'Events, live production, stage management, cue sheets, lighting and creative coordination.'),
        'marketing-social' => array('category'=>'19 Marketing — Growth Studio','title'=>'Marketing & Social Media','edition'=>'Growth Studio','color'=>'#d062ff','poster'=>'assets/images/posters/marketing-social.webp','icon'=>'assets/images/icons/marketing-social.webp','concept'=>'assets/images/concepts/marketing-social.webp','desc'=>'Marketing, strategy, community growth, social messaging, campaigns, metrics and creative reach.'),
        'documentary-exploration' => array('category'=>'20 Documentary — Exploration Desk','title'=>'Documentary & Exploration','edition'=>'Exploration Desk','color'=>'#ad72ff','poster'=>'assets/images/posters/documentary-exploration.webp','icon'=>'assets/images/icons/documentary-exploration.webp','concept'=>'assets/images/concepts/documentary-exploration.webp','desc'=>'Documentary, fieldwork, travel stories, research, place-based media and discovery-led production.'),
        'podcast-radio' => array('category'=>'21 Podcast & Radio — On Air Studio','title'=>'Podcast & Radio','edition'=>'On Air Studio','color'=>'#74d36a','poster'=>'assets/images/posters/podcast-radio.webp','icon'=>'assets/images/icons/podcast-radio.webp','concept'=>'assets/images/concepts/podcast-radio.webp','desc'=>'Podcast production, radio formats, interviews, cue cards, voice recording, audio publishing and on-air confidence.'),
        'production-manager' => array('category'=>'22 Production Management — Coordination Desk','title'=>'Production Management','edition'=>'Coordination Desk','color'=>'#caa6ff','poster'=>'assets/images/posters/production-manager.webp','icon'=>'assets/images/icons/production-manager.webp','concept'=>'assets/images/concepts/production-manager.webp','desc'=>'Production planning, schedules, shot lists, call sheets, coordination, crews, reviews and delivery management.'),
    );
}

function lgu_asset($path) { return get_template_directory_uri() . '/' . ltrim($path, '/') . '?v=2.0.2-dean-hero'; }


function lgu_parent_category_name() {
    return 'Ask La Gaffe — Creative Compass Academy';
}

function lgu_parent_category_slug() {
    return 'ask-la-gaffe-creative-compass-academy';
}

function lgu_parent_category_term() {
    $term = get_term_by('slug', lgu_parent_category_slug(), 'category');
    if ($term && !is_wp_error($term)) return $term;

    $term = get_term_by('name', lgu_parent_category_name(), 'category');
    if ($term && !is_wp_error($term)) return $term;

    return null;
}

function lgu_parent_category_url() {
    $term = lgu_parent_category_term();
    if ($term && !is_wp_error($term)) {
        $link = get_category_link($term->term_id);
        if (!is_wp_error($link)) return $link;
    }
    return home_url('/category/' . lgu_parent_category_slug() . '/');
}

function lgu_dean_email() {
    return 'zomb13s@protonmail.com';
}

function lgu_dean_mailto_url() {
    return 'mailto:' . lgu_dean_email() . '?subject=' . rawurlencode('Meet Ask Ask La Gaffe — Creative Media Academy');
}


function lgu_account_url($action = 'login') {
    // Front-end Academy account URLs. WordPress still powers users/security,
    // but visitors stay inside the website instead of being sent to wp-login.php.
    if (function_exists('cca_url')) {
        if (is_user_logged_in()) return cca_url('my-academy');
        if ($action === 'register') return cca_url('academy-register');
        return cca_url('academy-login');
    }

    // Safe fallback if the Academy module has not loaded yet.
    if (is_user_logged_in()) return home_url('/my-academy/');
    return home_url($action === 'register' ? '/academy-register/' : '/academy-login/');
}

function lgu_account_actions_markup($class = 'account-actions') {
    ob_start();
    ?>
    <div class="<?php echo esc_attr($class); ?>">
      <?php if (is_user_logged_in()): ?>
        <a class="btn" href="<?php echo esc_url(lgu_account_url()); ?>">My Academy</a>
        <a class="btn ghost" href="<?php echo esc_url(wp_logout_url(home_url('/'))); ?>">Log out</a>
      <?php else: ?>
        <a class="btn" href="<?php echo esc_url(lgu_account_url('login')); ?>">Log in</a>
        <a class="btn ghost" href="<?php echo esc_url(lgu_account_url('register')); ?>">Register</a>
      <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}



function lgu_world_category_name($slug) {
    $worlds = lgu_worlds();
    return isset($worlds[$slug]['category']) ? $worlds[$slug]['category'] : '';
}


function lgu_profession_worlds() {
    return array_filter(lgu_worlds(), function($world) {
        return empty($world['dean']);
    });
}

function lgu_dean_world() {
    $worlds = lgu_worlds();
    return $worlds['dean-career-compass'] ?? null;
}


function lgu_world_category_slug($slug) {
    $name = lgu_world_category_name($slug);
    return $name ? sanitize_title($name) : sanitize_title($slug . '-world');
}

function lgu_world_category_term($slug) {
    $name = lgu_world_category_name($slug);
    if ($name) {
        $term = get_term_by('name', $name, 'category');
        if ($term && !is_wp_error($term)) return $term;
    }
    $term = get_category_by_slug(lgu_world_category_slug($slug));
    if ($term && !is_wp_error($term)) return $term;
    return null;
}

function lgu_world_category_url($slug) {
    $term = lgu_world_category_term($slug);
    if ($term && !is_wp_error($term)) {
        $link = get_category_link($term->term_id);
        if (!is_wp_error($link)) return $link;
    }
    return home_url('/category/' . lgu_world_category_slug($slug) . '/');
}


function lgu_world_from_term($term) {
    if (!$term || is_wp_error($term)) return null;
    $worlds = lgu_worlds();
    $check_ids = array((int) $term->term_id);
    $ancestors = get_ancestors((int) $term->term_id, 'category');
    if (!empty($ancestors)) $check_ids = array_merge($check_ids, array_map('intval', $ancestors));

    foreach ($check_ids as $term_id) {
        $candidate = get_term($term_id, 'category');
        if (!$candidate || is_wp_error($candidate)) continue;
        foreach ($worlds as $slug => $world) {
            $official_slug = sanitize_title($world['category']);
            if ($candidate->name === $world['category'] || $candidate->slug === $official_slug || $candidate->slug === lgu_world_category_slug($slug)) {
                $world['slug'] = $slug;
                $world['term_id'] = (int) $candidate->term_id;
                $world['term_slug'] = $candidate->slug;
                return $world;
            }
        }
    }
    return null;
}

function lgu_world_from_post($post_id = 0) {
    $post_id = $post_id ? (int) $post_id : get_the_ID();
    $terms = get_the_category($post_id);
    if (!$terms || is_wp_error($terms)) return null;
    foreach ($terms as $term) {
        $world = lgu_world_from_term($term);
        if ($world) return $world;
    }
    return null;
}

function lgu_current_world() {
    if (is_category()) return lgu_world_from_term(get_queried_object());
    if (is_singular('post')) return lgu_world_from_post(get_the_ID());
    return null;
}

function lgu_dean_fallback_image() {
    return lgu_asset('assets/images/dean-grey-wizard-alien.webp');
}

function lgu_world_fallback_image($world = null, $type = 'poster') {
    if (is_array($world)) {
        if ($type === 'icon' && !empty($world['icon'])) return lgu_asset($world['icon']);
        if ($type === 'concept' && !empty($world['concept'])) return lgu_asset($world['concept']);
        if (!empty($world['poster'])) return lgu_asset($world['poster']);
    }
    return lgu_dean_fallback_image();
}

function lgu_current_category_fallback_image($type = 'poster') {
    if (is_category()) {
        $world = lgu_world_from_term(get_queried_object());
        if ($world) return lgu_world_fallback_image($world, $type);
    }
    return lgu_dean_fallback_image();
}

function lgu_post_image_url($post_id = 0, $size = 'large') {
    $post_id = $post_id ? (int) $post_id : get_the_ID();
    if (has_post_thumbnail($post_id)) {
        $url = get_the_post_thumbnail_url($post_id, $size);
        if ($url) return $url;
    }

    /* Category-specific fallback:
       posts inside a profession/category inherit that profession's poster image.
       Everything else falls back to the Dean, not a random/default professor. */
    $world = lgu_world_from_post($post_id);
    if ($world) return lgu_world_fallback_image($world, 'poster');

    return lgu_dean_fallback_image();
}

function lgu_post_image_alt($post_id = 0) {
    $post_id = $post_id ? (int) $post_id : get_the_ID();
    if (has_post_thumbnail($post_id)) {
        return get_the_title($post_id);
    }
    $world = lgu_world_from_post($post_id);
    return $world ? $world['title'] . ' studio fallback image' : 'Ask La Gaffe fallback image';
}


/* v2.0.5 — fallback image policy.
   The Dean is the universal fallback. Posts inside one of the 22 academy categories use that category/profession image. */
function lgu_fallback_image_for_context($type = 'poster') {
    if (is_singular('post')) {
        return lgu_post_image_url(get_the_ID(), 'large');
    }
    if (is_category()) {
        return lgu_current_category_fallback_image($type);
    }
    return lgu_dean_fallback_image();
}


function lgu_default_featured_slides() {
    $worlds = lgu_worlds();
    $slides = array(
        array(
            'kicker' => 'Purple Academy / Creative Studios',
            'title' => 'Ask La Gaffe Creative Media Academy',
            'text' => 'A welcoming purple academy where every creative studio invites you to make stories, images, sound, games, shows, designs and ideas together.',
            'button' => 'Enter the Academy',
            'url' => lgu_parent_category_url(),
            'image' => lgu_asset('assets/images/hero-ask-la-gaffe.webp'),
            'accent' => '#7b2cff',
            'sticky' => true,
        ),
    );
    foreach ($worlds as $slug => $world) {
        $slides[] = array(
            'kicker' => $world['edition'] . ' Course',
            'title' => $world['title'],
            'text' => $world['desc'],
            'button' => 'Open Course',
            'url' => lgu_world_category_url($slug),
            'image' => lgu_asset($world['poster']),
            'accent' => $world['color'],
            'sticky' => false,
        );
    }
    return $slides;
}

function lgu_featured_slides() {
    $defaults = lgu_default_featured_slides();
    $slides = array();

    for ($i = 1; $i <= 24; $i++) {
        $fallback = isset($defaults[$i - 1]) ? $defaults[$i - 1] : array(
            'kicker' => '',
            'title' => '',
            'text' => '',
            'button' => '',
            'url' => '',
            'image' => '',
            'accent' => '#7b2cff',
            'sticky' => false,
        );

        $enabled_default = ($i <= count($defaults)) ? '1' : '0';
        $enabled = get_theme_mod("lgu_featured_slide_{$i}_enabled", $enabled_default);
        if ($enabled !== '1') continue;

        $slide = array(
            'kicker' => get_theme_mod("lgu_featured_slide_{$i}_kicker", $fallback['kicker']),
            'title' => get_theme_mod("lgu_featured_slide_{$i}_title", $fallback['title']),
            'text' => get_theme_mod("lgu_featured_slide_{$i}_text", $fallback['text']),
            'button' => get_theme_mod("lgu_featured_slide_{$i}_button", $fallback['button']),
            'url' => get_theme_mod("lgu_featured_slide_{$i}_url", $fallback['url']),
            'image' => get_theme_mod("lgu_featured_slide_{$i}_image", $fallback['image']),
            'accent' => get_theme_mod("lgu_featured_slide_{$i}_accent", $fallback['accent']),
            'sticky' => !empty($fallback['sticky']),
        );

        if (trim($slide['title']) !== '') $slides[] = $slide;
    }

    return $slides ? $slides : $defaults;
}

function lgu_customize_featured_slider($wp_customize) {
    $wp_customize->add_section('lgu_featured_slider', array(
        'title' => __('Featured Slider', 'la-gaffe-creative academy-college-v1337-opt'),
        'description' => __('Edit the homepage featured slider. Slide 1 introduces the academy; the following slides cover the twenty creative media categories.', 'la-gaffe-creative academy-college-v1337-opt'),
        'priority' => 35,
    ));

    $defaults = lgu_default_featured_slides();

    for ($i = 1; $i <= 24; $i++) {
        $fallback = isset($defaults[$i - 1]) ? $defaults[$i - 1] : array('kicker'=>'','title'=>'','text'=>'','button'=>'','url'=>'','image'=>'','accent'=>'#7b2cff');
        $enabled_default = ($i <= count($defaults)) ? '1' : '0';

        $wp_customize->add_setting("lgu_featured_slide_{$i}_enabled", array('default'=>$enabled_default, 'sanitize_callback'=>'lgu_sanitize_checkbox'));
        $wp_customize->add_control("lgu_featured_slide_{$i}_enabled", array(
            'type' => 'checkbox',
            'section' => 'lgu_featured_slider',
            'label' => sprintf(__('Enable slide %d', 'la-gaffe-creative academy-college-v1337-opt'), $i),
        ));

        foreach (array('kicker'=>'Kicker / label', 'title'=>'Title', 'text'=>'Description', 'button'=>'Button text', 'url'=>'Button URL', 'accent'=>'Accent colour') as $field => $label) {
            $sanitize = ($field === 'url') ? 'esc_url_raw' : (($field === 'accent') ? 'sanitize_hex_color' : 'sanitize_text_field');
            if ($field === 'text') $sanitize = 'sanitize_textarea_field';
            $wp_customize->add_setting("lgu_featured_slide_{$i}_{$field}", array('default'=>$fallback[$field], 'sanitize_callback'=>$sanitize));
            $wp_customize->add_control("lgu_featured_slide_{$i}_{$field}", array(
                'section' => 'lgu_featured_slider',
                'label' => sprintf(__('Slide %1$d — %2$s', 'la-gaffe-creative academy-college-v1337-opt'), $i, $label),
                'type' => ($field === 'text') ? 'textarea' : 'text',
            ));
        }

        $wp_customize->add_setting("lgu_featured_slide_{$i}_image", array('default'=>$fallback['image'], 'sanitize_callback'=>'esc_url_raw'));
        $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, "lgu_featured_slide_{$i}_image", array(
            'section' => 'lgu_featured_slider',
            'label' => sprintf(__('Slide %d — Background image', 'la-gaffe-creative academy-college-v1337-opt'), $i),
        )));
    }
}
add_action('customize_register', 'lgu_customize_featured_slider');

function lgu_sanitize_checkbox($checked) {
    return ((isset($checked) && true == $checked) ? '1' : '0');
}



function lgu_ensure_world_categories() {
    if (!function_exists('wp_insert_category')) {
        require_once ABSPATH . 'wp-admin/includes/taxonomy.php';
    }

    $parent = lgu_parent_category_term();
    $parent_id = 0;

    if ($parent && !is_wp_error($parent)) {
        $parent_id = (int) $parent->term_id;
    } else {
        $created = wp_insert_category(array(
            'cat_name' => lgu_parent_category_name(),
            'category_nicename' => lgu_parent_category_slug(),
            'category_description' => 'The parent category tree for Ask La Gaffe Creative Media Academy: a purple media college with twenty-two creative media studios plus the Dean’s Career Compass and official-source lessons.',
        ), true);
        if (!is_wp_error($created)) $parent_id = (int) $created;
    }

    foreach (lgu_worlds() as $slug => $world) {
        $term = lgu_world_category_term($slug);
        if ($term && !is_wp_error($term)) {
            if ($parent_id && (int) $term->parent !== $parent_id) {
                wp_update_term((int) $term->term_id, 'category', array('parent' => $parent_id));
            }
            continue;
        }

        wp_insert_category(array(
            'cat_name' => $world['category'],
            'category_nicename' => lgu_world_category_slug($slug),
            'category_parent' => $parent_id,
            'category_description' => $world['desc'],
        ), true);
    }
}
add_action('after_switch_theme', 'lgu_ensure_world_categories');
add_action('admin_init', 'lgu_ensure_world_categories');


function lgu_ensure_world_menu_only() {
    // The official Ask La Gaffe Auto Poster plugin owns and creates the world categories.
    // The theme only links to those existing categories; it does not create duplicate category terms.
    $locations = get_theme_mod('nav_menu_locations');
    if (!is_array($locations)) $locations = array();
    if (!empty($locations['primary'])) return;

    $worlds = lgu_worlds();
    $menu_name = 'Ask La Gaffe Creative Media Academy';
    $menu = wp_get_nav_menu_object($menu_name);
    $menu_id = $menu ? $menu->term_id : wp_create_nav_menu($menu_name);
    if (is_wp_error($menu_id)) return;

    $existing = wp_get_nav_menu_items($menu_id);
    if (empty($existing)) {
        wp_update_nav_menu_item($menu_id, 0, array(
            'menu-item-title' => 'Home',
            'menu-item-url' => home_url('/'),
            'menu-item-status' => 'publish',
        ));
        foreach ($worlds as $slug => $w) {
            $term = lgu_world_category_term($slug);
            if ($term && !is_wp_error($term)) {
                wp_update_nav_menu_item($menu_id, 0, array(
                    'menu-item-title' => $w['title'],
                    'menu-item-object' => 'category',
                    'menu-item-object-id' => (int) $term->term_id,
                    'menu-item-type' => 'taxonomy',
                    'menu-item-status' => 'publish',
                ));
            } else {
                wp_update_nav_menu_item($menu_id, 0, array(
                    'menu-item-title' => $w['title'],
                    'menu-item-url' => lgu_world_category_url($slug),
                    'menu-item-status' => 'publish',
                ));
            }
        }
    }
    $locations['primary'] = (int) $menu_id;
    set_theme_mod('nav_menu_locations', $locations);
}
add_action('after_switch_theme', 'lgu_ensure_world_menu_only');


function lgu_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
    add_theme_support('custom-logo', array('height'=>120,'width'=>360,'flex-width'=>true,'flex-height'=>true));
    register_nav_menus(array('primary'=>__('Primary Menu','la-gaffe-creative academy-college-v1337-opt')));
}
add_action('after_setup_theme','lgu_setup');

function lgu_assets() {
    wp_enqueue_style('lgu-style', get_stylesheet_uri(), array(), '2.0.2-dean-hero');
    wp_enqueue_script('lgu-main', lgu_asset('assets/js/main.js'), array(), '2.0.2-dean-hero', true);
}
add_action('wp_enqueue_scripts','lgu_assets');

function lgu_register_cpts() {
    register_post_type('lgu_world', array(
        'labels'=>array('name'=>'Courses','singular_name'=>'Course'),
        'public'=>true, 'has_archive'=>true, 'menu_icon'=>'dashicons-art',
        'supports'=>array('title','editor','thumbnail','excerpt','custom-fields'),
        'rewrite'=>array('slug'=>'worlds'), 'show_in_rest'=>true,
    ));
    register_post_type('lgu_character', array(
        'labels'=>array('name'=>'Faculty','singular_name'=>'Faculty Member'),
        'public'=>true, 'has_archive'=>true, 'menu_icon'=>'dashicons-buddicons-replies',
        'supports'=>array('title','editor','thumbnail','excerpt','custom-fields'),
        'rewrite'=>array('slug'=>'characters'), 'show_in_rest'=>true,
    ));
    register_post_type('lgu_poster', array(
        'labels'=>array('name'=>'Training Posters','singular_name'=>'Training Poster'),
        'public'=>true, 'has_archive'=>true, 'menu_icon'=>'dashicons-format-image',
        'supports'=>array('title','editor','thumbnail','excerpt','custom-fields'),
        'rewrite'=>array('slug'=>'posters'), 'show_in_rest'=>true,
    ));
}
add_action('init','lgu_register_cpts');

function lgu_body_classes($classes) { $classes[]='lgu-theme'; return $classes; }
add_filter('body_class','lgu_body_classes');

function lgu_seed_notice() {
    if (current_user_can('manage_options')) echo '<!-- Ask La Gaffe Creative Media Academy theme loaded. Fallback copy is written for creative professionals and media training by Studio NotYouAgain.ai. -->';
}
add_action('wp_footer','lgu_seed_notice');


/**
 * v2.1.2 — Default collectible pre-order page.
 * Creates a real WordPress page on theme activation/admin load and also
 * provides a front-end fallback route so /pre-order-collectibles/ never 404s.
 */
function lgu_collectibles_page_slug() {
    return 'pre-order-collectibles';
}

function lgu_collectibles_page_title() {
    return 'Ask La Gaffe Creative Media Academy';
}

function lgu_collectibles_page_content() {
    return '<!-- wp:heading --><h2>Reserve the 11-colour La Gaffe collectible toy line</h2><!-- /wp:heading -->'
        . '<!-- wp:paragraph --><p>The Creative Faculty is the collectible-toy edition of Ask La Gaffe Creative Media Academy: eleven colour-coded media trainers from the Studio NotYouAgain.ai universe, built for creative professionals, collectors, studios, classrooms and campaign desks.</p><!-- /wp:paragraph -->'
        . '<!-- wp:paragraph --><p>Explore upcoming character releases, academy specials, creative bundles and playful studio drops from the Ask La Gaffe universe.</p><!-- /wp:paragraph -->'
        . '<!-- wp:heading {"level":3} --><h3>Default pre-order promise</h3><!-- /wp:heading -->'
        . '<!-- wp:list --><ul><li>Explore twenty playful creative studios.</li><li>Choose your path through storytelling, film, photo, audio, animation, design, writing, editing, music, streaming, reporting, coding, presenting, games, fashion, science, illustration, events, marketing and documentary.</li><li>Join future academy drops, workshops, showcases and creative missions.</li><li>Collect ideas, build confidence and share your work with the Ask La Gaffe community.</li></ul><!-- /wp:list -->'
        . '<!-- wp:paragraph --><p>Use this page as an editable academy landing, shop or pre-order page.</p><!-- /wp:paragraph -->';
}

function lgu_ensure_collectibles_page() {
    if (!function_exists('wp_insert_post')) return 0;

    $slug = lgu_collectibles_page_slug();
    $page = get_page_by_path($slug, OBJECT, 'page');

    if ($page && !is_wp_error($page)) {
        update_post_meta($page->ID, '_wp_page_template', 'page-collectibles.php');
        return (int) $page->ID;
    }

    $page_id = wp_insert_post(array(
        'post_title'   => lgu_collectibles_page_title(),
        'post_name'    => $slug,
        'post_status'  => 'publish',
        'post_type'    => 'page',
        'post_content' => lgu_collectibles_page_content(),
        'post_author'  => get_current_user_id() ?: 1,
        'meta_input'   => array('_wp_page_template' => 'page-collectibles.php'),
    ), true);

    if (!is_wp_error($page_id) && $page_id) {
        update_post_meta((int) $page_id, '_wp_page_template', 'page-collectibles.php');
        return (int) $page_id;
    }

    return 0;
}
add_action('after_switch_theme', 'lgu_ensure_collectibles_page');
add_action('admin_init', 'lgu_ensure_collectibles_page');

function lgu_collectibles_page_url() {
    $page = get_page_by_path(lgu_collectibles_page_slug(), OBJECT, 'page');
    if ($page && !is_wp_error($page)) {
        $link = get_permalink($page->ID);
        if ($link) return $link;
    }
    return home_url('/' . lgu_collectibles_page_slug() . '/');
}

function lgu_collectibles_virtual_template($template) {
    if (is_admin()) return $template;
    global $wp;
    $request = isset($wp->request) ? trim($wp->request, '/') : '';
    if ($request === lgu_collectibles_page_slug()) {
        $custom = locate_template('page-collectibles.php');
        if ($custom) {
            status_header(200);
            return $custom;
        }
    }
    return $template;
}
add_filter('template_include', 'lgu_collectibles_virtual_template', 99);



function lgu_register_widgets() {
    $areas = array(
        'academy_header' => 'Academy Header Widgets',
        'academy_home' => 'Homepage Academy Widgets',
        'academy_shop' => 'Shop / WooCommerce Widgets',
        'academy_footer' => 'Footer Academy Widgets',
    );
    foreach ($areas as $id => $name) {
        register_sidebar(array(
            'name' => __($name, 'ask-la-gaffe-creative-media-academy-v1337-opt-def'),
            'id' => $id,
            'description' => __('Editable widget area for the Ask La Gaffe Creative Media Academy theme.', 'ask-la-gaffe-creative-media-academy-v1337-opt-def'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h2 class="widget-title">',
            'after_title' => '</h2>',
        ));
    }
}
add_action('widgets_init', 'lgu_register_widgets');

function lgu_load_embedded_autoposter() {
    // HOTFIX: the importer is bundled with the theme, but the original plugin may
    // still be active. WordPress loads plugins before themes, so loading the
    // bundled module again would cause a fatal "Cannot declare class" error.
    if (class_exists('ALG_Official_Source_Auto_Poster')) {
        return;
    }
    $module = get_template_directory() . '/inc/official-source-autoposter.php';
    if (file_exists($module)) {
        require_once $module;
    }
}
lgu_load_embedded_autoposter();

function lgu_activate_embedded_autoposter() {
    if (class_exists('ALG_Official_Source_Auto_Poster') && method_exists('ALG_Official_Source_Auto_Poster', 'activate')) {
        ALG_Official_Source_Auto_Poster::activate();
    }
}
add_action('after_switch_theme', 'lgu_activate_embedded_autoposter');
require_once get_template_directory() . '/inc/category-copy-polisher.php';

require_once get_template_directory() . '/inc/academy-guidance.php';

require_once get_template_directory() . '/inc/creative-compass-os.php';



/* v2.1.2 — Guaranteed integrated RSS feed editor.
   This page is registered directly by the theme, so it remains visible even if the embedded importer class menu is not showing. */
if (!defined('ADLG_RSS_OPTION_SETTINGS')) {
    define('ADLG_RSS_OPTION_SETTINGS', 'alg_osap_settings');
    define('ADLG_RSS_OPTION_SOURCES', 'alg_osap_sources');
    define('ADLG_RSS_OPTION_LOG', 'alg_osap_log');
}

function adlg_theme_rss_default_settings() {
    return array(
        'post_status' => 'publish',
        'items_per_source' => 4,
        'max_posts_per_run' => 500,
        'excerpt_words' => 70,
        'confidence_threshold' => 60,
        'add_tags' => 1,
        'prepend_lagaffe_note' => 1,
        'taxonomy_mode' => 'hierarchy',
    );
}

function adlg_theme_rss_settings() {
    return wp_parse_args((array)get_option(ADLG_RSS_OPTION_SETTINGS, array()), adlg_theme_rss_default_settings());
}

function adlg_theme_rss_sources() {
    return (array)get_option(ADLG_RSS_OPTION_SOURCES, array());
}

function adlg_theme_rss_admin_menu() {
    add_menu_page(
        'Ask La Gaffe RSS Feed Editor',
        'La Gaffe RSS',
        'manage_options',
        'adlg-theme-rss-editor',
        'adlg_theme_rss_editor_page',
        'dashicons-rss',
        58
    );
    add_management_page(
        'Ask La Gaffe RSS Feed Editor',
        'La Gaffe RSS Feed Editor',
        'manage_options',
        'adlg-theme-rss-editor',
        'adlg_theme_rss_editor_page'
    );
}
add_action('admin_menu', 'adlg_theme_rss_admin_menu', 1);

function adlg_theme_rss_notice_redirect($message) {
    wp_safe_redirect(add_query_arg(array('page'=>'adlg-theme-rss-editor','adlg_rss_notice'=>rawurlencode($message)), admin_url('admin.php')));
    exit;
}

function adlg_theme_rss_editor_page() {
    if (!current_user_can('manage_options')) return;
    $settings = adlg_theme_rss_settings();
    $sources = adlg_theme_rss_sources();
    $log = (array)get_option(ADLG_RSS_OPTION_LOG, array());
    $next = function_exists('wp_next_scheduled') ? wp_next_scheduled('alg_osap_hourly_fetch') : false;
    ?>
    <div class="wrap adlg-rss-admin">
        <h1>Ask La Gaffe — Integrated RSS Feed Editor</h1>
        <p><strong>This RSS backend is integrated into the active theme.</strong> Use this screen to add feeds, edit feed URLs, auto-post now, restore built-in sources, and control publish settings.</p>
        <?php if (!empty($_GET['adlg_rss_notice'])): ?><div class="notice notice-success is-dismissible"><p><?php echo esc_html(wp_unslash($_GET['adlg_rss_notice'])); ?></p></div><?php endif; ?>

        <style>
            .adlg-rss-admin .alg-card{background:#fff;border:1px solid #ccd0d4;border-radius:8px;padding:18px;margin:16px 0;max-width:1180px}
            .adlg-rss-admin .alg-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}
            .adlg-rss-admin .alg-log{max-height:340px;overflow:auto;background:#101014;color:#e9e9ef;padding:14px;border-radius:6px;font-family:monospace;white-space:pre-wrap}
            .adlg-rss-admin .widefat input{width:100%}
            .adlg-rss-admin .alg-badge{display:inline-block;padding:4px 8px;border-radius:999px;background:#e7f5ff;color:#075985;font-weight:700}
            .adlg-rss-admin .button-primary{font-weight:700}
        </style>

        <div class="alg-card">
            <h2>Status</h2>
            <div class="alg-grid">
                <p><strong>Next hourly fetch:</strong><br><?php echo $next ? esc_html(date_i18n(get_option('date_format').' '.get_option('time_format'), $next)) : 'Not scheduled'; ?></p>
                <p><strong>Post status:</strong><br><span class="alg-badge"><?php echo esc_html($settings['post_status']); ?></span></p>
                <p><strong>Max posts/run:</strong><br><?php echo esc_html((string)$settings['max_posts_per_run']); ?></p>
                <p><strong>Sources in backend:</strong><br><?php echo esc_html((string)count($sources)); ?></p>
            </div>
        </div>

        <div class="alg-card">
            <h2>Auto Post Now</h2>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('adlg_theme_rss_fetch_now'); ?><input type="hidden" name="action" value="adlg_theme_rss_fetch_now">
                <?php submit_button('Auto Post Now / Fetch RSS Now', 'primary', 'submit', false); ?>
            </form>
            <p>The importer skips duplicate source URLs. Newly imported items use import time as the WordPress publish date, so they appear at the top of the homepage feed.</p>
        </div>

        <div class="alg-card">
            <h2>Settings</h2>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('adlg_theme_rss_save_settings'); ?><input type="hidden" name="action" value="adlg_theme_rss_save_settings">
                <table class="form-table" role="presentation">
                    <tr><th>Post status</th><td><select name="post_status"><option value="publish" <?php selected($settings['post_status'],'publish'); ?>>Publish immediately</option><option value="draft" <?php selected($settings['post_status'],'draft'); ?>>Draft</option><option value="pending" <?php selected($settings['post_status'],'pending'); ?>>Pending review</option></select></td></tr>
                    <tr><th>Items per source</th><td><input type="number" name="items_per_source" min="1" max="20" value="<?php echo esc_attr((string)$settings['items_per_source']); ?>"></td></tr>
                    <tr><th>Max posts per run</th><td><input type="number" name="max_posts_per_run" min="1" max="500" value="<?php echo esc_attr((string)$settings['max_posts_per_run']); ?>"></td></tr>
                    <tr><th>Excerpt length</th><td><input type="number" name="excerpt_words" min="20" max="200" value="<?php echo esc_attr((string)$settings['excerpt_words']); ?>"> words</td></tr>
                    <tr><th>Confidence threshold</th><td><input type="number" name="confidence_threshold" min="1" max="100" value="<?php echo esc_attr((string)$settings['confidence_threshold']); ?>"> %</td></tr>
                    <tr><th>Tags</th><td><label><input type="checkbox" name="add_tags" value="1" <?php checked($settings['add_tags'],1); ?>> Add source/category/topic tags</label></td></tr>
                    <tr><th>La Gaffe note</th><td><label><input type="checkbox" name="prepend_lagaffe_note" value="1" <?php checked($settings['prepend_lagaffe_note'],1); ?>> Add branded source note above imported excerpt</label></td></tr>
                </table>
                <?php submit_button('Save RSS Settings'); ?>
            </form>
        </div>

        <div class="alg-card">
            <h2>Add RSS Feed</h2>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('adlg_theme_rss_add_source'); ?><input type="hidden" name="action" value="adlg_theme_rss_add_source">
                <div class="alg-grid">
                    <p><label><strong>Name</strong><br><input type="text" name="source_name" class="widefat" placeholder="Example: Creative Careers Feed" required></label></p>
                    <p><label><strong>Group</strong><br><input type="text" name="source_group" class="widefat" placeholder="Dean Career Compass / Jobs"></label></p>
                    <p><label><strong>Feed URL</strong><br><input type="url" name="source_url" class="widefat" placeholder="https://example.com/feed/" required></label></p>
                    <p><label><strong>Default category</strong><br><input type="text" name="source_category" class="widefat" value="00 Dean La Gaffe — Career Compass"></label></p>
                </div>
                <p><label><input type="checkbox" name="source_enabled" value="1" checked> Enable immediately</label></p>
                <?php submit_button('Add RSS Feed'); ?>
            </form>
        </div>

        <div class="alg-card">
            <h2>Restore Built-In RSS Sources</h2>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('adlg_theme_rss_restore_sources'); ?><input type="hidden" name="action" value="adlg_theme_rss_restore_sources">
                <?php submit_button('Restore Built-In RSS Sources', 'secondary', 'submit', false); ?>
            </form>
        </div>

        <div class="alg-card">
            <h2>RSS Source Table</h2>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('adlg_theme_rss_save_sources'); ?><input type="hidden" name="action" value="adlg_theme_rss_save_sources">
                <table class="widefat striped">
                    <thead><tr><th>On</th><th>Name</th><th>Group</th><th>Feed URL</th><th>Default category</th></tr></thead>
                    <tbody>
                    <?php for ($i=0; $i<max(24, count($sources)+10); $i++): $s = isset($sources[$i]) ? $sources[$i] : array('enabled'=>0,'name'=>'','group'=>'','url'=>'','default_category'=>''); ?>
                        <tr>
                            <td><input type="checkbox" name="sources[<?php echo esc_attr((string)$i); ?>][enabled]" value="1" <?php checked(!empty($s['enabled']), true); ?>></td>
                            <td><input type="text" name="sources[<?php echo esc_attr((string)$i); ?>][name]" value="<?php echo esc_attr((string)($s['name'] ?? '')); ?>"></td>
                            <td><input type="text" name="sources[<?php echo esc_attr((string)$i); ?>][group]" value="<?php echo esc_attr((string)($s['group'] ?? '')); ?>"></td>
                            <td><input type="url" name="sources[<?php echo esc_attr((string)$i); ?>][url]" value="<?php echo esc_attr((string)($s['url'] ?? '')); ?>"></td>
                            <td><input type="text" name="sources[<?php echo esc_attr((string)$i); ?>][default_category]" value="<?php echo esc_attr((string)($s['default_category'] ?? '')); ?>"></td>
                        </tr>
                    <?php endfor; ?>
                    </tbody>
                </table>
                <?php submit_button('Save RSS Sources'); ?>
            </form>
        </div>

        <div class="alg-card"><h2>Recent log</h2><div class="alg-log"><?php if (!$log) { echo 'No log yet.'; } else { foreach (array_slice(array_reverse($log),0,80) as $entry) { echo esc_html($entry)."\n"; } } ?></div></div>
    </div>
    <?php
}

function adlg_theme_rss_handle_save_settings() {
    if (!current_user_can('manage_options') || !check_admin_referer('adlg_theme_rss_save_settings')) wp_die('Forbidden');
    $old = adlg_theme_rss_settings();
    $settings = array(
        'post_status' => in_array($_POST['post_status'] ?? 'publish', array('draft','pending','publish'), true) ? sanitize_key($_POST['post_status']) : 'publish',
        'items_per_source' => max(1, min(20, absint($_POST['items_per_source'] ?? $old['items_per_source']))),
        'max_posts_per_run' => max(1, min(500, absint($_POST['max_posts_per_run'] ?? $old['max_posts_per_run']))),
        'excerpt_words' => max(20, min(200, absint($_POST['excerpt_words'] ?? $old['excerpt_words']))),
        'confidence_threshold' => max(1, min(100, absint($_POST['confidence_threshold'] ?? $old['confidence_threshold']))),
        'add_tags' => isset($_POST['add_tags']) ? 1 : 0,
        'prepend_lagaffe_note' => isset($_POST['prepend_lagaffe_note']) ? 1 : 0,
        'taxonomy_mode' => $old['taxonomy_mode'] ?? 'hierarchy',
    );
    update_option(ADLG_RSS_OPTION_SETTINGS, $settings);
    adlg_theme_rss_notice_redirect('RSS settings saved.');
}
add_action('admin_post_adlg_theme_rss_save_settings', 'adlg_theme_rss_handle_save_settings');

function adlg_theme_rss_handle_save_sources() {
    if (!current_user_can('manage_options') || !check_admin_referer('adlg_theme_rss_save_sources')) wp_die('Forbidden');
    $clean = array();
    $rows = isset($_POST['sources']) && is_array($_POST['sources']) ? $_POST['sources'] : array();
    foreach ($rows as $row) {
        $name = sanitize_text_field($row['name'] ?? '');
        $url = esc_url_raw($row['url'] ?? '');
        if ($name === '' && $url === '') continue;
        $clean[] = array(
            'enabled' => !empty($row['enabled']) ? 1 : 0,
            'name' => $name,
            'group' => sanitize_text_field($row['group'] ?? ''),
            'url' => $url,
            'default_category' => sanitize_text_field($row['default_category'] ?? ''),
        );
    }
    update_option(ADLG_RSS_OPTION_SOURCES, $clean);
    adlg_theme_rss_notice_redirect('RSS sources saved.');
}
add_action('admin_post_adlg_theme_rss_save_sources', 'adlg_theme_rss_handle_save_sources');

function adlg_theme_rss_handle_add_source() {
    if (!current_user_can('manage_options') || !check_admin_referer('adlg_theme_rss_add_source')) wp_die('Forbidden');
    $name = sanitize_text_field($_POST['source_name'] ?? '');
    $url = esc_url_raw($_POST['source_url'] ?? '');
    if (!$name || !$url) adlg_theme_rss_notice_redirect('RSS source was not added: name and feed URL are required.');
    $sources = adlg_theme_rss_sources();
    $sources[] = array(
        'enabled' => !empty($_POST['source_enabled']) ? 1 : 0,
        'name' => $name,
        'group' => sanitize_text_field($_POST['source_group'] ?? ''),
        'url' => $url,
        'default_category' => sanitize_text_field($_POST['source_category'] ?? '00 Dean La Gaffe — Career Compass'),
    );
    update_option(ADLG_RSS_OPTION_SOURCES, $sources);
    adlg_theme_rss_notice_redirect('RSS feed added.');
}
add_action('admin_post_adlg_theme_rss_add_source', 'adlg_theme_rss_handle_add_source');

function adlg_theme_rss_handle_restore_sources() {
    if (!current_user_can('manage_options') || !check_admin_referer('adlg_theme_rss_restore_sources')) wp_die('Forbidden');
    if (class_exists('ALG_Official_Source_Auto_Poster') && method_exists('ALG_Official_Source_Auto_Poster', 'activate')) {
        ALG_Official_Source_Auto_Poster::activate();
        adlg_theme_rss_notice_redirect('Built-in RSS sources restored.');
    }
    adlg_theme_rss_notice_redirect('Importer class was not available. Reinstall or reactivate this theme, then try again.');
}
add_action('admin_post_adlg_theme_rss_restore_sources', 'adlg_theme_rss_handle_restore_sources');

function adlg_theme_rss_handle_fetch_now() {
    if (!current_user_can('manage_options') || !check_admin_referer('adlg_theme_rss_fetch_now')) wp_die('Forbidden');
    if (class_exists('ALG_Official_Source_Auto_Poster') && method_exists('ALG_Official_Source_Auto_Poster', 'instance')) {
        $plugin = ALG_Official_Source_Auto_Poster::instance();
        if (method_exists($plugin, 'daily_fetch')) {
            $count = $plugin->daily_fetch(true);
            adlg_theme_rss_notice_redirect('Auto Post Now complete. Created '.$count.' new post(s).');
        }
    }
    adlg_theme_rss_notice_redirect('Importer class was not available. Reinstall or reactivate this theme, then try again.');
}
add_action('admin_post_adlg_theme_rss_fetch_now', 'adlg_theme_rss_handle_fetch_now');
