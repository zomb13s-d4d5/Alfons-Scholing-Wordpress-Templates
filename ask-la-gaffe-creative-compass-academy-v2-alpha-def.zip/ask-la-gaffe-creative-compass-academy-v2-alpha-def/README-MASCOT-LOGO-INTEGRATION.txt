v2.2.0 Mascot logo integration

- Replaced the top-left header logo asset with a transparent face-only mascot logo based on the main Ask La Gaffe hero character.
- Preserved the one-line title lockup: Ask La Gaffe with Creative Compass Academy underneath.
- Added both WEBP and PNG logo assets for reliability.
- Based on the v2.1.9 logo-one-line theme build.
