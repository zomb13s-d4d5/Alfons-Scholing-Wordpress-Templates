v2.1.4 RSS limit update

- Items per source remains capped at 20.
- Max posts per run is now capped at 500 instead of 100.
- Default max posts per run is set to 500.
- Admin UI now allows 20 / 500 as requested.
