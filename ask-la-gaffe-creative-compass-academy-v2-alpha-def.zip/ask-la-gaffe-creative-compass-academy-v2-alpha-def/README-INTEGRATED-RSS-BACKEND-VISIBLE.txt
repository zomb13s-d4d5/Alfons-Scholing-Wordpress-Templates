v2.1.0 Integrated RSS backend visible

The RSS editor is integrated into the theme.

This build makes the theme-integrated backend visible as:
- WordPress Admin sidebar → La Gaffe RSS
- Tools → Auto Poster + RSS Feeds

It includes:
- Auto Post Now / Fetch RSS Now
- Add RSS Feed
- Restore Built-In RSS Sources
- Full editable RSS source table
- Publish/Draft/Pending controls
- Hourly auto-poster schedule
- Dean Career Compass feeds/category

Note:
If the old standalone RSS plugin is active, WordPress loads plugins before themes. The theme then steps aside to avoid a duplicate PHP class. For the theme-integrated backend to own the screen, deactivate the standalone plugin.
