<?php
get_header();
?>
<main class="entry page-entry guidance-page guidance-page--cheat-cards">
  <?php
  if (function_exists('lgu_render_ai_cheat_cards')) {
      echo lgu_render_ai_cheat_cards();
  } else {
      echo '<article class="panel panel-pad"><h1>AI Career Cheat Cards</h1><p>The guidance module is not loaded yet. Reinstall or reactivate the theme.</p></article>';
  }
  ?>
</main>
<?php get_footer(); ?>
