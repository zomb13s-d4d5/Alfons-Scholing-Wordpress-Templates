Ask La Gaffe — Creative Compass Academy v2 Alpha DEF — Dean Hero Slider Build

This build integrates the five new wide “La Gaffe explains” hero images as an automatic homepage slider.

What changed:
- Renamed visible brand in the header to “Ask La Gaffe”.
- Added five wide Dean-led hero slides:
  1. Welcome to your Creative Compass
  2. Meet the professors of the Academy
  3. Ask better questions with better words
  4. Free learning routes, gathered in one place
  5. Register, pick paths, build your inbox
- Added smooth automatic slider behavior with arrows, dots, hover/touch pause, and reduced-motion respect.
- Added the feature rail under the hero:
  - 22 Creative Paths
  - 1 Dean Guide
  - AI Compass Cards
  - Open Tutorial Feeds
  - Personal Academy OS
- Added an Open Tutorial Feeds page/shortcode so the hero CTA has a proper destination.
- Added cache-busting version v2.0.2-dean-hero.

Install as a standalone WordPress theme. If Safari/iPad shows the old hero, clear cache or refresh a few times after activation.
