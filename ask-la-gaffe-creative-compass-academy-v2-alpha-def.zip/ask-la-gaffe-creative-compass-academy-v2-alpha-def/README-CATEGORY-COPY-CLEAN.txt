Category copy clean pass:
- Removed structured maintainer/category prompt phrases from category descriptions.
- Official Source Auto Poster now creates audience-facing category descriptions without 'Purple edition', 'Core theme', 'Visual language', or 'Key props / symbols'.
- Theme category-copy filter now treats those phrases as stale technical copy and replaces them with visitor-friendly descriptions.
- Category copy polisher version bumped so descriptions are refreshed after install/admin load.
