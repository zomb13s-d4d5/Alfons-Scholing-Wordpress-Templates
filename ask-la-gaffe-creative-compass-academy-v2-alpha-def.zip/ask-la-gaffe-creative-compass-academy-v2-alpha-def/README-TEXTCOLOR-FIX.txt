Bright readable text fix only. Based on v3.1 fonts build. No layout/background overrides. Added Fredoka, Baloo 2, Nunito and readable white/pink text colors.
