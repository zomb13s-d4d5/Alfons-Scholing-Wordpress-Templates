v2.1.7 230 Cheat Cards

- Career Compass now has its own 10 Dean cards.
- Each of the 22 creative categories now has 10 professor cards.
- Total: 230 cards.
- Added jump navigation so all categories are visible and reachable.
- Added title-based page detection so existing pages with different slugs still render the deck.
