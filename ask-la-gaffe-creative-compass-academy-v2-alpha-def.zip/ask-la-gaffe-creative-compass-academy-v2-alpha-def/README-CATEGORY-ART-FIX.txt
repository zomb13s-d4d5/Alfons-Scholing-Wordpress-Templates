Category artwork mapping fix:
- Film & Video now uses the penguin explorer/camera studio image.
- Animation now uses the bunny drawing/character design studio image.
- Illustration & Painting now uses the bunny drawing/character design studio image.
Based on v3.1.3 LOGO75.
