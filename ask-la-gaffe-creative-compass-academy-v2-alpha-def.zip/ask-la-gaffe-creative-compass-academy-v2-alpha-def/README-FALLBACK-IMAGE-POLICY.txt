Ask La Gaffe v2.0.5 fallback image policy

- The universal/default fallback image is now the Grey Old Alien Dean.
- Posts inside one of the 22 academy profession categories use that category/profession poster as their fallback image.
- Category archive pages and inbox feeds keep using the matching profession image when no featured image exists.
- Uncategorized/general posts, pages, and unknown contexts fall back to the Dean.
