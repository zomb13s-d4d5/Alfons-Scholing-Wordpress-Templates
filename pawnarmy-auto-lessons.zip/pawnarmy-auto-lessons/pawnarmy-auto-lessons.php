<?php
/**
 * Plugin Name: PawnArmy Auto Lessons
 * Plugin URI: https://pawnarmy.com
 * Description: Auto-publishes daily professional PawnArmy chess tactics lessons in ELO blocks: Beginner, Medium, Professional, and Expert.
 * Version: 1.2.0
 * Author: NotYouAgain.ai / PawnArmy
 * License: GPLv2 or later
 * Text Domain: pawnarmy-auto-lessons
 */

if (!defined('ABSPATH')) {
    exit;
}

final class PawnArmy_Auto_Lessons {
    const VERSION = '1.2.0';
    const OPTION_KEY = 'pawnarmy_auto_lessons_settings';
    const CRON_HOOK = 'pawnarmy_auto_lessons_cron_generate';
    const CPT = 'pawnarmy_lesson';
    const QUEUE_PREFIX = 'pawnarmy_auto_lessons_queue_';
    const LAST_RUN = 'pawnarmy_auto_lessons_last_run';
    const LAST_ERROR = 'pawnarmy_auto_lessons_last_error';
    const ACTIVATION_SEEDED = 'pawnarmy_auto_lessons_activation_seeded_v120';
    const LAST_AUTO_DATE = 'pawnarmy_auto_lessons_last_auto_date';

    private static $instance = null;

    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('init', array($this, 'register_post_type'));
        add_action('init', array($this, 'register_shortcodes'));
        add_action('init', array($this, 'maybe_rescue_missing_schedule'), 20);
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'admin_assets'));
        add_action('admin_post_pawnarmy_generate_lesson', array($this, 'handle_generate_now'));
        add_action('admin_post_pawnarmy_reset_queue', array($this, 'handle_reset_queue'));
        add_action(self::CRON_HOOK, array($this, 'cron_generate'));
        add_filter('cron_schedules', array($this, 'cron_schedules'));
        add_action('update_option_' . self::OPTION_KEY, array($this, 'reschedule_after_settings_update'), 10, 3);
    }

    public static function activate() {
        $plugin = self::instance();

        // Migration/failsafe: older installed versions may have saved settings such as
        // weekly, draft, disabled, or the hidden custom post type. Force the bot into
        // the visible daily-publishing setup Alfons asked for.
        $existing = get_option(self::OPTION_KEY, array());
        $settings = wp_parse_args(is_array($existing) ? $existing : array(), $plugin->default_settings());
        $settings['enabled'] = '1';
        $settings['frequency'] = 'daily';
        $settings['post_status'] = 'publish';
        $settings['post_type'] = 'post';
        foreach (array('beginner','medium','professional','expert') as $level_key) {
            $settings['generate_' . $level_key] = '1';
        }
        update_option(self::OPTION_KEY, $settings, false);

        $plugin->register_post_type();
        flush_rewrite_rules();
        $plugin->schedule_cron(true);

        // Make the installation visibly work immediately: create one complete daily
        // set of normal WordPress posts the first time this fixed version is activated.
        if (!get_option(self::ACTIVATION_SEEDED)) {
            $result = $plugin->generate_daily_set(false);
            if (is_wp_error($result)) {
                update_option(self::LAST_ERROR, $result->get_error_message(), false);
            } else {
                update_option(self::ACTIVATION_SEEDED, current_time('mysql'), false);
                delete_option(self::LAST_ERROR);
            }
        }
    }

    public static function deactivate() {
        wp_clear_scheduled_hook(self::CRON_HOOK);
        flush_rewrite_rules();
    }

    public function register_post_type() {
        register_post_type(self::CPT, array(
            'labels' => array(
                'name' => __('PawnArmy Lessons', 'pawnarmy-auto-lessons'),
                'singular_name' => __('PawnArmy Lesson', 'pawnarmy-auto-lessons'),
                'add_new_item' => __('Add New PawnArmy Lesson', 'pawnarmy-auto-lessons'),
                'edit_item' => __('Edit PawnArmy Lesson', 'pawnarmy-auto-lessons'),
            ),
            'public' => true,
            'show_in_rest' => true,
            'menu_icon' => 'dashicons-games',
            'supports' => array('title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'comments', 'revisions'),
            'taxonomies' => array('category', 'post_tag'),
            'has_archive' => true,
            'rewrite' => array('slug' => 'lessons'),
        ));
    }

    public function register_shortcodes() {
        add_shortcode('pawnarmy_board', array($this, 'shortcode_board'));
    }

    public function admin_assets($hook) {
        if (strpos($hook, 'pawnarmy-auto-lessons') !== false) {
            wp_enqueue_style('pawnarmy-auto-lessons-admin', plugin_dir_url(__FILE__) . 'assets/admin.css', array(), self::VERSION);
        }
    }

    public function admin_menu() {
        add_menu_page(
            __('PawnArmy Bot', 'pawnarmy-auto-lessons'),
            __('PawnArmy Bot', 'pawnarmy-auto-lessons'),
            'manage_options',
            'pawnarmy-auto-lessons',
            array($this, 'render_admin_page'),
            'dashicons-games',
            58
        );
    }

    public function register_settings() {
        register_setting('pawnarmy_auto_lessons_group', self::OPTION_KEY, array($this, 'sanitize_settings'));
    }

    public function default_settings() {
        return array(
            'enabled' => '1',
            'frequency' => 'daily',
            'post_status' => 'publish',
            'category' => 'Chess Lessons',
            'author_id' => get_current_user_id() ?: 1,
            'mode' => 'template',
            'api_endpoint' => 'https://api.openai.com/v1/chat/completions',
            'api_key' => '',
            'api_model' => 'gpt-4o-mini',
            'brand_tagline' => 'Train the pawn. Build the army.',
            'publish_hour' => '09',
            'generate_beginner' => '1',
            'generate_medium' => '1',
            'generate_professional' => '1',
            'generate_expert' => '1',
            'human_review_note' => 'Original PawnArmy training content. Positions and tactics should be engine-checked during editorial QA.',
            'post_type' => 'post',
        );
    }

    public function get_settings() {
        return wp_parse_args(get_option(self::OPTION_KEY, array()), $this->default_settings());
    }

    public function sanitize_settings($input) {
        $defaults = $this->default_settings();
        $out = array();
        $out['enabled'] = !empty($input['enabled']) ? '1' : '0';
        $out['frequency'] = in_array(($input['frequency'] ?? 'daily'), array('daily', 'weekly', 'twiceweekly'), true) ? $input['frequency'] : 'daily';
        $out['post_status'] = in_array(($input['post_status'] ?? 'publish'), array('draft', 'publish', 'future'), true) ? $input['post_status'] : 'publish';
        $out['category'] = sanitize_text_field($input['category'] ?? $defaults['category']);
        $out['author_id'] = max(1, absint($input['author_id'] ?? $defaults['author_id']));
        $out['mode'] = in_array(($input['mode'] ?? 'template'), array('template', 'ai'), true) ? $input['mode'] : 'template';
        $out['api_endpoint'] = esc_url_raw($input['api_endpoint'] ?? $defaults['api_endpoint']);
        $out['api_key'] = sanitize_text_field($input['api_key'] ?? '');
        $out['api_model'] = sanitize_text_field($input['api_model'] ?? $defaults['api_model']);
        $out['brand_tagline'] = sanitize_text_field($input['brand_tagline'] ?? $defaults['brand_tagline']);
        $out['publish_hour'] = sprintf('%02d', min(23, max(0, absint($input['publish_hour'] ?? 9))));
        foreach (array('beginner','medium','professional','expert') as $level_key) {
            $out['generate_' . $level_key] = !empty($input['generate_' . $level_key]) ? '1' : '0';
        }
        $out['human_review_note'] = sanitize_textarea_field($input['human_review_note'] ?? $defaults['human_review_note']);
        $out['post_type'] = in_array(($input['post_type'] ?? 'post'), array('post', self::CPT), true) ? $input['post_type'] : 'post';
        return $out;
    }

    public function cron_schedules($schedules) {
        $schedules['pawnarmy_weekly'] = array('interval' => WEEK_IN_SECONDS, 'display' => __('Once Weekly', 'pawnarmy-auto-lessons'));
        $schedules['pawnarmy_twiceweekly'] = array('interval' => 3 * DAY_IN_SECONDS + 12 * HOUR_IN_SECONDS, 'display' => __('Twice Weekly', 'pawnarmy-auto-lessons'));
        return $schedules;
    }

    public function reschedule_after_settings_update($old_value, $value, $option) {
        $this->schedule_cron(true);
    }

    public function maybe_rescue_missing_schedule() {
        $settings = $this->get_settings();
        if ($settings['enabled'] === '1' && !wp_next_scheduled(self::CRON_HOOK)) {
            $this->schedule_cron(false);
        }
    }

    public function schedule_cron($force = false) {
        if ($force) {
            wp_clear_scheduled_hook(self::CRON_HOOK);
        }
        $settings = $this->get_settings();
        if ($settings['enabled'] !== '1') {
            return;
        }
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            $map = array('daily' => 'daily', 'weekly' => 'pawnarmy_weekly', 'twiceweekly' => 'pawnarmy_twiceweekly');
            $hour = absint($settings['publish_hour']);
            $timestamp = strtotime('today ' . $hour . ':00:00');
            if ($timestamp <= time()) {
                $timestamp = strtotime('tomorrow ' . $hour . ':00:00');
            }
            wp_schedule_event($timestamp, $map[$settings['frequency']] ?? 'daily', self::CRON_HOOK);
        }
    }

    private function level_blocks() {
        return array(
            'beginner' => array('label' => 'Beginner', 'elo' => '0-999', 'category' => 'Beginner ELO 0-999', 'tone' => 'clear fundamentals, pattern names, no notation overload'),
            'medium' => array('label' => 'Medium', 'elo' => '1000-1599', 'category' => 'Medium ELO 1000-1599', 'tone' => 'structured calculation, candidate moves, common defensive resources'),
            'professional' => array('label' => 'Professional', 'elo' => '1600-2199', 'category' => 'Professional ELO 1600-2199', 'tone' => 'tournament preparation, calculation discipline, strategic context'),
            'expert' => array('label' => 'Expert', 'elo' => '2200+', 'category' => 'Expert ELO 2200+', 'tone' => 'advanced forcing lines, prophylaxis, practical ambiguity, engine-verifiable detail'),
        );
    }

    private function enabled_level_keys($settings) {
        $keys = array();
        foreach (array_keys($this->level_blocks()) as $key) {
            if (($settings['generate_' . $key] ?? '1') === '1') {
                $keys[] = $key;
            }
        }
        return $keys ?: array('beginner', 'medium', 'professional', 'expert');
    }

    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $settings = $this->get_settings();
        $next = wp_next_scheduled(self::CRON_HOOK);
        $last_run = get_option(self::LAST_RUN, 'Never');
        $last_error = get_option(self::LAST_ERROR, '');
        $blocks = $this->level_blocks();
        ?>
        <div class="wrap pawnarmy-admin">
            <h1>PawnArmy Auto Lessons Bot</h1>
            <p class="pawnarmy-lead">Auto-publishes daily chess tactics lessons in four ELO blocks: Beginner, Medium, Professional, and Expert. Each post is original PawnArmy training content with FEN boards, tactical questions, academic training notes, and categorized ELO structure.</p>

            <div class="pawnarmy-grid">
                <div class="pawnarmy-card">
                    <h2>Generate today’s ELO block set now</h2>
                    <p>Creates one lesson for every enabled ELO block.</p>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <?php wp_nonce_field('pawnarmy_generate_lesson'); ?>
                        <input type="hidden" name="action" value="pawnarmy_generate_lesson">
                        <?php submit_button('Generate Daily Set Now', 'primary', 'submit', false); ?>
                    </form>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="pawnarmy-inline-form">
                        <?php wp_nonce_field('pawnarmy_reset_queue'); ?>
                        <input type="hidden" name="action" value="pawnarmy_reset_queue">
                        <?php submit_button('Reset All ELO Queues', 'secondary', 'submit', false); ?>
                    </form>
                    <p><strong>Next cron:</strong> <?php echo $next ? esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $next)) : 'Not scheduled'; ?></p>
                    <p><strong>Last run:</strong> <?php echo esc_html($last_run); ?></p>
                    <?php if (!empty($last_error)) : ?><p class="pawnarmy-error"><strong>Last error:</strong> <?php echo esc_html($last_error); ?></p><?php endif; ?>
                </div>

                <div class="pawnarmy-card pawnarmy-warning">
                    <h2>Auto-posting note</h2>
                    <p>This uses WordPress WP-Cron. It triggers when the site receives traffic. For exact daily publishing, add a real server cron hitting <code>wp-cron.php</code> every 5-15 minutes.</p>
                    <p>Default is now <strong>enabled, daily, publish</strong>. Switch to Draft when testing.</p>
                </div>
            </div>

            <form method="post" action="options.php" class="pawnarmy-settings-form">
                <?php settings_fields('pawnarmy_auto_lessons_group'); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row">Enable automation</th>
                        <td><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION_KEY); ?>[enabled]" value="1" <?php checked($settings['enabled'], '1'); ?>> Auto-generate on schedule</label></td>
                    </tr>
                    <tr>
                        <th scope="row">Frequency</th>
                        <td>
                            <select name="<?php echo esc_attr(self::OPTION_KEY); ?>[frequency]">
                                <option value="daily" <?php selected($settings['frequency'], 'daily'); ?>>Daily</option>
                                <option value="twiceweekly" <?php selected($settings['frequency'], 'twiceweekly'); ?>>Twice weekly</option>
                                <option value="weekly" <?php selected($settings['frequency'], 'weekly'); ?>>Weekly</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">ELO blocks to generate</th>
                        <td>
                            <?php foreach ($blocks as $key => $block) : ?>
                                <label class="pawnarmy-level-check"><input type="checkbox" name="<?php echo esc_attr(self::OPTION_KEY); ?>[generate_<?php echo esc_attr($key); ?>]" value="1" <?php checked($settings['generate_' . $key] ?? '1', '1'); ?>> <?php echo esc_html($block['label'] . ' — ELO ' . $block['elo']); ?></label><br>
                            <?php endforeach; ?>
                            <p class="description">Daily default: one post per enabled ELO block.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Generation mode</th>
                        <td>
                            <select name="<?php echo esc_attr(self::OPTION_KEY); ?>[mode]">
                                <option value="template" <?php selected($settings['mode'], 'template'); ?>>Template mode — no external AI</option>
                                <option value="ai" <?php selected($settings['mode'], 'ai'); ?>>AI-assisted mode</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Post status</th>
                        <td>
                            <select name="<?php echo esc_attr(self::OPTION_KEY); ?>[post_status]">
                                <option value="publish" <?php selected($settings['post_status'], 'publish'); ?>>Publish immediately</option>
                                <option value="future" <?php selected($settings['post_status'], 'future'); ?>>Schedule next day</option>
                                <option value="draft" <?php selected($settings['post_status'], 'draft'); ?>>Draft for human review</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Publish hour</th>
                        <td><input type="number" min="0" max="23" name="<?php echo esc_attr(self::OPTION_KEY); ?>[publish_hour]" value="<?php echo esc_attr($settings['publish_hour']); ?>"> <span class="description">Site timezone hour, 0-23.</span></td>
                    </tr>
                    <tr>
                        <th scope="row">Parent category</th>
                        <td><input type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[category]" value="<?php echo esc_attr($settings['category']); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row">Author user ID</th>
                        <td><input type="number" min="1" name="<?php echo esc_attr(self::OPTION_KEY); ?>[author_id]" value="<?php echo esc_attr($settings['author_id']); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row">Brand tagline</th>
                        <td><input type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[brand_tagline]" value="<?php echo esc_attr($settings['brand_tagline']); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row">AI endpoint</th>
                        <td><input type="url" class="large-text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[api_endpoint]" value="<?php echo esc_attr($settings['api_endpoint']); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row">AI model</th>
                        <td><input type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[api_model]" value="<?php echo esc_attr($settings['api_model']); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row">AI API key</th>
                        <td><input type="password" class="regular-text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[api_key]" value="<?php echo esc_attr($settings['api_key']); ?>" autocomplete="off"></td>
                    </tr>
                    <tr>
                        <th scope="row">Review note</th>
                        <td><textarea class="large-text" rows="3" name="<?php echo esc_attr(self::OPTION_KEY); ?>[human_review_note]"><?php echo esc_textarea($settings['human_review_note']); ?></textarea></td>
                    </tr>
                </table>
                <?php submit_button('Save Settings'); ?>
            </form>
        </div>
        <?php
    }

    public function handle_generate_now() {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        check_admin_referer('pawnarmy_generate_lesson');
        $result = $this->generate_daily_set(false);
        $redirect = admin_url('admin.php?page=pawnarmy-auto-lessons');
        if (is_wp_error($result)) {
            $redirect = add_query_arg(array('pawnarmy_error' => rawurlencode($result->get_error_message())), $redirect);
        } else {
            $redirect = add_query_arg(array('pawnarmy_created' => absint(count($result))), $redirect);
        }
        wp_safe_redirect($redirect);
        exit;
    }

    public function handle_reset_queue() {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        check_admin_referer('pawnarmy_reset_queue');
        foreach (array_keys($this->level_blocks()) as $key) {
            update_option(self::QUEUE_PREFIX . $key, 0, false);
        }
        wp_safe_redirect(admin_url('admin.php?page=pawnarmy-auto-lessons'));
        exit;
    }

    public function cron_generate() {
        $settings = $this->get_settings();
        if ($settings['enabled'] !== '1') {
            return;
        }

        // Prevent duplicate auto-post bursts when WP-Cron is triggered repeatedly.
        $today = current_time('Y-m-d');
        if (get_option(self::LAST_AUTO_DATE) === $today) {
            update_option(self::LAST_RUN, current_time('mysql') . ' / already generated today', false);
            return;
        }

        $result = $this->generate_daily_set(true);
        if (is_wp_error($result)) {
            update_option(self::LAST_RUN, current_time('mysql') . ' / error', false);
            update_option(self::LAST_ERROR, $result->get_error_message(), false);
        } else {
            update_option(self::LAST_AUTO_DATE, $today, false);
            update_option(self::LAST_RUN, current_time('mysql') . ' / auto-created ' . count($result) . ' normal post(s)', false);
            delete_option(self::LAST_ERROR);
        }
    }

    private function curriculum() {
        return array(
            'beginner' => array(
                array('id'=>'PA-B-001','track'=>'Tactics Fundamentals','theme'=>'The Loose Piece Drops Off','skill'=>'Undefended Piece Recognition','fen'=>'rnbqkbnr/pppppppp/8/8/8/4PN2/PPPP1PPP/RNBQKB1R b KQkq - 1 1','side'=>'Black','question'=>'Before choosing a move, which white piece or square needs attention?','answer'=>'Black should notice that early development creates targets and responsibilities. A beginner must first scan for undefended pieces before inventing attacks.','task'=>'In three of your games, circle every piece that is not protected. Then ask whether a check, capture, or threat attacks it.'),
                array('id'=>'PA-B-002','track'=>'Tactics Fundamentals','theme'=>'The Basic Pin','skill'=>'Pin Pattern','fen'=>'rnbqk2r/pppp1ppp/5n2/4p3/1b2P3/2N2N2/PPPP1PPP/R1BQKB1R w KQkq - 4 4','side'=>'White','question'=>'Which piece is pinned and why does that matter?','answer'=>'A pinned knight or piece cannot move freely when moving it exposes a more valuable piece behind it. Beginners should learn to name the line: attacker, pinned piece, target.','task'=>'Write attacker, pinned piece, and target for five pin positions.'),
                array('id'=>'PA-B-003','track'=>'Checkmates','theme'=>'Back Rank Safety','skill'=>'King Escape Squares','fen'=>'6k1/5ppp/8/8/8/8/5PPP/4R1K1 w - - 0 1','side'=>'White','question'=>'What back-rank weakness should White notice before checking?','answer'=>'A king boxed in by its own pawns can be mated or forced into passivity. Look for escape squares, rook checks, and whether defenders can interpose.','task'=>'Create one luft square in your next game before launching a rook attack.'),
                array('id'=>'PA-B-004','track'=>'Forks','theme'=>'Knight Fork Map','skill'=>'Knight Geometry','fen'=>'8/8/8/3k4/8/4N3/8/4K3 w - - 0 1','side'=>'White','question'=>'Which squares can the knight attack next, and which are fork targets?','answer'=>'A knight fork works because the knight attacks in an L-shape and cannot be blocked. Name all knight moves first; then identify valuable targets.','task'=>'Draw the eight knight destinations from e3 without moving the piece.'),
            ),
            'medium' => array(
                array('id'=>'PA-M-001','track'=>'Calculation','theme'=>'Checks, Captures, Threats','skill'=>'Candidate Move Order','fen'=>'r2q1rk1/ppp2ppp/2n2n2/3pp3/3PP3/2N2N2/PPP2PPP/R1BQ1RK1 w - - 0 7','side'=>'White','question'=>'What is the correct calculation order before selecting a quiet move?','answer'=>'Medium players must discipline the search: first checks, then captures, then direct threats, and only then positional improvements. This reduces tactical blindness.','task'=>'For this position, list three candidate moves and mark which are forcing.'),
                array('id'=>'PA-M-002','track'=>'Tactical Defense','theme'=>'Removing the Defender','skill'=>'Defender Identification','fen'=>'r1bq1rk1/ppp2ppp/2n2n2/3pp3/3PP3/2NB1N2/PPP2PPP/R1BQ1RK1 b - - 0 7','side'=>'Black','question'=>'Which defender protects the central structure, and can it be challenged?','answer'=>'A tactic often starts by identifying the defender, not the target. Medium training requires asking: what defends the target, can it be traded, pinned, overloaded, or deflected?','task'=>'Choose one defended pawn and name every defender and attacker.'),
                array('id'=>'PA-M-003','track'=>'Endgame Tactics','theme'=>'Outside Passed Pawn','skill'=>'Pawn Race Calculation','fen'=>'8/8/8/1P6/3k4/8/4K3/8 w - - 0 1','side'=>'White','question'=>'What must White calculate before pushing the pawn?','answer'=>'In pawn races, every tempo matters. Count king routes, promotion squares, and whether the defending king is inside the square of the pawn.','task'=>'Calculate the pawn square and explain whether Black can catch the b-pawn.'),
                array('id'=>'PA-M-004','track'=>'Attack Building','theme'=>'Open File Entry','skill'=>'Rook Invasion','fen'=>'2r2rk1/pp3ppp/4pn2/3p4/3P4/2P1PN2/PP3PPP/2R2RK1 w - - 0 16','side'=>'White','question'=>'Which file should White contest, and what is the invasion square?','answer'=>'The open c-file is the tactical highway. Medium players should not just occupy an open file; they should name the entry square and the target behind it.','task'=>'Write a two-move plan to improve the rook without allowing counterplay.'),
            ),
            'professional' => array(
                array('id'=>'PA-P-001','track'=>'Tournament Tactics','theme'=>'Candidate Moves Under Pressure','skill'=>'Calculation Protocol','fen'=>'r1bq1rk1/ppp2ppp/2n2n2/3pp3/3PP3/2N2N2/PPP2PPP/R1BQ1RK1 w - - 0 7','side'=>'White','question'=>'How should White build a professional candidate list?','answer'=>'A professional candidate list is not a guess list. It separates forcing moves, strategic stabilizers, and practical surprise moves, then compares them by risk and resulting structure.','task'=>'Produce a three-column candidate table: forcing, improving, prophylactic.'),
                array('id'=>'PA-P-002','track'=>'Strategic Tactics','theme'=>'Isolated Queen Pawn Initiative','skill'=>'Dynamic Compensation','fen'=>'r2q1rk1/pp2bppp/2n1pn2/3p4/3P4/2NBPN2/PP3PPP/R1BQ1RK1 w - - 0 9','side'=>'White','question'=>'What tactical justification does the IQP side need?','answer'=>'The IQP side must convert temporary activity into concrete threats: open files, piece pressure, kingside chances, and central breaks before the pawn becomes an endgame liability.','task'=>'Name one central break and one piece transfer that increases pressure.'),
                array('id'=>'PA-P-003','track'=>'Practical Defense','theme'=>'Prophylaxis Before Attack','skill'=>'Opponent Threat Audit','fen'=>'r4rk1/pp2qppp/2n1pn2/3p4/3P4/2NBPN2/PPQ2PPP/R4RK1 w - - 0 13','side'=>'White','question'=>'What must White ask before beginning an attack?','answer'=>'Professional attack begins with defensive literacy. Ask what the opponent threatens, which counter-sacrifices exist, and whether your king or back rank is tactically exposed.','task'=>'List Black’s next two threats before writing White’s plan.'),
                array('id'=>'PA-P-004','track'=>'Conversion','theme'=>'Technical Advantage Without Drama','skill'=>'Risk Reduction','fen'=>'8/5pk1/6p1/8/3P4/4K3/5PPP/8 w - - 0 1','side'=>'White','question'=>'How should White convert a small endgame edge?','answer'=>'Professional conversion means reducing counterplay first. Improve the king, fix weaknesses, create zugzwang chances, and only then cash in material or pawn breaks.','task'=>'Write a no-risk plan in three stages: improve, restrict, convert.'),
            ),
            'expert' => array(
                array('id'=>'PA-E-001','track'=>'Advanced Calculation','theme'=>'Forcing Lines With Quiet Moves','skill'=>'Zwischenzug Awareness','fen'=>'r2q1rk1/ppp2ppp/2n2n2/3pp3/3PP3/2N1BN2/PPP2PPP/R2Q1RK1 w - - 0 8','side'=>'White','question'=>'What quiet move or zwischenzug changes the tactical order?','answer'=>'Expert calculation includes non-obvious forcing quiet moves: threats that do not check or capture immediately but change the opponent’s legal defensive set.','task'=>'Calculate one line that starts with a quiet threat and compare it with an immediate capture.'),
                array('id'=>'PA-E-002','track'=>'Prophylaxis','theme'=>'Overprotection and Latent Breaks','skill'=>'Nimzowitsch-Style Control','fen'=>'r4rk1/pp2qppp/2n1pn2/3p4/3P4/2NBPN2/PPQ2PPP/R4RK1 b - - 0 13','side'=>'Black','question'=>'Which central break or piece reroute should Black restrain before it appears?','answer'=>'Expert prophylaxis fights ideas before they become moves. Identify the opponent’s latent pawn break, overprotect the critical square, and preserve tactical flexibility.','task'=>'Name the critical square and the piece that should overprotect it.'),
                array('id'=>'PA-E-003','track'=>'Endgame Precision','theme'=>'Triangulation and Zugzwang','skill'=>'Tempo Manipulation','fen'=>'8/8/8/3k4/3P4/4K3/8/8 w - - 0 1','side'=>'White','question'=>'Can White use move order to put Black in zugzwang?','answer'=>'Expert pawn endings require exact tempo control. The same structure can be won, drawn, or lost depending on opposition, triangulation, and reserve pawn tempi.','task'=>'Map the kings’ opposition squares and mark the triangulation route.'),
                array('id'=>'PA-E-004','track'=>'Opening-To-Middlegame Tactics','theme'=>'Engine-Checkable Novelty Discipline','skill'=>'Preparation Quality','fen'=>'rnbqk2r/ppp2ppp/5n2/3pp3/1b2P3/2N2N2/PPPP1PPP/R1BQKB1R w KQkq - 4 5','side'=>'White','question'=>'How do you test whether a prepared tactical idea is real?','answer'=>'Expert preparation separates inspiration from verification. Check move-order transpositions, defensive resources, engine refutations, and whether the idea survives against multiple legal replies.','task'=>'Create a mini-file: idea move, best reply, second-best reply, and resulting evaluation notes.'),
            ),
        );
    }

    private function get_next_curriculum_item($level_key) {
        $items_by_level = $this->curriculum();
        $items = $items_by_level[$level_key] ?? array();
        if (empty($items)) {
            return null;
        }
        $index = absint(get_option(self::QUEUE_PREFIX . $level_key, 0));
        if ($index >= count($items)) {
            $index = 0;
        }
        $item = $items[$index];
        update_option(self::QUEUE_PREFIX . $level_key, $index + 1, false);
        return $item;
    }

    private function generate_daily_set($from_cron = false) {
        $settings = $this->get_settings();
        $created = array();
        foreach ($this->enabled_level_keys($settings) as $level_key) {
            $post_id = $this->generate_lesson_post($level_key, $from_cron);
            if (is_wp_error($post_id)) {
                return $post_id;
            }
            $created[] = $post_id;
        }
        update_option(self::LAST_RUN, current_time('mysql') . ' / created ' . count($created) . ' lesson(s)', false);
        return $created;
    }

    private function generate_lesson_post($level_key, $from_cron = false) {
        $settings = $this->get_settings();
        $blocks = $this->level_blocks();
        $block = $blocks[$level_key] ?? $blocks['beginner'];
        $item = $this->get_next_curriculum_item($level_key);
        if (!$item) {
            return new WP_Error('pawnarmy_no_curriculum', 'No curriculum items found for ' . $level_key);
        }
        $title = $block['label'] . ' ELO ' . $block['elo'] . ' — ' . $item['id'] . ': ' . $item['theme'];
        $content = ($settings['mode'] === 'ai' && !empty($settings['api_key']))
            ? $this->generate_ai_content($item, $settings, $block)
            : $this->generate_template_content($item, $settings, $block);
        if (is_wp_error($content)) {
            $content = $this->generate_template_content($item, $settings, $block);
        }

        $cat_ids = $this->ensure_lesson_categories($settings['category'], $block['category']);
        $status = $settings['post_status'];
        $post_date = current_time('mysql');
        if ($status === 'future') {
            $post_date = date('Y-m-d H:i:s', strtotime('+1 day ' . absint($settings['publish_hour']) . ':00:00'));
        }

        $post_id = wp_insert_post(array(
            'post_title' => $title,
            'post_content' => $content,
            'post_excerpt' => wp_trim_words(wp_strip_all_tags($block['label'] . ' ELO ' . $block['elo'] . '. ' . $item['question']), 36),
            'post_status' => $status,
            'post_type' => ($settings['post_type'] ?? 'post') === 'post' ? 'post' : self::CPT,
            'post_author' => absint($settings['author_id']),
            'post_date' => $post_date,
            'comment_status' => 'open',
        ), true);

        if (is_wp_error($post_id)) {
            return $post_id;
        }

        if (!empty($cat_ids)) {
            wp_set_object_terms($post_id, array_map('absint', $cat_ids), 'category', false);
        }
        wp_set_object_terms($post_id, array('chess tactics', 'pawnarmy', strtolower($block['label']), 'elo-' . sanitize_title($block['elo'])), 'post_tag', false);

        update_post_meta($post_id, '_pawnarmy_lesson_id', $item['id']);
        update_post_meta($post_id, '_pawnarmy_level', $block['label']);
        update_post_meta($post_id, '_pawnarmy_elo_block', $block['elo']);
        update_post_meta($post_id, '_pawnarmy_track', $item['track']);
        update_post_meta($post_id, '_pawnarmy_skill', $item['skill']);
        update_post_meta($post_id, '_pawnarmy_fen', $item['fen']);
        update_post_meta($post_id, '_pawnarmy_copyright_status', 'Original PawnArmy content / public chess data only');
        update_post_meta($post_id, '_pawnarmy_generated_at', current_time('mysql'));
        update_post_meta($post_id, '_pawnarmy_from_cron', $from_cron ? '1' : '0');

        return $post_id;
    }

    private function generate_template_content($item, $settings, $block) {
        $fen_shortcode = '[pawnarmy_board fen="' . esc_attr($item['fen']) . '"]';
        $tagline = esc_html($settings['brand_tagline']);
        $review = esc_html($settings['human_review_note']);

        return "<!-- wp:group {\"className\":\"pawnarmy-lesson pawnarmy-elo-" . esc_attr(sanitize_title($block['label'])) . "\"} -->\n<div class=\"wp-block-group pawnarmy-lesson pawnarmy-elo-" . esc_attr(sanitize_title($block['label'])) . "\">\n" .
            "<!-- wp:paragraph {\"className\":\"pawnarmy-meta\"} --><p class=\"pawnarmy-meta\"><strong>ELO block:</strong> " . esc_html($block['label']) . " / " . esc_html($block['elo']) . " · <strong>Track:</strong> " . esc_html($item['track']) . " · <strong>Skill:</strong> " . esc_html($item['skill']) . "</p><!-- /wp:paragraph -->\n" .
            "<!-- wp:heading {\"level\":2} --><h2>Academic training objective</h2><!-- /wp:heading -->\n" .
            "<!-- wp:paragraph --><p>This lesson trains <strong>" . esc_html($item['theme']) . "</strong> at " . esc_html($block['label']) . " level. The teaching frame is " . esc_html($block['tone']) . ". The goal is not casual puzzle guessing: the goal is a repeatable decision method.</p><!-- /wp:paragraph -->\n" .
            "<!-- wp:shortcode -->" . $fen_shortcode . "<!-- /wp:shortcode -->\n" .
            "<!-- wp:heading {\"level\":2} --><h2>Position task</h2><!-- /wp:heading -->\n" .
            "<!-- wp:paragraph --><p><strong>" . esc_html($item['side']) . " to think:</strong> " . esc_html($item['question']) . "</p><!-- /wp:paragraph -->\n" .
            "<!-- wp:heading {\"level\":2} --><h2>Method</h2><!-- /wp:heading -->\n" .
            "<!-- wp:list --><ul><li>Identify king safety, loose pieces, and forcing moves.</li><li>List candidate moves before calculating.</li><li>Calculate checks, captures, and threats before quiet improvements.</li><li>Write the reason for the move in one sentence.</li></ul><!-- /wp:list -->\n" .
            "<!-- wp:heading {\"level\":2} --><h2>Solution and professional explanation</h2><!-- /wp:heading -->\n" .
            "<!-- wp:paragraph --><p>" . esc_html($item['answer']) . "</p><!-- /wp:paragraph -->\n" .
            "<!-- wp:heading {\"level\":2} --><h2>PawnArmy drill</h2><!-- /wp:heading -->\n" .
            "<!-- wp:paragraph --><p>" . esc_html($item['task']) . "</p><!-- /wp:paragraph -->\n" .
            "<!-- wp:heading {\"level\":2} --><h2>Evaluation rubric</h2><!-- /wp:heading -->\n" .
            "<!-- wp:list --><ul><li><strong>Correct tactic:</strong> the move solves the immediate position.</li><li><strong>Correct explanation:</strong> the move names the tactical motif and target.</li><li><strong>Correct discipline:</strong> the line checks opponent replies, not only your own idea.</li></ul><!-- /wp:list -->\n" .
            "<!-- wp:separator --><hr class=\"wp-block-separator has-alpha-channel-opacity\"/><!-- /wp:separator -->\n" .
            "<!-- wp:paragraph {\"className\":\"pawnarmy-tagline\"} --><p class=\"pawnarmy-tagline\"><strong>" . $tagline . "</strong></p><!-- /wp:paragraph -->\n" .
            "<!-- wp:paragraph {\"className\":\"pawnarmy-review-note\"} --><p class=\"pawnarmy-review-note\"><em>Editor note:</em> " . $review . "</p><!-- /wp:paragraph -->\n" .
            "</div>\n<!-- /wp:group -->";
    }

    private function generate_ai_content($item, $settings, $block) {
        $prompt = "Write an original PawnArmy.com chess tactics lesson for the ELO block " . $block['label'] . " " . $block['elo'] . ". Use an academic but readable training style. Do not copy any paid course, book, trainer handout, or copyrighted annotation. Use only the supplied chess data and create fresh explanation. Return WordPress-ready HTML with h2 headings: Academic training objective, Position task, Method, Solution and professional explanation, PawnArmy drill, Evaluation rubric. Data: " . wp_json_encode(array('block'=>$block,'item'=>$item));
        $body = array(
            'model' => $settings['api_model'],
            'messages' => array(
                array('role' => 'system', 'content' => 'You are a professional chess trainer writing original lessons for PawnArmy. Never claim official certification, never copy existing course material, and keep lines verifiable.'),
                array('role' => 'user', 'content' => $prompt),
            ),
            'temperature' => 0.55,
        );
        $response = wp_remote_post($settings['api_endpoint'], array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $settings['api_key'],
            ),
            'timeout' => 45,
            'body' => wp_json_encode($body),
        ));
        if (is_wp_error($response)) {
            return $response;
        }
        $code = wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            return new WP_Error('pawnarmy_ai_error', 'AI endpoint returned HTTP ' . $code);
        }
        $json = json_decode(wp_remote_retrieve_body($response), true);
        $text = $json['choices'][0]['message']['content'] ?? '';
        if (empty($text)) {
            return new WP_Error('pawnarmy_ai_empty', 'AI endpoint returned no content.');
        }
        $board = '[pawnarmy_board fen="' . esc_attr($item['fen']) . '"]';
        $safe = wp_kses_post($text);
        return "<!-- wp:shortcode -->" . $board . "<!-- /wp:shortcode -->\n" . $safe . "\n<p class=\"pawnarmy-review-note\"><em>Editor note:</em> " . esc_html($settings['human_review_note']) . "</p>";
    }

    private function ensure_lesson_categories($parent_name, $child_name) {
        $parent_id = $this->ensure_category($parent_name, 0);
        $child_id = $this->ensure_category($child_name, $parent_id);
        return array_filter(array($parent_id, $child_id));
    }

    private function ensure_category($name, $parent = 0) {
        $existing = term_exists($name, 'category', $parent);
        if (!$existing) {
            $existing = wp_insert_term($name, 'category', array('parent' => absint($parent)));
        }
        if (is_wp_error($existing)) {
            return 0;
        }
        return is_array($existing) ? absint($existing['term_id']) : absint($existing);
    }

    public function shortcode_board($atts) {
        $atts = shortcode_atts(array('fen' => ''), $atts, 'pawnarmy_board');
        $fen = sanitize_text_field($atts['fen']);
        if (empty($fen)) {
            return '';
        }
        $placement = explode(' ', $fen)[0];
        $ranks = explode('/', $placement);
        if (count($ranks) !== 8) {
            return '<p class="pawnarmy-board-error">Invalid FEN.</p>';
        }
        $pieces = array(
            'K'=>'♔','Q'=>'♕','R'=>'♖','B'=>'♗','N'=>'♘','P'=>'♙',
            'k'=>'♚','q'=>'♛','r'=>'♜','b'=>'♝','n'=>'♞','p'=>'♟',
        );
        $html = '<div class="pawnarmy-board" role="img" aria-label="Chess position ' . esc_attr($fen) . '">';
        foreach ($ranks as $rank_index => $rank) {
            $file = 0;
            for ($i = 0; $i < strlen($rank); $i++) {
                $char = $rank[$i];
                if (is_numeric($char)) {
                    $empty = absint($char);
                    for ($j = 0; $j < $empty; $j++) {
                        $color = (($rank_index + $file) % 2 === 0) ? 'light' : 'dark';
                        $html .= '<span class="sq ' . $color . '"></span>';
                        $file++;
                    }
                } else {
                    $color = (($rank_index + $file) % 2 === 0) ? 'light' : 'dark';
                    $html .= '<span class="sq ' . $color . '">' . esc_html($pieces[$char] ?? '') . '</span>';
                    $file++;
                }
            }
        }
        $html .= '</div>';
        $html .= '<style>.pawnarmy-board{display:grid;grid-template-columns:repeat(8,minmax(32px,56px));width:max-content;max-width:100%;border:3px solid #111;margin:1.25rem 0}.pawnarmy-board .sq{aspect-ratio:1/1;display:flex;align-items:center;justify-content:center;font-size:clamp(22px,5vw,40px);line-height:1}.pawnarmy-board .light{background:#f7f7f7;color:#111}.pawnarmy-board .dark{background:#111;color:#f7f7f7}.pawnarmy-meta,.pawnarmy-tagline{letter-spacing:.02em}.pawnarmy-review-note{font-size:.9rem;opacity:.75}</style>';
        return $html;
    }
}

PawnArmy_Auto_Lessons::instance();
register_activation_hook(__FILE__, array('PawnArmy_Auto_Lessons', 'activate'));
register_deactivation_hook(__FILE__, array('PawnArmy_Auto_Lessons', 'deactivate'));
