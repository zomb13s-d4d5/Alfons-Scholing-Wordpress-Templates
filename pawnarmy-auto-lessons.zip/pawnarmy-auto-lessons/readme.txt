=== PawnArmy Auto Lessons ===
Contributors: notyouagain, pawnarmy
Tags: chess, tactics, lessons, automation, elo, custom post type
Requires at least: 6.0
Tested up to: 6.7
Stable tag: 1.1.0
License: GPLv2 or later

Auto-publishes daily professional PawnArmy chess tactics lessons by ELO block: Beginner, Medium, Professional, and Expert.

== What changed in 1.1.0 ==
* Defaults changed to enabled, daily, and publish so the bot actually auto-posts.
* A daily run now creates one lesson for every enabled ELO block.
* Added ELO categories:
  * Beginner ELO 0-999
  * Medium ELO 1000-1599
  * Professional ELO 1600-2199
  * Expert ELO 2200+
* Fixed category assignment for the custom post type.
* Added queue tracking per ELO block.
* Added schedule rescue when WP-Cron exists but the event is missing.
* Added last-run and last-error visibility in the admin page.

== Installation ==
1. Upload the ZIP through Plugins > Add New > Upload Plugin.
2. Activate PawnArmy Auto Lessons.
3. Go to PawnArmy Bot in the WordPress admin.
4. Confirm Enable automation is checked, Frequency is Daily, and Post status is Publish.
5. Click Generate Daily Set Now once to test.

== Important cron note ==
This plugin uses WordPress WP-Cron. WP-Cron only runs when the site receives traffic. For exact daily publishing, configure a real server cron to hit wp-cron.php every 5-15 minutes.

== Copyright safety ==
This plugin is designed for original content. Do not paste paid course content, trainer notes, book text, or copyrighted annotations into AI prompts.
