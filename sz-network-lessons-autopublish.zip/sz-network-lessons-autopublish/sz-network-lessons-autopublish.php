<?php
/**
 * Plugin Name: SZ Network Lessons Autopublish (Stable Minimal)
 * Description: Robust, minimal RSS importer for the NYA network. Designed to keep working even when some feeds fail.
 * Version: 2.0.1
 * Author: NotYouAgain.ai + Assistant
 * License: GPLv2 or later
 * Text Domain: sz-nlap
 */

if (!defined('ABSPATH')) { exit; }

class SZ_NLAP_Stable {

    const OPTION_FEEDS = 'sz_nlap_feeds_v2';
    const OPTION_SETTINGS = 'sz_nlap_settings_v2';
    const OPTION_LAST_RUN = 'sz_nlap_last_run_v2';
    const CRON_HOOK = 'sz_nlap_cron_run_v2';

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'admin_menu']);
        add_action('admin_init', [__CLASS__, 'admin_init']);

        add_filter('cron_schedules', [__CLASS__, 'add_cron_schedule']);
        add_action(self::CRON_HOOK, [__CLASS__, 'cron_run']);

        register_activation_hook(__FILE__, [__CLASS__, 'activate']);
        register_deactivation_hook(__FILE__, [__CLASS__, 'deactivate']);
    }

    public static function default_feeds() {
        // Light & Shadow is kept but DISABLED by default.
        return [
            [
                'key' => 'odd',
                'name' => 'Open Democratic Debate',
                'url' => 'https://opendemocraticdebate.eu/feed/',
                'enabled' => 1,
                'category_slug' => 'odd',
                'fail_count' => 0,
                'last_error' => ''
            ],
            [
                'key' => 'alg',
                'name' => 'Ask La Gaffe',
                'url' => 'https://asklagaffe.com/feed/',
                'enabled' => 1,
                'category_slug' => 'alg',
                'fail_count' => 0,
                'last_error' => ''
            ],
            [
                'key' => 'osad',
                'name' => 'One Snack A Day',
                'url' => 'https://onesnackaday.com/feed/',
                'enabled' => 1,
                'category_slug' => 'osad',
                'fail_count' => 0,
                'last_error' => ''
            ],
            [
                'key' => 'pa',
                'name' => 'Pawn Army',
                'url' => 'https://pawnarmy.com/feed/',
                'enabled' => 1,
                'category_slug' => 'pa',
                'fail_count' => 0,
                'last_error' => ''
            ],
            [
                'key' => 'lasg',
                'name' => 'Light & Shadow Go School',
                'url' => 'https://lightandshadowgame.com/feed/',
                'enabled' => 0,
                'category_slug' => 'lasg',
                'fail_count' => 0,
                'last_error' => ''
            ],
            [
                'key' => 'mm',
                'name' => 'Mini Mensa',
                'url' => 'https://minimensa.com/feed/',
                'enabled' => 1,
                'category_slug' => 'mm',
                'fail_count' => 0,
                'last_error' => ''
            ],
            [
                'key' => 'ku',
                'name' => '074KU Programming',
                'url' => 'https://www.074ku.eu/feed/',
                'enabled' => 1,
                'category_slug' => 'ku',
                'fail_count' => 0,
                'last_error' => ''
            ],
        ];
    }

    public static function default_settings() {
        return [
            'interval' => 'sz_nlap_15min',
            'post_status' => 'publish',
            'author_id' => 0, // 0 means "auto"
            'max_items_per_feed' => 5,
            'auto_disable_after_failures' => 3,
            'debug_log' => 0,
            'relax_ssl' => 1, // helps on hosts with broken CA bundles
        ];
    }

    public static function activate() {
        if (!get_option(self::OPTION_FEEDS)) {
            add_option(self::OPTION_FEEDS, self::default_feeds());
        }
        if (!get_option(self::OPTION_SETTINGS)) {
            add_option(self::OPTION_SETTINGS, self::default_settings());
        }

        self::ensure_categories();
        self::schedule_event();
    }

    public static function deactivate() {
        wp_clear_scheduled_hook(self::CRON_HOOK);
    }

    public static function add_cron_schedule($schedules) {
        if (!isset($schedules['sz_nlap_15min'])) {
            $schedules['sz_nlap_15min'] = [
                'interval' => 15 * 60,
                'display'  => __('Every 15 Minutes (SZ NLAP)', 'sz-nlap')
            ];
        }
        return $schedules;
    }

    private static function schedule_event() {
        $settings = self::get_settings();
        $interval = isset($settings['interval']) ? $settings['interval'] : 'sz_nlap_15min';

        wp_clear_scheduled_hook(self::CRON_HOOK);

        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + 60, $interval, self::CRON_HOOK);
        }
    }

    public static function admin_init() {
        // Handle Run Now action
        if (is_admin() && isset($_POST['sz_nlap_run_now'])) {
            check_admin_referer('sz_nlap_run_now_action', 'sz_nlap_run_now_nonce');
            $result = self::run_import(true);
            update_option(self::OPTION_LAST_RUN, $result);
            add_action('admin_notices', function() use ($result) {
                $msg = sprintf(
                    'SZ NLAP ran: %d imported, %d skipped, %d errors.',
                    intval($result['imported']),
                    intval($result['skipped']),
                    intval($result['errors'])
                );
                echo '<div class="notice notice-success"><p>'.esc_html($msg).'</p></div>';
            });
        }

        // Handle Save settings
        if (is_admin() && isset($_POST['sz_nlap_save_settings'])) {
            check_admin_referer('sz_nlap_save_settings_action', 'sz_nlap_save_settings_nonce');

            $feeds = self::sanitize_feeds($_POST['sz_nlap_feeds'] ?? []);
            $settings = self::sanitize_settings($_POST['sz_nlap_settings'] ?? []);

            update_option(self::OPTION_FEEDS, $feeds);
            update_option(self::OPTION_SETTINGS, $settings);

            self::ensure_categories();
            self::schedule_event();

            add_action('admin_notices', function() {
                echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
            });
        }
    }

    public static function admin_menu() {
        add_options_page(
            'SZ Network Lessons Autopublish',
            'SZ Lessons Autopublish',
            'manage_options',
            'sz-nlap',
            [__CLASS__, 'render_settings_page']
        );
    }

    public static function render_settings_page() {
        if (!current_user_can('manage_options')) { return; }

        $feeds = self::get_feeds();
        $settings = self::get_settings();
        $last = get_option(self::OPTION_LAST_RUN);

        ?>
        <div class="wrap">
            <h1>SZ Network Lessons Autopublish (Stable Minimal)</h1>
            <p>This build removes fragile logic and focuses on reliable feed import. Broken feeds won’t stop the batch.</p>

            <?php if (defined('WP_HTTP_BLOCK_EXTERNAL') && WP_HTTP_BLOCK_EXTERNAL) : ?>
                <div class="notice notice-warning">
                    <p><strong>Note:</strong> WP_HTTP_BLOCK_EXTERNAL appears enabled on this site. This plugin will attempt to allow only the configured feed hosts during runs.</p>
                </div>
            <?php endif; ?>

            <h2>Run</h2>
            <form method="post">
                <?php wp_nonce_field('sz_nlap_run_now_action', 'sz_nlap_run_now_nonce'); ?>
                <p><input type="submit" class="button button-primary" name="sz_nlap_run_now" value="Run Now"></p>
            </form>

            <?php if (is_array($last)) : ?>
                <div style="margin:12px 0; padding:10px 12px; background:#fff; border:1px solid #ccd0d4;">
                    <strong>Last run</strong><br>
                    Time: <?php echo esc_html($last['time'] ?? ''); ?><br>
                    Imported: <?php echo esc_html(intval($last['imported'] ?? 0)); ?> |
                    Skipped: <?php echo esc_html(intval($last['skipped'] ?? 0)); ?> |
                    Errors: <?php echo esc_html(intval($last['errors'] ?? 0)); ?>
                </div>
            <?php endif; ?>

            <h2>Feeds</h2>
            <form method="post">
                <?php wp_nonce_field('sz_nlap_save_settings_action', 'sz_nlap_save_settings_nonce'); ?>

                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th>Enable</th>
                            <th>Key</th>
                            <th>Name</th>
                            <th>Feed URL</th>
                            <th>Category Slug</th>
                            <th>Fail Count</th>
                            <th>Last Error</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($feeds as $i => $f): ?>
                        <tr>
                            <td>
                                <input type="checkbox" name="sz_nlap_feeds[<?php echo esc_attr($i); ?>][enabled]" value="1" <?php checked(!empty($f['enabled'])); ?>>
                            </td>
                            <td>
                                <input type="text" name="sz_nlap_feeds[<?php echo esc_attr($i); ?>][key]" value="<?php echo esc_attr($f['key'] ?? ''); ?>" style="width:80px;">
                            </td>
                            <td>
                                <input type="text" name="sz_nlap_feeds[<?php echo esc_attr($i); ?>][name]" value="<?php echo esc_attr($f['name'] ?? ''); ?>" style="width:220px;">
                            </td>
                            <td>
                                <input type="url" name="sz_nlap_feeds[<?php echo esc_attr($i); ?>][url]" value="<?php echo esc_attr($f['url'] ?? ''); ?>" style="width:100%;">
                            </td>
                            <td>
                                <input type="text" name="sz_nlap_feeds[<?php echo esc_attr($i); ?>][category_slug]" value="<?php echo esc_attr($f['category_slug'] ?? ''); ?>" style="width:120px;">
                            </td>
                            <td>
                                <?php echo esc_html(intval($f['fail_count'] ?? 0)); ?>
                                <input type="hidden" name="sz_nlap_feeds[<?php echo esc_attr($i); ?>][fail_count]" value="<?php echo esc_attr(intval($f['fail_count'] ?? 0)); ?>">
                            </td>
                            <td>
                                <input type="text" name="sz_nlap_feeds[<?php echo esc_attr($i); ?>][last_error]" value="<?php echo esc_attr($f['last_error'] ?? ''); ?>" style="width:100%;" readonly>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>

                <h2>Importer Settings</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">Interval</th>
                        <td>
                            <select name="sz_nlap_settings[interval]">
                                <option value="sz_nlap_15min" <?php selected(($settings['interval'] ?? '') === 'sz_nlap_15min'); ?>>Every 15 minutes</option>
                                <option value="hourly" <?php selected(($settings['interval'] ?? '') === 'hourly'); ?>>Hourly</option>
                                <option value="twicedaily" <?php selected(($settings['interval'] ?? '') === 'twicedaily'); ?>>Twice daily</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Post Status</th>
                        <td>
                            <select name="sz_nlap_settings[post_status]">
                                <option value="publish" <?php selected(($settings['post_status'] ?? '') === 'publish'); ?>>Publish</option>
                                <option value="draft" <?php selected(($settings['post_status'] ?? '') === 'draft'); ?>>Draft</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Author</th>
                        <td>
                            <input type="number" min="0" name="sz_nlap_settings[author_id]" value="<?php echo esc_attr(intval($settings['author_id'] ?? 0)); ?>" />
                            <p class="description">0 = auto-detect first administrator.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Max items per feed per run</th>
                        <td>
                            <input type="number" min="1" max="50" name="sz_nlap_settings[max_items_per_feed]" value="<?php echo esc_attr(intval($settings['max_items_per_feed'] ?? 5)); ?>" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Auto-disable after consecutive failures</th>
                        <td>
                            <input type="number" min="0" max="10" name="sz_nlap_settings[auto_disable_after_failures]" value="<?php echo esc_attr(intval($settings['auto_disable_after_failures'] ?? 3)); ?>" />
                            <p class="description">Set to 0 to never auto-disable.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Relax SSL verification</th>
                        <td>
                            <label>
                                <input type="checkbox" name="sz_nlap_settings[relax_ssl]" value="1" <?php checked(!empty($settings['relax_ssl'])); ?>>
                                Allow feeds even if SSL verification fails (recommended on some shared hosts).
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Debug log</th>
                        <td>
                            <label>
                                <input type="checkbox" name="sz_nlap_settings[debug_log]" value="1" <?php checked(!empty($settings['debug_log'])); ?>>
                                Write to PHP error_log
                            </label>
                        </td>
                    </tr>
                </table>

                <p>
                    <input type="submit" class="button button-primary" name="sz_nlap_save_settings" value="Save Settings">
                </p>
            </form>
        </div>
        <?php
    }

    public static function get_feeds() {
        $feeds = get_option(self::OPTION_FEEDS);
        if (!is_array($feeds) || empty($feeds)) {
            $feeds = self::default_feeds();
            update_option(self::OPTION_FEEDS, $feeds);
        }
        // Ensure keys exist
        foreach ($feeds as &$f) {
            if (!isset($f['fail_count'])) { $f['fail_count'] = 0; }
            if (!isset($f['last_error'])) { $f['last_error'] = ''; }
        }
        return $feeds;
    }

    public static function get_settings() {
        $settings = get_option(self::OPTION_SETTINGS);
        if (!is_array($settings) || empty($settings)) {
            $settings = self::default_settings();
            update_option(self::OPTION_SETTINGS, $settings);
        }
        if (!isset($settings['relax_ssl'])) { $settings['relax_ssl'] = 1; }
        return $settings;
    }

    private static function sanitize_feeds($raw) {
        $clean = [];
        if (!is_array($raw)) { return self::default_feeds(); }

        foreach ($raw as $f) {
            $key = sanitize_key($f['key'] ?? '');
            if ($key === '') { continue; }

            $clean[] = [
                'key' => $key,
                'name' => sanitize_text_field($f['name'] ?? $key),
                'url' => esc_url_raw($f['url'] ?? ''),
                'enabled' => !empty($f['enabled']) ? 1 : 0,
                'category_slug' => sanitize_key($f['category_slug'] ?? $key),
                'fail_count' => intval($f['fail_count'] ?? 0),
                'last_error' => sanitize_text_field($f['last_error'] ?? ''),
            ];
        }

        if (empty($clean)) {
            $clean = self::default_feeds();
        }

        return array_values($clean);
    }

    private static function sanitize_settings($raw) {
        $defaults = self::default_settings();
        $s = is_array($raw) ? $raw : [];

        $interval = sanitize_text_field($s['interval'] ?? $defaults['interval']);
        $allowed_intervals = ['sz_nlap_15min', 'hourly', 'twicedaily'];
        if (!in_array($interval, $allowed_intervals, true)) {
            $interval = $defaults['interval'];
        }

        $status = sanitize_key($s['post_status'] ?? $defaults['post_status']);
        if (!in_array($status, ['publish', 'draft'], true)) {
            $status = $defaults['post_status'];
        }

        $author_id = intval($s['author_id'] ?? $defaults['author_id']);
        if ($author_id < 0) { $author_id = 0; }

        $max_items = intval($s['max_items_per_feed'] ?? $defaults['max_items_per_feed']);
        if ($max_items < 1) { $max_items = 1; }
        if ($max_items > 50) { $max_items = 50; }

        $auto_disable = intval($s['auto_disable_after_failures'] ?? $defaults['auto_disable_after_failures']);
        if ($auto_disable < 0) { $auto_disable = 0; }
        if ($auto_disable > 10) { $auto_disable = 10; }

        $debug = !empty($s['debug_log']) ? 1 : 0;
        $relax = !empty($s['relax_ssl']) ? 1 : 0;

        return [
            'interval' => $interval,
            'post_status' => $status,
            'author_id' => $author_id,
            'max_items_per_feed' => $max_items,
            'auto_disable_after_failures' => $auto_disable,
            'debug_log' => $debug,
            'relax_ssl' => $relax,
        ];
    }

    private static function ensure_categories() {
        $feeds = self::get_feeds();
        foreach ($feeds as $f) {
            $slug = $f['category_slug'] ?? $f['key'];
            if (!$slug) { continue; }
            $term = get_category_by_slug($slug);
            if (!$term) {
                wp_insert_term($f['name'] ?? $slug, 'category', ['slug' => $slug]);
            }
        }
    }

    private static function log($msg) {
        $settings = self::get_settings();
        if (!empty($settings['debug_log'])) {
            error_log('[SZ NLAP] ' . $msg);
        }
    }

    public static function cron_run() {
        $result = self::run_import(false);
        update_option(self::OPTION_LAST_RUN, $result);
    }

    private static function get_allowed_hosts_from_feeds($feeds) {
        $hosts = [];
        foreach ($feeds as $f) {
            $u = $f['url'] ?? '';
            if (!$u) { continue; }
            $parts = wp_parse_url($u);
            if (!empty($parts['host'])) {
                $hosts[] = strtolower($parts['host']);
            }
            // Also include non-www variant if present
            if (!empty($parts['host']) && strpos($parts['host'], 'www.') === 0) {
                $hosts[] = strtolower(substr($parts['host'], 4));
            }
        }
        return array_values(array_unique($hosts));
    }

    public static function run_import($manual = false) {
        if (!function_exists('fetch_feed')) {
            require_once ABSPATH . WPINC . '/feed.php';
        }

        $feeds = self::get_feeds();
        $settings = self::get_settings();

        $imported = 0;
        $skipped = 0;
        $errors = 0;

        $max_items = intval($settings['max_items_per_feed'] ?? 5);
        $auto_disable_after = intval($settings['auto_disable_after_failures'] ?? 3);

        // TEMPORARY HTTP whitelist for this run
        $allowed_hosts = self::get_allowed_hosts_from_feeds($feeds);
        $allowed_filter = function($hosts) use ($allowed_hosts) {
            if (!is_array($hosts)) { $hosts = []; }
            return array_values(array_unique(array_merge($hosts, $allowed_hosts)));
        };
        add_filter('allowed_http_hosts', $allowed_filter, 10, 1);

        // TEMPORARY SSL relax for this run
        $relax = !empty($settings['relax_ssl']);
        $ssl_filter = function($args, $url) use ($relax, $allowed_hosts) {
            if (!$relax) { return $args; }
            $parts = wp_parse_url($url);
            $host = strtolower($parts['host'] ?? '');
            if ($host && in_array($host, $allowed_hosts, true)) {
                $args['sslverify'] = false;
                $args['timeout'] = isset($args['timeout']) ? max(10, intval($args['timeout'])) : 10;
            }
            return $args;
        };
        add_filter('http_request_args', $ssl_filter, 10, 2);

        foreach ($feeds as $idx => $f) {
            if (empty($f['enabled'])) {
                continue;
            }

            $url = $f['url'] ?? '';
            if (!$url) {
                $errors++;
                $feeds[$idx]['last_error'] = 'Missing URL';
                continue;
            }

            $try_urls = [$url];
            if (preg_match('#/feed/?$#', $url)) {
                $root = preg_replace('#/feed/?$#', '/', $url);
                $try_urls[] = $root . '?feed=rss2';
                $try_urls[] = $root . '?feed=rss';
                $try_urls[] = $root . '?feed=atom';
            }

            $feed_obj = null;
            $feed_error = null;

            foreach ($try_urls as $u) {
                $u = esc_url_raw($u);
                $tmp = fetch_feed($u);
                if (is_wp_error($tmp)) {
                    $feed_error = $tmp->get_error_message();
                    self::log("Feed error for {$f['key']} at {$u}: {$feed_error}");
                    continue;
                }
                $feed_obj = $tmp;
                $feed_error = null;
                break;
            }

            if (!$feed_obj) {
                $errors++;
                $feeds[$idx]['fail_count'] = intval($f['fail_count'] ?? 0) + 1;
                $feeds[$idx]['last_error'] = $feed_error ? $feed_error : 'Unknown feed error';

                if ($auto_disable_after > 0 && $feeds[$idx]['fail_count'] >= $auto_disable_after) {
                    $feeds[$idx]['enabled'] = 0;
                    self::log("Auto-disabled feed {$f['key']} after {$feeds[$idx]['fail_count']} failures.");
                }
                continue;
            }

            $feeds[$idx]['fail_count'] = 0;
            $feeds[$idx]['last_error'] = '';

            $items = $feed_obj->get_items(0, $max_items);
            if (empty($items)) {
                continue;
            }

            foreach ($items as $item) {
                $guid = $item->get_id();
                if (!$guid) { $guid = $item->get_permalink(); }
                if (!$guid) { $skipped++; continue; }

                if (self::guid_exists($guid)) {
                    $skipped++;
                    continue;
                }

                $title = wp_strip_all_tags($item->get_title());
                $content = $item->get_content();
                if (!$content) { $content = $item->get_description(); }

                $date_u = $item->get_date('U');
                if (!$date_u) { $date_u = time(); }

                $author_id = self::resolve_author_id($settings);

                $cat_slug = $f['category_slug'] ?? $f['key'];
                $cat_id = self::ensure_category_id($cat_slug, $f['name'] ?? $cat_slug);

                $postarr = [
                    'post_title'   => $title ? $title : '(Untitled)',
                    'post_content' => $content ? $content : '',
                    'post_status'  => $settings['post_status'] ?? 'publish',
                    'post_author'  => $author_id,
                    'post_date'    => gmdate('Y-m-d H:i:s', $date_u + (get_option('gmt_offset') * HOUR_IN_SECONDS)),
                    'post_date_gmt'=> gmdate('Y-m-d H:i:s', $date_u),
                    'post_category'=> $cat_id ? [$cat_id] : [],
                ];

                $post_id = wp_insert_post($postarr, true);

                if (is_wp_error($post_id)) {
                    $errors++;
                    self::log("Insert error for {$f['key']}: " . $post_id->get_error_message());
                    $feeds[$idx]['last_error'] = $post_id->get_error_message();
                    continue;
                }

                add_post_meta($post_id, '_sz_nlap_guid', sanitize_text_field($guid), true);
                add_post_meta($post_id, '_sz_nlap_source_key', sanitize_text_field($f['key']), true);
                add_post_meta($post_id, '_sz_nlap_source_name', sanitize_text_field($f['name'] ?? $f['key']), true);
                add_post_meta($post_id, '_sz_nlap_item_link', esc_url_raw($item->get_permalink()), true);

                $imported++;
            }
        }

        remove_filter('allowed_http_hosts', $allowed_filter, 10);
        remove_filter('http_request_args', $ssl_filter, 10);

        update_option(self::OPTION_FEEDS, array_values($feeds));

        return [
            'time' => current_time('mysql'),
            'manual' => $manual ? 1 : 0,
            'imported' => $imported,
            'skipped' => $skipped,
            'errors' => $errors,
        ];
    }

    private static function resolve_author_id($settings) {
        $author_id = intval($settings['author_id'] ?? 0);
        if ($author_id > 0 && get_user_by('id', $author_id)) {
            return $author_id;
        }

        $admins = get_users([
            'role' => 'administrator',
            'orderby' => 'ID',
            'order' => 'ASC',
            'number' => 1,
            'fields' => ['ID'],
        ]);
        if (!empty($admins) && !empty($admins[0]->ID)) {
            return intval($admins[0]->ID);
        }

        $current = get_current_user_id();
        if ($current) { return $current; }
        return 1;
    }

    private static function ensure_category_id($slug, $name) {
        $slug = sanitize_key($slug);
        if (!$slug) { return 0; }
        $term = get_category_by_slug($slug);
        if ($term && !is_wp_error($term)) {
            return intval($term->term_id);
        }
        $created = wp_insert_term($name, 'category', ['slug' => $slug]);
        if (is_wp_error($created)) {
            return 0;
        }
        return intval($created['term_id'] ?? 0);
    }

    private static function guid_exists($guid) {
        global $wpdb;
        $guid = sanitize_text_field($guid);
        if ($guid === '') { return false; }
        $meta_key = '_sz_nlap_guid';
        $found = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s LIMIT 1",
            $meta_key, $guid
        ));
        return !empty($found);
    }
}

SZ_NLAP_Stable::init();