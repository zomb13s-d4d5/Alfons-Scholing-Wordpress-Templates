=== SZ Network Lessons Autopublish (Stable Minimal) ===
Contributors: notyouagain
Tags: rss, import, autopublish, network
Requires at least: 6.0
Tested up to: 6.6
Stable tag: 2.0.1
License: GPLv2 or later

A hardened rebuild focused on reliability.

What's new in 2.0.1:
- Shows Last Error per feed in the UI.
- Temporarily whitelists configured feed hosts during a run (helps if WP_HTTP_BLOCK_EXTERNAL is enabled).
- Optional "Relax SSL verification" toggle (ON by default) for shared hosts with SSL/CABundle issues.