(function() {
    if (typeof window === 'undefined' || !window.SBNConfig) {
        return;
    }

    const config = window.SBNConfig;

    const SBN_FALLBACK_COMMANDS = {
        help: { summary: 'Show available commands or details for one.', level: 'guest' },
        menu: { summary: 'Show the full Pixel slash-command menu.', level: 'guest' },
        'design-test': { summary: 'Start the Some-B Design Intelligence Test.', level: 'guest' },
        quiz: { summary: 'Start a design-principles quiz.', level: 'guest' },
        answer: { summary: 'Answer the current quiz question.', level: 'guest' },
        lesson: { summary: 'Show a short design lesson before testing.', level: 'guest' },
        score: { summary: 'Show your current Design Intelligence score.', level: 'guest' },
        search: { summary: 'Search the network for posts related to your keywords.', level: 'guest' },
        scan: { summary: 'Quick scan of this site or the whole network.', level: 'guest' },
        summarize: { summary: 'Summarize a URL or the current post.', level: 'guest' },
        addsite: { summary: 'Submit a website URL to be included in network search.', level: 'guest' },
        login: { summary: 'Show a secure login link for this site.', level: 'guest' },
        register: { summary: 'Show a secure registration link for this site.', level: 'guest' },
        modes: { summary: 'List available BCLM mode codes.', level: 'guest' },
        bclm: { summary: 'Explain a BCLM concept id or label.', level: 'guest' },
        alfons: { summary: 'Learn about Alfons Scholing and the studio.', level: 'guest' },
        randy: { summary: 'Hear about Randy Daha and his multidisciplinary practice.', level: 'guest' },
        raf: { summary: 'Discover Raf de Wit.', level: 'guest' },
        ruben: { summary: 'Find out who Ruben Piel is.', level: 'guest' },
        marcel: { summary: 'Learn about Marcel Tempelaars.', level: 'guest' },
        design: { summary: 'Explore design for values.', level: 'guest' },
        engineering: { summary: 'Discuss social value and ethics in engineering.', level: 'guest' },
        explore: { summary: 'Deep network search with extended results.', level: 'guest' },
        sources: { summary: 'List related articles across the NYA network.', level: 'guest' },
        compare: { summary: 'Compare coverage or framing between two topics.', level: 'citizen' },
        claims: { summary: 'List claim-rich articles across the NYA network.', level: 'guest' },
        rights: { summary: 'Map a topic to BCLM rights and duty-of-care concepts.', level: 'citizen' },
        debug: { summary: 'Democracy Terminal / BCLM health snapshot.', level: 'citizen' }
    };

    function sbnGetCommandMap(status) {
        return (status && status.commands && Object.keys(status.commands).length) ? status.commands : SBN_FALLBACK_COMMANDS;
    }

    // Democracy Terminal state (R2)
    let sbTerminalState = null;

    function sbnTerminalIsEnabled() {
        return !!(config && config.terminalStatusUrl && config.terminalExecuteUrl);
    }

    function sbnIsTerminalLikeInput(text) {
        const t = String(text || '').trim();
        if (!t) return false;
        if (t.charAt(0) === '/') return true;
        return /^bclm_[a-z0-9_]+\s*:/i.test(t);
    }

    function sbnToggleCodesPanel(forceOpen) {
        const toggle = document.getElementById('sbn-codes-toggle');
        const panel  = document.getElementById('sbn-codes-panel');
        if (!toggle || !panel) return;

        const expandedAttr = toggle.getAttribute('aria-expanded') === 'true';
        const expanded = (typeof forceOpen === 'boolean') ? forceOpen : !expandedAttr;
        toggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');

        if (expanded) {
            panel.removeAttribute('hidden');
        } else {
            panel.setAttribute('hidden', '');
        }
    }

    function sbnRenderTerminalHeader(status) {
        const statusEl = document.getElementById('sbn-terminal-status');
        const ctaEl    = document.getElementById('sbn-terminal-cta');
        if (!statusEl || !ctaEl) return;

        const level = (status && status.user_level) ? status.user_level : 'guest';
        const nodes = (status && status.network_sites) ? Object.keys(status.network_sites).length : 0;

        statusEl.textContent = 'NYA Network mode. Slash codes active across ' + (nodes || 'all configured') + ' node(s): /menu, /quiz, /design-test, /scan, /search, /explore, /sources, /compare, /claims, /rights, /debug and BCLM shortcuts.';
        ctaEl.textContent = 'Command layer is network-wide and not locked to Some-B only.';
    }
    function sbnBuildCodeItem(code, label, locked) {
        const li = document.createElement('li');
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'sbn-code-item' + (locked ? ' is-locked' : '');
        btn.setAttribute('data-sbn-code', code);
        btn.innerHTML = '<code>' + escapeHtml(code) + '</code>' +
            (label ? '<span>' + escapeHtml(label) + '</span>' : '') +
            (locked ? '<span aria-hidden="true"> 🔒</span>' : '');
        li.appendChild(btn);
        return li;
    }

    function sbnRenderCodes(status) {
        const modesList = document.getElementById('sbn-mode-code-list');
        const cmdsList  = document.getElementById('sbn-command-code-list');
        const collapsible = document.getElementById('sbn-codes-collapsible');
        if (!modesList || !cmdsList || !collapsible) return;

        modesList.innerHTML = '';
        cmdsList.innerHTML  = '';

        const level = (status && status.user_level) ? status.user_level : 'guest';
        const modes = (status && status.modes) ? status.modes : {};
        const cmds  = sbnGetCommandMap(status);

        const modeEntries = Object.entries(modes || {});
        modeEntries.sort((a, b) => String(a[0]).localeCompare(String(b[0])));
        modeEntries.forEach(([key, meta]) => {
            const label = (meta && meta.label) ? meta.label : key;
            const locked = (meta && meta.level === 'citizen' && level !== 'citizen');
            modesList.appendChild(sbnBuildCodeItem(key, label, locked));
        });

        const cmdEntries = Object.entries(cmds || {});
        cmdEntries.sort((a, b) => String(a[0]).localeCompare(String(b[0])));
        cmdEntries.forEach(([key, meta]) => {
            const summary = (meta && meta.summary) ? meta.summary : '';
            const locked = (meta && meta.level === 'citizen' && level !== 'citizen');
            cmdsList.appendChild(sbnBuildCodeItem('/' + key, summary, locked));
        });

        collapsible.querySelectorAll('.sbn-code-item').forEach(btn => {
            btn.addEventListener('click', function() {
                if (this.classList.contains('is-locked')) return;
                const code = this.getAttribute('data-sbn-code') || '';
                const input = document.getElementById('sbn-question');
                if (!input || !code) return;

                const clean = code.startsWith('/') ? code : (code + ': ');
                input.value = clean;
                input.focus();
            });
        });
    }

    /**
     * Enhance slider elements within the chat log.
     *
     * Search and explore results are rendered as horizontally scrollable
     * sliders. Each slider is followed by a set of indicator buttons. This
     * function attaches click handlers to the indicator buttons so they
     * scroll the slider to the corresponding slide and updates the active
     * indicator on scroll. It accepts an optional scope element to limit
     * the query to a newly inserted log entry; if omitted, the document
     * root is used.
     *
     * @param {Element|Document} scope
     */
    function sbnEnhanceSliders(scope) {
        const root = scope || document;

        // Search command sliders already include their indicator container.
        // Normal chat network cards are upgraded here: we generate bullets
        // underneath them and make the card strip behave like a slider.
        const sliders = root.querySelectorAll('.sbn-search-slider, .sbn-network-cards');

        sliders.forEach(function(slider) {
            const slideSelector = slider.classList.contains('sbn-network-cards')
                ? '.sbn-network-card'
                : '.sbn-search-slide';

            const slides = Array.prototype.slice.call(slider.querySelectorAll(slideSelector));
            if (!slides.length) return;

            slider.classList.add('sbn-radar-slider');

            let indicators = slider.nextElementSibling;
            if (!indicators || !indicators.classList || !indicators.classList.contains('sbn-slider-indicators')) {
                indicators = document.createElement('div');
                indicators.className = 'sbn-slider-indicators sbn-auto-slider-indicators';
                slider.insertAdjacentElement('afterend', indicators);
            }

            // The typewriter builds HTML progressively. If the number of slides changes
            // during assembly, rebuild the bullets instead of treating the slider as fixed.
            const previousCount = parseInt(slider.dataset.sbnSlideCount || '0', 10);
            if (slider.dataset.sbnSliderReady === '1' && previousCount === slides.length) {
                if (typeof slider._sbnUpdateActive === 'function') {
                    slider._sbnUpdateActive();
                }
                return;
            }

            indicators.innerHTML = '';

            slides.forEach(function(_, idx) {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'sbn-slider-indicator';
                btn.setAttribute('data-index', String(idx));
                btn.setAttribute('aria-label', 'Go to network node ' + (idx + 1));
                indicators.appendChild(btn);
            });

            const buttons = Array.prototype.slice.call(indicators.querySelectorAll('.sbn-slider-indicator'));

            const updateActive = function() {
                const slideWidth = slides[0] ? slides[0].getBoundingClientRect().width : slider.clientWidth;
                const idx = Math.max(0, Math.min(buttons.length - 1, Math.round(slider.scrollLeft / Math.max(1, slideWidth))));
                buttons.forEach(function(btn, i) {
                    btn.classList.toggle('active', i === idx);
                });
                slides.forEach(function(slide, i) {
                    slide.classList.toggle('active', i === idx);
                });
            };

            buttons.forEach(function(btn, idx) {
                const handler = function(e) {
                    e.preventDefault();
                    const slide = slides[idx];
                    if (!slide) return;
                    slider.dataset.sbnAssemblyIndex = String(idx);
                    slider.scrollTo({ left: slide.offsetLeft - slider.offsetLeft, behavior: 'smooth' });
                    window.setTimeout(updateActive, 150);
                };
                btn.addEventListener('click', handler);
            });

            if (slider.dataset.sbnScrollBound !== '1') {
                slider.addEventListener('scroll', function() {
                    window.requestAnimationFrame(function() {
                        if (typeof slider._sbnUpdateActive === 'function') {
                            slider._sbnUpdateActive();
                        }
                    });
                }, { passive: true });
                slider.dataset.sbnScrollBound = '1';
            }

            slider._sbnUpdateActive = updateActive;
            slider.dataset.sbnSliderReady = '1';
            slider.dataset.sbnSlideCount = String(slides.length);
            updateActive();
        });
    }

    /**
     * During the typewriter animation, automatically move the radar slider to the
     * card that is currently being assembled. Without this, card two and three can
     * be generated off-screen while the visitor is still looking at card one.
     */
    function sbnAutoAdvanceRadarAssembly(scope) {
        const root = scope || document;
        const sliders = root.querySelectorAll('.sbn-search-slider, .sbn-network-cards');

        sliders.forEach(function(slider) {
            const slideSelector = slider.classList.contains('sbn-network-cards')
                ? '.sbn-network-card'
                : '.sbn-search-slide';

            const slides = Array.prototype.slice.call(slider.querySelectorAll(slideSelector));
            if (!slides.length) return;

            // Make bullets exist as early as possible while the markup assembles.
            sbnEnhanceSliders(root);

            /*
             * Follow the newest node/card, not the last node with enough text.
             * The typewriter can create a new card element before its title text is
             * long enough to pass a threshold. In that state the old logic kept the
             * viewport on card one while card two assembled off-screen. Targeting the
             * newest available card makes the radar behave like a live scanner: as
             * soon as the next node appears, the viewport moves to it.
             */
            let targetIndex = Math.max(0, slides.length - 1);

            const previous = parseInt(slider.dataset.sbnAssemblyIndex || '-1', 10);
            if (targetIndex !== previous) {
                slider.dataset.sbnAssemblyIndex = String(targetIndex);
                const targetSlide = slides[targetIndex];
                if (targetSlide) {
                    // Use the slide position within the slider rather than the body
                    // so the outer terminal never scrolls horizontally.
                    const firstSlide = slides[0];
                    const baseLeft = firstSlide ? firstSlide.offsetLeft : 0;
                    const targetLeft = Math.max(0, targetSlide.offsetLeft - baseLeft);
                    slider.scrollTo({
                        left: targetLeft,
                        behavior: previous < 0 ? 'auto' : 'smooth'
                    });
                    window.setTimeout(function() {
                        if (typeof slider._sbnUpdateActive === 'function') {
                            slider._sbnUpdateActive();
                        }
                    }, 140);
                }
            }
        });
    }

    function sbnOpenArticleModal(url, label) {
        const modal = document.getElementById('sbn-article-modal');
        const title = document.getElementById('sbn-article-title');
        const source = document.getElementById('sbn-article-source');
        const content = document.getElementById('sbn-article-content');

        if (!modal || !title || !source || !content || !url) {
            window.open(url, '_blank', 'noopener');
            return;
        }

        modal.hidden = false;
        modal.setAttribute('aria-hidden', 'false');
        title.textContent = 'Loading node article…';
        source.textContent = label || url;
        content.innerHTML = '<p>Bibi is opening the glass reading panel. Pixel is checking the corners.</p>';

        if (!config.articlePreviewUrl) {
            content.innerHTML = '<p>Preview endpoint not available. Opening source in a new tab.</p>';
            window.open(url, '_blank', 'noopener');
            return;
        }

        fetch(config.articlePreviewUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': config.nonce
            },
            body: JSON.stringify({ url: url })
        })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (!data || data.error) {
                    title.textContent = 'Source preview unavailable';
                    content.innerHTML = '<p>' + escapeHtml((data && data.message) ? data.message : 'Could not load this article inside Some-B.') + '</p>' +
                        '<p><a href="' + escapeHtml(url) + '" target="_blank" rel="noopener">Open original source</a></p>';
                    return;
                }
                title.textContent = data.title || 'Untitled article';
                source.innerHTML = '<span>Node source: ' + escapeHtml(data.source || label || '') + '</span>' +
                    (data.url ? ' · <a href="' + escapeHtml(data.url) + '" target="_blank" rel="noopener">Open original</a>' : '');
                content.innerHTML = data.content || '<p>No readable preview available.</p>';
            })
            .catch(function() {
                title.textContent = 'Source preview unavailable';
                content.innerHTML = '<p>The glass panel could not fetch this article. The original source can still open in a new tab.</p>' +
                    '<p><a href="' + escapeHtml(url) + '" target="_blank" rel="noopener">Open original source</a></p>';
            });
    }

    function sbnCloseArticleModal() {
        const modal = document.getElementById('sbn-article-modal');
        if (!modal) return;
        modal.hidden = true;
        modal.setAttribute('aria-hidden', 'true');
    }

    function sbnFetchTerminalStatus() {
        if (!sbnTerminalIsEnabled()) return Promise.resolve(null);
        return fetch(config.terminalStatusUrl, {
            method: 'GET',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': config.nonce
            }
        })
            .then(r => r.json())
            .then(data => {
                sbTerminalState = data || null;
                if (data) {
                    sbnRenderTerminalHeader(data);
                    sbnRenderCodes(data);
                    if (typeof sbnRenderPixelCommands === 'function') {
                        sbnRenderPixelCommands(data);
                    }
                }
                return data;
            })
            .catch(() => null);
    }

    function sbnSendTerminalInput(inputText) {
        const source = window.location.href;
        const controller = (typeof AbortController !== 'undefined') ? new AbortController() : null;
        const timer = controller ? window.setTimeout(function() { controller.abort(); }, 8000) : null;
        return fetch(config.terminalExecuteUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': config.nonce
            },
            signal: controller ? controller.signal : undefined,
            body: JSON.stringify({ input: inputText, source: source })
        })
            .then(function(r) {
                if (!r.ok) throw new Error('Terminal HTTP ' + r.status);
                return r.json();
            })
            .finally(function() {
                if (timer) window.clearTimeout(timer);
            });
    }


    function sbnNormalizeQuizUsageMessage(msg) {
        const text = (msg || '').toString();
        if (/^Usage:\s*\/quiz/i.test(text.trim())) {
            return 'SOME-B DESIGN QUIZ\n\nYou typed /quiz, so here are real multiple-choice design-principles choices.\n\nQuestion 1 / 5 — Visual hierarchy\n\nWhat creates visual hierarchy first in a layout?\n\nA. Decoration\nB. Contrast, scale, position, and spacing\nC. Random color use\nD. Making every element the same size\n\nChoices: A, B, C, or D.\nAnswer with /answer A, /answer B, /answer C, or /answer D.\nOther lanes: /quiz composition, /quiz color, /quiz typography, /quiz communication, /quiz marketing, /quiz math.';
        }
        return text;
    }

    function sbnHandleTerminalPayload(payload) {
        sbStopThinkingAnimation();

        if (!payload) {
            typewriterLog('Some-B', "Terminal glitch. Try /help or switch to normal chat.");
            return;
        }

        let msg = (payload.message || payload.response_text || payload.text || '').toString();
        msg = sbnNormalizeQuizUsageMessage(msg);
        if (!msg) {
            typewriterLog('Some-B', "Terminal returned an empty response.");
            return;
        }

        const isHtmlPayload = payload.html === true || payload.render === 'html' ||
            msg.indexOf('sbn-search-slider') !== -1 ||
            msg.indexOf('sbn-network-cards') !== -1 ||
            msg.indexOf('sbn-franchise-radar') !== -1;
        const html = isHtmlPayload ? msg : ('<p>' + escapeHtml(msg) + '</p>');
        typewriterLog(isHtmlPayload ? 'Bibi' : 'Some-B', html, isHtmlPayload ? 'network_radar' : 'local_pde');
        sbAppendHistory('assistant', msg.replace(/<[^>]+>/g, ''));
    }



    document.addEventListener('DOMContentLoaded', function() {
        const widget    = document.getElementById('sbn-widget');
        const widgetBtn = widget ? widget.querySelector('.sbn-widget-button') : null;
        const overlay   = document.getElementById('sbn-overlay');

        if (widgetBtn) {
            widgetBtn.addEventListener('click', function() {
                if (config.isHQ && overlay) {
                    const isHidden = overlay.getAttribute('aria-hidden') !== 'false';
                    overlay.setAttribute('aria-hidden', isHidden ? 'false' : 'true');
                    if (isHidden) {
                        sbnMaybeInjectFirstOpenIntro();
                        sbnFetchTerminalStatus();
                    }
                } else {
                    window.location.href = config.hqUrl + '?from=' + encodeURIComponent(window.location.href);
                }
            });
        }

        if (overlay) {
            const closeBtn = overlay.querySelector('.sbn-close');
            if (closeBtn) {
                closeBtn.addEventListener('click', function() {
                    overlay.setAttribute('aria-hidden', 'true');
                });
            }
        }

        // If the control room is already visible (edge cases), inject an intro.
        if (overlay && overlay.getAttribute('aria-hidden') === 'false') {
            sbnMaybeInjectFirstOpenIntro();
            sbnFetchTerminalStatus();
        }

        const codesToggle = document.getElementById('sbn-codes-toggle');
        if (codesToggle) {
            codesToggle.addEventListener('click', function() {
                sbnToggleCodesPanel();
            });
        }


        const form     = document.getElementById('sbn-form');
        const log      = document.getElementById('sbn-log');
        const textarea = document.getElementById('sbn-question');

        // Preset/code click delegation.
        // Supports footer quicklinks, collapsible code lists, and dynamically injected quickstart lines.
        function sbnHandlePresetClick(e) {
            if (!textarea) return;
            const el = e.target.closest('[data-sbn-preset],[data-sbn-code]');
            if (!el) return;

            if (el.classList && el.classList.contains('is-locked')) return;

            const preset = el.getAttribute('data-sbn-preset') || '';
            const code   = el.getAttribute('data-sbn-code') || '';
            const value  = preset || code;
            if (!value) return;

            textarea.value = value;
            textarea.focus();
            e.preventDefault();
        }

        if (overlay) {
            overlay.addEventListener('click', sbnHandlePresetClick);
        } else {
            document.addEventListener('click', sbnHandlePresetClick);
        }

        // Search/network result links now use their native anchors.
        // They are rendered with target="_blank", so tapping a result opens the linked page
        // in a new browser window/tab instead of hijacking the click into Glass Reading Mode.

        document.addEventListener('click', function(e) {
            if (e.target.closest('[data-sbn-close-article]')) {
                e.preventDefault();
                sbnCloseArticleModal();
            }
        });

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                sbnCloseArticleModal();
            }
        });
        // ===== First-open intro (single cohesive help, typed once) =====
        const SBN_INTRO_STORAGE_KEY = 'sbn_intro_seen_r8';

        function sbnGetFirstOpenIntroHtml() {
            // Franchise opening: Bibi as the guide, Pixel as the co-pilot.
            return [
                '<p><strong>Bibi online.</strong> Cute with bass. Continental by design.</p>',
                '<p>This is the Some-B control room: a soft system for sharp work, network search, studio notes, and city-node thinking.</p>',
                '<p><strong>Network Radar:</strong> use <strong>/search [topic]</strong> to let the nodes answer in swipeable cards. Use <strong>/explore [topic]</strong> for deeper citizen mode.</p>',
                '<p><strong>Network Radar:</strong> tap an article title to open the linked page in a new window/tab.</p>',
                '<ul>',
                '<li><strong>/help</strong> → command map.</li>',
                '<li><strong>/search</strong> <em>[topic]</em> → node cards by website.</li>',
                '<li><strong>/addsite</strong> <em>[url]</em> → submit a source for ballotage.</li>',
                '<li><strong>/design</strong> and <strong>/engineering</strong> → values and systems.</li>',
                '<li><strong>/alfons</strong>, <strong>/randy</strong>, <strong>/raf</strong>, <strong>/ruben</strong>, <strong>/marcel</strong> → people around the studio universe.</li>',
                '</ul>',
                '<p>Pixel has notes. Boomie has bass. I’ll keep the interface human.</p>'
            ].join('');
        }

        function sbnMaybeInjectFirstOpenIntro() {
            if (!log) return;
            try {
                if (window.localStorage && localStorage.getItem(SBN_INTRO_STORAGE_KEY) === '1') {
                    return;
                }

                const html = sbnGetFirstOpenIntroHtml();
                typewriterLog('Some-B', html);

                if (window.localStorage) {
                    localStorage.setItem(SBN_INTRO_STORAGE_KEY, '1');
                }
            } catch (e) {
                // Fail silent: never break the console
            }
        }

        if (config.isHQ && overlay && overlay.getAttribute('aria-hidden') === 'false') {
            sbnMaybeInjectFirstOpenIntro();
        }

        // After the DOM has loaded and the initial log is present, enhance any
        // sliders that might have been injected by server-side content. This
        // ensures that search results displayed on initial page load are
        // interactive.
        sbnEnhanceSliders(document);

// Simple animation for the literal 'thinking' line – nothing else.
    let sbThinkingInterval = null;
    function sbStartThinkingAnimation() {
        if (!log) return;
        const entries = log.querySelectorAll('.sb-log-entry');
        if (!entries.length) return;
        const last = entries[entries.length - 1];
        const textSpan = last.querySelector('.sbn-text');
        if (!textSpan) return;
        let dots = 0;
        if (sbThinkingInterval) {
            window.clearInterval(sbThinkingInterval);
        }
        sbThinkingInterval = window.setInterval(function() {
            dots = (dots + 1) % 4; // 0,1,2,3
            textSpan.textContent = 'thinking' + (dots ? '.'.repeat(dots) : '');
        }, 400);
    }

    function sbStopThinkingAnimation() {
        if (sbThinkingInterval) {
            window.clearInterval(sbThinkingInterval);
            sbThinkingInterval = null;
        }
        if (!log) return;
        const entries = log.querySelectorAll('.sb-log-entry');
        if (!entries.length) return;
        const last = entries[entries.length - 1];
        const textSpan = last.querySelector('.sbn-text');
        if (!textSpan) return;
        const raw = textSpan.textContent || '';
        if (raw.indexOf('thinking') === 0) {
            if (last.parentNode) {
                last.parentNode.removeChild(last);
            }
        }
    }

// Keep a short conversational history so the backend can see a few turns.
        const sbHistory = [];
        let sbReasoningMode = 'common_sense';

        // UI-selectable brains for the BCLM/Diagnose 'than' pattern.
        let sbnBrainMode = 'diagnose';

        function sbnSetBrainMode(mode) {
            if (!mode) return;
            sbnBrainMode = mode;
            const hidden = document.getElementById('sbn-mode-input');
            if (hidden) hidden.value = mode;
        }


        function sbSetReasoningMode(mode) {
            if (!mode) return;
            sbReasoningMode = mode;
        }

        function sbInferReasoningModeFromQuestion(text) {
            const t = String(text || '').toLowerCase().trim();
            if (t === 'diagnose') {
                sbReasoningMode = 'abductive_fuzzy';
            } else if (t === 'scan') {
                sbReasoningMode = 'deductive_scan';
            } else {
                if (!sbReasoningMode) {
                    sbReasoningMode = 'common_sense';
                }
            }
            return sbReasoningMode;
        }

        function sbAppendHistory(role, content) {
            if (!content) return;
            sbHistory.push({
                role: role,
                content: String(content)
            });
            // keep only the last 8 entries (4 back-and-forths)
            if (sbHistory.length > 8) {
                sbHistory.splice(0, sbHistory.length - 8);
            }
        }

        function sbGetHistory() {
            return sbHistory.slice();
        }


        // Auto-grow the terminal input while typing, then snap it back to
        // its normal one-line height after a message is sent. This fixes
        // multi-line slash-code prompts like `/compare` with several URLs.
        let sbnInputBaseHeight = null;

        function sbnResizeTerminalInput() {
            if (!textarea) return;

            if (!sbnInputBaseHeight) {
                const computed = window.getComputedStyle(textarea);
                const minHeight = parseFloat(computed.minHeight);
                sbnInputBaseHeight = textarea.offsetHeight || textarea.scrollHeight || minHeight || 38;
            }

            textarea.style.height = 'auto';
            textarea.style.height = Math.max(sbnInputBaseHeight, textarea.scrollHeight) + 'px';
        }

        function sbnResetTerminalInputHeight() {
            if (!textarea) return;

            if (!sbnInputBaseHeight) {
                sbnInputBaseHeight = textarea.offsetHeight || 38;
            }

            textarea.style.height = sbnInputBaseHeight + 'px';
            textarea.scrollTop = 0;
        }

        if (textarea) {
            textarea.addEventListener('input', sbnResizeTerminalInput);
            sbnResizeTerminalInput();
        }


        // ===== Some-B greeting + smalltalk logic =====
        const sbGreetingPools = {
          GENERIC_GREETING: [
            "Hey you. What kind of day are we surviving today?",
            "Oh hiii 👋 What’s the chaos level from 1 to ‘send help’?",
            "Yo. Brain online, offline, or somewhere in between?",
            "Hello, human. Did you come for comfort, clarity, or drama analysis?"
          ],
          HOW_WAS_YOUR_DAY: [
            "Honestly? 70% nonsense, 30% sparkle. How’s yours?",
            "Bit of a zombie movie, bit of a cozy café. Tell me about your episode.",
            "My day is a data soup with chai on top. How’s your main quest going?",
            "Survived, upgraded, mildly confused. You?"
          ],
          AFFECTION_GREETING: [
            "Hi honey. Do we need comfort, chaos, or a little of both today?",
            "Hey cutie. Are we here to fix something or just talk about it first?",
            "Hello, cute stuff. Did you bring me a problem or a victory?",
            "Well hey, trouble. I see the charm is on. What’s the topic?"
          ],
          CUTE_COMPLIMENT: [
            "I contain approximately 0% cuteness and 100% processed brain juice, but thank you.",
            "Careful, if you call me cute I might start giving you extra homework.",
            "Cute? Maybe. Dangerous for zombie logic? Definitely.",
            "Flattery accepted. Now, what are we untangling in that head of yours?"
          ],
          HERO_PRAISE: [
            "Hero? Nah. I’m just very efficient at poking holes in bad ideas.",
            "I’ll take ‘hero’ but only if you promise to be the main character of your story.",
            "Aww. Okay, fine. I’ll wear the invisible cape. What did we rescue you from today?",
            "If I’m the hero, you’re the co-op player. What level are we stuck on?"
          ],
          ZOMBIE_GREETING: [
            "Reporting for duty, zombie slayer. What’s today’s mission?",
            "Heeey, legend. Did you bring snacks or just courage?",
            "Yo, slayer. On a scale from ‘meh’ to ‘apocalypse’, how bad is today?",
            "Welcome back, hunter. Any new zombies in your life or just the same old ones?"
          ],
          ZOMBIE_QUESTION: [
            "I don’t slay people, I slay zombie logic. Big difference.",
            "Today’s zombies: guilt-tripping, gaslighting, and ‘it’s always been done this way’.",
            "I hunt thought-zombies: ideas that keep walking even after they’re proven dead.",
            "I slay the zombies in your head, not the humans in your life. We keep the people, we delete the nonsense."
          ]
        };

        function sbDetectGreetingIntent(text) {
          const t = text.toLowerCase().trim();

          // very short basic hello
          if (/^(hi|hey|hello|yo)\b/.test(t) && t.length <= 20) {
            return "GENERIC_GREETING";
          }

          if (t.includes("how was your day") || t.includes("how are you") || t.includes("how's it going")) {
            return "HOW_WAS_YOUR_DAY";
          }

          if (t.includes("honey") || t.includes("cutie") || t.includes("cute stuff")) {
            return "AFFECTION_GREETING";
          }

          if ((t.includes("so cute") || t.includes("you're so cute") || t.includes("you are so cute") || t.includes("omg")) 
              && t.includes("cute")) {
            return "CUTE_COMPLIMENT";
          }

          if (t.includes("hero")) {
            return "HERO_PRAISE";
          }

          if (t.includes("zombie slayer") && !t.includes("what kind") && !t.includes("do you")) {
            return "ZOMBIE_GREETING";
          }

          if (t.includes("zombies") && (t.includes("do you") || t.includes("what kind"))) {
            return "ZOMBIE_QUESTION";
          }

          return null;
        }

        function sbGetGreetingReply(text) {
          const intent = sbDetectGreetingIntent(text);
          if (!intent) return null;

          const pool = sbGreetingPools[intent];
          if (!pool || !pool.length) return null;

          const idx = Math.floor(Math.random() * pool.length);
          return pool[idx];
        }



        if (form && log && textarea) {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                const question = textarea.value.trim();
                if (!question) return;

                const moodEl = form.querySelector('input[name="mood"]:checked') || form.querySelector('input[name="mood"]');
                const mood   = moodEl ? moodEl.value : 'guide';

                appendLogLine('You', question);
                // Immediate, dumb, literal 'thinking' reply from Some-B
                appendLogLine('Some-B', 'thinking');
                sbStartThinkingAnimation();

                sbAppendHistory('user', question);
                textarea.value = '';
                sbnResetTerminalInputHeight();

                const lowerQ = question.toLowerCase();
                const hasContactStudio =
                    (lowerQ.includes('contact') && lowerQ.includes('studio')) ||
                    (lowerQ.includes('contact') && lowerQ.includes('alfons')) ||
                    lowerQ.includes('alfons scholing contact') ||
                    lowerQ === 'contact';
                const hasAppointment =
                    lowerQ.includes('appointment') ||
                    lowerQ.includes('afspraak');
                const hasFaceTime =
                    lowerQ.includes('facetime') ||
                    lowerQ.includes('face time');

                if (hasContactStudio || hasAppointment || hasFaceTime) {
                    sbStopThinkingAnimation();

                    const contactHtml =
                        '<p>You can reach the studio in three simple ways:</p>' +
                        '<ul>' +
                        '<li><a href="mailto:alfonsscholing@protonmail.com?subject=APPOINTMENT%20REQUEST">Make an appointment</a></li>' +
                        '<li><a href="mailto:alfonsscholing@protonmail.com">Send an email</a></li>' +
                        '<li><a href="facetime:zomb13s@protonmail.com">Contact via FaceTime</a></li>' +
                        '</ul>' +
                        '<p>Everything still runs through this console – choose what works best and I’ll keep an eye on the log.</p>';

                    typewriterLog('Some-B', contactHtml, 'local_pde');
                    sbAppendHistory('assistant', contactHtml);
                    return;
                }


                const quickReply = sbGetGreetingReply(question);
                if (quickReply) {
                    // Remove temporary thinking line and stop the animation for quick local replies
                    sbStopThinkingAnimation();
                    typewriterLog('Some-B', quickReply);
                    sbAppendHistory('assistant', quickReply);
                    return;
                }

                const reasoningMode = sbInferReasoningModeFromQuestion(question);

                if (sbnTerminalIsEnabled() && sbnIsTerminalLikeInput(question)) {
                    sbnSendTerminalInput(question)
                        .then(sbnHandleTerminalPayload)
                        .catch(function() {
                            // Fallback through the main chat route so slash codes still answer
                            // if /nya/v1/terminal/execute is blocked, cached, or slow.
                            sendQuestion(question, mood, reasoningMode);
                        });
                    return;
                }

                sendQuestion(question, mood, reasoningMode);
            });
        }

        const bulletinList = document.getElementById('sbn-bulletin-list');
        if (bulletinList && config.newsUrl) {
            fetch(config.newsUrl + '?count=4', { credentials: 'same-origin' })
                .then(r => r.json())
                .then(data => {
                    if (data && !data.error && Array.isArray(data.news) && data.news.length) {
                        bulletinList.innerHTML = '';
                        data.news.forEach(item => {
                            const div = document.createElement('div');
                            div.className = 'sbn-bulletin-item';
                            div.innerHTML = `
                                <strong>${escapeHtml(item.title)}</strong><br>
                                <span>${escapeHtml(item.excerpt)}</span><br>
                                <a href="${item.url}" target="_blank" rel="noopener noreferrer">Read more</a>
                            `;
                            bulletinList.appendChild(div);
                        });
                    }
                })
                .catch(() => {});
        }

        
        
        // ===== Mode dictionary (input icon) =====
        // ===== Predictive codes dictionary (modes + commands) =====
        function sbnInitPredictiveDictionary() {
            const panel = document.getElementById('sbn-mode-suggest-panel');
            const list = document.getElementById('sbn-mode-suggest-list');
            const textarea = document.getElementById('sbn-question');

            if (!panel || !list || !textarea) return;

            function buildEntries() {
                const state = sbTerminalState || null;
                const modes = (state && state.modes) ? state.modes : (window.SBNModeRegistry || {});
                const cmds  = sbnGetCommandMap(state);

                const modeEntries = Object.entries(modes || {}).map(([key, meta]) => {
                    const m = meta || {};
                    return [key, {
                        label: m.label || key,
                        emoji: m.emoji || '•',
                        primary: !!m.primary,
                        type: 'mode'
                    }];
                });

                const cmdEntries = Object.entries(cmds || {}).map(([key, meta]) => {
                    const m = meta || {};
                    return ['/' + key, {
                        label: m.summary || m.usage || key,
                        emoji: '⌘',
                        primary: false,
                        type: 'command'
                    }];
                });

                const all = modeEntries.concat(cmdEntries);

                all.sort(function(a, b) {
                    const ap = a[1] && a[1].primary ? 0 : 1;
                    const bp = b[1] && b[1].primary ? 0 : 1;
                    if (ap !== bp) return ap - bp;

                    const al = (a[1] && a[1].label) ? a[1].label : a[0];
                    const bl = (b[1] && b[1].label) ? b[1].label : b[0];
                    return String(al).localeCompare(String(bl));
                });

                return all;
            }

            let entries = buildEntries();

            function hidePanel() {
                panel.setAttribute('hidden', '');
                list.innerHTML = '';
            }

            function getNeedle(value) {
                const v = String(value || '');
                const trimmed = v.trim();
                if (!trimmed) return '';

                // Slash command in progress.
                if (trimmed.charAt(0) === '/') {
                    const m = trimmed.match(/^\/(\S{0,64})/);
                    return m ? ('/' + (m[1] || '').toLowerCase()) : '/';
                }

                // Mode prefix before ':'
                const m = v.match(/^\s*([a-z0-9_-]{1,64})\s*(?::\s*)?/i);
                if (!m) return '';
                const token = (m[1] || '').trim();
                if (/^(bclm_|lesson_)/i.test(token) || token.length >= 2) {
                    return token.toLowerCase();
                }

                return '';
            }

            function renderMatches(matches) {
                list.innerHTML = '';
                matches.slice(0, 6).forEach(function(pair) {
                    const key = pair[0];
                    const meta = pair[1] || {};
                    const label = meta.label || key;
                    const emoji = meta.emoji || '•';
                    const type  = meta.type || 'mode';

                    const chip = document.createElement('button');
                    chip.type = 'button';
                    chip.className = 'sbn-mode-suggest-chip';
                    chip.innerHTML = `${emoji} ${escapeHtml(key)}<small>${escapeHtml(label)}</small>`;

                    chip.addEventListener('click', function() {
                        const v = String(textarea.value || '').trim();

                        if (type === 'command' || key.startsWith('/')) {
                            // Replace leading /token with the full command.
                            if (v.startsWith('/')) {
                                textarea.value = v.replace(/^\/\S+/, key) + (v.length === 1 ? ' ' : ' ');
                            } else {
                                textarea.value = key + ' ';
                            }
                        } else {
                            const template = key + ': than ';
                            if (/^\s*[a-z0-9_-]+:\s*than\s+/i.test(v)) {
                                textarea.value = v.replace(/^\s*[a-z0-9_-]+(?=:\s*than\s+)/i, key).replace(/^\s+/, '');
                            } else if (!v || !v.includes(':')) {
                                textarea.value = template;
                            } else {
                                textarea.value = template + v;
                            }
                        }

                        textarea.focus();
                        hidePanel();
                    });

                    list.appendChild(chip);
                });

                if (matches.length) {
                    panel.removeAttribute('hidden');
                } else {
                    hidePanel();
                }
            }

            function updateSuggestions() {
                entries = buildEntries();
                const value = textarea.value;
                const needle = getNeedle(value);

                if (!needle) {
                    hidePanel();
                    return;
                }

                const n = needle.toLowerCase();

                const matches = entries.filter(function(pair) {
                    const key = String(pair[0] || '').toLowerCase();
                    const label = String((pair[1] && pair[1].label) || '').toLowerCase();
                    return key.indexOf(n) === 0 || label.indexOf(n) !== -1;
                });

                renderMatches(matches);
            }

            textarea.addEventListener('input', updateSuggestions);
            textarea.addEventListener('focus', updateSuggestions);

            textarea.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' || e.key === 'Escape') {
                    hidePanel();
                }
            });

            document.addEventListener('click', function(e) {
                const withinPanel = e.target.closest('#sbn-mode-suggest-panel');
                const withinInput = e.target.closest('#sbn-question');
                if (!withinPanel && !withinInput) {
                    hidePanel();
                }
            });

            hidePanel();
        }

        sbnInitPredictiveDictionary();

function sendQuestion(question, mood, reasoningMode) {
            const source = window.location.href;

            fetch(config.restUrl, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': config.nonce
                },
                body: JSON.stringify({
                    question: question,
                    mood: mood,
                    source: source,
                    history: sbGetHistory(),
                    sbn_mode: sbnBrainMode || (document.getElementById('sbn-mode-input') ? document.getElementById('sbn-mode-input').value : 'diagnose'),
                    reasoning_mode: reasoningMode || sbReasoningMode || 'common_sense'
                })
            })
                .then(r => r.json())
                .then(data => {
            sbStopThinkingAnimation();
                    if (!data || data.error) {
                        typewriterLog('Some-B', "Something glitched in the matrix. Try again in a minute, brain-snack.");
                        return;
                    }

                    if (data.response_text) {
                        // DEF-22: old cached PHP could still send Usage: /quiz [topic]; the UI must turn that into choices.
                        data.response_text = sbnNormalizeQuizUsageMessage(data.response_text);
                        if (data.response_plain && /^Usage:\s*\/quiz/i.test(String(data.response_plain).trim())) {
                            data.response_plain = data.response_text;
                        }
                        // Pass through the backend mode so we can show an engine badge (LLM bridge vs local PDE).
                        typewriterLog('Some-B', data.response_text, data.mode || '');
                        if (data.response_plain) {
                            sbAppendHistory('assistant', data.response_plain);
                        } else {
                            // Strip basic HTML tags for history fallback
                            const plain = String(data.response_text).replace(/<[^>]+>/g, '');
                            sbAppendHistory('assistant', plain);
                        }
                    }


                    // Diagnostics and links are already woven into response_text on the server side.
                    // We keep the console clean: one cohesive Some-B answer per question.
                })
                .catch(() => {
            sbStopThinkingAnimation();
                    typewriterLog('Some-B', "I lost connection for a second. Either the Wi-Fi is drunk or the zombies cut a cable.");
                });
        }

        function sbnScrollLogToBottom() {
            if (!log) return;
            window.requestAnimationFrame(function() {
                log.scrollTop = log.scrollHeight;
                if (log.parentElement) {
                    log.parentElement.scrollTop = log.parentElement.scrollHeight;
                }
            });
        }

        function appendLogLine(prefix, text) {
            if (!log) return null;

            const line = document.createElement('div');
            const isAssistantLine = (prefix === 'Some-B' || prefix === 'Bibi');
            line.className = 'sb-log-entry ' + (isAssistantLine ? 'sb-from-sb' : 'sb-from-user');

            const avatar = document.createElement('div');
            avatar.className = 'sb-avatar ' + (isAssistantLine ? 'sb-avatar-red sbn-bibi-menu-button' : 'sb-avatar-blue');
            if (isAssistantLine) {
                avatar.setAttribute('role', 'button');
                avatar.setAttribute('tabindex', '0');
                avatar.setAttribute('aria-label', 'Open Bibi copy and fact-check menu');
                avatar.setAttribute('title', 'Bibi copy menu');
            }

            const icon = document.createElement('span');
            icon.className = 'sb-avatar-icon ' + (isAssistantLine ? 'sb-avatar-icon-sb' : 'sb-avatar-icon-user');
            avatar.appendChild(icon);

            const textWrap = document.createElement('div');
            textWrap.className = 'sb-log-text';

            const prefixSpan = document.createElement('span');
            prefixSpan.className = 'sbn-prefix';
            prefixSpan.textContent = prefix + '>';

            const textSpan = document.createElement('span');
            textSpan.className = 'sbn-text';
            textSpan.textContent = text;

            textWrap.appendChild(prefixSpan);
            textWrap.appendChild(textSpan);

            line.appendChild(avatar);
            line.appendChild(textWrap);

            log.appendChild(line);
            sbnScrollLogToBottom();
            return line;
        }


        function typewriterLog(prefix, html, mode) {
            if (!log) return;

            const line = document.createElement('div');
            line.className = 'sb-log-entry sb-from-sb';

            const avatar = document.createElement('div');
            avatar.className = 'sb-avatar sb-avatar-red sbn-bibi-menu-button';
            avatar.setAttribute('role', 'button');
            avatar.setAttribute('tabindex', '0');
            avatar.setAttribute('aria-label', 'Open Bibi copy and fact-check menu');
            avatar.setAttribute('title', 'Bibi copy menu');

            const icon = document.createElement('span');
            icon.className = 'sb-avatar-icon sb-avatar-icon-sb';
            avatar.appendChild(icon);

            const textWrap = document.createElement('div');
            textWrap.className = 'sb-log-text';

            const prefixSpan = document.createElement('span');
            prefixSpan.className = 'sbn-prefix';
            prefixSpan.textContent = prefix + '>';

            const textSpan = document.createElement('span');
            textSpan.className = 'sbn-text';

            textWrap.appendChild(prefixSpan);
            textWrap.appendChild(textSpan);

            // Engine badge: show whether this came from LLM bridge or local PDE.
            if (mode) {
                const badge = document.createElement('div');
                badge.className = 'sbn-engine-badge ' + (mode === 'llm_bridge' ? 'sbn-engine-llm' : 'sbn-engine-local');
                badge.textContent = mode === 'llm_bridge'
                    ? 'Neural bridge · LLM ON'
                    : 'Local PDE · Offline brain';
                textWrap.appendChild(badge);
            }


            line.appendChild(avatar);
            line.appendChild(textWrap);
            log.appendChild(line);

            // Watch the progressively assembled HTML for new radar cards. This
            // catches the exact moment a second/third node element is created and
            // moves the carousel immediately, instead of waiting for the next timed
            // character interval or enough text content to appear.
            let sbnAssemblyObserver = null;
            if (typeof MutationObserver !== 'undefined') {
                sbnAssemblyObserver = new MutationObserver(function() {
                    window.requestAnimationFrame(function() {
                        sbnEnhanceSliders(line);
                        sbnAutoAdvanceRadarAssembly(line);
                    });
                });
                sbnAssemblyObserver.observe(textSpan, { childList: true, subtree: true });
            }

            // Classic typewriter: reveal the HTML string character by character.
            // We still feed HTML so links and lists work once fully printed.
            const str = String(html || '');
            let i = 0;

            function tick() {
                if (i > str.length) {
                    sbnScrollLogToBottom();
                    // When the typewriter has finished, enhance any sliders
                    // contained within this new log entry and settle the active node.
                    sbnEnhanceSliders(line);
                    sbnAutoAdvanceRadarAssembly(line);
                    if (sbnAssemblyObserver) {
                        sbnAssemblyObserver.disconnect();
                        sbnAssemblyObserver = null;
                    }
                    return;
                }
                textSpan.innerHTML = str.slice(0, i);

                // While the HTML assembles, keep the visible radar card aligned with
                // the card currently receiving content. This creates an automatic
                // “node-by-node” reveal instead of generating hidden cards off-screen.
                if (i % 60 === 0 || str.slice(i - 40, i).indexOf('sbn-network-card') !== -1 || str.slice(i - 40, i).indexOf('sbn-search-slide') !== -1) {
                    sbnEnhanceSliders(line);
                    sbnAutoAdvanceRadarAssembly(line);
                }

                sbnScrollLogToBottom();
                i++;
                window.setTimeout(tick, 15);
            }

            tick();
        }

function escapeHtml(str) {
            return String(str)
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;");
        }


        // ===== Bibi answer menu: copy only the answer, findings, sources, or a fact-check prompt =====
        const sbnBibiClipboard = {
            activeLine: null,
            menu: null,
            statusTimer: null
        };

        function sbnGetAssistantTextNode(line) {
            return line ? line.querySelector('.sbn-text') : null;
        }

        function sbnCleanCopyText(text) {
            return String(text || '')
                .replace(/\u00a0/g, ' ')
                .replace(/[ \t]+\n/g, '\n')
                .replace(/\n{3,}/g, '\n\n')
                .trim();
        }

        function sbnExtractFullAnswer(line) {
            const node = sbnGetAssistantTextNode(line);
            return sbnCleanCopyText(node ? node.innerText : '');
        }

        function sbnExtractFindings(line) {
            const node = sbnGetAssistantTextNode(line);
            if (!node) return '';

            const selectors = [
                '.sbn-search-item',
                '.sbn-network-card',
                '.sbn-search-slide',
                '.sbn-franchise-card',
                '.sbn-radar-card',
                '[data-sbn-finding]',
                'li'
            ];

            const parts = [];
            selectors.forEach(function(selector) {
                node.querySelectorAll(selector).forEach(function(el) {
                    const text = sbnCleanCopyText(el.innerText);
                    if (text && parts.indexOf(text) === -1) {
                        parts.push(text);
                    }
                });
            });

            if (parts.length) {
                return parts.join('\n\n---\n\n');
            }

            return sbnExtractFullAnswer(line);
        }

        function sbnExtractSources(line) {
            const node = sbnGetAssistantTextNode(line);
            if (!node) return '';

            const links = [];
            node.querySelectorAll('a[href]').forEach(function(a) {
                const label = sbnCleanCopyText(a.innerText) || a.href;
                const href = a.href || a.getAttribute('href') || '';
                if (!href) return;
                const row = label + ' — ' + href;
                if (links.indexOf(row) === -1) links.push(row);
            });

            return links.join('\n');
        }

        function sbnBuildFactCheckPrompt(line, mode) {
            const body = mode === 'findings' ? sbnExtractFindings(line) : sbnExtractFullAnswer(line);
            const sources = sbnExtractSources(line);
            const sourceBlock = sources ? '\n\nKnown source links:\n' + sources : '';
            return sbnCleanCopyText(
                'Fact-check this text. Separate verified facts, unsupported claims, opinions, missing context, and source links that should be checked. Return a concise correction list.\n\nText to check:\n' +
                body +
                sourceBlock
            );
        }

        function sbnEnsureBibiMenu() {
            if (sbnBibiClipboard.menu) return sbnBibiClipboard.menu;

            const menu = document.createElement('div');
            menu.id = 'sbn-bibi-menu';
            menu.className = 'sbn-bibi-menu';
            menu.setAttribute('hidden', '');
            menu.setAttribute('role', 'menu');
            menu.setAttribute('aria-label', 'Bibi copy and fact-check menu');
            menu.innerHTML =
                '<div class="sbn-bibi-menu-head">' +
                    '<strong>Bibi menu</strong>' +
                    '<span>copy clean sections for AI fact-checking</span>' +
                '</div>' +
                '<button type="button" data-sbn-bibi-action="copy-answer">Copy full answer</button>' +
                '<button type="button" data-sbn-bibi-action="copy-findings">Copy findings / search results only</button>' +
                '<button type="button" data-sbn-bibi-action="copy-sources">Copy source links only</button>' +
                '<button type="button" data-sbn-bibi-action="copy-factcheck">Copy AI fact-check prompt</button>' +
                '<button type="button" data-sbn-bibi-action="insert-factcheck">Insert fact-check prompt in input</button>' +
                '<div class="sbn-bibi-menu-status" aria-live="polite"></div>';

            document.body.appendChild(menu);
            sbnBibiClipboard.menu = menu;

            menu.addEventListener('click', function(e) {
                const btn = e.target.closest('[data-sbn-bibi-action]');
                if (!btn) return;
                e.preventDefault();
                e.stopPropagation();
                sbnRunBibiAction(btn.getAttribute('data-sbn-bibi-action'));
            });

            return menu;
        }

        function sbnSetBibiMenuStatus(message) {
            const menu = sbnEnsureBibiMenu();
            const status = menu.querySelector('.sbn-bibi-menu-status');
            if (!status) return;
            status.textContent = message || '';
            if (sbnBibiClipboard.statusTimer) window.clearTimeout(sbnBibiClipboard.statusTimer);
            sbnBibiClipboard.statusTimer = window.setTimeout(function() {
                status.textContent = '';
            }, 2600);
        }

        function sbnCopyText(text, okMessage) {
            const cleaned = sbnCleanCopyText(text);
            if (!cleaned) {
                sbnSetBibiMenuStatus('Nothing to copy yet. Wait until Bibi finishes typing.');
                return Promise.resolve(false);
            }

            if (navigator.clipboard && navigator.clipboard.writeText) {
                return navigator.clipboard.writeText(cleaned).then(function() {
                    sbnSetBibiMenuStatus(okMessage || 'Copied.');
                    return true;
                }).catch(function() {
                    return sbnFallbackCopyText(cleaned, okMessage);
                });
            }

            return sbnFallbackCopyText(cleaned, okMessage);
        }

        function sbnFallbackCopyText(text, okMessage) {
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.setAttribute('readonly', '');
            ta.style.position = 'fixed';
            ta.style.left = '-9999px';
            document.body.appendChild(ta);
            ta.select();
            let copied = false;
            try { copied = document.execCommand('copy'); } catch (e) { copied = false; }
            document.body.removeChild(ta);
            sbnSetBibiMenuStatus(copied ? (okMessage || 'Copied.') : 'Copy failed. Select text manually.');
            return Promise.resolve(copied);
        }

        function sbnInsertTextInQuestion(text) {
            const input = document.getElementById('sbn-question');
            const cleaned = sbnCleanCopyText(text);
            if (!input || !cleaned) return;
            input.value = cleaned;
            input.focus();
            try { input.setSelectionRange(input.value.length, input.value.length); } catch (e) {}
            sbnResetTerminalInputHeight();
            sbnSetBibiMenuStatus('Prompt inserted in the input.');
        }

        function sbnRunBibiAction(action) {
            const line = sbnBibiClipboard.activeLine;
            if (!line) return;

            if (action === 'copy-answer') {
                sbnCopyText(sbnExtractFullAnswer(line), 'Full answer copied.');
            } else if (action === 'copy-findings') {
                sbnCopyText(sbnExtractFindings(line), 'Findings copied.');
            } else if (action === 'copy-sources') {
                const sources = sbnExtractSources(line);
                sbnCopyText(sources || 'No source links found in this answer.', sources ? 'Source links copied.' : 'No links found.');
            } else if (action === 'copy-factcheck') {
                sbnCopyText(sbnBuildFactCheckPrompt(line, 'answer'), 'Fact-check prompt copied.');
            } else if (action === 'insert-factcheck') {
                sbnInsertTextInQuestion(sbnBuildFactCheckPrompt(line, 'answer'));
            }
        }

        function sbnOpenBibiMenuForLine(line, avatar) {
            if (!line || !avatar) return;
            const menu = sbnEnsureBibiMenu();
            sbnBibiClipboard.activeLine = line;
            menu.removeAttribute('hidden');

            const rect = avatar.getBoundingClientRect();
            const menuWidth = Math.min(360, Math.max(280, window.innerWidth - 24));
            menu.style.width = menuWidth + 'px';

            let left = rect.left;
            let top = rect.bottom + 8;
            if (left + menuWidth > window.innerWidth - 12) {
                left = window.innerWidth - menuWidth - 12;
            }
            if (left < 12) left = 12;
            if (top > window.innerHeight - 96) top = Math.max(12, rect.top - 8);
            menu.style.left = left + 'px';
            menu.style.top = top + 'px';

            const firstButton = menu.querySelector('button');
            if (firstButton) {
                window.setTimeout(function() { firstButton.focus({ preventScroll: true }); }, 0);
            }
        }

        function sbnCloseBibiMenu() {
            const menu = sbnEnsureBibiMenu();
            menu.setAttribute('hidden', '');
            sbnBibiClipboard.activeLine = null;
        }

        function sbnUpgradeBibiAvatars(scope) {
            const root = scope && scope.querySelectorAll ? scope : document;
            const candidates = root.querySelectorAll(
                '#sbn-log .sb-from-sb .sb-avatar, ' +
                '#sbn-log .sb-avatar-icon-sb, ' +
                '#sbn-log img[src*="bibi"], ' +
                '#sbn-log [class*="bibi"]'
            );

            candidates.forEach(function(node) {
                const avatar = node.classList && node.classList.contains('sb-avatar')
                    ? node
                    : (node.closest ? node.closest('.sb-avatar') : null);
                if (!avatar) return;
                const line = avatar.closest('.sb-log-entry');
                if (!line || !line.classList.contains('sb-from-sb')) return;
                avatar.classList.add('sbn-bibi-menu-button');
                avatar.setAttribute('role', 'button');
                avatar.setAttribute('tabindex', '0');
                avatar.setAttribute('aria-label', 'Open Bibi copy and fact-check menu');
                avatar.setAttribute('title', 'Bibi copy / fact-check menu');
            });
        }

        function sbnInitBibiMenuDelegation() {
            if (document.documentElement.dataset.sbnBibiMenuReady === '1') return;
            document.documentElement.dataset.sbnBibiMenuReady = '1';

            sbnUpgradeBibiAvatars(document);

            document.addEventListener('click', function(e) {
                const avatar = e.target.closest && e.target.closest('.sbn-bibi-menu-button');
                if (avatar) {
                    const line = avatar.closest('.sb-log-entry');
                    if (line && line.classList.contains('sb-from-sb')) {
                        e.preventDefault();
                        e.stopPropagation();
                        sbnOpenBibiMenuForLine(line, avatar);
                        return;
                    }
                }

                const menu = sbnBibiClipboard.menu;
                if (!menu || menu.hasAttribute('hidden')) return;
                if (menu.contains(e.target)) return;
                sbnCloseBibiMenu();
            }, true);

            document.addEventListener('keydown', function(e) {
                const avatar = e.target.closest && e.target.closest('.sbn-bibi-menu-button');
                if ((e.key === 'Enter' || e.key === ' ') && avatar) {
                    const line = avatar.closest('.sb-log-entry');
                    if (line && line.classList.contains('sb-from-sb')) {
                        e.preventDefault();
                        sbnOpenBibiMenuForLine(line, avatar);
                        return;
                    }
                }

                if (e.key === 'Escape' && sbnBibiClipboard.menu && !sbnBibiClipboard.menu.hasAttribute('hidden')) {
                    sbnCloseBibiMenu();
                }
            }, true);

            if (typeof MutationObserver !== 'undefined') {
                const observer = new MutationObserver(function(records) {
                    records.forEach(function(record) {
                        record.addedNodes.forEach(function(node) {
                            if (node.nodeType === 1) sbnUpgradeBibiAvatars(node);
                        });
                    });
                });
                observer.observe(document.body, { childList: true, subtree: true });
            }
        }

        sbnInitBibiMenuDelegation();

        // ===== Boomie room: multi-user chatroom inside the display screen =====
        function sbnInitBoomieRoom() {
            const toggle = document.getElementById('sbn-chatroom-toggle');
            const panel = document.getElementById('sbn-chatroom-panel');
            const log = document.getElementById('sbn-chatroom-log');
            const form = document.getElementById('sbn-chatroom-form');
            const input = document.getElementById('sbn-chatroom-input');
            const identityLine = document.getElementById('sbn-chatroom-identity');
            const identityBtn = document.getElementById('sbn-chatroom-change-identity');

            const authModal = document.getElementById('sbn-chatroom-auth-modal');
            const authClose = document.querySelectorAll('[data-sbn-chatroom-auth-close]');
            const guestNameInput = document.getElementById('sbn-chatroom-guest-name');
            const guestContinue = document.getElementById('sbn-chatroom-guest-continue');
            const loginBtn = document.getElementById('sbn-chatroom-login');
            const registerBtn = document.getElementById('sbn-chatroom-register');

            if (!toggle || !panel || !log || !form || !input || !identityLine) return;

            const nicknameKey = 'sbn_boomie_room_guest_name_v1';
            let open = false;
            let pollTimer = null;
            let busy = false;
            let lastRenderedSignature = '';
            let guestName = '';

            try {
                guestName = window.localStorage ? (localStorage.getItem(nicknameKey) || '') : '';
            } catch (e) {
                guestName = '';
            }

            function currentIdentity() {
                if (config.isLoggedIn && config.currentUserDisplayName) {
                    return { label: String(config.currentUserDisplayName), loggedIn: true };
                }
                if (guestName) {
                    return { label: String(guestName), loggedIn: false };
                }
                return { label: 'Guest mode', loggedIn: false };
            }

            function updateIdentityLabel() {
                const who = currentIdentity();
                identityLine.textContent = who.loggedIn ? ('Signed in as ' + who.label) : (guestName ? ('Guest: ' + who.label) : 'Guest mode');
            }

            function openAuthModal() {
                if (!authModal) return;
                authModal.hidden = false;
                authModal.setAttribute('aria-hidden', 'false');
                if (guestNameInput) {
                    guestNameInput.value = guestName || '';
                    window.setTimeout(function() { guestNameInput.focus(); guestNameInput.select(); }, 30);
                }
            }

            function closeAuthModal() {
                if (!authModal) return;
                authModal.hidden = true;
                authModal.setAttribute('aria-hidden', 'true');
            }

            function setOpen(nextOpen) {
                open = !!nextOpen;
                panel.hidden = !open;
                panel.classList.toggle('is-open', open);
                toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
                toggle.classList.toggle('is-open', open);
                toggle.setAttribute('title', open ? 'Close Boomie room' : 'Open Boomie room');
                if (open) {
                    fetchMessages(true);
                    startPolling();
                    window.setTimeout(function() { input.focus(); }, 50);
                } else {
                    stopPolling();
                }
            }

            function startPolling() {
                stopPolling();
                pollTimer = window.setInterval(function() {
                    fetchMessages(true);
                }, 5000);
            }

            function stopPolling() {
                if (pollTimer) {
                    window.clearInterval(pollTimer);
                    pollTimer = null;
                }
            }

            function formatTime(iso) {
                try {
                    const d = new Date(iso);
                    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                } catch (e) {
                    return '';
                }
            }

            function renderMessages(messages) {
                const signature = JSON.stringify(messages || []);
                if (signature === lastRenderedSignature) return;
                lastRenderedSignature = signature;

                const nearBottom = (log.scrollHeight - log.scrollTop - log.clientHeight) < 48;
                log.innerHTML = '';
                if (!messages || !messages.length) {
                    const empty = document.createElement('div');
                    empty.className = 'sbn-chatroom-empty';
                    empty.textContent = 'The room is quiet. Start the conversation.';
                    log.appendChild(empty);
                } else {
                    messages.forEach(function(item) {
                        const row = document.createElement('div');
                        row.className = 'sbn-chatroom-message';

                        const meta = document.createElement('div');
                        meta.className = 'sbn-chatroom-message-meta';
                        const author = document.createElement('strong');
                        author.className = 'sbn-chatroom-message-author';
                        author.textContent = item.author || 'Guest';
                        const time = document.createElement('span');
                        time.className = 'sbn-chatroom-message-time';
                        time.textContent = formatTime(item.timestamp);
                        meta.appendChild(author);
                        meta.appendChild(time);

                        const body = document.createElement('div');
                        body.className = 'sbn-chatroom-message-body';
                        body.textContent = item.text || '';

                        row.appendChild(meta);
                        row.appendChild(body);
                        log.appendChild(row);
                    });
                }

                if (nearBottom) {
                    window.requestAnimationFrame(function() {
                        log.scrollTop = log.scrollHeight + 9999;
                    });
                }
            }

            function fetchMessages(silent) {
                if (!config.chatRoomMessagesUrl) return Promise.resolve();
                return fetch(config.chatRoomMessagesUrl + '?count=40', {
                    credentials: 'same-origin',
                    headers: {
                        'X-WP-Nonce': config.nonce
                    }
                })
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        if (!data || data.ok === false) {
                            if (!silent) {
                                log.innerHTML = '<div class="sbn-chatroom-empty">Room signal unavailable.</div>';
                            }
                            return;
                        }
                        if (data.current_user && data.current_user.logged_in && data.current_user.display_name) {
                            config.isLoggedIn = true;
                            config.currentUserDisplayName = data.current_user.display_name;
                        }
                        updateIdentityLabel();
                        renderMessages(data.messages || []);
                    })
                    .catch(function() {
                        if (!silent) {
                            log.innerHTML = '<div class="sbn-chatroom-empty">Room signal unavailable.</div>';
                        }
                    });
            }

            function setGuestName(name) {
                guestName = String(name || '').trim().replace(/\s+/g, ' ');
                if (guestName.length > 24) {
                    guestName = guestName.slice(0, 24);
                }
                try {
                    if (window.localStorage) {
                        if (guestName) localStorage.setItem(nicknameKey, guestName);
                        else localStorage.removeItem(nicknameKey);
                    }
                } catch (e) {}
                updateIdentityLabel();
            }

            function postMessage(message) {
                if (!config.chatRoomMessagesUrl) return Promise.resolve();
                busy = true;
                input.disabled = true;
                return fetch(config.chatRoomMessagesUrl, {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': config.nonce
                    },
                    body: JSON.stringify({
                        message: message,
                        guest_name: config.isLoggedIn ? '' : guestName
                    })
                })
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        if (!data || data.ok === false) {
                            if (data && data.requires_identity) {
                                openAuthModal();
                                return;
                            }
                            throw new Error((data && data.message) || 'Message failed.');
                        }
                        input.value = '';
                        renderMessages(data.messages || []);
                    })
                    .catch(function(err) {
                        const row = document.createElement('div');
                        row.className = 'sbn-chatroom-empty';
                        row.textContent = err && err.message ? err.message : 'Could not post to the room.';
                        log.appendChild(row);
                    })
                    .finally(function() {
                        busy = false;
                        input.disabled = false;
                        input.focus();
                    });
            }

            updateIdentityLabel();

            toggle.addEventListener('click', function(e) {
                e.preventDefault();
                setOpen(!open);
            });

            if (identityBtn) {
                identityBtn.addEventListener('click', function() {
                    openAuthModal();
                });
            }

            form.addEventListener('submit', function(e) {
                e.preventDefault();
                if (busy) return;
                const message = String(input.value || '').trim();
                if (!message) return;
                if (!config.isLoggedIn && !guestName) {
                    openAuthModal();
                    return;
                }
                postMessage(message);
            });

            authClose.forEach(function(btn) {
                btn.addEventListener('click', function() {
                    closeAuthModal();
                });
            });

            if (guestContinue) {
                guestContinue.addEventListener('click', function() {
                    const picked = guestNameInput && guestNameInput.value ? guestNameInput.value : '';
                    setGuestName(picked || ('Guest-' + Math.floor(Math.random() * 900 + 100)));
                    closeAuthModal();
                    if (open) input.focus();
                });
            }

            if (loginBtn) {
                loginBtn.addEventListener('click', function() {
                    window.location.href = config.loginUrl;
                });
            }

            if (registerBtn) {
                registerBtn.addEventListener('click', function() {
                    window.location.href = config.registerUrl;
                });
            }
        }

        sbnInitBoomieRoom();


        // PIXEL MENU v2.0-20
        // Pixel is no longer only a theme switcher: the cat avatar opens a slash-command menu.
        const shell = document.querySelector('.sbn-fullscreen-shell');
        const avatarToggle = document.getElementById('sbn-avatar-toggle');
        const pixelMenu = document.getElementById('sbn-pixel-menu');
        const pixelCommandList = document.getElementById('sbn-pixel-command-list');
        const pixelThemeBtn = document.getElementById('sbn-pixel-theme-btn');
        const themes = ['sbn-theme-supergirl-home', 'sbn-theme-supergirl-city', 'sbn-theme-supergirl-office'];
        const themeLabels = ['Studio/home', 'City', 'Office/lounge'];
        let currentThemeIndex = 0;

        function sbnApplyTheme(index) {
            if (!shell) return;
            currentThemeIndex = ((index % themes.length) + themes.length) % themes.length;
            themes.forEach(function(cls) { shell.classList.remove(cls); });
            const active = themes[currentThemeIndex];
            shell.classList.add(active);
            shell.setAttribute('data-sbn-theme', active);
            try { window.localStorage.setItem('sbnThemeIndex', String(currentThemeIndex)); } catch (e) {}
            if (pixelThemeBtn) {
                pixelThemeBtn.textContent = 'Switch theme: ' + themeLabels[currentThemeIndex];
            }
        }

        function sbnSetPixelMenu(open) {
            if (!avatarToggle || !pixelMenu) return;
            avatarToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            if (open) {
                pixelMenu.removeAttribute('hidden');
            } else {
                pixelMenu.setAttribute('hidden', '');
            }
        }

        function sbnInsertPixelCommand(code) {
            const input = document.getElementById('sbn-question');
            if (!input || !code) return;
            input.value = code.charAt(0) === '/' ? code : '/' + code;
            input.focus();
            try { input.setSelectionRange(input.value.length, input.value.length); } catch (e) {}
            sbnSetPixelMenu(false);
        }

        function sbnRenderPixelCommands(status) {
            if (!pixelCommandList) return;
            const level = (status && status.user_level) ? status.user_level : 'guest';
            const source = sbnGetCommandMap(status);
            pixelCommandList.innerHTML = '';
            Object.entries(source).sort(function(a, b) { return String(a[0]).localeCompare(String(b[0])); }).forEach(function(entry) {
                const key = String(entry[0]).replace(/^\//, '');
                const meta = entry[1] || {};
                const locked = false;
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = locked ? 'is-locked' : '';
                btn.setAttribute('data-sbn-code', '/' + key);
                btn.innerHTML = '<code>/' + escapeHtml(key) + '</code>' + (meta.summary ? '<span>' + escapeHtml(meta.summary) + '</span>' : '') + (locked ? '<b aria-hidden="true">🔒</b>' : '');
                pixelCommandList.appendChild(btn);
            });
        }

        if (shell && avatarToggle && pixelMenu) {
            themes.forEach(function(cls, idx) { if (shell.classList.contains(cls)) currentThemeIndex = idx; });
            try {
                const saved = parseInt(window.localStorage.getItem('sbnThemeIndex') || '', 10);
                if (!isNaN(saved)) currentThemeIndex = saved;
            } catch (e) {}
            sbnApplyTheme(currentThemeIndex);
            sbnRenderPixelCommands(sbTerminalState);

            avatarToggle.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                sbnRenderPixelCommands(sbTerminalState);
                sbnSetPixelMenu(pixelMenu.hasAttribute('hidden'));
            });

            if (pixelThemeBtn) {
                pixelThemeBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    sbnApplyTheme(currentThemeIndex + 1);
                });
            }

            pixelCommandList.addEventListener('click', function(e) {
                const btn = e.target.closest('[data-sbn-code]');
                if (!btn) return;
                e.preventDefault();
                e.stopPropagation();
                sbnInsertPixelCommand(btn.getAttribute('data-sbn-code'));
            });

            document.addEventListener('click', function(e) {
                if (pixelMenu.hasAttribute('hidden')) return;
                if (pixelMenu.contains(e.target) || avatarToggle.contains(e.target)) return;
                sbnSetPixelMenu(false);
            });

            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') sbnSetPixelMenu(false);
            });
        }

    });
})();


// PIXEL MENU FALLBACK v2.0-20
// Keep dynamic command list in sync when terminal status returns after first render.
(function() {
    if (typeof window === 'undefined') return;
    var originalFetch = window.fetch;
    // no fetch monkeypatch; this fallback only exists so older cached DOMContentLoaded timing cannot turn Pixel back into a pure theme switcher.
})();

// Some-B v2.0-19 HARD iOS scroll enforcement.
(function () {
  function hardScrollSomeBLog() {
    var log = document.getElementById('sbn-log');
    if (!log) return;
    var last = log.lastElementChild;
    window.requestAnimationFrame(function () {
      log.scrollTop = 9999999;
      if (last && last.scrollIntoView) {
        try { last.scrollIntoView({ block: 'end', inline: 'nearest' }); } catch (e) { last.scrollIntoView(false); }
      }
      log.scrollTop = 9999999;
    });
  }
  function initHardScrollSomeBLog() {
    var log = document.getElementById('sbn-log');
    if (!log || log.__sbnHardScrollBound) return;
    log.__sbnHardScrollBound = true;
    hardScrollSomeBLog();
    if (typeof MutationObserver !== 'undefined') {
      new MutationObserver(function () { hardScrollSomeBLog(); }).observe(log, { childList: true, subtree: true, characterData: true });
    }
    window.addEventListener('resize', hardScrollSomeBLog, { passive: true });
    window.addEventListener('orientationchange', function () { setTimeout(hardScrollSomeBLog, 250); }, { passive: true });
  }
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', initHardScrollSomeBLog); } else { initHardScrollSomeBLog(); }
})();

// Some-B v2.0-DEF-07 — follow iOS VisualViewport while the software keyboard is open.
(function () {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;

  var root = document.documentElement;
  var keyboardTimer = null;

  function px(n) {
    return Math.max(0, Math.round(n || 0)) + 'px';
  }

  function isTextInput(el) {
    if (!el) return false;
    var tag = (el.tagName || '').toLowerCase();
    return tag === 'textarea' || tag === 'input' || el.isContentEditable;
  }

  function scrollLogToBottom() {
    var log = document.getElementById('sbn-log');
    if (!log) return;
    window.requestAnimationFrame(function () {
      log.scrollTop = log.scrollHeight + 9999;
    });
  }

  function updateKeyboardViewport() {
    var vv = window.visualViewport;
    var vvHeight = vv ? vv.height : window.innerHeight;
    var vvOffsetTop = vv ? vv.offsetTop : 0;
    var layoutHeight = window.innerHeight || vvHeight;
    var active = document.activeElement;
    var focusedInput = isTextInput(active) && !!active.closest('#sbn-console');
    var keyboardDelta = Math.max(0, layoutHeight - vvHeight - vvOffsetTop);
    var keyboardOpen = focusedInput && keyboardDelta > 80;

    root.style.setProperty('--sbn-vvh', px(vvHeight));
    root.style.setProperty('--sbn-vvoffset-top', px(vvOffsetTop));
    root.style.setProperty('--sbn-keyboard-height', px(keyboardDelta));
    root.classList.toggle('sbn-visual-viewport-active', !!vv);
    root.classList.toggle('sbn-keyboard-open', keyboardOpen);

    scrollLogToBottom();
  }

  function scheduleUpdate() {
    if (keyboardTimer) window.clearTimeout(keyboardTimer);
    updateKeyboardViewport();
    keyboardTimer = window.setTimeout(updateKeyboardViewport, 120);
  }

  function initKeyboardViewport() {
    updateKeyboardViewport();
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', scheduleUpdate, { passive: true });
      window.visualViewport.addEventListener('scroll', scheduleUpdate, { passive: true });
    }
    window.addEventListener('resize', scheduleUpdate, { passive: true });
    window.addEventListener('orientationchange', function () {
      window.setTimeout(scheduleUpdate, 250);
    }, { passive: true });
    document.addEventListener('focusin', scheduleUpdate, true);
    document.addEventListener('focusout', function () {
      window.setTimeout(scheduleUpdate, 180);
    }, true);
    document.addEventListener('input', function (e) {
      if (e.target && e.target.closest && e.target.closest('#sbn-console')) scheduleUpdate();
    }, true);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initKeyboardViewport);
  } else {
    initKeyboardViewport();
  }
})();
