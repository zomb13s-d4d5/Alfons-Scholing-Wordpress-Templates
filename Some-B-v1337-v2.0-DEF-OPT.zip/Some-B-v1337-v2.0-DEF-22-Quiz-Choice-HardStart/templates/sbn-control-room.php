<?php
/**
 * Template partial for Some-B Control Room (glass overlay console).
 *
 * Rendered via [sbn_control_room] shortcode.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<div class="sbn-fullscreen-shell sbn-theme-supergirl-home">

    <div class="sb-console" id="sbn-console">

        <!-- PANEL 1: LOG (with internal Boomie room toggle inside the display screen) -->
        <div class="sb-log-panel">
            <div id="sbn-log" class="sb-log sbn-log">
                <!-- First-open intro is injected dynamically by sbn-frontend.js -->
            </div>

            <div class="sbn-screen-room-anchor" aria-label="<?php echo esc_attr__( 'Boomie room tools', 'some-b-ask-the-network' ); ?>">
                <button
                    type="button"
                    id="sbn-chatroom-toggle"
                    class="sbn-chatroom-toggle"
                    aria-expanded="false"
                    aria-controls="sbn-chatroom-panel"
                    title="<?php echo esc_attr__( 'Open Boomie room', 'some-b-ask-the-network' ); ?>"
                >
                    <img
                        class="sbn-chatroom-toggle-image"
                        src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/boomie-room-toggle.png' ); ?>"
                        alt="<?php echo esc_attr__( 'Boomie boombox', 'some-b-ask-the-network' ); ?>"
                    />
                    <span class="screen-reader-text"><?php esc_html_e( 'Toggle Boomie room', 'some-b-ask-the-network' ); ?></span>
                </button>

                <section
                    id="sbn-chatroom-panel"
                    class="sbn-chatroom-panel"
                    hidden
                    aria-label="<?php echo esc_attr__( 'Boomie room chat room', 'some-b-ask-the-network' ); ?>"
                >
                    <div class="sbn-chatroom-panel-head">
                        <div>
                            <div class="sbn-chatroom-kicker"><?php esc_html_e( 'Boomie room', 'some-b-ask-the-network' ); ?></div>
                            <div id="sbn-chatroom-identity" class="sbn-chatroom-identity"><?php esc_html_e( 'Guest mode', 'some-b-ask-the-network' ); ?></div>
                        </div>
                        <button type="button" id="sbn-chatroom-change-identity" class="sbn-chatroom-identity-btn"><?php esc_html_e( 'Identity', 'some-b-ask-the-network' ); ?></button>
                    </div>

                    <div id="sbn-chatroom-log" class="sbn-chatroom-log" aria-live="polite"></div>

                    <form id="sbn-chatroom-form" class="sbn-chatroom-form" autocomplete="off">
                        <input
                            id="sbn-chatroom-input"
                            class="sbn-chatroom-input"
                            type="text"
                            maxlength="500"
                            placeholder="<?php echo esc_attr__( 'Message the room…', 'some-b-ask-the-network' ); ?>"
                        />
                        <button type="submit" class="sbn-chatroom-send"><?php esc_html_e( 'Send', 'some-b-ask-the-network' ); ?></button>
                    </form>
                </section>
            </div>
        </div>

        <!-- PANEL 2: INPUT -->
        <form id="sbn-form" class="sb-input-panel" autocomplete="off">
            <button type="button" class="sb-avatar sb-avatar-blue sb-pixel-menu-button" id="sbn-avatar-toggle" aria-label="Open Pixel command menu" aria-haspopup="true" aria-expanded="false" title="Pixel command menu">
                <span class="sb-avatar-icon sb-avatar-icon-user"></span>
            </button>
            <div id="sbn-pixel-menu" class="sbn-pixel-menu" hidden aria-label="Pixel slash command menu">
                <div class="sbn-pixel-menu-head">
                    <strong>Pixel menu</strong>
                    <span>slash commands + theme</span>
                </div>
                <button type="button" class="sbn-pixel-theme-btn" id="sbn-pixel-theme-btn">Switch theme</button>
                <div class="sbn-pixel-menu-title">Terminal commands</div>
                <div id="sbn-pixel-command-list" class="sbn-pixel-command-list">
                    <button type="button" data-sbn-code="/help"><code>/help</code><span>command map</span></button>
                    <button type="button" data-sbn-code="/quiz"><code>/quiz</code><span>design principles test</span></button>
                    <button type="button" data-sbn-code="/design-test"><code>/design-test</code><span>full design intelligence intro</span></button>
                    <button type="button" data-sbn-code="/lesson principles"><code>/lesson</code><span>design lesson</span></button>
                    <button type="button" data-sbn-code="/score"><code>/score</code><span>quiz score</span></button>
                    <button type="button" data-sbn-code="/menu"><code>/menu</code><span>Pixel slash menu</span></button>
                    <button type="button" data-sbn-code="/search"><code>/search</code><span>network search</span></button>
                    <button type="button" data-sbn-code="/scan"><code>/scan</code><span>site/network scan</span></button>
                    <button type="button" data-sbn-code="/summarize"><code>/summarize</code><span>summarize page or URL</span></button>
                    <button type="button" data-sbn-code="/addsite"><code>/addsite</code><span>submit source</span></button>
                    <button type="button" data-sbn-code="/login"><code>/login</code><span>login link</span></button>
                    <button type="button" data-sbn-code="/register"><code>/register</code><span>registration link</span></button>
                    <button type="button" data-sbn-code="/modes"><code>/modes</code><span>BCLM modes</span></button>
                    <button type="button" data-sbn-code="/bclm"><code>/bclm</code><span>BCLM concept</span></button>
                    <button type="button" data-sbn-code="/alfons"><code>/alfons</code><span>studio bio</span></button>
                    <button type="button" data-sbn-code="/randy"><code>/randy</code><span>bio</span></button>
                    <button type="button" data-sbn-code="/raf"><code>/raf</code><span>bio</span></button>
                    <button type="button" data-sbn-code="/ruben"><code>/ruben</code><span>bio</span></button>
                    <button type="button" data-sbn-code="/marcel"><code>/marcel</code><span>bio</span></button>
                    <button type="button" data-sbn-code="/design"><code>/design</code><span>values design</span></button>
                    <button type="button" data-sbn-code="/engineering"><code>/engineering</code><span>ethical engineering</span></button>
                    <button type="button" data-sbn-code="/explore" class="is-locked"><code>/explore</code><span>deep search 🔒</span></button>
                    <button type="button" data-sbn-code="/sources" class="is-locked"><code>/sources</code><span>related sources 🔒</span></button>
                    <button type="button" data-sbn-code="/compare" class="is-locked"><code>/compare</code><span>compare topics 🔒</span></button>
                    <button type="button" data-sbn-code="/claims" class="is-locked"><code>/claims</code><span>claim scan 🔒</span></button>
                    <button type="button" data-sbn-code="/rights" class="is-locked"><code>/rights</code><span>rights map 🔒</span></button>
                    <button type="button" data-sbn-code="/debug" class="is-locked"><code>/debug</code><span>health snapshot 🔒</span></button>
                </div>
            </div>

            <input type="hidden" name="sbn_mode" id="sbn-mode-input" value="diagnose" />

            <textarea
                id="sbn-question"
                name="question"
                class="sb-input"
                rows="1"
                placeholder="<?php echo esc_attr__( 'Ask Some-B (from NYA)...', 'some-b-ask-the-network' ); ?>"
                autocomplete="off"
            ></textarea>

            <!-- Mode dictionary (predictive code suggestions) -->
            <button type="button" id="sbn-mode-suggest-btn" class="sbn-mode-suggest-btn" aria-label="Mode suggestions" title="Mode suggestions">
                <span class="sbn-mode-suggest-icon" aria-hidden="true">🧠</span>
            </button>
            <div id="sbn-mode-suggest-panel" class="sbn-mode-suggest-panel" hidden>
                <div class="sbn-mode-suggest-title">Mode codes</div>
                <div id="sbn-mode-suggest-list" class="sbn-mode-suggest-list"></div>
            </div>

            <input type="hidden" name="mood" value="guide" />

            <button type="submit" class="sb-ask-btn">
                <span class="sb-ask-icon sb-ask-icon-send">
                    <?php esc_html_e( 'Ask', 'some-b-ask-the-network' ); ?>
                </span>
            </button>
        </form>

        <div class="sbn-footer-quicklinks">
            <button type="button" class="sbn-footer-link" data-sbn-preset="I want to contact the studio">
                <?php esc_html_e( 'CONTACT STUDIO', 'some-b-ask-the-network' ); ?>
            </button>
            <button type="button" class="sbn-footer-link" data-sbn-preset="I want to make an appointment with Alfons Scholing">
                <?php esc_html_e( 'MAKE APPOINTMENT', 'some-b-ask-the-network' ); ?>
            </button>
            <button type="button" class="sbn-footer-link" data-sbn-preset="I want to contact you via FaceTime">
                <?php esc_html_e( 'FACETIME', 'some-b-ask-the-network' ); ?>
            </button>
        </div>

    </div>

    <div id="sbn-chatroom-auth-modal" class="sbn-chatroom-auth-modal" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="sbn-chatroom-auth-title">
        <div class="sbn-chatroom-auth-backdrop" data-sbn-chatroom-auth-close></div>
        <div class="sbn-chatroom-auth-glass">
            <button type="button" class="sbn-chatroom-auth-close" data-sbn-chatroom-auth-close aria-label="<?php echo esc_attr__( 'Close chat room access panel', 'some-b-ask-the-network' ); ?>">×</button>
            <div class="sbn-chatroom-auth-kicker"><?php esc_html_e( 'Glass access panel', 'some-b-ask-the-network' ); ?></div>
            <h2 id="sbn-chatroom-auth-title" class="sbn-chatroom-auth-title"><?php esc_html_e( 'Join the Boomie room', 'some-b-ask-the-network' ); ?></h2>
            <p class="sbn-chatroom-auth-copy"><?php esc_html_e( 'Use your site account or drop in with a guest nickname. The room is multi-user and updates live for everyone.', 'some-b-ask-the-network' ); ?></p>
            <label class="sbn-chatroom-auth-label" for="sbn-chatroom-guest-name"><?php esc_html_e( 'Guest nickname', 'some-b-ask-the-network' ); ?></label>
            <input type="text" id="sbn-chatroom-guest-name" class="sbn-chatroom-auth-input" maxlength="24" placeholder="<?php echo esc_attr__( 'Example: BoomieKid', 'some-b-ask-the-network' ); ?>" />
            <div class="sbn-chatroom-auth-actions">
                <button type="button" id="sbn-chatroom-guest-continue" class="sbn-chatroom-auth-button is-primary"><?php esc_html_e( 'Continue as guest', 'some-b-ask-the-network' ); ?></button>
                <button type="button" id="sbn-chatroom-login" class="sbn-chatroom-auth-button"><?php esc_html_e( 'Log in', 'some-b-ask-the-network' ); ?></button>
                <button type="button" id="sbn-chatroom-register" class="sbn-chatroom-auth-button"><?php esc_html_e( 'Register', 'some-b-ask-the-network' ); ?></button>
            </div>
        </div>
    </div>

    <div id="sbn-article-modal" class="sbn-article-modal" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="sbn-article-title">
        <div class="sbn-article-backdrop" data-sbn-close-article></div>
        <article class="sbn-article-glass">
            <button type="button" class="sbn-article-close" data-sbn-close-article aria-label="<?php echo esc_attr__( 'Close article preview', 'some-b-ask-the-network' ); ?>">×</button>
            <div class="sbn-article-kicker"><?php esc_html_e( 'Glass Reading Mode · Network Radar', 'some-b-ask-the-network' ); ?></div>
            <h2 id="sbn-article-title" class="sbn-article-title"></h2>
            <div id="sbn-article-source" class="sbn-article-source"></div>
            <div id="sbn-article-content" class="sbn-article-content"></div>
            <div class="sbn-article-footer"><?php esc_html_e( 'Pixel has notes. Verify the source before you quote it.', 'some-b-ask-the-network' ); ?></div>
        </article>
    </div>

</div><!-- /.sbn-fullscreen-shell -->
