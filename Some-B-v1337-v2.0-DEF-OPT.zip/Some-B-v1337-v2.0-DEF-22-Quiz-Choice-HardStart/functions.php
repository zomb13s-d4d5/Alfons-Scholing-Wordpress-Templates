<?php
/**
 * Theme bootstrap for Some-B // Ask The Network (HQ).
 *
 * This theme is a conversion of the Some-B // Ask The Network plugin.
 * It renders the control room as the full site experience (no floating button).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Load the converted core (original plugin logic adapted for theme context).
require_once get_template_directory() . '/inc/sbn-core.php';
require_once get_template_directory() . '/includes/rest-chatroom.php';

/**
 * Initialize the Some-B core class if available.
 */
function sbn_theme_boot() {
    if ( class_exists( 'SBN_Ask_The_Network' ) ) {
        $GLOBALS['sbn_ask_the_network'] = new SBN_Ask_The_Network();

        // Remove floating widget injection; the theme renders the UI as the page.
        remove_action( 'wp_footer', array( $GLOBALS['sbn_ask_the_network'], 'render_floating_widget' ) );

        // We will enqueue assets from the theme to avoid plugin_dir_url usage mismatches.
        remove_action( 'wp_enqueue_scripts', array( $GLOBALS['sbn_ask_the_network'], 'enqueue_assets' ) );
    }
}
add_action( 'after_setup_theme', 'sbn_theme_boot' );

/**
 * Enqueue frontend assets for the fullscreen control room.
 */
function sbn_theme_enqueue_assets() {
    if ( is_admin() ) {
        return;
    }

    $theme_url = get_template_directory_uri();
    $theme     = wp_get_theme();
    $ver       = $theme->get( 'Version' );

    wp_enqueue_style(
        'sbn-style',
        $theme_url . '/assets/css/sbn-style.css',
        array(),
        $ver
    );

    wp_enqueue_script(
        'sbn-frontend',
        $theme_url . '/assets/js/sbn-frontend.js',
        array( 'wp-util' ),
        $ver,
        true
    );

    // Mirror the plugin's localized config as closely as possible.
    $hq_page_id = class_exists( 'SBN_Ask_The_Network' ) ? (int) get_option( SBN_Ask_The_Network::OPTION_HQ_PAGE_ID ) : 0;
    $hq_url     = $hq_page_id ? get_permalink( $hq_page_id ) : home_url( '/' );

    $advanced_option = defined( 'NYA_TERMINAL_OPTION_ADVANCED' ) ? NYA_TERMINAL_OPTION_ADVANCED : 'nya_terminal_advanced_enabled';

    wp_localize_script(
        'sbn-frontend',
        'SBNConfig',
        array(
            'restUrl' => esc_url_raw( rest_url( 'sbn/v1/question' ) ),
            'newsUrl' => esc_url_raw( rest_url( 'sbn/v1/news' ) ),
            'terminalStatusUrl'  => esc_url_raw( rest_url( 'nya/v1/terminal/status' ) ),
            'terminalExecuteUrl' => esc_url_raw( rest_url( 'nya/v1/terminal/execute' ) ),
                'articlePreviewUrl'  => esc_url_raw( rest_url( 'nya/v1/article/preview' ) ),
            'advancedEnabled'    => (bool) get_option( $advanced_option, false ),
            'nonce'   => wp_create_nonce( 'wp_rest' ),
            'hqUrl'   => esc_url_raw( $hq_url ),
            'loginUrl'         => esc_url_raw( wp_login_url( $hq_url ) ),
            'registerUrl'      => esc_url_raw( wp_registration_url() ),
            'chatRoomMessagesUrl' => esc_url_raw( rest_url( 'nya/v1/chatroom/messages' ) ),
            'isLoggedIn'       => is_user_logged_in(),
            'currentUserDisplayName' => is_user_logged_in() ? wp_get_current_user()->display_name : ''
        )
    );
}
add_action( 'wp_enqueue_scripts', 'sbn_theme_enqueue_assets', 20 );

/**
 * Theme supports.
 */
function sbn_theme_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
}
add_action( 'after_setup_theme', 'sbn_theme_setup' );

