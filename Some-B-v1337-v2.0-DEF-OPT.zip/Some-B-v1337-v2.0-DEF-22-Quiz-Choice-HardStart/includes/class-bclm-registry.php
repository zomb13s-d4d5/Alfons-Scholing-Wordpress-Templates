<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Lightweight BCLM registry for the Democracy Terminal.
 *
 * Loads BCLM v0.4 JSON stored inside the plugin and provides
 * small helper methods for concept lookup.
 */
class NYA_BCLM_Registry {

    protected static $data = null;

    public static function load() {
        if ( self::$data !== null ) {
            return self::$data;
        }

        $path = plugin_dir_path( __FILE__ ) . '../docs/bclm-os-v0.4-nyanetwork.json';
        if ( ! file_exists( $path ) ) {
            self::$data = [];
            return self::$data;
        }

        $json = file_get_contents( $path );
        self::$data = json_decode( $json, true );
        if ( ! is_array( self::$data ) ) {
            self::$data = [];
        }
        return self::$data;
    }

    public static function packs() {
        $data = self::load();
        return $data['packs'] ?? [];
    }

    /**
     * Flatten all concepts across packs.
     *
     * @return array
     */
    public static function all_concepts() {
        $packs = self::packs();
        $out   = [];
        foreach ( (array) $packs as $pack ) {
            $concepts = $pack['concepts'] ?? [];
            foreach ( (array) $concepts as $c ) {
                if ( ! is_array( $c ) ) {
                    continue;
                }
                $id = $c['id'] ?? '';
                if ( ! $id ) {
                    continue;
                }
                $out[] = $c;
            }
        }
        return $out;
    }

    /**
     * Find concept by id or label.
     *
     * @param string $query
     * @return array|null
     */
    public static function find_concept( $query ) {
        $q = strtoupper( trim( (string) $query ) );
        if ( $q === '' ) {
            return null;
        }

        $concepts = self::all_concepts();

        // 1) Exact ID match.
        foreach ( $concepts as $c ) {
            $id = strtoupper( (string) ( $c['id'] ?? '' ) );
            if ( $id && $id === $q ) {
                return $c;
            }
        }

        // 2) Exact label match.
        $ql = strtolower( trim( (string) $query ) );
        foreach ( $concepts as $c ) {
            $label = strtolower( (string) ( $c['label'] ?? '' ) );
            if ( $label && $label === $ql ) {
                return $c;
            }
        }

        // 3) Partial label match.
        foreach ( $concepts as $c ) {
            $label = strtolower( (string) ( $c['label'] ?? '' ) );
            if ( $label && false !== strpos( $label, $ql ) ) {
                return $c;
            }
        }

        return null;
    }

    /**
     * Lightweight status snapshot for /debug and other health checks.
     *
     * Returns BCLM version, file id, slang/jargon bridge + Bushmaster rule flags,
     * and a minimal attribution block.
     *
     * @return array
     */
    public static function get_status_snapshot() {
        $os   = self::load();
        $meta = isset( $os['meta'] ) && is_array( $os['meta'] ) ? $os['meta'] : [];

        return [
            'bclm_version'            => $os['bclm_version'] ?? null,
            'file_id'                 => $os['file_id'] ?? null,
            'slang_bridge_enabled'    => ! empty( $meta['slang_bridge_enabled'] ),
            'bushmaster_rule_enabled' => ! empty( $meta['bushmaster_rule_enabled'] ),
            'attribution'             => isset( $meta['attribution'] ) && is_array( $meta['attribution'] )
                ? $meta['attribution']
                : [],
        ];
    }
}
