<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Central registry for Democracy Terminal commands.
 *
 * This registry powers:
 * - The terminal UI command list.
 * - The /help command.
 * - The command router.
 */
class NYA_Command_Registry {

    /**
     * Command map.
     *
     * level   : guest|citizen
     * handler : callable function name
     * summary : short one-liner for UI
     * usage   : example syntax
     * aliases : optional short names
     */
    protected static $commands = [
        'scan' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_scan',
            'summary' => 'Quick scan of this site or the whole network.',
            'usage'   => '/scan [site|network]',
            'aliases' => [],
        ],
        'summarize' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_summarize',
            'summary' => 'Summarize a URL or the current post.',
            'usage'   => '/summarize [url]',
            'aliases' => [ 'sum' ],
        ],

        // Advanced network search commands. These use the underlying network
        // discovery engine rather than the language model. They provide a
        // realism boost by surfacing posts and pages from across the entire
        // Some‑B / NYA network, ranked by basic relevance and scoring. Guests
        // can use /search for a quick lookup; citizens can use /explore for
        // deeper digging with more results per site.
        'search' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_search',
            'summary' => 'Search the network for posts related to your keywords.',
            'usage'   => '/search [keywords]',
            'aliases' => [ 'find', 'lookup' ],
        ],
        'explore' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_explore',
            'summary' => 'Deep network search with extended results and BCLM expansion.',
            'usage'   => '/explore [keywords]',
            'aliases' => [ 'deep', 'investigate' ],
        ],

        // Auth helper commands (UI should encourage these instead of static header links).
        'login' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_login',
            'summary' => 'Show a secure login link for this site.',
            'usage'   => '/login',
            'aliases' => [ 'log-in', 'signin', 'sign-in' ],
        ],
        'register' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_register',
            'summary' => 'Show a secure registration link for this site.',
            'usage'   => '/register',
            'aliases' => [ 'signup', 'sign-up' ],
        ],

        'sources' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_sources',
            'summary' => 'List related articles across the NYA network.',
            'usage'   => '/sources [topic]',
            'aliases' => [ 'trace' ],
        ],
        'compare' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_compare',
            'summary' => 'Compare coverage or framing between two topics.',
            'usage'   => '/compare [topicA] vs [topicB]',
            'aliases' => [],
        ],
        'claims' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_claims',
            'summary' => 'List claim-rich articles across the NYA network for a topic.',
            'usage'   => '/claims [topic]',
            'aliases' => [],
        ],
        'rights' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_rights',
            'summary' => 'Map a topic to BCLM rights & duty-of-care concepts.',
            'usage'   => '/rights [topic]',
            'aliases' => [],
        ],

        'modes' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_modes',
            'summary' => 'List available BCLM mode codes.',
            'usage'   => '/modes',
            'aliases' => [],
        ],
        'bclm' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_bclm',
            'summary' => 'Explain a BCLM concept id or label.',
            'usage'   => '/bclm [concept_id|label]',
            'aliases' => [],
        ],
        'debug' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_debug',
            'summary' => 'Democracy Terminal / BCLM health snapshot.',
            'usage'   => '/debug',
            'aliases' => [ 'health' ],
        ],

        'help' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_help',
            'summary' => 'Show available commands or details for one.',
            'usage'   => '/help [command]',
            'aliases' => [],
        ],

        'menu' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_menu',
            'summary' => 'Show the full Pixel slash-command menu.',
            'usage'   => '/menu',
            'aliases' => [ 'commands', 'cmds' ],
        ],

        // Biographies & studio guides
        'alfons' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_alfons',
            'summary' => 'Learn about Alfons Scholing, co‑founder and creative engineer.',
            'usage'   => '/alfons',
            'aliases' => [ 'al', 'scholing' ],
        ],
        'randy' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_randy',
            'summary' => 'Hear about Randy Daha and his multidisciplinary practice.',
            'usage'   => '/randy',
            'aliases' => [ 'rd', 'daha' ],
        ],
        'raf' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_raf',
            'summary' => 'Discover Raf de Wit, an Amsterdam artist and friend of the studio.',
            'usage'   => '/raf',
            'aliases' => [],
        ],
        'ruben' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_ruben',
            'summary' => 'Find out who Ruben Piel is and his role in creative tech.',
            'usage'   => '/ruben',
            'aliases' => [],
        ],
        'marcel' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_marcel',
            'summary' => 'Learn about Marcel Tempelaars and his scientific collaborations.',
            'usage'   => '/marcel',
            'aliases' => [],
        ],
        'design' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_design',
            'summary' => 'Explore the concept of design for values.',
            'usage'   => '/design',
            'aliases' => [ 'values' ],
        ],
        'engineering' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_engineering',
            'summary' => 'Discuss social value and ethics in engineering.',
            'usage'   => '/engineering',
            'aliases' => [ 'engineer', 'eng' ],
        ],



        // Some-B Design Intelligence Test commands.
        'design-test' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_design_test',
            'summary' => 'Start the Some-B Design Intelligence Test.',
            'usage'   => '/design-test',
            'aliases' => [ 'test', 'designquiz' ],
        ],
        'quiz' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_quiz',
            'summary' => 'Start the design-principles quiz immediately with multiple-choice answers.',
            'usage'   => '/quiz — starts question 1. Optional: /quiz color, /quiz typography, /quiz marketing, /quiz math.',
            'aliases' => [ 'q' ],
        ],
        'answer' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_answer',
            'summary' => 'Answer the current quiz question.',
            'usage'   => '/answer [A|B|C|D]',
            'aliases' => [ 'ans' ],
        ],
        'lesson' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_lesson',
            'summary' => 'Show a short design lesson before testing.',
            'usage'   => '/lesson [principles|composition|hierarchy|color|typography|communication|marketing|math]',
            'aliases' => [ 'learn' ],
        ],
        'score' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_score',
            'summary' => 'Show your current Design Intelligence quiz score.',
            'usage'   => '/score',
            'aliases' => [ 'result', 'results' ],
        ],

        // User-contributed site submission. Adds a custom URL to the search engine after moderation.
        'addsite' => [
            'level'   => 'guest',
            'handler' => 'nya_cmd_addsite',
            'summary' => 'Submit a website URL to be included in network search (subject to ballotage).',
            'usage'   => '/addsite [url]',
            'aliases' => [ 'addurl', 'site' ],
        ],
    ];

    public static function all() {
        return self::$commands;
    }

    public static function find( $name ) {
        $name = strtolower( (string) $name );
        foreach ( self::$commands as $cmd => $meta ) {
            $aliases = isset( $meta['aliases'] ) && is_array( $meta['aliases'] ) ? $meta['aliases'] : [];
            if ( $cmd === $name || in_array( $name, $aliases, true ) ) {
                return array_merge( $meta, [ 'name' => $cmd ] );
            }
        }
        return null;
    }
}
