<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'sbn_chatroom_option_key' ) ) {
    function sbn_chatroom_option_key() {
        return 'sbn_boomie_chatroom_messages';
    }
}

if ( ! function_exists( 'sbn_chatroom_get_messages' ) ) {
    function sbn_chatroom_get_messages() {
        $messages = get_option( sbn_chatroom_option_key(), array() );
        return is_array( $messages ) ? array_values( $messages ) : array();
    }
}

if ( ! function_exists( 'sbn_chatroom_save_messages' ) ) {
    function sbn_chatroom_save_messages( $messages ) {
        $messages = is_array( $messages ) ? array_values( $messages ) : array();
        if ( count( $messages ) > 120 ) {
            $messages = array_slice( $messages, -120 );
        }
        update_option( sbn_chatroom_option_key(), $messages, false );
        return $messages;
    }
}

if ( ! function_exists( 'sbn_chatroom_format_message' ) ) {
    function sbn_chatroom_format_message( $message ) {
        return array(
            'id'        => isset( $message['id'] ) ? (string) $message['id'] : '',
            'author'    => isset( $message['author'] ) ? (string) $message['author'] : 'Guest',
            'text'      => isset( $message['text'] ) ? (string) $message['text'] : '',
            'timestamp' => isset( $message['timestamp'] ) ? (string) $message['timestamp'] : gmdate( 'c' ),
            'is_user'   => ! empty( $message['is_user'] ),
        );
    }
}

if ( ! function_exists( 'sbn_chatroom_current_identity' ) ) {
    function sbn_chatroom_current_identity( WP_REST_Request $request ) {
        if ( is_user_logged_in() ) {
            $user = wp_get_current_user();
            return array(
                'author'  => $user->display_name ? $user->display_name : $user->user_login,
                'is_user' => true,
            );
        }

        $guest_name = sanitize_text_field( (string) $request->get_param( 'guest_name' ) );
        $guest_name = trim( preg_replace( '/\s+/', ' ', $guest_name ) );
        if ( $guest_name !== '' ) {
            $guest_name = function_exists( 'mb_substr' ) ? mb_substr( $guest_name, 0, 24 ) : substr( $guest_name, 0, 24 );
            return array(
                'author'  => $guest_name,
                'is_user' => false,
            );
        }

        return null;
    }
}

if ( ! function_exists( 'sbn_chatroom_register_rest_routes' ) ) {
    function sbn_chatroom_register_rest_routes() {
        register_rest_route(
            'nya/v1',
            '/chatroom/messages',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => function ( WP_REST_Request $request ) {
                        $messages = sbn_chatroom_get_messages();
                        $count    = absint( $request->get_param( 'count' ) );
                        if ( $count < 1 ) {
                            $count = 40;
                        }
                        $messages = array_slice( $messages, -1 * min( $count, 120 ) );

                        $identity = is_user_logged_in()
                            ? ( wp_get_current_user()->display_name ?: wp_get_current_user()->user_login )
                            : '';

                        return array(
                            'ok'           => true,
                            'messages'     => array_map( 'sbn_chatroom_format_message', $messages ),
                            'current_user' => array(
                                'logged_in'    => is_user_logged_in(),
                                'display_name' => $identity,
                            ),
                        );
                    },
                    'permission_callback' => '__return_true',
                ),
                array(
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => function ( WP_REST_Request $request ) {
                        $identity = sbn_chatroom_current_identity( $request );
                        if ( ! $identity ) {
                            return array(
                                'ok'                => false,
                                'requires_identity' => true,
                                'message'           => 'Choose a guest nickname or use login/register first.',
                            );
                        }

                        $text = sanitize_textarea_field( (string) $request->get_param( 'message' ) );
                        $text = trim( preg_replace( '/\s+/', ' ', $text ) );
                        if ( $text === '' ) {
                            return array(
                                'ok'      => false,
                                'message' => 'Empty message.',
                            );
                        }

                        if ( function_exists( 'mb_substr' ) ) {
                            $text = mb_substr( $text, 0, 500 );
                        } else {
                            $text = substr( $text, 0, 500 );
                        }

                        $messages   = sbn_chatroom_get_messages();
                        $messages[] = array(
                            'id'        => (string) ( round( microtime( true ) * 1000 ) . wp_rand( 10, 99 ) ),
                            'author'    => $identity['author'],
                            'text'      => $text,
                            'timestamp' => gmdate( 'c' ),
                            'is_user'   => ! empty( $identity['is_user'] ),
                        );

                        $messages = sbn_chatroom_save_messages( $messages );

                        return array(
                            'ok'       => true,
                            'messages' => array_map( 'sbn_chatroom_format_message', array_slice( $messages, -40 ) ),
                        );
                    },
                    'permission_callback' => '__return_true',
                ),
            )
        );
    }
}

add_action( 'rest_api_init', 'sbn_chatroom_register_rest_routes' );
