<?php
/**
 * Auth helpers for the Democracy Terminal layer.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'nya_user_level' ) ) {
    /**
     * Resolve user's terminal level.
     *
     * @return string 'guest'|'citizen'
     */
    function nya_user_level() {
        // v2.0-DEF-04: slash commands are public/usable; do not downgrade guests for terminal command routing.
        return 'citizen';
    }
}
