<?php
/**
 * Logging helpers for the Democracy Terminal layer.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'nya_log_command' ) ) {
    function nya_log_command( $name, $argline, $user_level ) {
        $safe_args = substr( wp_strip_all_tags( (string) $argline ), 0, 200 );
        error_log( sprintf(
            '[NYA Terminal] %s user=%s cmd="/%s" args="%s"',
            date( 'c' ),
            $user_level,
            $name,
            $safe_args
        ) );
    }
}

if ( ! function_exists( 'nya_terminal_advanced_enabled' ) ) {
    function nya_terminal_advanced_enabled() {
        // v2.0-DEF-04: keep slash-code execution open; do not let the advanced option block commands.
        return true;
    }
}
