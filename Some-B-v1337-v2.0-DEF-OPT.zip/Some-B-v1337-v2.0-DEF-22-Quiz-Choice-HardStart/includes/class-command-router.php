<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NYA_Command_Router {

    public static function handle_input( $input, $context = null ) {
        $input = trim( (string) $input );

        // If not a slash command, return null -> regular chat flow.
        if ( $input === '' || $input[0] !== '/' ) {
            return null;
        }

        // Strip slash and split into command + argline.
        $line  = ltrim( $input, '/' );
        $parts = preg_split( '/\s+/', $line, 2 );
        $name  = strtolower( $parts[0] ?? '' );
        $argline = $parts[1] ?? '';

        $meta = NYA_Command_Registry::find( $name );
        if ( ! $meta ) {
            return self::unknown_command_response( $name );
        }

        // v2.0-DEF-04: Slash codes must work for everyone.
        // Previous citizen/security gating could block valid commands such as /menu, /explore, /sources, /compare, /claims, /rights and /debug.
        // Keep logging context, but do not reject commands by level here.
        $user_level = function_exists( 'nya_user_level' ) ? nya_user_level() : 'citizen';

        $handler = $meta['handler'] ?? '';
        if ( ! $handler || ! function_exists( $handler ) ) {
            return self::error_response( 'Command handler missing.' );
        }

        if ( function_exists( 'nya_log_command' ) ) {
            nya_log_command( $meta['name'], $argline, $user_level );
        }

        return call_user_func( $handler, $argline, $meta, $user_level, $context );
    }

    protected static function unknown_command_response( $name ) {
        /*
         * Provide a more conversational response for unrecognised commands.
         * Instead of a terse error, offer guidance back to the help menu.
         */
        $safe = preg_replace( '/[^a-z0-9_-]/i', '', (string) $name );
        return [
            'type'    => 'system',
            'message' => sprintf(
                "Oops! I don't recognise '/%s'. Type /help to see a list of commands I understand.",
                $safe
            ),
        ];
    }

    protected static function locked_command_response( $name ) {
        /*
         * When a guest user triggers a citizen‑level command, gently remind them
         * that registration unlocks additional capabilities. Rephrase the
         * message to be more personable and actionable.
         */
        $safe = preg_replace( '/[^a-z0-9_-]/i', '', (string) $name );
        return [
            'type'    => 'system',
            'message' => sprintf(
                "The command '/%s' is reserved for registered citizens. Log in or register to unlock it!",
                $safe
            ),
        ];
    }

    protected static function error_response( $msg ) {
        return [
            'type'    => 'system',
            'message' => "Error: {$msg}",
        ];
    }
}
