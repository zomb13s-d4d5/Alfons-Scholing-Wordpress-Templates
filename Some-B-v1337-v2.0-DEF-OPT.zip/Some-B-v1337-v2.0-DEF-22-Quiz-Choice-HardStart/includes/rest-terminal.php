<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Democracy Terminal REST endpoints + command handlers.
 *
 * v2.0-DEF-04: slash-code execution is open; old advanced/citizen gate removed.
 */

// ------------------------------------------------------------
// Modes
// ------------------------------------------------------------
if ( ! function_exists( 'nya_terminal_get_modes' ) ) {
    function nya_terminal_get_modes() {
        $registry = [];
        if ( class_exists( 'SBN_Ask_The_Network' ) && method_exists( 'SBN_Ask_The_Network', 'get_mode_registry' ) ) {
            $registry = apply_filters( 'sbn_mode_registry', SBN_Ask_The_Network::get_mode_registry() );
        }

        $modes = [];
        foreach ( (array) $registry as $key => $meta ) {
            if ( 0 !== strpos( $key, 'bclm_' ) ) {
                continue;
            }

            $level = 'guest';
            if ( in_array( $key, [ 'bclm_democracy', 'bclm_legal' ], true ) ) {
                $level = 'citizen';
            }

            $modes[ $key ] = [
                'label'    => $meta['label'] ?? $key,
                'emoji'    => $meta['emoji'] ?? '',
                'keywords' => isset( $meta['keywords'] ) ? preg_split( '/\s+/', trim( (string) $meta['keywords'] ) ) : [],
                'level'    => $level,
            ];
        }

        return $modes;
    }
}

// ------------------------------------------------------------
// BCLM shortcut parsing
// ------------------------------------------------------------
if ( ! function_exists( 'nya_parse_bclm_shortcut' ) ) {
    function nya_parse_bclm_shortcut( $input ) {
        $input = trim( (string) $input );
        if ( preg_match( '/^(bclm_[a-z0-9_]+)\s*:\s*(.+)$/i', $input, $m ) ) {
            return [
                'mode' => strtolower( $m[1] ),
                'rest' => trim( $m[2] ),
            ];
        }
        return null;
    }
}

if ( ! function_exists( 'nya_handle_bclm_shortcut' ) ) {
    function nya_handle_bclm_shortcut( $shortcut ) {
        $modes = nya_terminal_get_modes();
        $mode  = $shortcut['mode'] ?? '';
        $topic = $shortcut['rest'] ?? '';

        $mode_def = $modes[ $mode ] ?? null;
        if ( ! $mode_def ) {
            return [ 'type' => 'system', 'message' => "Unknown mode code: {$mode}." ];
        }

        $level = function_exists( 'nya_user_level' ) ? nya_user_level() : 'guest';
        // v2.0-DEF-04: BCLM shortcuts must work without the old civic keycard gate.

        $cmd_line = '/sources ' . $topic;
        return NYA_Command_Router::handle_input( $cmd_line, $mode_def );
    }
}

// ------------------------------------------------------------
// Helpers to bridge terminal payloads to legacy SBN response
// ------------------------------------------------------------
if ( ! function_exists( 'nya_terminal_to_sbn_response' ) ) {
    function nya_terminal_to_sbn_response( $payload ) {
        $msg  = $payload['message'] ?? '';
        $type = $payload['type'] ?? 'result';
        $score = 0;
        $label = 'no-zombie';

        if ( $type === 'error' ) {
            $label = 'low';
            $score = 10;
        } elseif ( $type === 'system' ) {
            $label = 'low';
            $score = 5;
        }

        return [
            'error'          => false,
            'mode'           => 'terminal',
            'topics'         => [],
            'diagnostic'     => [
                'score'   => $score,
                'label'   => $label,
                'message' => 'Democracy Terminal response.',
            ],
            'response_text'  => (string) $msg,
            'response_plain' => wp_strip_all_tags( (string) $msg ),
            'linked_content' => [],
        ];
    }
}


// ------------------------------------------------------------
// DEF-22: hard-start /quiz with choices, even when old routers/cache try usage text
// ------------------------------------------------------------
if ( ! function_exists( 'nya_design_quiz_immediate_payload' ) ) {
    function nya_design_quiz_immediate_payload() {
        if ( function_exists( 'nya_cmd_quiz' ) ) {
            return nya_cmd_quiz( '', array( 'name' => 'quiz' ), 'guest', null );
        }

        return array(
            'type'    => 'result',
            'message' => "SOME-B DESIGN QUIZ\n\nQuestion 1 / 5 — Visual hierarchy\n\nWhat creates visual hierarchy first in a layout?\n\nA. Decoration\nB. Contrast, scale, position, and spacing\nC. Random color use\nD. Making every element the same size\n\nAnswer with /answer A, /answer B, /answer C, or /answer D.",
            'meta'    => array( 'action' => 'quiz_question', 'topic' => 'principles' ),
        );
    }
}

// ------------------------------------------------------------
// Command handlers
// ------------------------------------------------------------

if ( ! function_exists( 'nya_cmd_login' ) ) {
    function nya_cmd_login( $argline, $meta, $user_level, $context = null ) {
        $redirect = home_url( '/' );
        $url = wp_login_url( $redirect );
        return [
            'type'    => 'system',
            'message' => "Log in here: {$url}",
            'meta'    => [ 'action' => 'login', 'url' => $url ],
        ];
    }
}

if ( ! function_exists( 'nya_cmd_register' ) ) {
    function nya_cmd_register( $argline, $meta, $user_level, $context = null ) {
        $url = wp_registration_url();
        return [
            'type'    => 'system',
            'message' => "Register here: {$url}",
            'meta'    => [ 'action' => 'register', 'url' => $url ],
        ];
    }
}

if ( ! function_exists( 'nya_cmd_help' ) ) {
    /**
     * /help – Show available commands or details for one.
     *
     * This implementation improves on the original by adding a rotating intro,
     * grouping commands by access level and exposing aliases when you look up
     * a specific command. It is designed to be conversational and avoid
     * repeating identical headings, aligning with best‑practices for chat UI
     * design【35471262809477†L178-L203】. The list of commands is always derived
     * from the central registry so new commands automatically appear.
     */
    function nya_cmd_help( $argline, $meta, $user_level, $context = null ) {
        $argline = trim( (string) $argline );
        $all = NYA_Command_Registry::all();

        // When a specific command is requested, show detailed information.
        if ( $argline !== '' ) {
            $one = NYA_Command_Registry::find( $argline );
            if ( ! $one ) {
                return [ 'type' => 'system', 'message' => "Unknown command: /{$argline}." ];
            }
            $is_locked = ( ( $one['level'] ?? 'guest' ) === 'citizen' && $user_level !== 'citizen' );
            $lock      = $is_locked ? ' 🔒' : '';
            $usage     = $one['usage'] ?? '';
            $summary   = $one['summary'] ?? '';
            $aliases   = isset( $one['aliases'] ) && is_array( $one['aliases'] ) ? $one['aliases'] : [];

            $lines = [];
            $lines[] = "/{$one['name']}{$lock}";
            if ( $summary ) {
                $lines[] = $summary;
            }
            if ( $usage ) {
                $lines[] = 'Usage: ' . $usage;
            }
            if ( $aliases ) {
                $lines[] = 'Aliases: ' . implode( ', ', array_map( function ( $a ) { return '/' . $a; }, $aliases ) );
            }

            return [
                'type'    => 'system',
                'message' => implode( "\n", $lines ),
            ];
        }

        // When no argument is given, show grouped command overview.
        $intro_options = [
            'Here are the commands I can respond to:',
            'Need a hand? Try one of these commands:',
            'Available commands:',
            'I can do the following:',
        ];
        $intro = $intro_options[ array_rand( $intro_options ) ];

        $guest_cmds   = [];
        $citizen_cmds = [];
        foreach ( $all as $name => $c ) {
            $level = $c['level'] ?? 'guest';
            $lock  = ( $level === 'citizen' && $user_level !== 'citizen' ) ? ' 🔒' : '';
            $line  = "/{$name}{$lock} — " . ( $c['summary'] ?? '' );
            if ( $level === 'citizen' ) {
                $citizen_cmds[] = $line;
            } else {
                $guest_cmds[]   = $line;
            }
        }

        $sections = [];
        if ( ! empty( $guest_cmds ) ) {
            $sections[] = "Guest access:\n" . implode( "\n", $guest_cmds );
        }
        if ( ! empty( $citizen_cmds ) ) {
            $sections[] = "Citizen access:\n" . implode( "\n", $citizen_cmds );
        }
        $body = implode( "\n\n", $sections );
        return [
            'type'    => 'system',
            'message' => $intro . "\n" . $body,
        ];
    }
}
if ( ! function_exists( 'nya_cmd_menu' ) ) {
    /**
     * /menu – Show the slash command menu in text form.
     * This is the server-side companion for the Pixel menu button, so the code
     * also works when typed directly in the terminal input.
     */
    function nya_cmd_menu( $argline, $meta, $user_level, $context = null ) {
        $commands = class_exists( 'NYA_Command_Registry' ) ? NYA_Command_Registry::all() : [];
        if ( empty( $commands ) ) {
            return [ 'type' => 'system', 'message' => 'Command menu is currently empty.' ];
        }

        $lines = [];
        $lines[] = 'Pixel slash-command menu';
        $lines[] = '--------------------------';
        foreach ( $commands as $name => $cmd_meta ) {
            $summary = isset( $cmd_meta['summary'] ) ? (string) $cmd_meta['summary'] : '';
            $usage   = isset( $cmd_meta['usage'] ) ? (string) $cmd_meta['usage'] : '/' . $name;
            $lines[] = $usage . ( $summary ? ' — ' . $summary : '' );
        }
        $network_sites = function_exists( 'nya_terminal_get_network_sites' ) ? nya_terminal_get_network_sites() : array();
        if ( ! empty( $network_sites ) ) {
            $lines[] = '';
            $lines[] = 'NYA-network nodes covered by these slash codes:';
            foreach ( $network_sites as $site ) {
                $label = isset( $site['label'] ) ? (string) $site['label'] : '';
                $base  = isset( $site['base'] ) ? (string) $site['base'] : '';
                if ( $label || $base ) {
                    $lines[] = '- ' . trim( $label . ( $base ? ' — ' . $base : '' ) );
                }
            }
        }

        $lines[] = '';
        $lines[] = 'Tip: tap the Pixel avatar to insert commands, or type any /code directly. The command layer is network-wide, not locked to Some-B only.';
        return [ 'type' => 'result', 'message' => implode( "\n", $lines ) ];
    }
}
if ( ! function_exists( 'nya_cmd_debug' ) ) {
    /**
     * /debug (alias /health) – Democracy Terminal + BCLM status snapshot.
     *
     * Visible as a citizen-only command. Intended for field-testing and
     * quick sanity checks without opening wp-admin or server logs.
     */
    function nya_cmd_debug( $argline, $meta, $user_level, $context = null ) {
        $now       = current_time( 'mysql' );
        $site      = home_url( '/' );
        $blog_name = get_bloginfo( 'name', 'display' );

        $advanced_enabled = false;
        if ( defined( 'NYA_TERMINAL_OPTION_ADVANCED' ) ) {
            $advanced_enabled = (bool) get_option( NYA_TERMINAL_OPTION_ADVANCED, false );
        }

        $bclm_status = null;
        if ( class_exists( 'NYA_BCLM_Registry' ) && method_exists( 'NYA_BCLM_Registry', 'get_status_snapshot' ) ) {
            $bclm_status = NYA_BCLM_Registry::get_status_snapshot();
        }

        $indexer_ok = false;
        $indexer_id = 'none';
        if ( function_exists( 'nya_terminal_get_sbn_instance' ) ) {
            $inst = nya_terminal_get_sbn_instance();
            if ( $inst ) {
                $indexer_ok = true;
                if ( isset( $inst->version ) ) {
                    $indexer_id = (string) $inst->version;
                } elseif ( method_exists( $inst, 'get_version' ) ) {
                    $indexer_id = (string) $inst->get_version();
                } else {
                    $indexer_id = 'online';
                }
            }
        }

        $lines   = [];
        $lines[] = 'Democracy Terminal health check';
        $lines[] = '-------------------------------';
        $lines[] = 'Site: ' . $blog_name . ' (' . $site . ')';
        $network_sites = function_exists( 'nya_terminal_get_network_sites' ) ? nya_terminal_get_network_sites() : array();
        $lines[] = 'Network nodes configured: ' . count( (array) $network_sites );
        if ( ! empty( $network_sites ) ) {
            foreach ( $network_sites as $node ) {
                $lines[] = '  - ' . ( $node['label'] ?? 'NYA node' ) . ': ' . ( $node['base'] ?? '' );
            }
        }
        $lines[] = 'Time (WP): ' . $now;
        $lines[] = 'User level: ' . $user_level;
        $lines[] = 'Advanced terminal codes: ' . ( $advanced_enabled ? 'enabled' : 'disabled' );

        if ( $bclm_status ) {
            $version   = $bclm_status['bclm_version'] ?? 'n/a';
            $file_id   = $bclm_status['file_id'] ?? 'n/a';
            $slang_on  = ! empty( $bclm_status['slang_bridge_enabled'] );
            $bush_on   = ! empty( $bclm_status['bushmaster_rule_enabled'] );
            $lines[]   = '';
            $lines[]   = 'BCLM OS';
            $lines[]   = '  - Version: ' . $version;
            $lines[]   = '  - File ID: ' . $file_id;
            $lines[]   = '  - Slang/jargon bridge: ' . ( $slang_on ? 'on' : 'off' );
            $lines[]   = '  - Bushmaster rule: ' . ( $bush_on ? 'on' : 'off' );

            if ( ! empty( $bclm_status['attribution'] ) && is_array( $bclm_status['attribution'] ) ) {
                $att  = $bclm_status['attribution'];
                $who  = [];
                if ( ! empty( $att['primary_author'] ) ) {
                    $who[] = $att['primary_author'];
                }
                if ( ! empty( $att['studio'] ) ) {
                    $who[] = $att['studio'];
                }
                if ( ! empty( $who ) ) {
                    $lines[] = '  - Attribution: ' . implode( ' · ', $who );
                }
            }
        }

        $lines[] = '';
        $lines[] = 'Network indexer';
        $lines[] = '  - Status: ' . ( $indexer_ok ? 'online' : 'missing' );
        $lines[] = '  - ID: ' . $indexer_id;

        $lines[] = '';
        $lines[] = 'Tip: use /modes or /help to explore democracy codes. Keep BCLM as a map, not a judge.';

        return [
            'type'    => 'system',
            'message' => implode( "\n", $lines ),
        ];
    }
}

// ------------------------------------------------------------
// Command: /search
// ------------------------------------------------------------
if ( ! function_exists( 'nya_cmd_search' ) ) {
    /**
     * /search – Quick network search using the algorithmic discovery engine.
     *
     * This command runs a relevance‑scored search across every site in the network,
     * ranking the results by the underlying scoring in the SBN engine. It
     * surfaces a handful of posts with snippets so users can quickly gauge
     * whether a topic has coverage without relying on a language model.
     * Guests and citizens alike can use /search. Citizens can run /explore
     * for a deeper dive.
     *
     * @param string $argline User input after the command name.
     * @param array  $meta Command metadata from the registry.
     * @param string $user_level Current user level ('guest' or 'citizen').
     * @param array|null $context Additional context (unused here).
     * @return array Terminal payload
     */
    function nya_cmd_search( $argline, $meta, $user_level, $context = null ) {
        $query = trim( (string) $argline );
        if ( '' === $query ) {
            return [ 'type' => 'system', 'message' => 'Usage: /search [keywords]' ];
        }

        $inst = nya_terminal_get_sbn_instance();
        if ( ! $inst || ! method_exists( $inst, 'terminal_find_network_links' ) ) {
            return [ 'type' => 'system', 'message' => 'Search engine not available.' ];
        }

        // Perform network search with a modest per‑site limit for speed.
        $links = $inst->terminal_find_network_links( $query, [], 5 );
        if ( empty( $links ) ) {
            return [ 'type' => 'result', 'message' => 'No matching articles found.' ];
        }

        // Group results by site so they can be presented in separate slides. Each
        // slide will contain up to five items from one site. A slide shows the
        // site label and lists the article titles with optional snippets. When a
        // URL is available it will be used as a link; otherwise the title is
        // rendered as plain text.
        $grouped = array();
        $max_per_slide = 5;
        $total_slides = 0;
        foreach ( $links as $l ) {
            $site    = isset( $l['site_label'] ) && $l['site_label'] ? $l['site_label'] : ( isset( $l['site_slug'] ) ? $l['site_slug'] : '' );
            if ( '' === $site ) {
                $site = __( 'unknown site', 'some-b-ask-the-network' );
            }
            // Initialise bucket for this site
            if ( ! isset( $grouped[ $site ] ) ) {
                $grouped[ $site ] = array();
            }
            if ( count( $grouped[ $site ] ) >= $max_per_slide ) {
                continue;
            }
            $title   = isset( $l['title'] ) ? $l['title'] : '';
            $snippet = isset( $l['snippet'] ) ? wp_trim_words( (string) $l['snippet'], 20 ) : '';
            $url     = isset( $l['url'] ) ? $l['url'] : '';
            $grouped[ $site ][] = array(
                'title'   => $title,
                'snippet' => $snippet,
                'url'     => $url,
            );
        }

        // Include results from user-submitted custom sites (ballotage applies).
        $custom_sites = get_option( 'nya_custom_sites', array() );
        if ( is_array( $custom_sites ) && ! empty( $custom_sites ) ) {
            foreach ( $custom_sites as $base ) {
                $endpoint = rtrim( $base, '/' ) . '/wp-json/wp/v2/search?search=' . rawurlencode( $query ) . '&per_page=5';
                $response = wp_remote_get( $endpoint, array( 'timeout' => 4 ) );
                if ( is_wp_error( $response ) ) {
                    continue;
                }
                $body = wp_remote_retrieve_body( $response );
                if ( empty( $body ) ) {
                    continue;
                }
                $items = json_decode( $body, true );
                if ( ! is_array( $items ) || empty( $items ) ) {
                    continue;
                }
                $site_label = parse_url( $base, PHP_URL_HOST );
                if ( ! isset( $grouped[ $site_label ] ) ) {
                    $grouped[ $site_label ] = array();
                }
                foreach ( $items as $it ) {
                    if ( count( $grouped[ $site_label ] ) >= $max_per_slide ) {
                        break;
                    }
                    $title = isset( $it['title'] ) ? wp_strip_all_tags( $it['title'] ) : '';
                    $snippet_raw = isset( $it['excerpt'] ) ? wp_strip_all_tags( $it['excerpt'] ) : '';
                    $snippet = wp_trim_words( $snippet_raw, 20 );
                    $url = isset( $it['url'] ) ? $it['url'] : '';
                    $grouped[ $site_label ][] = array(
                        'title'   => $title,
                        'snippet' => $snippet,
                        'url'     => $url,
                    );
                }
            }
        }

        if ( empty( $grouped ) ) {
            return [ 'type' => 'result', 'message' => __( 'No matching articles found.', 'some-b-ask-the-network' ) ];
        }

        $slides_html     = '';
        $indicators_html = '';
        $slide_index     = 0;
        foreach ( $grouped as $site_label => $items ) {
            $slides_html .= '<div class="sbn-search-slide">';
            $slides_html .= '<div class="sbn-search-site">' . esc_html( $site_label ) . '</div>';
            foreach ( $items as $it ) {
                $slides_html .= '<div class="sbn-search-item">';
                if ( ! empty( $it['url'] ) ) {
                    $slides_html .= '<a href="' . esc_url( $it['url'] ) . '" target="_blank" rel="noopener" class="sbn-search-link">' . esc_html( $it['title'] ) . '</a>';
                } else {
                    $slides_html .= esc_html( $it['title'] );
                }
                if ( ! empty( $it['snippet'] ) ) {
                    $slides_html .= '<span class="sbn-search-snippet"> — ' . esc_html( $it['snippet'] ) . '</span>';
                }
                $slides_html .= '</div>';
            }
            $slides_html .= '</div>';
            $indicators_html .= '<button type="button" class="sbn-slider-indicator" data-index="' . intval( $slide_index ) . '" aria-label="' . esc_attr__( 'Go to slide', 'some-b-ask-the-network' ) . ' ' . ( $slide_index + 1 ) . '"></button>';
            $slide_index++;
        }

        $message_html  = '<p>' . sprintf( /* translators: %s: search query */ esc_html__( 'Search results for “%s”:', 'some-b-ask-the-network' ), esc_html( $query ) ) . '</p>';
        $message_html .= '<div class="sbn-search-slider">' . $slides_html . '</div>';
        $message_html .= '<div class="sbn-slider-indicators">' . $indicators_html . '</div>';

        return [ 'type' => 'result', 'render' => 'html', 'html' => true, 'message' => $message_html ];
    }
}

// ------------------------------------------------------------
// Command: /explore
// ------------------------------------------------------------
if ( ! function_exists( 'nya_cmd_explore' ) ) {
    /**
     * /explore – Deep network search for citizen users.
     *
     * This command expands on /search by increasing the per‑site retrieval limit
     * and returning more lines of results. It also piggybacks on the built‑in
     * BCLM mode token expansion, so queries like “bclm_democracy youth vote”
     * automatically include mode keywords, producing a richer set of results.
     * Only citizens can invoke /explore; guests will be prompted to register.
     *
     * @param string $argline User input after the command name.
     * @param array  $meta Command metadata from the registry.
     * @param string $user_level Current user level ('guest' or 'citizen').
     * @param array|null $context Additional context (unused here).
     * @return array Terminal payload
     */
    function nya_cmd_explore( $argline, $meta, $user_level, $context = null ) {
        if ( $user_level !== 'citizen' ) {
            // Should not be reachable thanks to the router, but double check.
            return [ 'type' => 'system', 'message' => 'The /explore command is reserved for registered citizens.' ];
        }
        $query = trim( (string) $argline );
        if ( '' === $query ) {
            return [ 'type' => 'system', 'message' => 'Usage: /explore [keywords]' ];
        }
        $inst = nya_terminal_get_sbn_instance();
        if ( ! $inst || ! method_exists( $inst, 'terminal_find_network_links' ) ) {
            return [ 'type' => 'system', 'message' => 'Search engine not available.' ];
        }

        // Higher per‑site limit for deeper exploration.
        $links = $inst->terminal_find_network_links( $query, [], 10 );
        if ( empty( $links ) ) {
            return [ 'type' => 'result', 'message' => 'No matching articles found.' ];
        }
        // Build grouped results similar to /search but with a higher per‑site
        // cap. Each slide can contain up to 8 items from a single site.
        $grouped = array();
        $max_per_slide = 8;
        foreach ( $links as $l ) {
            $site    = isset( $l['site_label'] ) && $l['site_label'] ? $l['site_label'] : ( isset( $l['site_slug'] ) ? $l['site_slug'] : '' );
            if ( '' === $site ) {
                $site = __( 'unknown site', 'some-b-ask-the-network' );
            }
            if ( ! isset( $grouped[ $site ] ) ) {
                $grouped[ $site ] = array();
            }
            if ( count( $grouped[ $site ] ) >= $max_per_slide ) {
                continue;
            }
            $title   = isset( $l['title'] ) ? $l['title'] : '';
            $snippet = isset( $l['snippet'] ) ? wp_trim_words( (string) $l['snippet'], 30 ) : '';
            $url     = isset( $l['url'] ) ? $l['url'] : '';
            $grouped[ $site ][] = array(
                'title'   => $title,
                'snippet' => $snippet,
                'url'     => $url,
            );
        }
        // Append custom site results
        $custom_sites = get_option( 'nya_custom_sites', array() );
        if ( is_array( $custom_sites ) && ! empty( $custom_sites ) ) {
            foreach ( $custom_sites as $base ) {
                $endpoint = rtrim( $base, '/' ) . '/wp-json/wp/v2/search?search=' . rawurlencode( $query ) . '&per_page=10';
                $response = wp_remote_get( $endpoint, array( 'timeout' => 4 ) );
                if ( is_wp_error( $response ) ) {
                    continue;
                }
                $body = wp_remote_retrieve_body( $response );
                if ( empty( $body ) ) {
                    continue;
                }
                $items = json_decode( $body, true );
                if ( ! is_array( $items ) || empty( $items ) ) {
                    continue;
                }
                $site_label = parse_url( $base, PHP_URL_HOST );
                if ( ! isset( $grouped[ $site_label ] ) ) {
                    $grouped[ $site_label ] = array();
                }
                foreach ( $items as $it ) {
                    if ( count( $grouped[ $site_label ] ) >= $max_per_slide ) {
                        break;
                    }
                    $title = isset( $it['title'] ) ? wp_strip_all_tags( $it['title'] ) : '';
                    $snippet_raw = isset( $it['excerpt'] ) ? wp_strip_all_tags( $it['excerpt'] ) : '';
                    $snippet = wp_trim_words( $snippet_raw, 30 );
                    $url = isset( $it['url'] ) ? $it['url'] : '';
                    $grouped[ $site_label ][] = array(
                        'title'   => $title,
                        'snippet' => $snippet,
                        'url'     => $url,
                    );
                }
            }
        }
        if ( empty( $grouped ) ) {
            return [ 'type' => 'result', 'message' => __( 'No matching articles found.', 'some-b-ask-the-network' ) ];
        }
        $slides_html     = '';
        $indicators_html = '';
        $slide_index     = 0;
        foreach ( $grouped as $site_label => $items ) {
            $slides_html .= '<div class="sbn-search-slide">';
            $slides_html .= '<div class="sbn-search-site">' . esc_html( $site_label ) . '</div>';
            foreach ( $items as $it ) {
                $slides_html .= '<div class="sbn-search-item">';
                if ( ! empty( $it['url'] ) ) {
                    $slides_html .= '<a href="' . esc_url( $it['url'] ) . '" target="_blank" rel="noopener" class="sbn-search-link">' . esc_html( $it['title'] ) . '</a>';
                } else {
                    $slides_html .= esc_html( $it['title'] );
                }
                if ( ! empty( $it['snippet'] ) ) {
                    $slides_html .= '<span class="sbn-search-snippet"> — ' . esc_html( $it['snippet'] ) . '</span>';
                }
                $slides_html .= '</div>';
            }
            $slides_html .= '</div>';
            $indicators_html .= '<button type="button" class="sbn-slider-indicator" data-index="' . intval( $slide_index ) . '" aria-label="' . esc_attr__( 'Go to slide', 'some-b-ask-the-network' ) . ' ' . ( $slide_index + 1 ) . '"></button>';
            $slide_index++;
        }
        $message_html  = '<p>' . sprintf( /* translators: %s: search query */ esc_html__( 'Explore results for “%s”:', 'some-b-ask-the-network' ), esc_html( $query ) ) . '</p>';
        $message_html .= '<div class="sbn-search-slider">' . $slides_html . '</div>';
        $message_html .= '<div class="sbn-slider-indicators">' . $indicators_html . '</div>';
        return [ 'type' => 'result', 'render' => 'html', 'html' => true, 'message' => $message_html ];
    }
}

// ------------------------------------------------------------
// Commands: Biographies and knowledge
// ------------------------------------------------------------

if ( ! function_exists( 'nya_cmd_alfons' ) ) {
    /**
     * /alfons – Describe Alfons Scholing and his role at the studio.
     *
     * Returns a short biography highlighting Alfons’ journey from
     * engineering to design, his freelance background and his values.
     */
    function nya_cmd_alfons( $argline, $meta, $user_level, $context = null ) {
        $text = "Alfons Scholing is a co‑founder of Studio NyA and a multidisciplinary designer and creative engineer. " .
            "He originally studied electrical engineering but followed his passion for graphic design and became a self‑taught freelancer. " .
            "Combining technical know‑how with artistic vision, he has built an adaptable studio that navigates digital, print and interactive projects. " .
            "Alfons believes in resilience and community: when construction jobs vanished, his freelance career kept him employed and allowed him to support collaborators. " .
            "Today he mentors young designers and sees technology as a tool for empowerment.";
        return [ 'type' => 'result', 'message' => $text ];
    }
}

if ( ! function_exists( 'nya_cmd_randy' ) ) {
    /**
     * /randy – Describe Randy Daha and his creative practice.
     */
    function nya_cmd_randy( $argline, $meta, $user_level, $context = null ) {
        $text = "Randy Daha is a multidisciplinary creative with Surinamese roots. " .
            "His practice blends music, image‑making, rhythm and memory, drawing energy from hip‑hop, graffiti, studio culture and everyday Amsterdam life. " .
            "Randy fuses Caribbean warmth and movement with Dutch structure and design clarity, creating playful yet deliberate work. " .
            "He views the studio as both a physical space and a mindset for sampling, layering, refining and transforming influences. " .
            "Outside of visuals, he builds identity through sound, image and street culture.";
        return [ 'type' => 'result', 'message' => $text ];
    }
}

if ( ! function_exists( 'nya_cmd_raf' ) ) {
    /**
     * /raf – Introduce Raf de Wit, friend of the studio.
     */
    function nya_cmd_raf( $argline, $meta, $user_level, $context = null ) {
        $text = "Raf de Wit is an Amsterdam‑based artist and a close friend of Studio NyA. " .
            "He is known for his monochromatic drawings using Conté pencil and charcoal, often manipulating photographs into delicate black‑and‑white studies. " .
            "Raf’s work explores mood and texture, and he frequently collaborates with designers and musicians. " .
            "Around the studio he lends a calm, thoughtful presence and contributes to occasional illustration and storyboarding projects.";
        return [ 'type' => 'result', 'message' => $text ];
    }
}

if ( ! function_exists( 'nya_cmd_ruben' ) ) {
    /**
     * /ruben – Introduce Ruben Piel, creative developer.
     */
    function nya_cmd_ruben( $argline, $meta, $user_level, $context = null ) {
        $text = "Ruben Piel is a developer and engineer connected to Studio NyA. " .
            "Trained in computer science and passionate about creative code, he builds interactive experiences and custom tools for art and design projects. " .
            "Ruben enjoys bridging engineering with aesthetics, whether prototyping web‑based installations or hacking together sensors for immersive pieces. " .
            "He believes technology should serve social and cultural values, making complex systems approachable and humane.";
        return [ 'type' => 'result', 'message' => $text ];
    }
}

if ( ! function_exists( 'nya_cmd_marcel' ) ) {
    /**
     * /marcel – Describe Marcel Tempelaars and his collaborations.
     */
    function nya_cmd_marcel( $argline, $meta, $user_level, $context = null ) {
        $text = "Marcel Tempelaars is a researcher at Wageningen University & Research who collaborates with Studio NyA on science‑inspired artworks. " .
            "In his day job at the Food Microbiology department he teaches and assists students with lab techniques like flow cytometry. " .
            "Marcel values curiosity, precision and teamwork. With NyA he shares insights from biology and helps translate complex scientific concepts into accessible visual stories.";
        return [ 'type' => 'result', 'message' => $text ];
    }
}

if ( ! function_exists( 'nya_cmd_design' ) ) {
    /**
     * /design – Explain the idea of design for values.
     */
    function nya_cmd_design( $argline, $meta, $user_level, $context = null ) {
        $text = "Design is never neutral. The concept of ‘design for values’ argues that values like justice, sustainability, autonomy, privacy and security should be embedded in a project from the start. " .
            "Rather than adding ethics as an afterthought, designers and engineers work with philosophers and social scientists to identify stakeholder values, translate them into design requirements and iteratively test their impacts. " .
            "This transdisciplinary approach helps create morally acceptable technologies and spaces that serve communities, not just markets.";
        return [ 'type' => 'result', 'message' => $text ];
    }
}

if ( ! function_exists( 'nya_cmd_engineering' ) ) {
    /**
     * /engineering – Discuss social value and ethics in engineering.
     */
    function nya_cmd_engineering( $argline, $meta, $user_level, $context = null ) {
        $text = "Engineering shapes the world: roads, bridges, apps, water systems and more. " .
            "Social value in engineering measures how these projects contribute to society beyond profit. Examples include earthquake‑resistant buildings, renewable energy grids, assistive robots and hydroponic farms. " .
            "Social value also involves fostering inclusive teams: embracing equality, diversity and inclusion, supporting mental health and ensuring that solutions are built with communities, not imposed on them. " .
            "Thoughtful engineering integrates sustainability and social justice into every stage of the process.";
        return [ 'type' => 'result', 'message' => $text ];
    }
}

// ------------------------------------------------------------
// Command: /addsite
// ------------------------------------------------------------
if ( ! function_exists( 'nya_cmd_addsite' ) ) {
    /**
     * /addsite – Allow users to submit a URL to be included in custom search.
     *
     * This command stores the base URL in a WordPress option so that future
     * searches can include results from the specified site. To prevent abuse
     * and inappropriate content, simple checks are performed on the domain name.
     * Administrators may review the list of custom sites via the WordPress
     * options interface. The list is stored as an array under the option
     * `nya_custom_sites`.
     *
     * @param string $argline URL provided by the user
     * @param array  $meta Command metadata from the registry
     * @param string $user_level Current user level
     * @param array|null $context Additional context
     * @return array Terminal payload
     */
    function nya_cmd_addsite( $argline, $meta, $user_level, $context = null ) {
        $url = trim( (string) $argline );
        if ( '' === $url ) {
            return [ 'type' => 'system', 'message' => 'Usage: /addsite [url]' ];
        }
        // Normalize and validate URL.
        if ( false === filter_var( $url, FILTER_VALIDATE_URL ) ) {
            return [ 'type' => 'system', 'message' => 'That doesn’t look like a valid URL.' ];
        }
        $parts = wp_parse_url( $url );
        if ( empty( $parts['host'] ) ) {
            return [ 'type' => 'system', 'message' => 'Could not determine the domain from that URL.' ];
        }
        $host = strtolower( $parts['host'] );
        // Basic ballotage: reject obvious adult or problematic domains.
        $banned = [ 'porn', 'adult', 'xxx', 'sex', 'playboy' ];
        foreach ( $banned as $bad ) {
            if ( false !== strpos( $host, $bad ) ) {
                return [ 'type' => 'system', 'message' => 'This URL is blocked due to content guidelines.' ];
            }
        }
        // Derive base URL (scheme + host) for WP JSON search. Use https by default.
        $scheme = isset( $parts['scheme'] ) ? $parts['scheme'] : 'https';
        $base   = $scheme . '://' . $host;
        // Retrieve existing list and update if necessary.
        $custom = get_option( 'nya_custom_sites', array() );
        if ( ! is_array( $custom ) ) {
            $custom = array();
        }
        if ( in_array( $base, $custom, true ) ) {
            return [ 'type' => 'system', 'message' => 'This site is already in the custom search list.' ];
        }
        $custom[] = $base;
        update_option( 'nya_custom_sites', $custom );
        return [ 'type' => 'system', 'message' => 'The site has been submitted and will be included in future searches after ballotage.' ];
    }
}

if ( ! function_exists( 'nya_terminal_get_sbn_instance' ) ) {
    function nya_terminal_get_sbn_instance() {
        return $GLOBALS['sbn_ask_the_network'] ?? null;
    }
}

if ( ! function_exists( 'nya_terminal_get_network_sites' ) ) {
    function nya_terminal_get_network_sites() {
        $inst = nya_terminal_get_sbn_instance();
        if ( $inst && method_exists( $inst, 'terminal_get_network_sites' ) ) {
            return (array) $inst->terminal_get_network_sites();
        }
        return array();
    }
}

if ( ! function_exists( 'nya_terminal_url_is_network_url' ) ) {
    function nya_terminal_url_is_network_url( $url ) {
        $host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
        if ( '' === $host ) {
            return false;
        }
        $host = preg_replace( '/^www\./', '', $host );
        foreach ( nya_terminal_get_network_sites() as $site ) {
            $base = isset( $site['base'] ) ? (string) $site['base'] : '';
            $base_host = strtolower( (string) wp_parse_url( $base, PHP_URL_HOST ) );
            $base_host = preg_replace( '/^www\./', '', $base_host );
            if ( $base_host && $host === $base_host ) {
                return true;
            }
        }
        return false;
    }
}

if ( ! function_exists( 'nya_cmd_scan' ) ) {
    function nya_cmd_scan( $argline, $meta, $user_level, $context = null ) {
        $argline = strtolower( trim( (string) $argline ) );
        if ( $argline === '' ) {
            $argline = 'network';
        }

        $inst = nya_terminal_get_sbn_instance();

        if ( $argline === 'network' && $inst && method_exists( $inst, 'terminal_get_site_pde_snapshot' ) ) {
            $snapshot = $inst->terminal_get_site_pde_snapshot();
            $lines = [];
            foreach ( (array) $snapshot as $slug => $info ) {
                $label  = $info['label'] ?? $slug;
                $code   = isset( $info['http_code'] ) ? intval( $info['http_code'] ) : 0;
                $status = ( $code >= 200 && $code <= 299 ) ? 'green' : 'amber';
                $lines[] = "{$label}: HTTP {$code} ({$status})";
            }
            $text = $lines ? implode( " | ", $lines ) : 'No sites configured yet in the PDE snapshot.';
            return [ 'type' => 'result', 'message' => "Scan network: {$text}" ];
        }

        if ( $argline === 'site' ) {
            $post = get_post();
            if ( $post ) {
                $title = get_the_title( $post );
                return [ 'type' => 'result', 'message' => "Scan site: you are reading “{$title}”." ];
            }
            return [ 'type' => 'result', 'message' => 'Scan site: no current post context.' ];
        }

        return [ 'type' => 'system', 'message' => 'Usage: /scan [site|network]' ];
    }
}

if ( ! function_exists( 'nya_cmd_summarize' ) ) {
    function nya_cmd_summarize( $argline, $meta, $user_level, $context = null ) {
        $argline = trim( (string) $argline );

        if ( $argline === '' ) {
            $post = get_post();
            if ( $post ) {
                $content = wp_strip_all_tags( $post->post_content );
                $sum = wp_trim_words( $content, 60 );
                return [ 'type' => 'result', 'message' => $sum ?: 'Nothing to summarize here yet.' ];
            }
            return [ 'type' => 'system', 'message' => 'Usage: /summarize [url]' ];
        }

        $url = esc_url_raw( $argline );
        if ( ! $url ) {
            return [ 'type' => 'system', 'message' => 'Invalid URL.' ];
        }

        $post_id = url_to_postid( $url );
        if ( $post_id ) {
            $post = get_post( $post_id );
            $content = $post ? wp_strip_all_tags( $post->post_content ) : '';
            $sum = wp_trim_words( $content, 60 );
            return [ 'type' => 'result', 'message' => $sum ?: 'Nothing to summarize in that post.' ];
        }

        // Network-wide summarizer: allow remote URLs from the configured NYA-network.
        if ( function_exists( 'nya_terminal_url_is_network_url' ) && nya_terminal_url_is_network_url( $url ) ) {
            $response = wp_remote_get( $url, array( 'timeout' => 6, 'redirection' => 3 ) );
            if ( is_wp_error( $response ) ) {
                return [ 'type' => 'system', 'message' => 'I could not reach that NYA-network URL right now.' ];
            }
            $code = wp_remote_retrieve_response_code( $response );
            if ( $code < 200 || $code >= 400 ) {
                return [ 'type' => 'system', 'message' => 'That NYA-network URL answered with HTTP ' . intval( $code ) . '.' ];
            }
            $body = wp_remote_retrieve_body( $response );
            $body = preg_replace( '/<script\b[^>]*>.*?<\/script>/is', ' ', (string) $body );
            $body = preg_replace( '/<style\b[^>]*>.*?<\/style>/is', ' ', (string) $body );
            $plain = html_entity_decode( wp_strip_all_tags( $body ), ENT_QUOTES, get_bloginfo( 'charset' ) );
            $plain = preg_replace( '/\s+/', ' ', trim( $plain ) );
            $sum = wp_trim_words( $plain, 80 );
            return [ 'type' => 'result', 'message' => $sum ?: 'Nothing readable found at that NYA-network URL.' ];
        }

        return [ 'type' => 'system', 'message' => 'Summarize accepts local posts and URLs from the configured NYA-network.' ];
    }
}

if ( ! function_exists( 'nya_cmd_sources' ) ) {
    function nya_cmd_sources( $argline, $meta, $user_level, $context = null ) {
        $argline = trim( (string) $argline );
        if ( $argline === '' ) {
            return [ 'type' => 'system', 'message' => 'Usage: /sources [topic]' ];
        }

        $inst = nya_terminal_get_sbn_instance();
        $keywords = [];
        if ( is_array( $context ) && ! empty( $context['keywords'] ) ) {
            $keywords = (array) $context['keywords'];
        }

        $query = $argline;
        if ( $keywords ) {
            $query = trim( implode( ' ', $keywords ) . ' ' . $argline );
        }

        if ( $inst && method_exists( $inst, 'terminal_find_network_links' ) ) {
            $links = $inst->terminal_find_network_links( $query, [], 5 );
            if ( empty( $links ) ) {
                return [ 'type' => 'result', 'message' => 'No related network links found yet.' ];
            }

            // Deduplicate results by title. Articles across different sites may have
            // identical or near‑identical titles; showing them once improves
            // readability and mirrors best‑practice deduplication strategies【35200158192342†L38-L60】. We
            // retain a list of sites that share the same title and indicate
            // duplicates with a +N suffix.
            $dedup = [];
            foreach ( $links as $l ) {
                $title = trim( (string) ( $l['title'] ?? '' ) );
                if ( $title === '' ) {
                    continue;
                }
                $site = $l['site_label'] ?? ( $l['site'] ?? '' );
                if ( ! isset( $dedup[ $title ] ) ) {
                    $dedup[ $title ] = [ 'sites' => [], 'title' => $title ];
                }
                $dedup[ $title ]['sites'][] = $site;
            }
            $lines = [];
            foreach ( $dedup as $entry ) {
                $sites = $entry['sites'];
                $title = $entry['title'];
                // Show first site as the primary source.
                $primary = array_shift( $sites );
                $suffix  = '';
                $dupCount = count( $sites );
                if ( $dupCount > 0 ) {
                    $suffix = ' (+' . $dupCount . ' more)';
                }
                $lines[] = trim( "{$primary}: {$title}{$suffix}" );
            }
            $header = 'Sources for “' . $argline . '”:\n';
            return [ 'type' => 'result', 'message' => $header . implode( "\n", $lines ) ];
        }

        return [ 'type' => 'system', 'message' => 'Sources engine not available.' ];
    }
}



// ------------------------------------------------------------
// Command: /claims
// ------------------------------------------------------------
if ( ! function_exists( 'nya_cmd_claims' ) ) {
    function nya_cmd_claims( $argline, $meta, $user_level, $context = null ) {
        $argline = trim( (string) $argline );
        if ( $argline === '' ) {
            return [ 'type' => 'system', 'message' => 'Usage: /claims [topic]' ];
        }

        $inst = nya_terminal_get_sbn_instance();
        $keywords = [];
        if ( is_array( $context ) && ! empty( $context['keywords'] ) ) {
            $keywords = (array) $context['keywords'];
        }

        $query = $argline;
        if ( $keywords ) {
            $query = trim( implode( ' ', $keywords ) . ' ' . $argline );
        }

        if ( $inst && method_exists( $inst, 'terminal_find_network_links' ) ) {
            $links = $inst->terminal_find_network_links( $query, [], 5 );
            if ( empty( $links ) ) {
                return [ 'type' => 'result', 'message' => 'No claim-rich articles found yet.' ];
            }

            $lines = [];
            foreach ( $links as $l ) {
                $site  = $l['site_label'] ?? ( $l['site'] ?? '' );
                $title = $l['title'] ?? '';
                $lines[] = trim( "{$site}: {$title}" );
            }

            return [
                'type'    => 'result',
                'message' => "Claim candidates for “{$argline}”:
" . implode( "
", $lines ),
            ];
        }

        return [ 'type' => 'system', 'message' => 'Claims engine not available.' ];
    }
}


// ------------------------------------------------------------
// Command: /rights
// ------------------------------------------------------------
if ( ! function_exists( 'nya_cmd_rights' ) ) {
    function nya_cmd_rights( $argline, $meta, $user_level, $context = null ) {
        $argline = trim( (string) $argline );
        if ( $argline === '' ) {
            return [ 'type' => 'system', 'message' => 'Usage: /rights [topic]' ];
        }

        if ( ! class_exists( 'NYA_BCLM_Registry' ) ) {
            return [ 'type' => 'system', 'message' => 'BCLM registry not available.' ];
        }

        $concepts = NYA_BCLM_Registry::all_concepts();
        if ( empty( $concepts ) ) {
            return [ 'type' => 'system', 'message' => 'No BCLM concepts loaded.' ];
        }

        $needles = [ 'RIGHT', 'RIGHTS', 'DUTY', 'CARE', 'LAW', 'RULE' ];
        $matches = [];

        foreach ( $concepts as $c ) {
            $id    = strtoupper( (string) ( $c['id'] ?? '' ) );
            $label = strtoupper( (string) ( $c['label'] ?? '' ) );

            foreach ( $needles as $n ) {
                if ( ( $id && strpos( $id, $n ) !== false ) || ( $label && strpos( $label, $n ) !== false ) ) {
                    $matches[] = $c;
                    break;
                }
            }
        }

        if ( empty( $matches ) ) {
            return [ 'type' => 'result', 'message' => 'No rights-related BCLM concepts found.' ];
        }

        $lines = [];
        $count = 0;
        foreach ( $matches as $c ) {
            $cid   = (string) ( $c['id'] ?? '' );
            $clab  = (string) ( $c['label'] ?? '' );
            if ( $cid || $clab ) {
                $lines[] = trim( "{$cid} — {$clab}" );
                $count++;
            }
            if ( $count >= 8 ) {
                break;
            }
        }

        $msg  = "Rights & duty-of-care concepts to explore for “{$argline}”:
";
        $msg .= implode( "
", $lines );
        $msg .= "

Tip: use /bclm [concept_id] for definitions.";

        return [ 'type' => 'result', 'message' => $msg ];
    }
}

if ( ! function_exists( 'nya_cmd_compare' ) ) {
    function nya_cmd_compare( $argline, $meta, $user_level, $context = null ) {
        $argline = trim( (string) $argline );
        if ( $argline === '' || false === stripos( $argline, 'vs' ) ) {
            return [ 'type' => 'system', 'message' => 'Usage: /compare [topicA] vs [topicB]' ];
        }

        $parts = preg_split( '/\s+vs\s+/i', $argline );
        $a = trim( $parts[0] ?? '' );
        $b = trim( $parts[1] ?? '' );

        if ( $a === '' || $b === '' ) {
            return [ 'type' => 'system', 'message' => 'Usage: /compare [topicA] vs [topicB]' ];
        }

        $inst = function_exists( 'nya_terminal_get_sbn_instance' ) ? nya_terminal_get_sbn_instance() : null;
        if ( ! $inst || ! method_exists( $inst, 'terminal_find_network_links' ) ) {
            return [ 'type' => 'system', 'message' => 'Compare engine not available.' ];
        }

        // Fetch limited hit sets for both topics.
        $links_a = $inst->terminal_find_network_links( $a, [], 5 );
        $links_b = $inst->terminal_find_network_links( $b, [], 5 );

        $counts_a = [];
        foreach ( (array) $links_a as $l ) {
            $site = $l['site_label'] ?? ( $l['site'] ?? 'Unknown' );
            if ( ! isset( $counts_a[ $site ] ) ) {
                $counts_a[ $site ] = 0;
            }
            $counts_a[ $site ]++;
        }

        $counts_b = [];
        foreach ( (array) $links_b as $l ) {
            $site = $l['site_label'] ?? ( $l['site'] ?? 'Unknown' );
            if ( ! isset( $counts_b[ $site ] ) ) {
                $counts_b[ $site ] = 0;
            }
            $counts_b[ $site ]++;
        }

        $all_sites = array_unique( array_merge( array_keys( $counts_a ), array_keys( $counts_b ) ) );
        sort( $all_sites, SORT_NATURAL | SORT_FLAG_CASE );

        $coverage_lines = [];
        foreach ( $all_sites as $site_label ) {
            $ca = $counts_a[ $site_label ] ?? 0;
            $cb = $counts_b[ $site_label ] ?? 0;
            $coverage_lines[] = "- {$site_label}: {$ca} vs {$cb}";
        }

        $hit_lines_a = [];
        $i = 1;
        foreach ( (array) $links_a as $l ) {
            $site  = $l['site_label'] ?? ( $l['site'] ?? '' );
            $title = $l['title'] ?? '';
            if ( $title ) {
                $hit_lines_a[] = $i . ') ' . trim( "{$site}: {$title}" );
                $i++;
            }
            if ( $i > 5 ) {
                break;
            }
        }

        $hit_lines_b = [];
        $j = 1;
        foreach ( (array) $links_b as $l ) {
            $site  = $l['site_label'] ?? ( $l['site'] ?? '' );
            $title = $l['title'] ?? '';
            if ( $title ) {
                $hit_lines_b[] = $j . ') ' . trim( "{$site}: {$title}" );
                $j++;
            }
            if ( $j > 5 ) {
                break;
            }
        }

        $msg = [];
        $msg[] = "Compare “{$a}” vs “{$b}”";
        $msg[] = 'Coverage snapshot (top search hits across the network):';
        $msg[] = $coverage_lines ? implode( "\n", $coverage_lines ) : '- No hits yet.';

        if ( $hit_lines_a ) {
            $msg[] = '';
            $msg[] = "Top hits for “{$a}”:";
            $msg[] = implode( "\n", $hit_lines_a );
        }

        if ( $hit_lines_b ) {
            $msg[] = '';
            $msg[] = "Top hits for “{$b}”:";
            $msg[] = implode( "\n", $hit_lines_b );
        }

        return [ 'type' => 'result', 'message' => implode( "\n", $msg ) ];
    }
}

if ( ! function_exists( 'nya_cmd_modes' ) ) {
    function nya_cmd_modes( $argline, $meta, $user_level, $context = null ) {
        $modes = nya_terminal_get_modes();
        if ( empty( $modes ) ) {
            return [ 'type' => 'system', 'message' => 'No BCLM modes are registered yet.' ];
        }

        $lines = [];
        foreach ( $modes as $code => $m ) {
            $lock = ( ( $m['level'] ?? 'guest' ) === 'citizen' && $user_level !== 'citizen' ) ? ' 🔒' : '';
            $label = $m['label'] ?? $code;
            $emoji = $m['emoji'] ?? '';
            $lines[] = trim( "{$emoji} {$code}{$lock} — {$label}" );
        }

        return [
            'type'    => 'system',
            'message' => "Available modes:\n" . implode( "\n", $lines ),
        ];
    }
}

if ( ! function_exists( 'nya_cmd_bclm' ) ) {
    function nya_cmd_bclm( $argline, $meta, $user_level, $context = null ) {
        $argline = trim( (string) $argline );
        if ( $argline === '' ) {
            return [ 'type' => 'system', 'message' => 'Usage: /bclm [concept_id|label]' ];
        }

        if ( ! class_exists( 'NYA_BCLM_Registry' ) ) {
            return [ 'type' => 'system', 'message' => 'BCLM registry not available.' ];
        }

        $concept = NYA_BCLM_Registry::find_concept( $argline );
        if ( ! $concept ) {
            return [ 'type' => 'system', 'message' => "Unknown BCLM concept: {$argline}." ];
        }

        $id    = $concept['id'] ?? '';
        $label = $concept['label'] ?? '';
        $adult = $concept['definition_adult'] ?? '';
        $kid   = $concept['definition_kid'] ?? '';

        $msg_lines = [];
        $msg_lines[] = strtoupper( (string) $id ) . ( $label ? " — {$label}" : '' );
        if ( $adult ) {
            $msg_lines[] = "Adult: {$adult}";
        }
        if ( $kid ) {
            $msg_lines[] = "Kid: {$kid}";
        }

        return [
            'type'    => 'result',
            'message' => implode( "\n", $msg_lines ),
        ];
    }
}

// ------------------------------------------------------------
// REST endpoints (optional; frontend can keep using sbn/v1/question)
// ------------------------------------------------------------
if ( ! function_exists( 'nya_terminal_register_rest_routes' ) ) {
    function nya_terminal_register_rest_routes() {
        register_rest_route(
            'nya/v1',
            '/terminal/status',
            [
                'methods'  => 'GET',
                'callback' => function () {
                    $level = function_exists( 'nya_user_level' ) ? nya_user_level() : 'guest';
                    return [
                        'user_level'       => $level,
                        'commands'         => class_exists( 'NYA_Command_Registry' ) ? NYA_Command_Registry::all() : [],
                        'modes'            => nya_terminal_get_modes(),
                        'network_sites'    => function_exists( 'nya_terminal_get_network_sites' ) ? nya_terminal_get_network_sites() : array(),
                        'advanced_enabled' => true,
                    ];
                },
                'permission_callback' => '__return_true',
            ]
        );

        register_rest_route(
            'nya/v1',
            '/terminal/execute',
            [
                'methods'  => 'POST',
                'callback' => function ( WP_REST_Request $request ) {
                    $input = $request->get_param( 'input' ) ?? '';
                    $trim  = trim( (string) $input );
                    $cmd   = '';
                    if ( $trim && $trim[0] === '/' ) {
                        $line  = ltrim( $trim, '/' );
                        $parts = preg_split( '/\s+/', $line, 2 );
                        $cmd   = strtolower( $parts[0] ?? '' );
                    }

                    // DEF-22: /quiz must start a question immediately, never return only usage text.
                    if ( in_array( $cmd, array( 'quiz', 'q' ), true ) ) {
                        $line    = ltrim( $trim, '/' );
                        $parts   = preg_split( '/\s+/', $line, 2 );
                        $argline = isset( $parts[1] ) ? trim( (string) $parts[1] ) : '';
                        if ( '' === $argline && function_exists( 'nya_design_quiz_immediate_payload' ) ) {
                            return nya_design_quiz_immediate_payload();
                        }
                    }

                    // v2.0-DEF-04: removed advanced/citizen security gate so every registered slash code can execute.

                    $shortcut = nya_parse_bclm_shortcut( $input );
                    if ( $shortcut ) {
                        return nya_handle_bclm_shortcut( $shortcut );
                    }

                    $response = NYA_Command_Router::handle_input( $input );
                    if ( $response !== null ) {
                        return $response;
                    }

                    return [ 'type' => 'system', 'message' => 'Not a command. Use the standard Some-B chat.' ];
                },
                'permission_callback' => '__return_true',
            ]
        );


        register_rest_route(
            'nya/v1',
            '/article/preview',
            [
                'methods'  => 'POST',
                'callback' => function ( WP_REST_Request $request ) {
                    $url = esc_url_raw( (string) ( $request->get_param( 'url' ) ?? '' ) );
                    if ( ! $url ) {
                        return [ 'error' => true, 'message' => 'No article URL supplied.' ];
                    }

                    $parts = wp_parse_url( $url );
                    if ( empty( $parts['host'] ) ) {
                        return [ 'error' => true, 'message' => 'Invalid article URL.' ];
                    }

                    $host = strtolower( $parts['host'] );
                    $banned = [ 'porn', 'adult', 'xxx', 'sex', 'casino', 'gambling' ];
                    foreach ( $banned as $bad ) {
                        if ( false !== strpos( $host, $bad ) ) {
                            return [ 'error' => true, 'message' => 'This source is blocked by ballotage.' ];
                        }
                    }

                    $response = wp_remote_get(
                        $url,
                        [
                            'timeout'     => 6,
                            'redirection' => 3,
                            'user-agent'  => 'some-B Network Radar/1.0',
                        ]
                    );

                    if ( is_wp_error( $response ) ) {
                        return [ 'error' => true, 'message' => 'Could not reach that article.' ];
                    }

                    $code = wp_remote_retrieve_response_code( $response );
                    if ( $code < 200 || $code >= 400 ) {
                        return [ 'error' => true, 'message' => 'The article source returned HTTP ' . intval( $code ) . '.' ];
                    }

                    $html = wp_remote_retrieve_body( $response );
                    if ( empty( $html ) ) {
                        return [ 'error' => true, 'message' => 'The article returned no readable body.' ];
                    }

                    $title = '';
                    if ( preg_match( '/<title[^>]*>(.*?)<\/title>/is', $html, $m ) ) {
                        $title = wp_strip_all_tags( html_entity_decode( $m[1], ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
                    }

                    // Remove noisy elements.
                    $clean = preg_replace( '/<script\b[^>]*>.*?<\/script>/is', '', $html );
                    $clean = preg_replace( '/<style\b[^>]*>.*?<\/style>/is', '', $clean );
                    $clean = preg_replace( '/<nav\b[^>]*>.*?<\/nav>/is', '', $clean );
                    $clean = preg_replace( '/<footer\b[^>]*>.*?<\/footer>/is', '', $clean );
                    $clean = preg_replace( '/<form\b[^>]*>.*?<\/form>/is', '', $clean );

                    $paragraphs = [];
                    if ( preg_match_all( '/<p\b[^>]*>(.*?)<\/p>/is', $clean, $pm ) ) {
                        foreach ( $pm[1] as $p ) {
                            $plain = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( html_entity_decode( $p, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) ) );
                            if ( strlen( $plain ) < 50 ) {
                                continue;
                            }
                            $paragraphs[] = $plain;
                            if ( count( $paragraphs ) >= 8 ) {
                                break;
                            }
                        }
                    }

                    if ( empty( $paragraphs ) ) {
                        $plain = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( html_entity_decode( $clean, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) ) );
                        $paragraphs[] = wp_trim_words( $plain, 160 );
                    }

                    $content = '';
                    foreach ( $paragraphs as $p ) {
                        $content .= '<p>' . esc_html( $p ) . '</p>';
                    }

                    return [
                        'error'   => false,
                        'title'   => $title ? $title : $host,
                        'source'  => $host,
                        'url'     => esc_url_raw( $url ),
                        'content' => $content,
                    ];
                },
                'permission_callback' => '__return_true',
            ]
        );
    }
}


// ------------------------------------------------------------
// Some-B Design Intelligence Test commands
// ------------------------------------------------------------
if ( ! function_exists( 'nya_design_quiz_session_key' ) ) {
    function nya_design_quiz_session_key() {
        $uid = function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0;
        if ( $uid > 0 ) {
            return 'sbn_design_quiz_user_' . $uid;
        }
        $ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0.0.0.0';
        $ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : 'unknown';
        return 'sbn_design_quiz_guest_' . md5( $ip . '|' . $ua );
    }
}

if ( ! function_exists( 'nya_design_quiz_categories' ) ) {
    function nya_design_quiz_categories() {
        return [ 'principles', 'composition', 'color', 'typography', 'hierarchy', 'communication', 'marketing', 'math' ];
    }
}

if ( ! function_exists( 'nya_design_quiz_questions' ) ) {
    function nya_design_quiz_questions() {
        return [
            'principles' => [
                [
                    'title'    => 'Design Principles',
                    'question' => 'Which statement best describes design?',
                    'answers'  => [
                        'A' => 'Decoration added after the real work is done',
                        'B' => 'A controlled communication system that shapes attention, meaning, and action',
                        'C' => 'Whatever looks trendy this month',
                        'D' => 'Making everything bigger and brighter',
                    ],
                    'correct' => 'B',
                    'explain' => 'Design is not just surface style. It organizes information so people notice, understand, feel, decide, and act.',
                ],
                [
                    'title'    => 'Design Principles',
                    'question' => 'Which principle says related elements should visually belong together?',
                    'answers'  => [ 'A' => 'Proximity', 'B' => 'Randomness', 'C' => 'Saturation', 'D' => 'Resolution' ],
                    'correct' => 'A',
                    'explain' => 'Proximity groups related information. When related things sit near each other, the viewer reads them as one unit.',
                ],
                [
                    'title'    => 'Design Principles',
                    'question' => 'What is the strongest warning sign that a design has no clear hierarchy?',
                    'answers'  => [ 'A' => 'Everything competes for attention', 'B' => 'The grid is invisible', 'C' => 'There is only one accent color', 'D' => 'The image is black and white' ],
                    'correct' => 'A',
                    'explain' => 'If everything shouts, nothing leads. Hierarchy gives the viewer an order: first this, then this, then this.',
                ],
                [
                    'title'    => 'Design Principles',
                    'question' => 'Why is repetition useful in a design system?',
                    'answers'  => [ 'A' => 'It makes every page identical and boring', 'B' => 'It creates recognition, rhythm, and trust', 'C' => 'It removes the need for contrast', 'D' => 'It hides poor content' ],
                    'correct' => 'B',
                    'explain' => 'Repetition makes patterns predictable. Predictable visual language helps users understand the system faster.',
                ],
            ],
            'composition' => [
                [
                    'title'    => 'Composition',
                    'question' => 'What usually makes a layout feel organized?',
                    'answers'  => [ 'A' => 'More decoration', 'B' => 'Clear alignment, spacing, and hierarchy', 'C' => 'More fonts', 'D' => 'A bigger logo' ],
                    'correct' => 'B',
                    'explain' => 'Composition becomes stronger when elements have clear relationships: alignment, grouping, rhythm, spacing, and hierarchy.',
                ],
                [
                    'title'    => 'Composition',
                    'question' => 'Why does negative space matter?',
                    'answers'  => [ 'A' => 'It is wasted space', 'B' => 'It gives elements room to breathe and helps the viewer separate ideas', 'C' => 'It only works in luxury ads', 'D' => 'It means the page is unfinished' ],
                    'correct' => 'B',
                    'explain' => 'Negative space is active. It separates, frames, slows down, and gives importance to what remains visible.',
                ],
                [
                    'title'    => 'Composition',
                    'question' => 'A focal point is the part of a composition that:',
                    'answers'  => [ 'A' => 'Receives attention first', 'B' => 'Must always be centered', 'C' => 'Must always be a logo', 'D' => 'Should be hidden' ],
                    'correct' => 'A',
                    'explain' => 'A focal point is the first visual anchor. It can be made through scale, contrast, color, shape, isolation, or position.',
                ],
            ],
            'color' => [
                [
                    'title'    => 'Color',
                    'question' => 'Why use one bright accent color in a mostly black-and-white design system?',
                    'answers'  => [ 'A' => 'To make everything equally important', 'B' => 'To create a strong signal point', 'C' => 'To hide weak typography', 'D' => 'To avoid layout decisions' ],
                    'correct' => 'B',
                    'explain' => 'A single accent color works as a visual signal. It tells the eye where attention should go.',
                ],
                [
                    'title'    => 'Color',
                    'question' => 'What does saturation describe?',
                    'answers'  => [ 'A' => 'How vivid or muted a color is', 'B' => 'How large a typeface is', 'C' => 'How many pages are in a site', 'D' => 'How fast a button loads' ],
                    'correct' => 'A',
                    'explain' => 'Saturation is intensity. High saturation feels vivid and loud; low saturation feels muted, greyed, or restrained.',
                ],
                [
                    'title'    => 'Color',
                    'question' => 'For readable text, the most important color relationship is:',
                    'answers'  => [ 'A' => 'Trendiness', 'B' => 'Contrast between text and background', 'C' => 'Using as many colors as possible', 'D' => 'Matching the logo exactly everywhere' ],
                    'correct' => 'B',
                    'explain' => 'Readability depends heavily on contrast. If the viewer cannot separate text from background, the message fails.',
                ],
            ],
            'typography' => [
                [
                    'title'    => 'Typography',
                    'question' => 'What makes body text easier to read?',
                    'answers'  => [ 'A' => 'Very tight line spacing', 'B' => 'All caps for every paragraph', 'C' => 'Comfortable line height and clear contrast', 'D' => 'Using as many fonts as possible' ],
                    'correct' => 'C',
                    'explain' => 'Readable type depends on clear contrast, usable line height, consistent rhythm, and restraint.',
                ],
                [
                    'title'    => 'Typography',
                    'question' => 'Why should generated links inherit the site UI font?',
                    'answers'  => [ 'A' => 'So automated content still feels like one interface', 'B' => 'So every link looks random', 'C' => 'So contact links become harder to read', 'D' => 'So typography rules disappear' ],
                    'correct' => 'A',
                    'explain' => 'Generated content is still part of the interface. Contact links, slash chips, and buttons should share the same typographic voice.',
                ],
                [
                    'title'    => 'Typography',
                    'question' => 'Using too many typefaces usually creates:',
                    'answers'  => [ 'A' => 'A clearer system', 'B' => 'Noise and inconsistent hierarchy', 'C' => 'Better accessibility automatically', 'D' => 'A stronger grid' ],
                    'correct' => 'B',
                    'explain' => 'Too many typefaces create visual noise. Strong systems usually use limited font roles with clear weights and spacing.',
                ],
            ],
            'hierarchy' => [
                [
                    'title'    => 'Hierarchy',
                    'question' => 'Which set of tools creates visual hierarchy?',
                    'answers'  => [ 'A' => 'Scale, contrast, position, weight, spacing', 'B' => 'Only decoration', 'C' => 'Only the logo', 'D' => 'Only image resolution' ],
                    'correct' => 'A',
                    'explain' => 'Hierarchy is built from differences. Size, contrast, position, weight, and space tell the eye what matters first.',
                ],
                [
                    'title'    => 'Hierarchy',
                    'question' => 'If a call-to-action button is important, it should usually be:',
                    'answers'  => [ 'A' => 'Hidden among identical links', 'B' => 'Visually distinct and placed where the decision happens', 'C' => 'Smaller than body text', 'D' => 'Styled differently on every page' ],
                    'correct' => 'B',
                    'explain' => 'Important actions need visibility and context. The user should see the next step exactly when motivation is highest.',
                ],
            ],
            'communication' => [
                [
                    'title'    => 'Communication',
                    'question' => 'In communication theory, what does noise mean?',
                    'answers'  => [ 'A' => 'Only sound', 'B' => 'Anything that interferes with the message being understood', 'C' => 'A bright color', 'D' => 'A slogan' ],
                    'correct' => 'B',
                    'explain' => 'Noise can be visual clutter, bad wording, cultural mismatch, weak contrast, poor timing, or technical failure.',
                ],
                [
                    'title'    => 'Communication',
                    'question' => 'Denotation is:',
                    'answers'  => [ 'A' => 'The literal thing shown or said', 'B' => 'The emotional association around it', 'C' => 'The advertising budget', 'D' => 'The image crop ratio' ],
                    'correct' => 'A',
                    'explain' => 'Denotation is the direct/literal meaning. Connotation is the implied, cultural, emotional, or symbolic meaning.',
                ],
                [
                    'title'    => 'Communication',
                    'question' => 'Good communication design should reduce:',
                    'answers'  => [ 'A' => 'Meaning', 'B' => 'Clarity', 'C' => 'Noise and ambiguity', 'D' => 'Accessibility' ],
                    'correct' => 'C',
                    'explain' => 'The designer removes unnecessary confusion so the intended message survives the trip from sender to receiver.',
                ],
            ],
            'marketing' => [
                [
                    'title'    => 'Marketing',
                    'question' => 'A call to action works best when it is:',
                    'answers'  => [ 'A' => 'Hidden at the bottom', 'B' => 'Clear, visible, and connected to user motivation', 'C' => 'Written in five different styles', 'D' => 'Less important than decoration' ],
                    'correct' => 'B',
                    'explain' => 'A call to action works when people understand what to do, why it matters, and where to act.',
                ],
                [
                    'title'    => 'Marketing',
                    'question' => 'Positioning answers which question?',
                    'answers'  => [ 'A' => 'Where does this fit in the mind of the audience?', 'B' => 'How many decorative icons can we add?', 'C' => 'What is the largest possible logo?', 'D' => 'How do we avoid making a choice?' ],
                    'correct' => 'A',
                    'explain' => 'Positioning defines the place a brand, offer, or message occupies relative to alternatives in the audience mind.',
                ],
                [
                    'title'    => 'Marketing',
                    'question' => 'A landing page should usually optimize for:',
                    'answers'  => [ 'A' => 'One clear primary action', 'B' => 'Ten competing actions', 'C' => 'Maximum confusion', 'D' => 'No measurable result' ],
                    'correct' => 'A',
                    'explain' => 'Landing pages work best when the primary next step is obvious, desirable, and measurable.',
                ],
            ],
            'math' => [
                [
                    'title'    => 'Design Math',
                    'question' => 'If 1,000 people visit a landing page and 50 sign up, what is the conversion rate?',
                    'answers'  => [ 'A' => '0.5%', 'B' => '5%', 'C' => '15%', 'D' => '50%' ],
                    'correct' => 'B',
                    'explain' => '50 divided by 1,000 times 100 equals 5%.',
                ],
                [
                    'title'    => 'Design Math',
                    'question' => 'A modular spacing system helps because it:',
                    'answers'  => [ 'A' => 'Creates consistent rhythm and predictable relationships', 'B' => 'Forces every element to be the same size', 'C' => 'Removes all hierarchy', 'D' => 'Only matters in print' ],
                    'correct' => 'A',
                    'explain' => 'Spacing systems use repeated values or ratios so layouts feel intentional instead of manually guessed.',
                ],
                [
                    'title'    => 'Design Math',
                    'question' => 'Return on ad spend is usually calculated as:',
                    'answers'  => [ 'A' => 'Ad spend divided by font size', 'B' => 'Revenue divided by ad spend', 'C' => 'Clicks divided by colors', 'D' => 'Logo size divided by page height' ],
                    'correct' => 'B',
                    'explain' => 'ROAS = revenue divided by ad spend. It connects design and campaign performance to money returned.',
                ],
            ],
        ];
    }
}

if ( ! function_exists( 'nya_design_quiz_normalize_topic' ) ) {
    function nya_design_quiz_normalize_topic( $topic ) {
        $topic = strtolower( trim( (string) $topic ) );
        $topic = preg_replace( '/[^a-z0-9_-]/', '', $topic );
        if ( '' === $topic || 'full' === $topic || 'design' === $topic || 'principle' === $topic || 'topic' === $topic || '[topic]' === $topic ) {
            return 'principles';
        }
        return $topic;
    }
}

if ( ! function_exists( 'nya_design_quiz_get_state' ) ) {
    function nya_design_quiz_get_state() {
        $state = get_transient( nya_design_quiz_session_key() );
        if ( ! is_array( $state ) ) {
            $state = [ 'score' => 0, 'answered' => 0, 'current' => null, 'history' => [], 'index' => [] ];
        }
        if ( ! isset( $state['index'] ) || ! is_array( $state['index'] ) ) {
            $state['index'] = [];
        }
        if ( ! isset( $state['history'] ) || ! is_array( $state['history'] ) ) {
            $state['history'] = [];
        }
        return $state;
    }
}

if ( ! function_exists( 'nya_design_quiz_pick_question' ) ) {
    function nya_design_quiz_pick_question( $topic, $state ) {
        $questions = nya_design_quiz_questions();
        if ( ! isset( $questions[ $topic ] ) ) {
            return null;
        }
        $count = count( $questions[ $topic ] );
        $idx = isset( $state['index'][ $topic ] ) ? (int) $state['index'][ $topic ] : 0;
        if ( $idx < 0 ) { $idx = 0; }
        $idx = $idx % max( 1, $count );
        return [ 'index' => $idx, 'question' => $questions[ $topic ][ $idx ], 'total' => $count ];
    }
}

if ( ! function_exists( 'nya_design_quiz_topic_list' ) ) {
    function nya_design_quiz_topic_list() {
        return '/quiz principles, /quiz composition, /quiz color, /quiz typography, /quiz hierarchy, /quiz communication, /quiz marketing, /quiz math';
    }
}

if ( ! function_exists( 'nya_cmd_design_test' ) ) {
    function nya_cmd_design_test( $argline, $meta, $user_level, $context = null ) {
        $message = "Some-B Design Intelligence Test\n\n" .
            "This is not a trivia toy. It tests design principles: composition, color, typography, hierarchy, communication, marketing, and the math behind visual decisions.\n\n" .
            "Start with /quiz for the principles track.\n" .
            "Or choose a lane:\n" .
            "/quiz composition\n/quiz color\n/quiz typography\n/quiz hierarchy\n/quiz communication\n/quiz marketing\n/quiz math\n\n" .
            "Answer with /answer A, /answer B, /answer C, or /answer D. Use /score to see your Design Intelligence profile.";

        return [ 'type' => 'result', 'message' => $message, 'meta' => [ 'action' => 'design_test_intro' ] ];
    }
}

if ( ! function_exists( 'nya_cmd_quiz' ) ) {
    function nya_cmd_quiz( $argline, $meta, $user_level, $context = null ) {
        $topic = nya_design_quiz_normalize_topic( $argline );
        $questions = nya_design_quiz_questions();

        if ( ! isset( $questions[ $topic ] ) ) {
            return [
                'type'    => 'system',
                'message' => "Unknown quiz topic. Try: " . nya_design_quiz_topic_list() . '.',
            ];
        }

        $state = nya_design_quiz_get_state();
        $picked = nya_design_quiz_pick_question( $topic, $state );
        if ( ! $picked ) {
            return [ 'type' => 'system', 'message' => 'Quiz topic could not be loaded. Try /design-test.' ];
        }

        $q = $picked['question'];
        $state['current'] = [ 'topic' => $topic, 'index' => $picked['index'] ];
        set_transient( nya_design_quiz_session_key(), $state, HOUR_IN_SECONDS );

        $lines = [];
        $lines[] = 'SOME-B DESIGN QUIZ';
        $lines[] = '';
        $lines[] = 'You asked for /quiz, so here is a real multiple-choice design-principles question.';
        $lines[] = '';
        $lines[] = 'Question ' . ( $picked['index'] + 1 ) . ' / ' . $picked['total'] . ' — ' . $q['title'];
        $lines[] = '';
        $lines[] = $q['question'];
        $lines[] = '';
        foreach ( $q['answers'] as $letter => $answer ) {
            $lines[] = $letter . '. ' . $answer;
        }
        $lines[] = '';
        $lines[] = 'Choices: A, B, C, or D.';
        $lines[] = 'Answer with /answer A, /answer B, /answer C, or /answer D.';
        $lines[] = 'Other lanes: /quiz composition, /quiz color, /quiz typography, /quiz communication, /quiz marketing, /quiz math.';

        return [ 'type' => 'result', 'message' => implode( "\n", $lines ), 'meta' => [ 'action' => 'quiz_question', 'topic' => $topic ] ];
    }
}

if ( ! function_exists( 'nya_cmd_answer' ) ) {
    function nya_cmd_answer( $argline, $meta, $user_level, $context = null ) {
        $letter = strtoupper( trim( (string) $argline ) );
        $letter = substr( preg_replace( '/[^A-D]/', '', $letter ), 0, 1 );
        if ( '' === $letter ) {
            return [ 'type' => 'system', 'message' => 'Answer with /answer A, /answer B, /answer C, or /answer D.' ];
        }

        $state = nya_design_quiz_get_state();
        if ( empty( $state['current'] ) || ! is_array( $state['current'] ) ) {
            return [ 'type' => 'system', 'message' => 'No active quiz question found. Start with /quiz.' ];
        }

        $topic = isset( $state['current']['topic'] ) ? (string) $state['current']['topic'] : 'principles';
        $idx   = isset( $state['current']['index'] ) ? (int) $state['current']['index'] : 0;
        $questions = nya_design_quiz_questions();
        if ( ! isset( $questions[ $topic ][ $idx ] ) ) {
            return [ 'type' => 'system', 'message' => 'The active quiz question could not be found. Start again with /quiz.' ];
        }

        $q = $questions[ $topic ][ $idx ];
        $correct = strtoupper( $q['correct'] );
        $is_correct = ( $letter === $correct );

        $state['answered'] = isset( $state['answered'] ) ? (int) $state['answered'] + 1 : 1;
        $state['score'] = isset( $state['score'] ) ? (int) $state['score'] : 0;
        if ( $is_correct ) { $state['score']++; }
        $state['history'][] = [ 'topic' => $topic, 'index' => $idx, 'answer' => $letter, 'correct' => $correct, 'ok' => $is_correct ];
        $state['current'] = null;
        $state['index'][ $topic ] = ( $idx + 1 ) % max( 1, count( $questions[ $topic ] ) );
        set_transient( nya_design_quiz_session_key(), $state, HOUR_IN_SECONDS );

        $next = '/quiz ' . $topic;
        $lines = [];
        $lines[] = $is_correct ? 'Correct.' : 'Not quite.';
        $lines[] = '';
        $lines[] = 'Correct answer: ' . $correct . '. ' . ( $q['answers'][ $correct ] ?? '' );
        $lines[] = '';
        $lines[] = $q['explain'];
        $lines[] = '';
        $lines[] = 'Current score: ' . (int) $state['score'] . ' / ' . (int) $state['answered'];
        $lines[] = '';
        $lines[] = 'Next: ' . $next . ' or choose another lane: /quiz color, /quiz typography, /quiz marketing, /quiz math. Use /score for your result profile.';

        return [ 'type' => 'result', 'message' => implode( "\n", $lines ) ];
    }
}

if ( ! function_exists( 'nya_cmd_lesson' ) ) {
    function nya_cmd_lesson( $argline, $meta, $user_level, $context = null ) {
        $topic = nya_design_quiz_normalize_topic( $argline );
        $lessons = [
            'principles'   => 'Design is controlled communication: attention first, meaning second, trust third, action last.',
            'composition'  => 'Composition arranges elements so the viewer understands order, grouping, rhythm, and focus.',
            'hierarchy'    => 'Hierarchy controls attention. Size, contrast, position, weight, and spacing tell the eye where to go.',
            'color'        => 'Color is not decoration. Color creates contrast, emotion, structure, recognition, and signal.',
            'typography'   => 'Typography controls voice, rhythm, readability, and trust before the words are even understood.',
            'communication'=> 'Communication design protects the message from noise between sender and receiver.',
            'marketing'    => 'Marketing design turns attention into action by making value and next steps clear.',
            'math'         => 'Design math appears in ratios, grids, spacing systems, contrast, conversion rates, testing, and performance metrics.',
        ];
        if ( ! isset( $lessons[ $topic ] ) ) {
            return [ 'type' => 'result', 'message' => "Available lessons:\n/lesson principles\n/lesson composition\n/lesson hierarchy\n/lesson color\n/lesson typography\n/lesson communication\n/lesson marketing\n/lesson math" ];
        }
        return [ 'type' => 'result', 'message' => 'LESSON: ' . strtoupper( $topic ) . "\n\n" . $lessons[ $topic ] . "\n\nNow test it with:\n/quiz " . $topic ];
    }
}

if ( ! function_exists( 'nya_cmd_score' ) ) {
    function nya_cmd_score( $argline, $meta, $user_level, $context = null ) {
        $state = nya_design_quiz_get_state();
        if ( empty( $state['answered'] ) ) {
            return [ 'type' => 'result', 'message' => 'No Design Intelligence score yet. Start with /quiz.' ];
        }
        $score = (int) ( $state['score'] ?? 0 );
        $answered = max( 1, (int) ( $state['answered'] ?? 0 ) );
        $pct = round( ( $score / $answered ) * 100 );
        if ( $pct >= 81 ) { $profile = 'Design Strategist'; $note = 'You connect visual systems, audience behavior, persuasion, and measurable results.'; }
        elseif ( $pct >= 61 ) { $profile = 'Communication Designer'; $note = 'You understand that design is controlled communication, not decoration.'; }
        elseif ( $pct >= 41 ) { $profile = 'Design Operator'; $note = 'You understand hierarchy, composition, color, and message structure at a practical level.'; }
        elseif ( $pct >= 21 ) { $profile = 'Layout Beginner'; $note = 'You know some basics, but the system behind the decisions still needs sharpening.'; }
        else { $profile = 'Visual Tourist'; $note = 'You notice design, but you are still learning how it works.'; }
        return [ 'type' => 'result', 'message' => "Design Intelligence Score\n\nScore: {$score} / {$answered} ({$pct}%)\nProfile: {$profile}\n\n{$note}\n\nContinue with " . nya_design_quiz_topic_list() . '.' ];
    }
}
