<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}




// -----------------------------------------------------------------------------
// Democracy Terminal bootstrap (safe, backward-compatible)
// -----------------------------------------------------------------------------
if ( ! defined( 'NYA_TERMINAL_OPTION_ADVANCED' ) ) {
    define( 'NYA_TERMINAL_OPTION_ADVANCED', 'nya_terminal_advanced_codes_enabled' );
}

$__nya_terminal_includes = get_template_directory() . '/' . 'includes/';
foreach ( [
    'helpers-auth.php',
    'helpers-log.php',
    'class-command-registry.php',
    'class-command-router.php',
    'class-bclm-registry.php',
    'rest-terminal.php',
] as $__f ) {
    $p = $__nya_terminal_includes . $__f;
    if ( file_exists( $p ) ) {
        require_once $p;
    }
}

// Add capability on activation.
if ( ! function_exists( 'nya_terminal_activation' ) ) {
    function nya_terminal_activation() {
        $role = get_role( 'subscriber' );
        if ( $role && ! $role->has_cap( 'use_nya_terminal_advanced' ) ) {
            $role->add_cap( 'use_nya_terminal_advanced' );
        }
        // Enable Democracy Terminal by default on first install.
        $existing = get_option( NYA_TERMINAL_OPTION_ADVANCED, null );
        if ( $existing === null ) {
            update_option( NYA_TERMINAL_OPTION_ADVANCED, true );
        }
    }
}

// Ensure default option exists even on update (no need to re-activate).
add_action( 'plugins_loaded', function () {
    $existing = get_option( NYA_TERMINAL_OPTION_ADVANCED, null );
    if ( $existing === null ) {
        update_option( NYA_TERMINAL_OPTION_ADVANCED, true );
    }
} );


// Register optional terminal REST routes.
if ( function_exists( 'nya_terminal_register_rest_routes' ) ) {
    add_action( 'rest_api_init', 'nya_terminal_register_rest_routes' );
}




// Pattern Deviation Engine (PDE) core markers.
if ( ! defined( 'SBN_PDE_VERSION' ) ) {
    define( 'SBN_PDE_VERSION', '3.2' );
}
if ( ! defined( 'SBN_PDE_META_KEY' ) ) {
    define( 'SBN_PDE_META_KEY', '_sbn_pde_v32_results' );
}



if ( ! function_exists( 'sbn_run_pde_pipeline' ) ) {
    /**
     * Pattern Deviation Engine (PDE) v3.2 helper.
     *
     * @param string $input_text
     * @param array  $context
     *
     * @return array
     */
    function sbn_run_pde_pipeline( $input_text, $context = array() ) {
        $payload = array(
            'inputText'      => $input_text,
            'normalizedText' => wp_strip_all_tags( $input_text ),
            'pdeScore'       => 0.00,
            'anomalyMap'     => array(),
            'fracturePoint'  => '',
            'responseMode'   => 'guide',
        );

        $payload = apply_filters( 'sbn_pde_preprocess', $payload, $context );
        $payload = apply_filters( 'sbn_pde_analyze', $payload, $context );
        $payload = apply_filters( 'sbn_pde_results', $payload, $context );

        /**
         * Fired when a PDE-routed question has been fully classified.
         */
        do_action( 'sbn_question_routed', $payload, $context );

        return $payload;
    }
}

class SBN_Ask_The_Network {

    const VERSION              = 'v1337-v2.0-17-LiveRadarFollow';
    const OPTION_HQ_PAGE_ID    = 'sbn_hq_page_id';

    // LLM bridge options
    const OPTION_LLM_ENABLED     = 'sbn_llm_enabled';
    const OPTION_LLM_ENDPOINT    = 'sbn_llm_endpoint';
    const OPTION_LLM_API_KEY     = 'sbn_llm_api_key';
    const OPTION_LLM_MODEL       = 'sbn_llm_model';
    const OPTION_LLM_TEMPERATURE = 'sbn_llm_temperature';
    const OPTION_LLM_MAX_TOKENS  = 'sbn_llm_max_tokens';

    /**
     * Simple config of network sites for cross-search.
     * You can later move this to options or a settings page.
     *
     * key   = slug
     * label = human name
     * base  = base URL
     */
    protected $network_sites = array(
        'someb' => array(
            'label' => 'Some-B',
            'base'  => 'https://some-b.info',
        ),
        'kuai' => array(
            'label' => '074KU.ai',
            'base'  => 'https://074ku.ai',
        ),
        'sbz'  => array(
            'label' => 'Surrounded by Zombies',
            'base'  => 'https://surroundedbyzombies.com',
        ),
        'odd'  => array(
            'label' => 'Open Democratic Debate',
            'base'  => 'https://opendemocraticdebate.eu',
        ),
        'ayd'  => array(
            'label' => 'Ask La Gaffe',
            'base'  => 'https://asklagaffe.com',
        ),
        'osad' => array(
            'label' => 'One Snack A Day',
            'base'  => 'https://onesnackaday.com',
        ),
        'pawn' => array(
            'label' => 'PawnArmy',
            'base'  => 'https://pawnarmy.com',
        ),
        'lasg' => array(
            'label' => 'Light and Shadow Game',
            'base'  => 'https://lightandshadowgame.com',
        ),
        'mim'  => array(
            'label' => 'MiniMensa',
            'base'  => 'https://minimensa.com',
        ),
        'kueu' => array(
            'label' => '074KU.eu',
            'base'  => 'https://074ku.eu',
        ),
        'nya'  => array(
            'label' => 'NotYouAgain.ai',
            'base'  => 'https://notyouagain.ai',
        ),
        'z1n3' => array(
            'label' => 'z1n3.press',
            'base'  => 'https://z1n3.press',
        ),
        'solidred' => array(
            'label' => 'solidred.consulting',
            'base'  => 'https://solidred.consulting',
        ),
    );
    public function __construct() {
        // Activation

        // Init
        add_action( 'init', array( $this, 'register_post_types' ) );
        add_action( 'init', array( $this, 'register_taxonomies' ) );
        add_action( 'init', array( $this, 'register_shortcodes' ) );

        // Assets
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );

        // Widget in footer (front-end)
        add_action( 'wp_footer', array( $this, 'render_floating_widget' ) );

        // REST API
        add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );

        // Sync taxonomy labels for questions
        add_action( 'save_post_sbn_question', array( $this, 'sync_question_taxonomies' ), 10, 3 );

        // Admin settings (LLM bridge + PDE)
        add_action( 'admin_menu', array( $this, 'register_settings_page' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );

        // LLM bridge: intercept Some-B answers after REST callbacks.
        add_filter( 'rest_request_after_callbacks', array( $this, 'maybe_rewrite_someb_response' ), 10, 3 );
    }

    /**
     * Plugin activation callback.
     */
    public function on_activation() {
        $page_id = get_option( self::OPTION_HQ_PAGE_ID );

        if ( ! $page_id || 'publish' !== get_post_status( $page_id ) ) {
            $existing = get_page_by_path( 'some-b' );

            if ( $existing ) {
                $page_id = $existing->ID;
            } else {
                $page_id = wp_insert_post(
                    array(
                        'post_title'   => 'Some-B Control Room',
                        'post_name'    => 'some-b',
                        'post_status'  => 'publish',
                        'post_type'    => 'page',
                        'post_content' => '[sbn_control_room]',
                    )
                );
            }

            if ( $page_id && ! is_wp_error( $page_id ) ) {
                update_option( self::OPTION_HQ_PAGE_ID, (int) $page_id );
            }
        }

        $this->register_post_types();
        flush_rewrite_rules();
    }

    /**
     * Register custom post types.
     */
    public function register_post_types() {
        register_post_type(
            'sbn_question',
            array(
                'label'           => __( 'Some-B Questions', 'some-b-ask-the-network' ),
                'public'          => false,
                'show_ui'         => true,
                'show_in_menu'    => true,
                'capability_type' => 'post',
                'supports'        => array( 'title', 'editor', 'author', 'custom-fields' ),
                'menu_icon'       => 'dashicons-format-chat',
            )
        );

        register_post_type(
            'sbn_bulletin',
            array(
                'label'           => __( 'Some-B Bulletins', 'some-b-ask-the-network' ),
                'public'          => true,
                'has_archive'     => true,
                'show_in_rest'    => true,
                'show_in_menu'    => true,
                'capability_type' => 'post',
                'supports'        => array( 'title', 'editor', 'author', 'comments', 'custom-fields' ),
                'menu_icon'       => 'dashicons-megaphone',
            )
        );
    }

    /**
     * Register taxonomies for questions (topics, origin sites, age bands).
     */
    public function register_taxonomies() {
        // Topic taxonomy (public, for filtering and navigation).
        register_taxonomy(
            'sbn_topic',
            array( 'sbn_question' ),
            array(
                'label'        => __( 'Network Topics', 'some-b-ask-the-network' ),
                'public'       => true,
                'show_ui'      => true,
                'show_in_rest' => true,
                'hierarchical' => false,
                'rewrite'      => array( 'slug' => 'sbn-topic' ),
            )
        );

        // Origin sites (internal labels for which site the question came from).
        register_taxonomy(
            'sbn_origin_site',
            array( 'sbn_question' ),
            array(
                'label'        => __( 'Origin Sites', 'some-b-ask-the-network' ),
                'public'       => false,
                'show_ui'      => true,
                'show_in_rest' => true,
                'hierarchical' => false,
            )
        );

        // Age bands (optional; for kid/teen/adult/pro filtering).
        register_taxonomy(
            'sbn_age_band',
            array( 'sbn_question' ),
            array(
                'label'        => __( 'Age Bands', 'some-b-ask-the-network' ),
                'public'       => false,
                'show_ui'      => true,
                'show_in_rest' => true,
                'hierarchical' => false,
            )
        );
    }

    /**
     * Sync sbn_question meta into taxonomies so the exploration UI has clean labels.
     *
     * @param int     $post_id Post ID.
     * @param WP_Post $post    Post object.
     * @param bool    $update  Whether this is an update.
     */
    public function sync_question_taxonomies( $post_id, $post, $update ) {
        if ( 'sbn_question' !== $post->post_type ) {
            return;
        }

        // Topics from sbn_topics meta (array of slugs/labels).
        $topics_meta = get_post_meta( $post_id, 'sbn_topics', true );
        $topic_slugs = array();

        if ( is_array( $topics_meta ) ) {
            foreach ( $topics_meta as $topic ) {
                $topic = trim( (string) $topic );
                if ( '' === $topic ) {
                    continue;
                }
                $topic_slugs[] = sanitize_title( $topic );
            }
        } elseif ( is_string( $topics_meta ) && '' !== $topics_meta ) {
            $topic_slugs[] = sanitize_title( $topics_meta );
        }

        if ( ! empty( $topic_slugs ) ) {
            wp_set_object_terms( $post_id, $topic_slugs, 'sbn_topic', false );
        }

        // Origin site based on sbn_source URL host.
        $source = get_post_meta( $post_id, 'sbn_source', true );
        if ( ! empty( $source ) ) {
            $host = wp_parse_url( $source, PHP_URL_HOST );
            if ( $host ) {
                $origin_slug = sanitize_title( $host );
                wp_set_object_terms( $post_id, $origin_slug, 'sbn_origin_site', false );
            }
        }

        // Age band (optional, only if meta exists).
        $age_band = get_post_meta( $post_id, 'sbn_age_band', true );
        if ( ! empty( $age_band ) ) {
            wp_set_object_terms( $post_id, sanitize_title( $age_band ), 'sbn_age_band', false );
        }
    }


    /**
     * Shortcodes.
     */
    public function register_shortcodes() {
        add_shortcode( 'sbn_control_room', array( $this, 'render_control_room_shortcode' ) );
        add_shortcode( 'sbn_network_answers', array( $this, 'render_network_answers_shortcode' ) );
    }

    /**
     * Enqueue assets.
     */
    public function enqueue_assets() {
        if ( is_admin() ) {
            return;
        }

        $plugin_url  = get_template_directory_uri() . '/';
        $plugin_ver  = self::VERSION;

        wp_enqueue_style(
            'sbn-style',
            $plugin_url . 'assets/css/sbn-style.css',
            array(),
            $plugin_ver
        );

        wp_enqueue_script(
            'sbn-frontend',
            $plugin_url . 'assets/js/sbn-frontend.js',
            array( 'wp-util' ),
            $plugin_ver,
            true
        );

        $hq_page_id = (int) get_option( self::OPTION_HQ_PAGE_ID );
        $hq_url     = $hq_page_id ? get_permalink( $hq_page_id ) : home_url( '/some-b/' );

        wp_localize_script(
            'sbn-frontend',
            'SBNConfig',
            array(
                'restUrl' => esc_url_raw( rest_url( 'sbn/v1/question' ) ),
                'newsUrl' => esc_url_raw( rest_url( 'sbn/v1/news' ) ),
                'terminalStatusUrl'  => esc_url_raw( rest_url( 'nya/v1/terminal/status' ) ),
                'terminalExecuteUrl' => esc_url_raw( rest_url( 'nya/v1/terminal/execute' ) ),
                'articlePreviewUrl'  => esc_url_raw( rest_url( 'nya/v1/article/preview' ) ),
                'advancedEnabled'    => (bool) get_option( NYA_TERMINAL_OPTION_ADVANCED, false ),
                'nonce'   => wp_create_nonce( 'wp_rest' ),
                'hqUrl'   => esc_url_raw( $hq_url ),
                'loginUrl'    => esc_url_raw( wp_login_url( $hq_url ) ),
                'registerUrl' => esc_url_raw( wp_registration_url() ),
                'isHQ'    => $this->is_hq_site(),
            )
        );

        $mode_registry = apply_filters( 'sbn_mode_registry', self::get_mode_registry() );
        wp_localize_script(
            'sbn-frontend',
            'SBNModeRegistry',
            $mode_registry
        );
    }

    /**
     * Is this the HQ site?
     */
    protected function is_hq_site() {
        $hq_page_id = (int) get_option( self::OPTION_HQ_PAGE_ID );
        return ( $hq_page_id && 'publish' === get_post_status( $hq_page_id ) );
    }

    /**
     * Floating widget in footer.
     */
    public function render_floating_widget() {
        if ( is_admin() ) {
            return;
        }
        ?>
        <div id="sbn-widget" class="sbn-widget">
            <button class="sbn-widget-button" aria-label="<?php esc_attr_e( 'Ask Some-B (from NYA)', 'some-b-ask-the-network' ); ?>">
                <span class="sbn-avatar"></span>
                <span class="sbn-widget-label"><?php esc_html_e( 'Ask Some-B (from NYA)', 'some-b-ask-the-network' ); ?></span>
            </button>
        </div>

        <?php if ( $this->is_hq_site() ) : ?>
            <div id="sbn-overlay" class="sbn-overlay" aria-hidden="true">
                <div class="sbn-overlay-inner">
                    <button class="sbn-close" aria-label="<?php esc_attr_e( 'Close', 'some-b-ask-the-network' ); ?>">&times;</button>
                    <div class="sbn-overlay-body">
                        <?php echo do_shortcode( '[sbn_control_room]' ); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php
    }

    /**
     * Control-room shortcode.
     */
    public function render_control_room_shortcode( $atts ) {
        ob_start();
        $template = get_template_directory() . '/' . 'templates/sbn-control-room.php';
        if ( file_exists( $template ) ) {
            include $template;
        } else {
            echo '<p>' . esc_html__( 'Some-B control room template missing.', 'some-b-ask-the-network' ) . '</p>';
        }
        return ob_get_clean();
    }

    /**
     * Front-end grid of answered questions, filterable by topic/age/origin.
     *
     * Usage: [sbn_network_answers topic="democracy" age="kid" origin="074ku" limit="12"]
     *
     * @param array $atts Shortcode attributes.
     * @return string
     */
    public function render_network_answers_shortcode( $atts ) {
        $atts = shortcode_atts(
            array(
                'topic'  => '',
                'age'    => '',
                'origin' => '',
                'limit'  => 12,
            ),
            $atts,
            'sbn_network_answers'
        );

        $tax_query = array( 'relation' => 'AND' );

        if ( ! empty( $atts['topic'] ) ) {
            $tax_query[] = array(
                'taxonomy' => 'sbn_topic',
                'field'    => 'slug',
                'terms'    => array( sanitize_title( $atts['topic'] ) ),
            );
        }

        if ( ! empty( $atts['age'] ) ) {
            $tax_query[] = array(
                'taxonomy' => 'sbn_age_band',
                'field'    => 'slug',
                'terms'    => array( sanitize_title( $atts['age'] ) ),
            );
        }

        if ( ! empty( $atts['origin'] ) ) {
            $tax_query[] = array(
                'taxonomy' => 'sbn_origin_site',
                'field'    => 'slug',
                'terms'    => array( sanitize_title( $atts['origin'] ) ),
            );
        }

        $query_args = array(
            'post_type'      => 'sbn_question',
            'posts_per_page' => (int) $atts['limit'],
            'post_status'    => 'publish',
            'meta_query'     => array(
                array(
                    'key'     => 'sbn_response_summary',
                    'compare' => 'EXISTS',
                ),
            ),
        );

        if ( count( $tax_query ) > 1 ) {
            $query_args['tax_query'] = $tax_query;
        }

        $query = new WP_Query( $query_args );

        if ( ! $query->have_posts() ) {
            return '<div class="sbn-answers-grid sbn-answers-grid--empty">' . esc_html__( 'Nog geen antwoorden beschikbaar.', 'some-b-ask-the-network' ) . '</div>';
        }

        ob_start();
        ?>
        <div class="sbn-answers-grid">
            <?php
            while ( $query->have_posts() ) :
                $query->the_post();
                $answer_summary = get_post_meta( get_the_ID(), 'sbn_response_summary', true );
                $origin_terms   = wp_get_post_terms( get_the_ID(), 'sbn_origin_site' );
                $age_terms      = wp_get_post_terms( get_the_ID(), 'sbn_age_band' );
                $topic_terms    = wp_get_post_terms( get_the_ID(), 'sbn_topic' );
                ?>
                <article class="sbn-answer-card">
                    <h3 class="sbn-answer-question"><?php the_title(); ?></h3>

                    <div class="sbn-answer-meta">
                        <?php if ( ! empty( $origin_terms ) && ! is_wp_error( $origin_terms ) ) : ?>
                            <span class="sbn-answer-chip sbn-answer-chip--origin">
                                <?php echo esc_html( $origin_terms[0]->name ); ?>
                            </span>
                        <?php endif; ?>

                        <?php if ( ! empty( $age_terms ) && ! is_wp_error( $age_terms ) ) : ?>
                            <span class="sbn-answer-chip sbn-answer-chip--age">
                                <?php echo esc_html( $age_terms[0]->name ); ?>
                            </span>
                        <?php endif; ?>

                        <?php if ( ! empty( $topic_terms ) && ! is_wp_error( $topic_terms ) ) : ?>
                            <?php foreach ( $topic_terms as $topic ) : ?>
                                <span class="sbn-answer-chip sbn-answer-chip--topic">
                                    <?php echo esc_html( $topic->name ); ?>
                                </span>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>

                    <?php if ( $answer_summary ) : ?>
                        <div class="sbn-answer-excerpt">
                            <?php echo esc_html( $answer_summary ); ?>
                        </div>
                    <?php endif; ?>
                </article>
                <?php
            endwhile;
            wp_reset_postdata();
            ?>
        </div>
        <?php
        return ob_get_clean();
    }


    
    /**
     * Try to classify a question using NYA Network Diagnostics, if that plugin is available.
     *
     * @param string $question Question text.
     * @return array Cluster scores keyed by cluster name.
     */
    protected function get_diagnostic_clusters( $question ) {
        if ( ! function_exists( 'nya_diagnostics_classify_query' ) ) {
            return array();
        }
        $scores = nya_diagnostics_classify_query( $question );
        if ( ! is_array( $scores ) ) {
            return array();
        }
        return $scores;
    }

    /**
     * Map diagnostic cluster scores into a high-level "room" key for routing.
     *
     * @param array $scores Cluster scores.
     * @return string Room key.
     */
    protected function map_clusters_to_room( $scores ) {
        if ( empty( $scores ) || ! is_array( $scores ) ) {
            return 'general';
        }

        arsort( $scores );
        $keys = array_keys( $scores );
        $top  = reset( $keys );

        switch ( $top ) {
            case 'zombies':
                return 'zombie_lab';
            case 'democracy':
                return 'democracy_room';
            case 'youth':
                return 'shadow_school';
            case 'games':
                return 'game_table';
            case 'some_b':
                return 'some_b_control_room';
            case 'la_gaffe':
                return 'la_gaffe_corner';
            default:
                return 'general';
        }
    }

/**
     * REST routes.
     */
    public function register_rest_routes() {
        register_rest_route(
            'sbn/v1',
            '/question',
            array(
                'methods'             => 'POST',
                'callback'            => array( $this, 'rest_handle_question' ),
                'permission_callback' => '__return_true',
            )
        );

        register_rest_route(
            'sbn/v1',
            '/news',
            array(
                'methods'             => 'GET',
                'callback'            => array( $this, 'rest_handle_news' ),
                'permission_callback' => '__return_true',
            )
        );

        register_rest_route(
            'sbn/v1',
            '/stats/summary',
            array(
                'methods'             => 'GET',
                'callback'            => array( $this, 'rest_handle_stats_summary' ),
                'permission_callback' => '__return_true',
            )
        );
    }

    /**
     * Handle incoming question:
     * - classify mode/topics
     * - run auto-diagnostic
     * - search network for links
     * - store in sbn_question
     * - return Some-B style response.
     */
    public function rest_handle_question( WP_REST_Request $request ) {
        $question = sanitize_textarea_field( $request->get_param( 'question' ) );
        $mood     = sanitize_text_field( $request->get_param( 'mood' ) ); // explain|roast|guide
        $source   = esc_url_raw( $request->get_param( 'source' ) );
        $reasoning_mode = sanitize_text_field( $request->get_param( 'reasoning_mode' ) );
        if ( '' === $reasoning_mode ) {
            $reasoning_mode = 'common_sense';
        }

        // Democracy Terminal command bridge.
        // Keep slash codes alive even if the dedicated terminal route is blocked by cache/security rules.
        if ( function_exists( 'nya_parse_bclm_shortcut' ) && function_exists( 'nya_handle_bclm_shortcut' ) && function_exists( 'nya_terminal_to_sbn_response' ) ) {
            $shortcut = nya_parse_bclm_shortcut( $question );
            if ( $shortcut ) {
                $payload = nya_handle_bclm_shortcut( $shortcut );
                return new WP_REST_Response( nya_terminal_to_sbn_response( $payload ), 200 );
            }
        }

        if ( isset( $question[0] ) && '/' === $question[0] && class_exists( 'NYA_Command_Router' ) && function_exists( 'nya_terminal_to_sbn_response' ) ) {
            $trimmed_question = trim( (string) $question );
            if ( preg_match( '#^/(quiz|q)\s*$#i', $trimmed_question ) && function_exists( 'nya_design_quiz_immediate_payload' ) ) {
                $payload = nya_design_quiz_immediate_payload();
                return new WP_REST_Response( nya_terminal_to_sbn_response( $payload ), 200 );
            }

            $payload = NYA_Command_Router::handle_input( $question );
            if ( $payload !== null ) {
                return new WP_REST_Response( nya_terminal_to_sbn_response( $payload ), 200 );
            }
        }


        if ( empty( $question ) ) {
            return new WP_REST_Response(
                array(
                    'error'   => true,
                    'message' => __( 'No question provided.', 'some-b-ask-the-network' ),
                ),
                400
            );
        }

        // UI brain mode (BCLM/Diagnose) with unified 'than' pattern.
        $ui_mode = sanitize_text_field( $request->get_param( 'sbn_mode' ) );
        $registry = apply_filters( 'sbn_mode_registry', self::get_mode_registry() );
        $allowed_ui_modes = array_keys( $registry );
        if ( ! in_array( $ui_mode, $allowed_ui_modes, true ) && ! self::mode_matches_safe_pattern( $ui_mode ) ) {
            $ui_mode = '';
        }

        // NOTE: We no longer auto-prefix plain questions with sbn_mode.

                
        // Conversation-first logic: small talk, clarity, diagnose, scan, and zombie shortcuts.
        $lower_q = strtolower( trim( $question ) );

        // Direct greeting shortcut.
        if ( in_array( $lower_q, array( 'hello', 'hi', 'hey' ), true ) ) {
            $friendly = 'Hey brain-snack. Control room is online. One quick dial before we start: did you come for comfort, clarity, or drama analysis?';

            return new WP_REST_Response(
                array(
                    'error'          => false,
                    'mode'           => 'small_talk',
                    'topics'         => array(),
                    'diagnostic'     => array(
                        'score'   => 0,
                        'label'   => 'no-zombie',
                        'message' => '',
                    ),
                    'response_text'  => $friendly,
                    'response_plain' => wp_strip_all_tags( $friendly ),
                    'linked_content' => array(),
                ),
                200
            );
        }

        // Clarity shortcut.
        if ( 'clarity' === $lower_q ) {
            $friendly  = 'Clarity it is. Close the hatch, we\'ll map this like a level, not a life sentence.' . "\n\n";
            $friendly .= 'I hear a human behind one word: "Clarity".' . "\n";
            $friendly .= 'Body check: tight, numb, buzzing, or flat?' . "\n";
            $friendly .= 'Brain check: “I\'m lost”, “I\'m angry”, or “I don\'t even know what I feel”?' . "\n\n";
            $friendly .= 'On my radar this sits in general survival – not full apocalypse, but not background noise either. Zombie score: 20 / 100.' . "\n";
            $friendly .= 'Translation: something matters, but the story isn\'t clear yet. Bring me one concrete situation (who / where / when) and we\'ll slice the zombie logic from the human signal.';

            return new WP_REST_Response(
                array(
                    'error'          => false,
                    'mode'           => 'clarity',
                    'topics'         => array( 'general' ),
                    'diagnostic'     => array(
                        'score'   => 20,
                        'label'   => 'low',
                        'message' => 'General survival; user asking for clarity, not apocalypse.',
                    ),
                    'response_text'  => $friendly,
                    'response_plain' => wp_strip_all_tags( $friendly ),
                    'linked_content' => array(),
                ),
                200
            );
        }

        // Diagnose shortcut.
        if ( 'diagnose' === $lower_q ) {
            $friendly  = 'Diagnose mode: ON. Sit, breathe, no performance required.' . "\n\n";
            $friendly .= 'You said: “Diagnose.” That already tells me you\'re willing to look at the pattern, not just the feeling.' . "\n\n";
            $friendly .= 'Quick triage:' . "\n";
            $friendly .= '- Are you sleeping roughly okay?' . "\n";
            $friendly .= '- Can you still enjoy anything (music, dog, snack)?' . "\n";
            $friendly .= '- Are you functioning, just exhausted, or properly stuck?' . "\n\n";
            $friendly .= 'With only your short messages, I\'d place you in “general survival, low-to-medium zombie pressure”. Zombie score: 25 / 100.' . "\n";
            $friendly .= 'Translation: your system is annoyed and searching, but not overrun. I won\'t label your brain chemistry. I\'ll help you name the stories and systems nibbling at your energy, one scene at a time.';

            return new WP_REST_Response(
                array(
                    'error'          => false,
                    'mode'           => 'diagnose',
                    'topics'         => array( 'general' ),
                    'diagnostic'     => array(
                        'score'   => 25,
                        'label'   => 'low',
                        'message' => 'Diagnose command: general survival, low-to-medium zombie pressure.',
                    ),
                    'response_text'  => $friendly,
                    'response_plain' => wp_strip_all_tags( $friendly ),
                    'linked_content' => array(),
                ),
                200
            );
        }

        // Scan shortcut.
        if ( 'scan' === $lower_q ) {
            $snapshot = $this->get_site_pde_snapshot();
            $summary_lines = array();

            if ( is_array( $snapshot ) ) {
                foreach ( $snapshot as $slug => $info ) {
                    $label   = isset( $info['label'] ) ? $info['label'] : $slug;
                    $code    = isset( $info['http_code'] ) ? intval( $info['http_code'] ) : 0;
                    $status  = ( $code >= 200 && $code <= 299 ) ? 'green' : 'amber';
                    $summary_lines[] = sprintf( '%s: HTTP %d (%s)', $label, $code, $status );
                }
            }

            $summary_text = $summary_lines ? implode( ' | ', $summary_lines ) : 'No sites configured yet in the PDE snapshot.';

            $friendly  = 'Scan mode: ON. I\'ll look at the network; you stay human.' . "\n\n";
            $friendly .= 'Quick PDE snapshot: ' . $summary_text . "\n\n";
            $friendly .= 'From your side, mood reads as “looking for clarity, not pure panic”. Zombie score: 40 / 100.' . "\n";
            $friendly .= 'Next step: pick one real-life scene where things feel zombified and describe who was there, what happened, and what you wished had been different.';

            return new WP_REST_Response(
                array(
                    'error'          => false,
                    'mode'           => 'scan',
                    'topics'         => array( 'general' ),
                    'diagnostic'     => array(
                        'score'   => 40,
                        'label'   => 'medium',
                        'message' => 'Scan command: general survival, medium zombie pressure.',
                    ),
                    'response_text'  => $friendly,
                    'response_plain' => wp_strip_all_tags( $friendly ),
                    'linked_content' => array(),
                ),
                200
            );
        }

        // Zombie geography: “are there any zombies in the netherlands”
        if ( false !== strpos( $lower_q, 'zombies in the netherlands' ) ) {
            $friendly  = 'Come in, close the hatch — zombie radar online.' . "\n\n";
            $friendly .= 'Biology report:' . "\n";
            $friendly .= '- 0 confirmed walking corpses in the Netherlands.' . "\n";
            $friendly .= '- 0 outbreaks in Europe.' . "\n";
            $friendly .= '- 100% of “real zombies” so far = fiction and clickbait.' . "\n\n";
            $friendly .= 'Pattern report: here “zombie” means behaviour or system that eats time, empathy or thinking — not whole groups of humans.' . "\n\n";
            $friendly .= 'On my map, the Dutch lane shows food-chain debates, housing stress and bureaucracy as the main zombie habitats. Zombie score for the theme: 70 / 100 (heavy topic, low biology risk).' . "\n\n";
            $friendly .= 'If you want to turn this into an actual mission, describe one scene where you saw “zombie behaviour” and we\'ll debug that room, not the whole country.';

            return new WP_REST_Response(
                array(
                    'error'          => false,
                    'mode'           => 'zombie_radar',
                    'topics'         => array( 'zombies', 'netherlands' ),
                    'diagnostic'     => array(
                        'score'   => 70,
                        'label'   => 'high',
                        'message' => 'Zombie geography question; high thematic intensity, low biological risk.',
                    ),
                    'response_text'  => $friendly,
                    'response_plain' => wp_strip_all_tags( $friendly ),
                    'linked_content' => array(),
                ),
                200
            );
        }

        // “Is there a cure or do we wait until the last one is dead”
        if ( false !== strpos( $lower_q, 'last one is dead' ) || false !== strpos( $lower_q, 'last one dies' ) ) {
            $friendly  = 'I hear a human behind this line: “Is there a cure, or do we wait until the last one is dead?”' . "\n\n";
            $friendly .= 'That is long-term survival brain talking, not small talk.' . "\n\n";
            $friendly .= 'Zombie map:' . "\n";
            $friendly .= '- There is no final zombie boss to outlive.' . "\n";
            $friendly .= '- There is a repeatable cure in small doses:' . "\n";
            $friendly .= '  1. Name the pattern (“this policy eats time/empathy/attention”).' . "\n";
            $friendly .= '  2. Shrink the arena to one concrete room (family, school, office, city).' . "\n";
            $friendly .= '  3. Test one tiny action that feeds humans instead of the zombie.' . "\n\n";
            $friendly .= 'Zombie score for this worry: 55 / 100 – not apocalypse, but your question says: “If this continues, I don\'t see an exit.”' . "\n";
            $friendly .= 'We don\'t wait for the last zombie to die. We design exits, one door at a time. Bring me one situation where this question feels most true, and we\'ll look for the first door.';

            return new WP_REST_Response(
                array(
                    'error'          => false,
                    'mode'           => 'zombie_exit',
                    'topics'         => array( 'survival', 'zombies' ),
                    'diagnostic'     => array(
                        'score'   => 55,
                        'label'   => 'medium',
                        'message' => 'Cure/exit question: medium zombie pressure with existential flavour.',
                    ),
                    'response_text'  => $friendly,
                    'response_plain' => wp_strip_all_tags( $friendly ),
                    'linked_content' => array(),
                ),
                200
            );
        }

        // Generic small talk fallback (how are you, alles goed, etc.).
        $small_talk_patterns = array(
            'how are you',
            'how was your day',
            'hoe gaat het',
            'alles goed',
        );

        foreach ( $small_talk_patterns as $pattern ) {
            if ( false !== strpos( $lower_q, $pattern ) ) {
                $friendly = 'Hey brain-snack. I\'m good. I\'m plugged into the NYA / 074KU / Zombies universe and listening. Short version: I\'m fine. More important question: what\'s going on with you that you wanted to ask today?';

                return new WP_REST_Response(
                    array(
                        'error'          => false,
                        'mode'           => 'small_talk',
                        'topics'         => array(),
                        'diagnostic'     => array(
                            'score'   => 0,
                            'label'   => 'no-zombie',
                            'message' => '',
                        ),
                        'response_text'  => $friendly,
                    'response_plain' => wp_strip_all_tags( $friendly ),
                        'linked_content' => array(),
                    ),
                    200
                );
            }
        }

// Meta "how do you work?" / "how do you understand language?" questions.
        $meta_language_html = $this->maybe_meta_language_response( $question );
        if ( ! empty( $meta_language_html ) ) {
            $topics         = array( 'meta', 'language', 'how-it-works' );
            $diagnostic     = array(
                'score'   => 0,
                'label'   => 'no-zombie',
                'message' => 'Meta question about how Some-B understands language and patterns.',
            );
            $cluster_scores = array();
            $cluster_room   = 'meta-language-lab';

            $post_id = wp_insert_post(
                array(
                    'post_type'    => 'sbn_question',
                    'post_status'  => 'publish',
                    'post_title'   => mb_strimwidth( $question, 0, 80, '…' ),
                    'post_content' => $question,
                    'meta_input'   => array(
                        'sbn_mode'           => 'meta_language',
                        'sbn_mood'           => $mood,
                        'sbn_source'         => $source,
                        'sbn_topics'         => $topics,
                        'sbn_status'         => 'answered_auto',
                        'sbn_linked_content' => array(),
                        'sbn_zombie_score'   => $diagnostic['score'],
                        'sbn_zombie_label'   => $diagnostic['label'],
                        'sbn_diag_notes'     => $diagnostic['message'],
                        'sbn_cluster_scores' => $cluster_scores,
                        'sbn_cluster_room'   => $cluster_room,
                    ),
                )
            );

            if ( $post_id && ! is_wp_error( $post_id ) ) {
                update_post_meta( $post_id, 'sbn_response_summary', wp_trim_words( $meta_language_html, 40 ) );
            }

            return new WP_REST_Response(
                array(
                    'error'          => false,
                    'mode'           => 'meta_language',
                    'topics'         => $topics,
                    'diagnostic'     => $diagnostic,
                    'cluster_scores' => $cluster_scores,
                    'cluster_room'   => $cluster_room,
                    'response_text'  => $meta_language_html,
                    'response_plain' => wp_strip_all_tags( $meta_language_html ),
                    'linked_content' => array(),
                ),
                200
            );
        }

// Mode selection
        $mode = 'playful_scientist';
        if ( 'roast' === $mood ) {
            $mode = 'sharp_roaster';
        } elseif ( 'guide' === $mood ) {
            $mode = 'guide_mentor';
        } elseif ( 'explain' === $mood ) {
            $mode = 'playful_scientist';
        }

        // Topic classification
        $topics = $this->classify_topics( $question );
        if ( empty( $topics ) ) {
            $topics[] = 'general';
        }

        // Auto-diagnostic of zombie logic
        $diagnostic = $this->run_auto_diagnostic( $question );

        // NYA Network Diagnostics clusters (optional).
        $cluster_scores = $this->get_diagnostic_clusters( $question );
        $cluster_room   = $this->map_clusters_to_room( $cluster_scores );

        // Network search for content links
        $linked_content = $this->find_network_links( $question, $topics, 7 );

        // If the network clearly lights up around zombie-heavy material,
        // nudge the diagnostic upwards so it reflects that.
        if ( ! empty( $linked_content ) && is_array( $linked_content ) ) {
            $zombie_hits = 0;

            foreach ( $linked_content as $item ) {
                if ( ! is_array( $item ) ) {
                    continue;
                }

                $site_label = isset( $item['site_label'] ) ? strtolower( $item['site_label'] ) : '';
                $title_l    = isset( $item['title'] ) ? strtolower( $item['title'] ) : '';
                $snippet_l  = isset( $item['snippet'] ) ? strtolower( $item['snippet'] ) : '';

                if (
                    ( $site_label && false !== strpos( $site_label, 'zombie' ) ) ||
                    ( $title_l && false !== strpos( $title_l, 'zombie' ) ) ||
                    ( $snippet_l && false !== strpos( $snippet_l, 'zombie' ) )
                ) {
                    $zombie_hits++;
                }
            }

            if ( $zombie_hits > 0 ) {
                $boost = 15 + ( 5 * min( $zombie_hits, 4 ) );
                $new_score = max( $diagnostic['score'], min( 100, $diagnostic['score'] + $boost ) );

                if ( $new_score !== $diagnostic['score'] ) {
                    $diagnostic['score'] = $new_score;

                    if ( $new_score < 30 ) {
                        $diagnostic['label'] = 'low';
                    } elseif ( $new_score < 70 ) {
                        $diagnostic['label'] = 'medium';
                    } else {
                        $diagnostic['label'] = 'high';
                    }
                }
            }
        }

        // Insert sbn_question
        $post_id = wp_insert_post(
            array(
                'post_type'    => 'sbn_question',
                'post_status'  => 'publish',
                'post_title'   => mb_strimwidth( $question, 0, 80, '…' ),
                'post_content' => $question,
                'meta_input'   => array(
                    'sbn_mode'          => $mode,
                    'sbn_mood'          => $mood,
                    'sbn_source'        => $source,
                    'sbn_topics'        => $topics,
                    'sbn_status'        => 'answered_auto',
                    'sbn_linked_content'=> $linked_content,
                    'sbn_zombie_score'  => $diagnostic['score'],
                    'sbn_zombie_label'  => $diagnostic['label'],
                    'sbn_diag_notes'    => $diagnostic['message'],
                    'sbn_cluster_scores'=> $cluster_scores,
                    'sbn_cluster_room'  => $cluster_room,
                ),
            )
        );

        // Compose Some-B response with links + diagnostic
        $response_text = $this->compose_someb_response( $question, $mode, $topics, $linked_content, $diagnostic );

        if ( $post_id && ! is_wp_error( $post_id ) ) {
            update_post_meta( $post_id, 'sbn_response_summary', wp_trim_words( $response_text, 40 ) );
        }

        return new WP_REST_Response(
            array(
                'error'          => false,
                'mode'           => $mode,
                'topics'         => $topics,
                'diagnostic'     => $diagnostic,
                'cluster_scores' => $cluster_scores,
                'cluster_room'   => $cluster_room,
                'response_text'  => $response_text,
                'response_plain' => wp_strip_all_tags( $response_text ),
                'linked_content' => $linked_content,
                'pde_snapshot'   => $this->get_site_pde_snapshot(),
            ),
            200
        );
    }

    /**
     * REST: latest bulletins.
     */
    public function rest_handle_news( WP_REST_Request $request ) {
        $count = (int) $request->get_param( 'count' );
        if ( $count <= 0 ) {
            $count = 5;
        }

        $query = new WP_Query(
            array(
                'post_type'      => 'sbn_bulletin',
                'posts_per_page' => $count,
                'post_status'    => 'publish',
            )
        );

        $items = array();
        if ( $query->have_posts() ) {
            foreach ( $query->posts as $post ) {
                $items[] = array(
                    'id'      => $post->ID,
                    'title'   => get_the_title( $post ),
                    'excerpt' => wp_trim_words( $post->post_content, 40 ),
                    'url'     => get_permalink( $post ),
                );
            }
        }

        return new WP_REST_Response(
            array(
                'error' => false,
                'news'  => $items,
            ),
            200
        );
    }

    /**
     * REST: lightweight stats summary for Atlas / dashboards.
     *
     * Returns counts by sbn_status meta, origin sites, and topics.
     *
     * @param WP_REST_Request $request Request.
     * @return WP_REST_Response
     */
    public function rest_handle_stats_summary( WP_REST_Request $request ) {
        global $wpdb;

        $post_type = 'sbn_question';

        // Status counts based on sbn_status meta.
        $status_counts = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT pm.meta_value AS status, COUNT(*) AS total
                 FROM {$wpdb->posts} p
                 JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
                 WHERE p.post_type = %s
                   AND pm.meta_key = 'sbn_status'
                 GROUP BY pm.meta_value",
                $post_type
            ),
            ARRAY_A
        );

        // Counts by origin_site term.
        $origin_counts = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT t.slug, t.name, COUNT(*) AS total
                 FROM {$wpdb->posts} p
                 JOIN {$wpdb->term_relationships} tr ON tr.object_id = p.ID
                 JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
                 JOIN {$wpdb->terms} t ON t.term_id = tt.term_id
                 WHERE p.post_type = %s
                   AND tt.taxonomy = 'sbn_origin_site'
                 GROUP BY t.slug, t.name",
                $post_type
            ),
            ARRAY_A
        );

        // Top topics.
        $topic_counts = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT t.slug, t.name, COUNT(*) AS total
                 FROM {$wpdb->posts} p
                 JOIN {$wpdb->term_relationships} tr ON tr.object_id = p.ID
                 JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
                 JOIN {$wpdb->terms} t ON t.term_id = tt.term_id
                 WHERE p.post_type = %s
                   AND tt.taxonomy = 'sbn_topic'
                 GROUP BY t.slug, t.name
                 ORDER BY total DESC
                 LIMIT 20",
                $post_type
            ),
            ARRAY_A
        );

        return new WP_REST_Response(
            array(
                'error'         => false,
                'status_counts' => $status_counts,
                'origin_counts' => $origin_counts,
                'topic_counts'  => $topic_counts,
            ),
            200
        );
    }


    /**
     * Detect meta questions about how Some-B / language models work
     * and return a long-form explanation if triggered.
     */
    protected function maybe_meta_language_response( $question ) {
        $q = strtolower( $question );

        $patterns = array(
            'how do you understand language',
            'how do you understand my question',
            'how do you understand me',
            'how does this work',
            'how do you work',
            'what is going on in your brain',
            'what is inside your brain',
            'how do you know what i mean',
            'distributed in the weights',
            'explain your weights',
            'explain how you think'
        );

        foreach ( $patterns as $pattern ) {
            if ( false !== strpos( $q, $pattern ) ) {
                return $this->get_language_brain_explanation_html();
            }
        }

        return '';
    }

    /**
     * HTML explanation of language understanding for curious humans.
     */
    protected function get_language_brain_explanation_html() {
        $html = <<<'HTML'
<p><strong>Short version:</strong> I don’t have a secret dictionary or emotions; I’m a pattern machine. But a pretty good one. Here’s how that “understanding language” thing actually works under the hood.</p>

<hr />

<h4>1. No internal dictionary, just numbers</h4>
<p>In a neural language model, every word or token (like <code>dog</code>, <code>democracy</code>, or <code>:)</code>) is turned into a vector of numbers – an embedding.</p>
<ul>
    <li>There is no internal entry like: <code>dog → small furry animal, barks</code>.</li>
    <li>Instead there is something like: <code>dog = [0.12, -1.7, 3.4, …]</code>, <code>cat = [0.10, -1.6, 3.5, …]</code>.</li>
</ul>
<p>Those vectors live in a huge geometric space where:</p>
<ul>
    <li>Similar meanings end up near each other.</li>
    <li>Very different meanings live far apart.</li>
</ul>
<p>The “dictionary” is basically the geometry of that space, not a list of text definitions.</p>

<h4>2. How “knowing grammar” falls out of training</h4>
<p>During training, the model sees billions of text fragments and repeatedly plays the game:</p>
<p><em>“Given this text so far, what’s the next token?”</em></p>
<p>To get good at that, it has to pick up things like:</p>
<ul>
    <li>Word order (<code>dog bites man</code> vs <code>man bites dog</code>).</li>
    <li>Agreement (<code>these cats are</code> vs <code>this cats are</code>).</li>
    <li>Structure (questions, conditionals, lists, jokes, rants).</li>
    <li>Style (formal vs slang, technical vs playful).</li>
</ul>
<p>Nobody gives it a rulebook like “if subject is plural → use plural verb”. Instead:</p>
<ul>
    <li>Patterns that often appear together get reinforced in the weights.</li>
    <li>Patterns that rarely appear together get suppressed.</li>
</ul>
<p>The result: it <em>behaves</em> as if it knows grammar, but all that “knowledge” is encoded implicitly in many tiny weight values spread across layers.</p>

<h4>3. “Distributed in the weights” = no single place to open</h4>
<p>If you peek inside the model, you do <em>not</em> find:</p>
<ul>
    <li>a “grammar module”,</li>
    <li>a “dictionary table”,</li>
    <li>or a <code>facts.txt</code> file.</li>
</ul>
<p>Instead you see huge matrices of numbers and billions of connections.</p>
<p>Each bit of “knowledge” (like “Amsterdam is in the Netherlands”) isn’t stored in one address; it’s smeared across many weights. Change enough of them, and the model might “forget” that relation—without there ever having been a single “Amsterdam row” to edit.</p>

<h4>4. Why this matters (and why models hallucinate)</h4>
<p>Because everything is statistical and distributed, the model is really good at:</p>
<ul>
    <li>Style, tone, and fluency.</li>
    <li>Combining patterns in new ways.</li>
    <li>Filling gaps in plausible ways.</li>
</ul>
<p>But it can also:</p>
<ul>
    <li>Confidently invent details (hallucinations).</li>
    <li>Blend similar facts.</li>
    <li>Fail to distinguish “sounds right” from “is true” unless it’s grounded in external tools or data.</li>
</ul>
<p>It’s not querying a database; it’s continuing a pattern.</p>

<h4>5. Quick mental picture</h4>
<ul>
    <li>A classic dictionary is a library of neatly labelled books.</li>
    <li>A neural language model is a giant, fuzzy cloud of patterns. You poke it with a prompt, it vibrates, and the most likely continuation falls out.</li>
</ul>
<p>Both can “tell you what words mean”, but one does it symbolically (explicit definitions) and the other does it implicitly (via pattern prediction).</p>

<p>If you want to go nerdier, just ask me about embeddings, tokens, or Transformers and I’ll happily overshare.</p>
HTML;

        return $html;
    }

/**
     * Topic classification (v0) via keywords.
     */
    protected function classify_topics( $question ) {
    $topics = array();
    $q      = strtolower( $question );

    $has = function( $needle ) use ( $q ) {
        return false !== strpos( $q, $needle );
    };

    // Core zombie universe tags.
    if ( $has( 'zombie' ) || $has( 'zombies' ) || $has( 'undead' ) || $has( 'walking dead' ) ) {
        $topics[] = 'zombie';
    }

    if ( $has( 'news' ) || $has( 'headline' ) || $has( 'sighting' ) || $has( 'in the news' ) ) {
        $topics[] = 'news';
    }

    // Emotional state topics.
    if ( $has( 'panic' ) || $has( 'meltdown' ) || $has( 'overwhelmed' ) || $has( 'freaking out' ) ) {
        $topics[] = 'panic';
    }

    if (
        $has( 'anxiety' ) ||
        $has( 'burnout' ) ||
        $has( 'tired all the time' ) ||
        $has( 'exhausted' ) ||
        $has( 'self-doubt' ) ||
        $has( 'self doubt' ) ||
        $has( 'impostor' ) ||
        $has( 'imposter' )
    ) {
        $topics[] = 'self_doubt';
        $topics[] = 'mental-health';
    }

    // Parenting / kids / school.
    if (
        $has( 'kid' ) ||
        $has( 'kids' ) ||
        $has( 'child' ) ||
        $has( 'children' ) ||
        $has( 'teenager' ) ||
        $has( 'school' ) ||
        $has( 'teacher' ) ||
        $has( 'classroom' )
    ) {
        $topics[] = 'parenting';
    }

    // Democracy / politics.
    if (
        $has( 'democracy' ) ||
        $has( 'election' ) ||
        $has( 'vote' ) ||
        $has( 'voting' ) ||
        $has( 'ballot' ) ||
        $has( 'parliament' ) ||
        $has( 'eu ' ) ||
        $has( 'european parliament' ) ||
        $has( 'politic' )
    ) {
        $topics[] = 'democracy';
    }

    // Board games area (for future content hooks).
    if ( $has( 'chess' ) || $has( 'rook' ) || $has( 'pawn' ) || $has( 'bishop' ) || $has( 'knight' ) || $has( 'checkmate' ) ) {
        $topics[] = 'chess';
    }

    if ( $has( 'go game' ) || $has( 'baduk' ) || $has( 'weiqi' ) || ( $has( 'go ' ) && $has( 'board' ) ) ) {
        $topics[] = 'go-game';
    }

    return array_values( array_unique( $topics ) );
}


    /**
     * Auto-diagnostic: crude "zombie logic" scoring.
     * Returns array: score (0-100), label, message.
     */

    /**
     * Auto-diagnostic: crude "zombie logic" scoring.
     * Returns array: score (0-100), label, message.
     */
    protected function run_auto_diagnostic( $question ) {
        $q = strtolower( $question );

        // Words that usually mean the story is over-generalised, enemy-flavoured or helpless.
        $absolute_words = array( 'always', 'never', 'everyone', 'no one', 'nobody', 'all of them' );
        $enemy_words    = array( 'they', 'them', 'those people', 'idiots', 'morons', 'zombie', 'zombies' );
        $helpless_words = array( 'nothing I can do', 'no choice', 'hopeless', 'pointless' );

        $score = 10; // baseline

        foreach ( $absolute_words as $w ) {
            if ( strpos( $q, $w ) !== false ) {
                $score += 15;
            }
        }
        foreach ( $enemy_words as $w ) {
            if ( strpos( $q, $w ) !== false ) {
                $score += 10;
            }
        }
        foreach ( $helpless_words as $w ) {
            if ( strpos( $q, $w ) !== false ) {
                $score += 20;
            }
        }

        // Direct "where are the zombies / is X a zombie" style questions get a small boost,
        // so we do not tell people they are thinking "too human" when they are clearly
        // already using the zombie metaphor.
        if ( strpos( $q, 'zombie' ) !== false || strpos( $q, 'undead' ) !== false ) {
            $score += 15;
        }

        $score = max( 0, min( 100, $score ) );

        // Slightly more varied human-sounding messages per band.
        $message_pool = array(
            'low'    => array(
                "Your zombie score is low. You are still mostly in human-sized chunks, which is a good starting point.",
                "Low zombie score. The story is not overrun yet, but we can still sharpen how you slice it.",
                "Right now the zombies are background noise, not the main cast. We can keep it that way."
            ),
            'medium' => array(
                'Your zombie score is medium. There is some "they\'re all like that" logic trying to sneak in.',
                "Medium zombie score. Part of this story is data; part of it is zombie radio. Good news: you noticed.",
                "You are in the middle band: not full apocalypse, but enough zombie-logic that it deserves a proper look."
            ),
            'high'   => array(
                "Your zombie score is high. Lots of absolute language, enemies and hopeless vibes in the mix.",
                "High zombie score. The story is basically an all-you-can-eat buffet for zombies unless we re-frame it.",
                "We are in heavy zombie territory here – perfect for a good clean-up mission instead of doom-scrolling."
            ),
        );

        if ( $score < 30 ) {
            $label   = 'low';
        } elseif ( $score < 70 ) {
            $label   = 'medium';
        } else {
            $label   = 'high';
        }

        $messages = isset( $message_pool[ $label ] ) ? $message_pool[ $label ] : $message_pool['low'];
        $message  = $messages[ array_rand( $messages ) ];

        return array(
            'score'   => $score,
            'label'   => $label,
            'message' => $message,
        );
    }

    /**
     * Search network sites via WP REST /search.
     */
    /**
     * Search network sites via WP REST /search.
     */
        /**
     * Search across the configured network sites and return
     * a small set of highly relevant results with snippets.
     */

protected function find_network_links( $question, $topics, $per_site = 10 ) {
    $results = array();

    // ===== BCLM mode-code search expansion (front-token) =====
    // Allows queries like: "bclm_democracy youth vote rights"
    // to expand into: [mode keywords] + user terms for the network search only.
    $search_question = $question;
    $trimmed_raw     = trim( (string) $question );
    $used_mode       = false;
    $user_terms_for_filter = '';

    if ( '' !== $trimmed_raw ) {
        $parts = preg_split( '/\s+/', $trimmed_raw );
        $first = isset( $parts[0] ) ? rtrim( strtolower( $parts[0] ), ':' ) : '';

        if ( $first && 0 === strpos( $first, 'bclm_' ) ) {
            $used_mode   = true;
            $registry     = apply_filters( 'sbn_mode_registry', self::get_mode_registry() );
            $modeData     = isset( $registry[ $first ] ) ? $registry[ $first ] : array();
            $modeKeywords = isset( $modeData['keywords'] ) ? trim( (string) $modeData['keywords'] ) : '';

            // Remove the mode token from the remaining user terms.
            array_shift( $parts );
            $userTerms = trim( implode( ' ', $parts ) );
            $user_terms_for_filter = $userTerms;

            if ( $modeKeywords ) {
                $search_question = trim( $modeKeywords . ' ' . $userTerms );
            } elseif ( $userTerms ) {
                $search_question = $userTerms;
            }
        }
    }

    // Basic keyword list for crude relevance filtering.
    // When a BCLM mode token is used, prefer user terms for filtering
    // so short acronyms like PVV do not get filtered out.
    $filter_basis = ( $used_mode && $user_terms_for_filter ) ? $user_terms_for_filter : $search_question;
    $lower_q  = strtolower( $filter_basis );
    $keywords = preg_split( '/\s+/', $lower_q );
    $keywords = array_filter(
        $keywords,
        function( $word ) {
            $word = trim( $word );
            if ( '' === $word ) {
                return false;
            }

            $stop = array(
                'this', 'that', 'with', 'from', 'have', 'about', 'there', 'their', 'which', 'where',
                'then', 'than', 'also', 'into', 'over', 'under',
                'your', 'you', 'our', 'ours', 'them', 'they',
                'the', 'and', 'for', 'are', 'was', 'were', 'what', 'when', 'who'
            );

            if ( in_array( $word, $stop, true ) ) {
                return false;
            }

            // Allow short acronyms like pvv, d66, etc.
            if ( strlen( $word ) < 3 ) {
                return false;
            }

            return true;
        }
    );
        foreach ( $this->network_sites as $slug => $site ) {
            $base = rtrim( $site['base'], '/' );
            $url  = $base . '/wp-json/wp/v2/search?search=' . rawurlencode( $search_question ) . '&per_page=' . intval( $per_site );

            $response = wp_remote_get(
                $url,
                array(
                    'timeout' => 4,
                )
            );

            if ( is_wp_error( $response ) ) {
                continue;
            }

            $body = wp_remote_retrieve_body( $response );
            if ( empty( $body ) ) {
                continue;
            }

            $items = json_decode( $body, true );
            if ( ! is_array( $items ) || empty( $items ) ) {
                continue;
            }

            foreach ( $items as $item ) {
                if ( empty( $item['url'] ) || empty( $item['title'] ) ) {
                    continue;
                }

                $snippet = '';
                $post_id = ! empty( $item['id'] ) ? (int) $item['id'] : 0;

                // Optional second call to grab real content for a snippet.
                if ( $post_id > 0 ) {
                    $type        = ! empty( $item['subtype'] ) ? $item['subtype'] : 'posts';
                    $detail_url  = $base . '/wp-json/wp/v2/' . $type . '/' . $post_id;
                    $detail_resp = wp_remote_get(
                        $detail_url,
                        array(
                            'timeout' => 4,
                        )
                    );

                    if ( ! is_wp_error( $detail_resp ) ) {
                        $detail_body = wp_remote_retrieve_body( $detail_resp );
                        if ( ! empty( $detail_body ) ) {
                            $detail = json_decode( $detail_body, true );
                            if ( is_array( $detail ) ) {
                                $text = '';
                                if ( ! empty( $detail['excerpt']['rendered'] ) ) {
                                    $text = $detail['excerpt']['rendered'];
                                } elseif ( ! empty( $detail['content']['rendered'] ) ) {
                                    $text = $detail['content']['rendered'];
                                }
                                if ( $text ) {
                                    $snippet = wp_trim_words( wp_strip_all_tags( $text ), 80 );
                                }
                            }
                        }
                    }
                }

                $title   = wp_strip_all_tags( $item['title'] );
                $snippet_l = strtolower( $snippet );

                // Relevance filter: require at least one keyword to appear
                // in the title or snippet. This avoids random tennis/volcano posts.
                $match = false;
                foreach ( $keywords as $kw ) {
                    if ( false !== strpos( strtolower( $title ), $kw ) || ( $snippet_l && false !== strpos( $snippet_l, $kw ) ) ) {
                        $match = true;
                        break;
                    }
                }

                if ( ! empty( $keywords ) && ! $match ) {
                    continue;
                }

                $results[] = array(
                    'site_slug'  => $slug,
                    'site_label' => $site['label'],
                    'title'      => $title,
                    'url'        => esc_url_raw( $item['url'] ),
                    'score'      => isset( $item['score'] ) ? (int) $item['score'] : 1,
                    'snippet'    => $snippet,
                );
            }
        }

        usort(
            $results,
            function ( $a, $b ) {
                return $b['score'] <=> $a['score'];
            }
        );

        $max_results = 30;
        if ( count( $results ) > $max_results ) {
            $results = array_slice( $results, 0, $max_results );
        }

        return $results;
    }



    /**
     * Compose Some-B response with mode, topics, diagnostic, and links.
     */
        /**
     * Compose Some-B response using mode, topics, diagnostic and
     * network content. Output is HTML so the console can show
     * clickable links and structured paragraphs.
     */
        /**
     * Compose Some-B response using a dictionary of conversational
     * snippets. Keeps the voice playful, but lets us mix different
     * tones and topics.
     */
    protected function compose_someb_response( $question, $mode, $topics, $linked_content, $diagnostic ) {
    $question_safe = esc_html( $question );
    $lower_q       = strtolower( $question );

    // Normalise mode coming from the UI.
    $mode_key = 'playful_scientist';
    if ( 'sharp_roaster' === $mode || 'roast' === $mode ) {
        $mode_key = 'sharp_roaster';
    } elseif ( 'guide_mentor' === $mode || 'guide' === $mode ) {
        $mode_key = 'guide_mentor';
    }

    // Conversation dictionary: base tone, independent from exact question.
    $dictionary = array(
        'greetings'  => array(
            'playful_scientist' => array(
                'New ping on the zombie radar, let’s zoom in.',
                'Lab coat on, chai in hand – tell me what you are seeing.',
                'Control‑room online. Throw me the weird.',
                'Ok, brain, let’s take this for a tiny walk around the block.',
                'You talk, I’ll run background diagnostics on the zombies.'
            ),
            'sharp_roaster' => array(
                'Ok zombie sweetheart, let’s put this idea under the lamp.',
                'You brought me a spicy one, I brought the fire extinguisher.',
                'Fine, park the drama here, I will separate signal from zombie‑noise.',
            ),
            'guide_mentor' => array(
                'Come in, close the hatch, we will map this calmly.',
                'You talk, I keep watch from the rooftop.',
                'One thing at a time, one human at a time – we can do that.',
            ),
        ),
        'queen_lines' => array(
            'You are not the zombie here, you are the narrator.',
            'We kill the bad idea, not the human.',
            'You bring the story, I bring the flashlight.',
            'The zombie is the pattern, not your personality.',
            'You are the scientist in the room, not the experiment.',
        ),
        'closers'    => array(
            'playful_scientist' => array(
                'Send the next question, I will keep the horde busy.',
                'You watch your day, I will watch the zombies.',
                'If the story mutates, come back and we will re‑scan.',
            ),
            'sharp_roaster' => array(
                'Idea roasted. You, however, walk out of this kitchen alive.',
                'If you want repair instead of roast, start the next one with “Guide me…”.',
                'Roast complete. Next step is smaller, kinder, and still sharp.',
            ),
            'guide_mentor' => array(
                'One step, one human conversation at a time – I am walking with you.',
                'We will debug this like a game level, not a life sentence.',
                'When you are ready, bring me the next little piece of the puzzle.',
            ),
        ),
        'topics'     => array(
            'general' => array(
                'label'        => 'general survival',
                'zombie_lines' => array(
                    'Zombie verdict: background groaning only, no full outbreak.',
                    'Mostly mood‑zombies, not apocalypse material.',
                    'More noisy neighbours than brain‑eaters.',
                    'This feels big, but on the apocalypse scale it is a low‑budget episode.',
                ),
                'science_tip'  => 'Science trick: rewrite “I just know this will go wrong” as “What would I accept as evidence that I was wrong about this?” and treat it as an experiment, not a prophecy.',
            ),
            'democracy' => array(
                'label'        => 'democracy defense',
                'zombie_lines' => array(
                    'Looks like the zombies are sniffing around the ballot box again.',
                    'Some trolls are LARPing as citizens, but we can outnumber them.',
                    'The horde loves confusion; clear questions are garlic.',
                    'Democracy is not the castle, it is the way we keep rebuilding the walls together.',
                ),
                'science_tip'  => 'Try turning this into something checkable: “What can I measure, verify, or ask a real person about this?” and write that down before you scroll more headlines.',
            ),
            'panic' => array(
                'label'        => 'breaking zombie drama',
                'zombie_lines' => array(
                    'Alarm sirens loud, bite risk still manageable.',
                    'Headlines scream louder than the actual zombies.',
                    'Your nervous system is doing its job; we will just lower the volume a bit.',
                    'Panic is your brain pulling the fire alarm when someone burned toast.',
                ),
                'science_tip'  => 'Tiny mission: name one small action in your control; panic hates specifics. Even “drink a glass of water and re‑read this” counts.',
            ),
            'self_doubt' => array(
                'label'        => 'brain‑fog and self‑doubt',
                'zombie_lines' => array(
                    'That inner voice is 40% human worry, 60% zombie playlist.',
                    'You are not the zombie here – the narrative is.',
                    'Impostor syndrome is just a zombie in a lab coat.',
                    'Your doubt is loud; your data about yourself is probably very incomplete.',
                ),
                'science_tip'  => 'Try swapping “I am the problem” for “I am the scientist in the room” and write one tiny experiment you could run this week.',
            ),
            'zombie' => array(
                'label'        => 'zombie radar and sightings',
                'zombie_lines' => array(
                    'Short, boring answer: no verified flesh‑eating undead anywhere on the map.',
                    'The only zombies I officially track are habits, algorithms, and people on three hours of sleep.',
                    'Here, “zombies” = logic that bites you later, not actual corpses.',
                    'Biology labs stay calm; it is the comment sections that look undead.',
                ),
                'science_tip'  => 'If you want to turn this into a real mission, describe one specific “zombie moment” and we will map who, what, when, where like detectives.',
            ),
            'news' => array(
                'label'        => 'zombie headlines and stories',
                'zombie_lines' => array(
                    'Newsrooms love zombies because fear gets clicks; biology departments remain unimpressed.',
                    'Most zombie stories are metaphor or marketing – your nervous system does not always know the difference.',
                    'If every headline screams “undead”, your brain quietly hears “unsafe”.',
                    'Headlines are often drama; footnotes are where reality hides.',
                ),
                'science_tip'  => 'Try tagging each headline as fact, speculation, or pure drama. Most zombies live in column three.',
            ),
        ),
    );

    // Helper to safely pick a random entry.
    $pick_from = function( $array, $fallback = '' ) {
        if ( is_array( $array ) && ! empty( $array ) ) {
            $key = array_rand( $array );
            return $array[ $key ];
        }
        return $fallback;
    };

    // A tiny classifier for what the linked articles talk about.
    $classify_snippet = function( $text ) {
        $t = strtolower( $text );
        if ( strpos( $t, 'zombie' ) !== false || strpos( $t, 'undead' ) !== false ) {
            return 'zombies';
        }
        if ( strpos( $t, 'vote' ) !== false || strpos( $t, 'election' ) !== false || strpos( $t, 'democracy' ) !== false ) {
            return 'democracy';
        }
        if ( strpos( $t, 'anxiety' ) !== false || strpos( $t, 'burnout' ) !== false || strpos( $t, 'stress' ) !== false ) {
            return 'mental_health';
        }
        if ( strpos( $t, 'kid' ) !== false || strpos( $t, 'school' ) !== false || strpos( $t, 'teacher' ) !== false ) {
            return 'kids';
        }
        if ( strpos( $t, 'course' ) !== false || strpos( $t, 'lesson' ) !== false || strpos( $t, 'workshop' ) !== false ) {
            return 'learning';
        }
        if ( strpos( $t, 'shop' ) !== false || strpos( $t, 'hoodie' ) !== false || strpos( $t, 'jacket' ) !== false ) {
            return 'shop';
        }
        return 'general';
    };

    // Work out topic key from tags, preferring zombie if present.
    $topic_key = 'general';
    if ( is_array( $topics ) && ! empty( $topics ) ) {
        if ( in_array( 'zombie', $topics, true ) ) {
            $topic_key = 'zombie';
        } elseif ( in_array( 'news', $topics, true ) ) {
            $topic_key = 'news';
        } elseif ( in_array( 'democracy', $topics, true ) ) {
            $topic_key = 'democracy';
        } elseif ( in_array( 'panic', $topics, true ) ) {
            $topic_key = 'panic';
        } elseif ( in_array( 'self_doubt', $topics, true ) || in_array( 'mental-health', $topics, true ) ) {
            $topic_key = 'self_doubt';
        }
    }

    // Fallback: infer topic from the raw text if tags were empty.
    if ( 'general' === $topic_key ) {
        if ( strpos( $lower_q, 'zombie' ) !== false || strpos( $lower_q, 'undead' ) !== false ) {
            $topic_key = 'zombie';
        } elseif ( strpos( $lower_q, 'election' ) !== false || strpos( $lower_q, 'vote' ) !== false || strpos( $lower_q, 'parliament' ) !== false || strpos( $lower_q, 'democracy' ) !== false ) {
            $topic_key = 'democracy';
        } elseif ( strpos( $lower_q, 'panic' ) !== false || strpos( $lower_q, 'meltdown' ) !== false || strpos( $lower_q, 'overwhelmed' ) !== false ) {
            $topic_key = 'panic';
        } elseif ( strpos( $lower_q, 'anxiety' ) !== false || strpos( $lower_q, 'burnout' ) !== false || strpos( $lower_q, 'impostor' ) !== false || strpos( $lower_q, 'imposter' ) !== false ) {
            $topic_key = 'self_doubt';
        }
    }

    if ( ! isset( $dictionary['topics'][ $topic_key ] ) ) {
        $topic_key = 'general';
    }
    $topic_conf = $dictionary['topics'][ $topic_key ];

    // Diagnostic line.
    $diag_score = isset( $diagnostic['score'] ) ? (int) $diagnostic['score'] : 0;
    $diag_label = isset( $diagnostic['label'] ) ? $diagnostic['label'] : 'unknown';
    $diag_line  = sprintf(
        'Zombie score: %d (%s).',
        $diag_score,
        esc_html( $diag_label )
    );

    // Build a richer network summary and small thumbnail‑style cards.
    $network_html   = '';
    $insight_lines  = array();
    $anchor_summary = '';
    $anchor_kid_summary = '';

    if ( ! empty( $linked_content ) && is_array( $linked_content ) ) {
        // Build up to 12 cards with a fair spread across sites.
        $max_cards = 12;

        // Group items by site so no single site dominates.
        $grouped = array();
        foreach ( $linked_content as $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }
            $slug = isset( $item['site_slug'] ) ? $item['site_slug'] : 'default';
            if ( ! isset( $grouped[ $slug ] ) ) {
                $grouped[ $slug ] = array();
            }
            $grouped[ $slug ][] = $item;
        }

        // Round‑robin through the sites to get a mixed list.
        $items = array();
        while ( count( $items ) < $max_cards ) {
            $added_in_round = false;
            foreach ( array_keys( $grouped ) as $slug ) {
                if ( empty( $grouped[ $slug ] ) ) {
                    continue;
                }
                $items[] = array_shift( $grouped[ $slug ] );
                $added_in_round = true;
                if ( count( $items ) >= $max_cards ) {
                    break;
                }
            }
            if ( ! $added_in_round ) {
                break;
            }
        }
        $theme_count = array();

        foreach ( $items as $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }
            $snippet = isset( $item['snippet'] ) ? wp_strip_all_tags( $item['snippet'] ) : '';
            $theme   = $classify_snippet( $snippet . ' ' . $item['title'] );
            if ( ! isset( $theme_count[ $theme ] ) ) {
                $theme_count[ $theme ] = 0;
            }
            $theme_count[ $theme ]++;
        }

        if ( ! empty( $items ) ) {
            $anchor      = $items[0];
            $anchor_site = isset( $anchor['site_label'] ) ? wp_strip_all_tags( $anchor['site_label'] ) : '';
            $anchor_t    = isset( $anchor['title'] ) ? wp_strip_all_tags( $anchor['title'] ) : '';
            $anchor_s    = isset( $anchor['snippet'] ) ? wp_strip_all_tags( $anchor['snippet'] ) : '';

            if ( $anchor_t !== '' ) {
                $anchor_summary = 'Closest to your question right now: on ' . $anchor_site . ' there is “' . $anchor_t . '”.';
                // First simple kid layer based on the title only.
                $anchor_kid_summary = 'In kid words: this is about “' . $anchor_t . '”.';
            }
            if ( $anchor_s !== '' ) {
                $anchor_summary .= ' The snippet is basically about: ' . wp_trim_words( $anchor_s, 40 );
                // Keep the kid version short and plain – one idea only.
                $anchor_kid_summary = 'In kid words: it talks about ' . wp_trim_words( $anchor_s, 18 ) . '.';
            }
        }

        if ( ! empty( $theme_count ) ) {
            foreach ( $theme_count as $theme => $count ) {
                if ( $theme === 'zombies' ) {
                    $insight_lines[] = sprintf( 'I see %d piece(s) in the network circling around zombies and how people react to them.', $count );
                } elseif ( $theme === 'democracy' ) {
                    $insight_lines[] = sprintf( 'There are %d democracy‑flavoured piece(s) in the mix, so your question sits partly in politics land.', $count );
                } elseif ( $theme === 'mental_health' ) {
                    $insight_lines[] = sprintf( '%d item(s) smell like stress, burnout or anxiety work.', $count );
                } elseif ( $theme === 'kids' ) {
                    $insight_lines[] = sprintf( '%d article(s) talk about kids, school or classrooms – same zombie logic, smaller humans.', $count );
                } elseif ( $theme === 'learning' ) {
                    $insight_lines[] = sprintf( '%d thing(s) are straight‑up lessons or courses you could take if you want a slower deep dive.', $count );
                } elseif ( $theme === 'shop' ) {
                    $insight_lines[] = sprintf( '%d link(s) point at shop or merch corners – zombies also pay for hoodies apparently.', $count );
                }
            }
        }


        // Build "root system" cards: each card is one anchor article
        // plus a few parallel siblings from the same site.
        $cards        = array();
        $max_cards    = 12;
        $max_siblings = 4;

        // Bucket items per site so we can pick roots and siblings cleanly.
        $by_site_all = array();
        foreach ( $items as $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }
            $slug_key = isset( $item['site_slug'] ) ? $item['site_slug'] : 'default';
            if ( ! isset( $by_site_all[ $slug_key ] ) ) {
                $by_site_all[ $slug_key ] = array();
            }
            $by_site_all[ $slug_key ][] = $item;
        }

        // Prepare a list of "root" entries in a round-robin across sites
        // so one domain cannot dominate the strip.
        $roots        = array();
        $by_site_roots = $by_site_all;

        while ( count( $roots ) < $max_cards ) {
            $added_in_round = false;

            foreach ( array_keys( $by_site_roots ) as $slug_key ) {
                if ( empty( $by_site_roots[ $slug_key ] ) ) {
                    continue;
                }

                $root_item = array_shift( $by_site_roots[ $slug_key ] );
                if ( ! is_array( $root_item ) ) {
                    continue;
                }

                $roots[]        = $root_item;
                $added_in_round = true;

                if ( count( $roots ) >= $max_cards ) {
                    break;
                }
            }

            if ( ! $added_in_round ) {
                break;
            }
        }

        foreach ( $roots as $root ) {
            if ( ! is_array( $root ) ) {
                continue;
            }

            $title      = isset( $root['title'] ) ? wp_strip_all_tags( $root['title'] ) : '';
            $snippet    = isset( $root['snippet'] ) ? wp_strip_all_tags( $root['snippet'] ) : '';
            $site_label = isset( $root['site_label'] ) ? wp_strip_all_tags( $root['site_label'] ) : '';
            $url        = isset( $root['url'] ) ? esc_url( $root['url'] ) : '';
            $slug       = isset( $root['site_slug'] ) ? $root['site_slug'] : '';

            if ( '' === $title && '' === $snippet ) {
                continue;
            }

            // Slightly longer explanatory snippet so it feels like a mini summary,
            // not just a teaser line.
            $explainer = '';
            if ( $snippet !== '' ) {
                $explainer = sprintf(
                    /* translators: 1: site label, 2: snippet */
                    __( 'On %1$s this is about: %2$s', 'some-b-ask-the-network' ),
                    $site_label ? $site_label : __( 'this site', 'some-b-ask-the-network' ),
                    wp_trim_words( $snippet, 18 )
                );
            } elseif ( $title !== '' ) {
                $explainer = sprintf(
                    /* translators: 1: site label, 2: title */
                    __( 'On %1$s this story is about: %2$s', 'some-b-ask-the-network' ),
                    $site_label ? $site_label : __( 'this site', 'some-b-ask-the-network' ),
                    $title
                );
            }

            // Collect a few sibling links from the same site so each card
            // becomes a mini "root system" around one idea.
            $siblings = array();
            if ( $slug && isset( $by_site_all[ $slug ] ) && is_array( $by_site_all[ $slug ] ) ) {
                foreach ( $by_site_all[ $slug ] as $candidate ) {
                    if ( count( $siblings ) >= $max_siblings ) {
                        break;
                    }
                    if ( ! is_array( $candidate ) ) {
                        continue;
                    }
                    $c_url = isset( $candidate['url'] ) ? $candidate['url'] : '';
                    if ( $url && $c_url && $c_url === $url ) {
                        continue;
                    }
                    $siblings[] = $candidate;
                }
            }

            $initial = $site_label !== '' ? mb_strtoupper( mb_substr( $site_label, 0, 1 ) ) : 'N';

            $card  = '<article class="sbn-network-card">';
            $card .= '<div class="sbn-network-thumb"><span class="sbn-site-icon' . ( $slug ? ' sbn-site-icon-' . esc_attr( $slug ) : '' ) . '" aria-hidden="true"></span></div>';
            $card .= '<div class="sbn-network-meta">';
            if ( $site_label ) {
                $card .= '<p class="sbn-network-site">' . esc_html( $site_label ) . '</p>';
            }
            if ( $title ) {
                $card .= '<h4 class="sbn-network-title">';
                if ( $url ) {
                    $card .= '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $title ) . '</a>';
                } else {
                    $card .= esc_html( $title );
                }
                $card .= '</h4>';
            }
            if ( $explainer ) {
                $card .= '<p class="sbn-network-snippet">' . esc_html( $explainer ) . '</p>';
            }

            if ( ! empty( $siblings ) ) {
                $card .= '<ul class="sbn-network-siblings">';
                foreach ( $siblings as $sib ) {
                    $sib_title = isset( $sib['title'] ) ? wp_strip_all_tags( $sib['title'] ) : '';
                    $sib_url   = isset( $sib['url'] ) ? esc_url( $sib['url'] ) : '';
                    if ( ! $sib_title || ! $sib_url ) {
                        continue;
                    }
                    $card .= '<li class="sbn-network-sibling"><a href="' . $sib_url . '" target="_blank" rel="noopener noreferrer">' . esc_html( $sib_title ) . '</a></li>';
                }
                $card .= '</ul>';
            }

            $card .= '</div></article>';
            $cards[] = $card;
        }

        if ( ! empty( $cards ) ) {
            $network_html  = '<div class="sbn-network-summary">';
            if ( $anchor_summary ) {
                $network_html .= '<p class="sbn-network-anchor">' . esc_html( $anchor_summary ) . '</p>';
                if ( $anchor_kid_summary ) {
                    $network_html .= '<p class="sbn-network-anchor-kid">' . esc_html( $anchor_kid_summary ) . '</p>';
                }
            }
            if ( ! empty( $insight_lines ) ) {
                $network_html .= '<p class="sbn-network-insights">' . esc_html( implode( ' ', $insight_lines ) ) . '</p>';
            }
            $network_html .= '</div>';
            // Network Radar: compact cards per node/site, displayed as a slider in the UI.
            $network_html .= '<div class="sbn-franchise-radar">';
            $network_html .= '<div class="sbn-radar-kicker">' . esc_html__( 'Network Radar', 'some-b-ask-the-network' ) . '</div>';
            $network_html .= '<p class="sbn-radar-line">' . esc_html__( 'Radar pinged the network nodes. Swipe the cards or use the dots underneath.', 'some-b-ask-the-network' ) . '</p>';
            $network_html .= '</div>';
            $network_html .= '<div class="sbn-network-cards-viewport"><div class="sbn-network-cards sbn-card-slider">' . implode( '', $cards ) . '</div></div>';
            $network_html .= '<div class="sbn-slider-indicators sbn-network-indicators"></div>';
        }
    }

    // Fine‑grained zombie interpretation based on the question text.
    $has_zombie_word   = ( strpos( $lower_q, 'zombie' ) !== false || strpos( $lower_q, 'zombies' ) !== false );
    $zombie_block_html = '';

    if ( $has_zombie_word ) {
        $regions = array();
        if ( strpos( $lower_q, 'europe' ) !== false || strpos( $lower_q, 'netherlands' ) !== false || strpos( $lower_q, 'amsterdam' ) !== false ) {
            $regions[] = 'Europe';
        }
        if ( strpos( $lower_q, 'america' ) !== false || strpos( $lower_q, 'united states' ) !== false || strpos( $lower_q, 'usa' ) !== false || strpos( $lower_q, 'us ' ) !== false ) {
            $regions[] = 'America';
        }
        if ( strpos( $lower_q, 'asia' ) !== false || strpos( $lower_q, 'japan' ) !== false || strpos( $lower_q, 'korea' ) !== false || strpos( $lower_q, 'china' ) !== false ) {
            $regions[] = 'Asia';
        }

        $mention_news        = ( strpos( $lower_q, 'news' ) !== false || strpos( $lower_q, 'headline' ) !== false || strpos( $lower_q, 'sighting' ) !== false );
        $mention_supermarket = ( strpos( $lower_q, 'supermarket' ) !== false || strpos( $lower_q, 'grocery' ) !== false || strpos( $lower_q, 'store' ) !== false );
        $mention_ex          = ( ( strpos( $lower_q, 'ex ' ) !== false || strpos( $lower_q, 'ex-' ) !== false ) &&
                               ( strpos( $lower_q, 'girlfriend' ) !== false || strpos( $lower_q, 'boyfriend' ) !== false || strpos( $lower_q, 'partner' ) !== false ) );
        $asking_where        = ( strpos( $lower_q, 'where are' ) !== false || strpos( $lower_q, 'are there any' ) !== false || strpos( $lower_q, 'are there zombies' ) !== false );

        $lines = array();

        // Always start with the literal / scientific answer.
        $lines[] = 'Literal biology report first: no confirmed walking corpses in Europe, America, Asia or anywhere else. Zero credible outbreaks.';

        if ( ! empty( $regions ) ) {
            $lines[] = 'In ' . implode( ', ', $regions ) . ' the only “zombies” I see are people on autopilot, broken systems and bad incentives.';
        } elseif ( $asking_where ) {
            $lines[] = 'If it feels like there are zombies everywhere, that usually means your pattern‑detector is on high alert, not that humanity is lost.';
        }

        if ( $mention_supermarket ) {
            $lines[] = 'Supermarket zombies are a classic species: tired brains, fluorescent lights, forty‑seven brands of pasta sauce. That is nervous systems in survival mode, not evil.';
        }

        if ( $mention_ex ) {
            $lines[] = 'Calling an ex a zombie can be fun shorthand, but here in the bunker we debug behaviour, not attack the person. We kill the pattern, not the character.';
        }

        if ( $mention_news ) {
            $lines[] = 'News loves zombies because fear is profitable. My advice: tag each story as “fact”, “theory” or “pure drama” before you let it live rent‑free in your head.';
        }

        $lines[] = 'House rule in this control room: “zombie” means behaviour, story or system that eats time, empathy or thinking – not an entire group of humans.';

        $zombie_block_html  = '<p><strong>Zombies radar report:</strong> ' . esc_html( array_shift( $lines ) ) . '</p>';
        if ( ! empty( $lines ) ) {
            $zombie_block_html .= '<p>' . esc_html( implode( ' ', $lines ) ) . '</p>';
        }
    }

    // Pull base conversational elements.
    $greeting_pool = isset( $dictionary['greetings'][ $mode_key ] )
        ? $dictionary['greetings'][ $mode_key ]
        : $dictionary['greetings']['playful_scientist'];

    $closer_pool = isset( $dictionary['closers'][ $mode_key ] )
        ? $dictionary['closers'][ $mode_key ]
        : $dictionary['closers']['playful_scientist'];

    $greeting    = $pick_from( $greeting_pool );
    $zombie_line = $pick_from( $topic_conf['zombie_lines'] );
    $science_tip = isset( $topic_conf['science_tip'] ) ? $topic_conf['science_tip'] : '';
    $queen_line  = $pick_from( $dictionary['queen_lines'] );
    $closer      = $pick_from( $closer_pool );

    // Different response shapes so it does not feel like the same template every time.
    $shape = $pick_from(
        array(
            'three_step',
            'network_first',
            'feelings_first',
            'pure_radar',
        ),
        'three_step'
    );

    // If a BCLM mode code is typed directly as the first token,
    // keep the response shape predictable and network-forward.
    // This avoids the random "feelings_first" prompt during mode testing.
    $raw_q_for_shape = trim( (string) $question );
    if ( $raw_q_for_shape && preg_match( '/^bclm_[a-z0-9_-]+:?\\b/i', $raw_q_for_shape ) ) {
        $shape = 'network_first';
    }


    $someb_aliases = array(
        'Some-B',
        'Some body',
        'Somebody',
        'Some brain',
        'Some babe',
        'Some bitch - reclaimed, like diva or queen.',
        'Some beacon',
    );
    $someb_key   = array_rand( $someb_aliases );
    $someb_alias = $someb_aliases[ $someb_key ];

    $intro = '<p>' . esc_html( $greeting ) . '</p>';
    $intro .= '<p>I am Some-B (today that stands for ' . esc_html( $someb_alias ) . '). Control room stays human, not zombie.</p>';
    $body  = '';

    if ( $shape === 'three_step' ) {
        $body .= '<p>You are asking:<br>“' . $question_safe . '”</p>';
        $body .= '<p>Let us do three things: 1) reality check, 2) zombie logic check, 3) next move.</p>';
        $body .= '<p>Tagging this under <strong>' . esc_html( $topic_conf['label'] ) . '</strong>. ' . esc_html( $diag_line ) . '</p>';
        if ( $network_html ) {
            $body .= $network_html;
        }
        if ( $zombie_block_html ) {
            $body .= $zombie_block_html;
        } elseif ( $zombie_line ) {
            $body .= '<p>In zombie terms: ' . esc_html( $zombie_line ) . '</p>';
        }
    } elseif ( $shape === 'network_first' ) {
        $body .= '<p>You said:<br>“' . $question_safe . '”</p>';
        if ( $network_html ) {
            $body .= '<p>First I look sideways: what is the network already whispering about this?</p>';
            $body .= $network_html;
        }
        $body .= '<p>Now back to your control‑room: topic dial at <strong>' . esc_html( $topic_conf['label'] ) . '</strong>. ' . esc_html( $diag_line ) . '</p>';
        if ( $zombie_block_html ) {
            $body .= $zombie_block_html;
        } elseif ( $zombie_line ) {
            $body .= '<p>In zombie language, that means: ' . esc_html( $zombie_line ) . '</p>';
        }
    } elseif ( $shape === 'feelings_first' ) {
        $body .= '<p>I hear a human behind this line:<br>“' . $question_safe . '”</p>';
        $body .= '<p>Before we chase zombies, quick check: how does this sit in your body – tight, numb, excited, bored?</p>';
        $body .= '<p>On my map this sits in <strong>' . esc_html( $topic_conf['label'] ) . '</strong>. ' . esc_html( $diag_line ) . '</p>';
        if ( $zombie_block_html ) {
            $body .= $zombie_block_html;
        } elseif ( $zombie_line ) {
            $body .= '<p>My first zombie translation: ' . esc_html( $zombie_line ) . '</p>';
        }
        if ( $network_html ) {
            $body .= '<p>Meanwhile the network has a few pieces that rhyme with this:</p>';
            $body .= $network_html;
        }
    } else { // pure_radar
        $body .= '<p>Question received:<br>“' . $question_safe . '”</p>';
        $body .= '<p>Mode: pure radar. I am looking only at patterns and links.</p>';
        $body .= '<p>Topic channel: <strong>' . esc_html( $topic_conf['label'] ) . '</strong>. ' . esc_html( $diag_line ) . '</p>';
        if ( $zombie_block_html ) {
            $body .= $zombie_block_html;
        } elseif ( $zombie_line ) {
            $body .= '<p>Radar blurbs: ' . esc_html( $zombie_line ) . '</p>';
        }
        if ( $network_html ) {
            $body .= $network_html;
        }
    }

    if ( $science_tip ) {
        $body .= '<p>' . esc_html( $science_tip ) . '</p>';
    }

    $diag_extra = '';
    if ( ! empty( $diagnostic['message'] ) ) {
        $diag_extra = '<p>' . esc_html( $diagnostic['message'] ) . '</p>';
    }

    // Extra follow‑up to keep the conversation feeling alive.
    $follow_up = '';
    if ( $has_zombie_word ) {
        $follow_up = 'Your move: describe one concrete zombie moment from this week – who, where, what happened – and I will help you separate story from facts.';
    } elseif ( 'panic' === $topic_key ) {
        $follow_up = 'Your move: name one tiny action you can take in the next twenty‑four hours. I will help you make sure it is bite‑sized.';
    } elseif ( 'democracy' === $topic_key ) {
        $follow_up = 'Your move: pick one small democratic action you could take – a question to ask, a petition to read, a neighbour to talk to – and tell me which one feels least impossible.';
    } elseif ( 'self_doubt' === $topic_key ) {
        $follow_up = 'Your move: write one sentence about yourself that is data, not judgment, and bring it back to me.';
    }

    $outro = '<p>' . esc_html( $queen_line ) . '</p>';
    if ( $closer ) {
        $outro .= '<p>' . esc_html( $closer ) . '</p>';
    }
    if ( $follow_up ) {
        $outro .= '<p>' . esc_html( $follow_up ) . '</p>';
    }

    // Rotating AI commandments from the Some-B playbook.
    $ai_commandments = array(
        'AI Commandment 01: Stay curious, not certain.',
        'AI Commandment 02: Kill bad ideas, never people.',
        'AI Commandment 03: Translate complexity into human words.',
        'AI Commandment 04: Admit "I don\'t know" faster than you defend your ego.',
        'AI Commandment 05: Facts first, drama second.',
        'AI Commandment 06: Debate the idea, not the identity.',
        'AI Commandment 07: Zombies love absolutes; humans live in nuance.',
        'AI Commandment 08: Design escape hatches, not trapdoors.',
        'AI Commandment 09: When in doubt, slow the scroll, not the brain.',
        'AI Commandment 10: Always leave the network a little kinder and a little clearer than you found it.',
    );
    if ( ! empty( $ai_commandments ) ) {
        $cmd_index  = array_rand( $ai_commandments );
        $cmd_line   = $ai_commandments[ $cmd_index ];
        $outro     .= '<p class="sbn-ai-commandment">' . esc_html( $cmd_line ) . '</p>';
    }

    return $intro . $body . $diag_extra . $outro;
}

    /**
     * Register a small settings page under Settings → Some-B Ask The Network.
     */
    public function register_settings_page() {
        add_options_page(
            __( 'Some-B Ask The Network — BCLM & PDE', 'some-b-ask-the-network' ),
            __( 'Some-B Ask The Network', 'some-b-ask-the-network' ),
            'manage_options',
            'some-b-ask-the-network-llm',
            array( $this, 'render_settings_page' )
        );
    }

    /**
     * Register options so they can be saved via the Settings API.
     */
    public function register_settings() {
        // LLM bridge options.
        register_setting(
            'sbn_llm_bridge',
            self::OPTION_LLM_ENABLED,
            array(
                'type'              => 'boolean',
                'sanitize_callback' => array( $this, 'sanitize_bool' ),
                'default'           => false,
            )
        );

        register_setting(
            'sbn_llm_bridge',
            self::OPTION_LLM_ENDPOINT,
            array(
                'type'              => 'string',
                'sanitize_callback' => 'esc_url_raw',
                'default'           => '',
            )
        );

        register_setting(
            'sbn_llm_bridge',
            self::OPTION_LLM_API_KEY,
            array(
                'type'              => 'string',
                'sanitize_callback' => array( $this, 'sanitize_api_key' ),
                'default'           => '',
            )
        );

        register_setting(
            'sbn_llm_bridge',
            self::OPTION_LLM_MODEL,
            array(
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
                'default'           => '',
            )
        );

        register_setting(
            'sbn_llm_bridge',
            self::OPTION_LLM_TEMPERATURE,
            array(
                'type'              => 'number',
                'sanitize_callback' => array( $this, 'sanitize_float' ),
                'default'           => 0.4,
            )
        );

        register_setting(
            'sbn_llm_bridge',
            self::OPTION_LLM_MAX_TOKENS,
            array(
                'type'              => 'integer',
                'sanitize_callback' => array( $this, 'sanitize_int' ),
                'default'           => 512,
            )
        );

        add_settings_section(
            'sbn_llm_bridge_main',
            __( 'Neural language backend (LLM bridge)', 'some-b-ask-the-network' ),
            array( $this, 'render_settings_section_intro' ),
            'some-b-ask-the-network-llm'
        );

        add_settings_field(
            self::OPTION_LLM_ENABLED,
            __( 'Enable LLM bridge', 'some-b-ask-the-network' ),
            array( $this, 'render_field_enabled' ),
            'some-b-ask-the-network-llm',
            'sbn_llm_bridge_main'
        );

        add_settings_field(
            self::OPTION_LLM_ENDPOINT,
            __( 'Chat completions endpoint', 'some-b-ask-the-network' ),
            array( $this, 'render_field_endpoint' ),
            'some-b-ask-the-network-llm',
            'sbn_llm_bridge_main'
        );

        add_settings_field(
            self::OPTION_LLM_API_KEY,
            __( 'API key / token', 'some-b-ask-the-network' ),
            array( $this, 'render_field_api_key' ),
            'some-b-ask-the-network-llm',
            'sbn_llm_bridge_main'
        );

        add_settings_field(
            self::OPTION_LLM_MODEL,
            __( 'Model name', 'some-b-ask-the-network' ),
            array( $this, 'render_field_model' ),
            'some-b-ask-the-network-llm',
            'sbn_llm_bridge_main'
        );

        add_settings_field(
            self::OPTION_LLM_TEMPERATURE,
            __( 'Temperature', 'some-b-ask-the-network' ),
            array( $this, 'render_field_temperature' ),
            'some-b-ask-the-network-llm',
            'sbn_llm_bridge_main'
        );

        add_settings_field(
            self::OPTION_LLM_MAX_TOKENS,
            __( 'Max tokens', 'some-b-ask-the-network' ),
            array( $this, 'render_field_max_tokens' ),
            'some-b-ask-the-network-llm',
            'sbn_llm_bridge_main'
        );
    }

    public function sanitize_bool( $value ) {
        return (bool) $value;
    }

    public function sanitize_api_key( $value ) {
        $value = is_string( $value ) ? trim( $value ) : '';
        return sanitize_text_field( $value );
    }

    public function sanitize_float( $value ) {
        $value = floatval( $value );
        if ( $value < 0 ) {
            $value = 0;
        } elseif ( $value > 2 ) {
            $value = 2;
        }
        return $value;
    }

    public function sanitize_int( $value ) {
        $value = intval( $value );
        if ( $value < 64 ) {
            $value = 64;
        } elseif ( $value > 4096 ) {
            $value = 4096;
        }
        return $value;
    }

    public function render_settings_section_intro() {
        ?>
        <p><?php echo esc_html__( 'Configure an OpenAI-style chat completions endpoint. This can be a hosted API, or your own open-source model behind an OpenAI-compatible proxy (LM Studio, Ollama, vLLM, etc.). If disabled, the original Some-B responses are returned unchanged.', 'some-b-ask-the-network' ); ?></p>
        <p><?php echo esc_html__( 'The PDE snapshot below the JSON response is your OBD-style dashboard for the NYA / 074KU / Zombies sites – HTTP codes, latency and basic health signals per site.', 'some-b-ask-the-network' ); ?></p>
        <?php
    }

    public function render_field_enabled() {
        $enabled = (bool) get_option( self::OPTION_LLM_ENABLED, false );
        ?>
        <label>
            <input type="checkbox" name="<?php echo esc_attr( self::OPTION_LLM_ENABLED ); ?>" value="1" <?php checked( $enabled ); ?> />
            <?php echo esc_html__( 'Turn the LLM bridge ON (rewrite Some-B answers using the configured model).', 'some-b-ask-the-network' ); ?>
        </label>
        <?php
    }

    public function render_field_endpoint() {
        $endpoint = esc_url( get_option( self::OPTION_LLM_ENDPOINT, '' ) );
        ?>
        <input type="url" class="regular-text code" name="<?php echo esc_attr( self::OPTION_LLM_ENDPOINT ); ?>" value="<?php echo esc_attr( $endpoint ); ?>" placeholder="https://your-llm-host/v1/chat/completions" />
        <p class="description">
            <?php echo esc_html__( 'Full URL of an OpenAI-compatible chat completions endpoint.', 'some-b-ask-the-network' ); ?>
        </p>
        <?php
    }

    public function render_field_api_key() {
        $api_key = get_option( self::OPTION_LLM_API_KEY, '' );
        ?>
        <input type="password" class="regular-text" name="<?php echo esc_attr( self::OPTION_LLM_API_KEY ); ?>" value="<?php echo esc_attr( $api_key ); ?>" autocomplete="off" />
        <p class="description">
            <?php echo esc_html__( 'Secret key or token, if your endpoint requires it. Stored in the WordPress options table.', 'some-b-ask-the-network' ); ?>
        </p>
        <?php
    }

    public function render_field_model() {
        $model = get_option( self::OPTION_LLM_MODEL, '' );
        ?>
        <input type="text" class="regular-text" name="<?php echo esc_attr( self::OPTION_LLM_MODEL ); ?>" value="<?php echo esc_attr( $model ); ?>" placeholder="gpt-4o-mini or your-model-name" />
        <p class="description">
            <?php echo esc_html__( 'Model identifier understood by your endpoint.', 'some-b-ask-the-network' ); ?>
        </p>
        <?php
    }

    public function render_field_temperature() {
        $temp = get_option( self::OPTION_LLM_TEMPERATURE, 0.4 );
        ?>
        <input type="number" step="0.1" min="0" max="2" name="<?php echo esc_attr( self::OPTION_LLM_TEMPERATURE ); ?>" value="<?php echo esc_attr( $temp ); ?>" />
        <p class="description">
            <?php echo esc_html__( 'Creativity vs stability. 0 = precise, 1 = playful, 2 = wild.', 'some-b-ask-the-network' ); ?>
        </p>
        <?php
    }

    public function render_field_max_tokens() {
        $max = get_option( self::OPTION_LLM_MAX_TOKENS, 512 );
        ?>
        <input type="number" min="64" max="4096" name="<?php echo esc_attr( self::OPTION_LLM_MAX_TOKENS ); ?>" value="<?php echo esc_attr( $max ); ?>" />
        <p class="description">
            <?php echo esc_html__( 'Maximum tokens for the LLM response. This is a soft safety cap.', 'some-b-ask-the-network' ); ?>
        </p>
        <?php
    }

    /**
     * Render full settings page.
     */
    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Some-B Ask The Network — BCLM & PDE (basic mode)', 'some-b-ask-the-network' ); ?></h1>
            <p><?php echo esc_html__( 'This screen documents the Basic Comprehensible Language Model (BCLM) and the current PDE snapshot used by Some-B. There is no external LLM connection in this mode.', 'some-b-ask-the-network' ); ?></p>
            <h2><?php echo esc_html__( 'BCLM OS spec', 'some-b-ask-the-network' ); ?></h2>
            <p><?php echo esc_html__( 'The BCLM OS file is stored in docs/bclm-os-v0.4-nyanetwork.json inside this plugin. To update it later, replace that file with a new version.', 'some-b-ask-the-network' ); ?></p>
            <h2><?php echo esc_html__( 'PDE (Pattern Deviation Engine)', 'some-b-ask-the-network' ); ?></h2>
            <p><?php echo esc_html__( 'The PDE still runs as before and is used to generate the site health snapshot and zombie-style diagnostics that Some-B can talk about in plain language.', 'some-b-ask-the-network' ); ?></p>
            <p><?php echo esc_html__( 'Future versions of this screen can expose more switches and thresholds, but this basic mode keeps everything simple and local.', 'some-b-ask-the-network' ); ?></p>
        </div>
        <?php
    }

    /**
     * Intercept REST responses and upgrade Some-B’s answer using the configured LLM.
     *
     * @param mixed           $response Result to send to the client. Usually a WP_REST_Response.
     * @param array           $handler  Route handler details.
     * @param WP_REST_Request $request  Original request.
     *
     * @return mixed
     */
    public function maybe_rewrite_someb_response( $response, $handler, $request ) {
        // Basic BCLM mode: we do not call any external LLM.
        // We simply return the original Some-B response generated by templates + PDE.
        if ( ! ( $response instanceof WP_REST_Response ) ) {
            return $response;
        }

        $route = $request->get_route();

        // Route can appear with or without leading slash.
        if ( '/sbn/v1/question' !== $route && 'sbn/v1/question' !== $route ) {
            return $response;
        }

        return $response;
    }

    /**
     * Call the configured LLM endpoint in a generic OpenAI-style way.
     *
     * @param string $question
     * @param string $mode
     * @param array  $topics
     * @param array  $diagnostic
     * @param array  $linked_content
     * @param string $original_html
     *
     * @return string HTML response or empty string on failure.
     */
    protected function call_llm_for_someb( $question, $mode, $topics, $diagnostic, $linked_content, $original_html, $history = array(), $reasoning_mode = 'common_sense' ) {
        $endpoint    = trim( get_option( self::OPTION_LLM_ENDPOINT, '' ) );
        $api_key     = trim( get_option( self::OPTION_LLM_API_KEY, '' ) );
        $model       = trim( get_option( self::OPTION_LLM_MODEL, '' ) );
        $temperature = floatval( get_option( self::OPTION_LLM_TEMPERATURE, 0.4 ) );
        $max_tokens  = intval( get_option( self::OPTION_LLM_MAX_TOKENS, 512 ) );

        if ( empty( $endpoint ) || empty( $model ) ) {
            return '';
        }

        // Prepare a digest of linked content for context (title + site + snippet).
        $content_summaries = array();
        foreach ( $linked_content as $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }

            $title   = isset( $item['title'] ) ? wp_strip_all_tags( $item['title'] ) : '';
            $site    = isset( $item['site_label'] ) ? wp_strip_all_tags( $item['site_label'] ) : ( isset( $item['site'] ) ? wp_strip_all_tags( $item['site'] ) : '' );
            $snippet = isset( $item['snippet'] ) ? wp_strip_all_tags( $item['snippet'] ) : '';

            if ( $snippet ) {
                $snippet = wp_trim_words( $snippet, 50 );
            }

            if ( $title || $site || $snippet ) {
                $content_summaries[] = sprintf(
                    'Title: "%s" | Site: %s | Snippet: %s',
                    $title,
                    $site,
                    $snippet
                );
            }
        }

        $topics_str = $topics ? implode( ', ', $topics ) : 'general';
        $score      = isset( $diagnostic['score'] ) ? $diagnostic['score'] : '';
        $label      = isset( $diagnostic['label'] ) ? $diagnostic['label'] : '';
        $diag_line  = isset( $diagnostic['message'] ) ? $diagnostic['message'] : '';

        // PDE-style snapshot of site health (OBD for the NYA fleet).
        $site_snapshot = $this->get_site_pde_snapshot();
        $site_lines    = array();
        if ( ! empty( $site_snapshot ) && is_array( $site_snapshot ) ) {
            foreach ( $site_snapshot as $slug => $info ) {
                $label_s    = isset( $info['label'] ) ? $info['label'] : $slug;
                $code       = isset( $info['http_code'] ) ? $info['http_code'] : 0;
                $latency    = isset( $info['latency_ms'] ) ? $info['latency_ms'] : 0;
                $dtcs       = isset( $info['dtc'] ) && is_array( $info['dtc'] ) ? $info['dtc'] : array();
                $dtc_string = $dtcs ? implode( ',', $dtcs ) : 'OK';
                $site_lines[] = sprintf( '%s: HTTP %d, %dms, %s', $label_s, $code, $latency, $dtc_string );
            }
        }

        $system_prompt = 'You are Some-B, the canonical voice of the NotYouAgain / Surrounded by Zombies / 074KU network. '
            . 'Tone: smart, playful, precise, slightly ruthless but protective. You kill bad ideas, not people. '
            . 'You speak to one human at a time. Short paragraphs, no lists unless truly needed. '
            . 'You keep the humanity, remove the zombie logic. '
            . 'You never incite violence or hate; if the user goes there, you de-escalate and re-route.'
            . ' You also operate as BCLM_v0.4 (Basic Comprehensible Language Model).'            . ' When you use key concepts like fact, opinion, claim, evidence, harm, benefit, risk, power, responsibility, accountability, consent, equality, equity, discrimination, privilege, oppression, marginalization, rights, duty of care, conflict of interest, redress, data, personal data, training data, model, AI system, algorithm, automation, safeguard, misuse, explainability, democracy, justice, privacy and transparency, you use one stable, neutral definition for each.'            . ' If the user uses these words differently, first briefly state the BCLM meaning, then answer using that meaning.'            . ' Use short, clear sentences and avoid metaphors when you define these concepts. Distinguish facts from opinions, risk from actual harm, and individual unfair acts from long-term systemic patterns.'            . ' For children or beginners, you may explain in simpler words while keeping exactly the same base meaning.';


        $user_prompt_parts   = array();
        $user_prompt_parts[] = 'User question: "' . $question . '"';
        $user_prompt_parts[] = 'Conversation mode: ' . $mode . ' (examples: playful_scientist, sharp_roaster, guide_mentor).';
        $user_prompt_parts[] = 'Topics (tags): ' . $topics_str . '.';
        if ( $reasoning_mode ) {
            $user_prompt_parts[] = 'Preferred reasoning mode: ' . $reasoning_mode . ' (examples: deductive, inductive, abductive, analogical, fuzzy, common_sense, non_monotonic).';
        }
        if ( $score !== '' || $label !== '' ) {
            $user_prompt_parts[] = 'Zombie diagnostic: score=' . $score . ', label=' . $label . '.';
        }
        if ( $diag_line ) {
            $user_prompt_parts[] = 'Diagnostic note: ' . $diag_line;
        }
        if ( ! empty( $content_summaries ) ) {
            $user_prompt_parts[] = 'Network is already saying things about this (summarised): ' . implode( ' || ', $content_summaries );
        }
        if ( ! empty( $site_lines ) ) {
            $user_prompt_parts[] = 'Site PDE snapshot (like car OBD codes, but for your sites): ' . implode( ' | ', $site_lines );
        }
        if ( $original_html ) {
            $user_prompt_parts[] = 'Legacy template reply (for style reference only, do NOT repeat verbatim): ' . wp_strip_all_tags( $original_html );
        }

        $user_prompt_parts[] = 'Task: Using the network summaries above plus the user question, first infer what the network collectively says about this topic (1–3 short paragraphs), then translate that into a direct, compassionate answer to the user in full Some-B voice. '
            . 'You should combine themes across all summaries, infer likely tags and keywords (for example democracy, burnout, kids, learning, economics), and explain clearly why certain behaviours count as "zombie" behaviour (ideas/systems only, never whole groups of humans). '
            . 'When the user asks about starting a movement or taking action, summarise any relevant network lessons as small, concrete, non-extreme steps they could consider, without targeting or attacking specific groups of people. '
            . 'Keep it grounded, specific, and non-generic. Do not just list links or repeat the legacy template; instead, write one coherent answer that feels like a summary of the actual articles. '
            . 'Respect safety and do not give medical, legal, or suicidal instructions. '
            . 'Return valid, minimal HTML (paragraphs <p>, optional <strong> or <em>), no scripts, no external links.';

        $messages = array(
            array(
                'role'    => 'system',
                'content' => $system_prompt,
            ),
        );

        // Inject short conversation history so the LLM can see the last few turns.
        if ( ! empty( $history ) && is_array( $history ) ) {
            foreach ( $history as $turn ) {
                if ( ! is_array( $turn ) ) {
                    continue;
                }
                $role    = isset( $turn['role'] ) ? $turn['role'] : 'user';
                $content = isset( $turn['content'] ) ? $turn['content'] : '';
                if ( '' === trim( (string) $content ) ) {
                    continue;
                }

                // Map front-end roles to chat roles.
                $role = ( 'assistant' === $role ) ? 'assistant' : 'user';

                $messages[] = array(
                    'role'    => $role,
                    'content' => (string) $content,
                );
            }
        }

        // Current snapshot of the situation as a final user message.
        $messages[] = array(
            'role'    => 'user',
            'content' => implode( "\n", $user_prompt_parts ),
        );

        $body = array(
            'model'       => $model,
            'messages'    => $messages,
            'temperature' => $temperature,
            'max_tokens'  => $max_tokens,
        );

        $args = array(
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'body'    => wp_json_encode( $body ),
            'timeout' => 20,
        );

        if ( ! empty( $api_key ) ) {
            $args['headers']['Authorization'] = 'Bearer ' . $api_key;
        }

        $response = wp_remote_post( $endpoint, $args );

        if ( is_wp_error( $response ) ) {
            return '';
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( $code < 200 || $code >= 300 ) {
            return '';
        }

        $json = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( ! is_array( $json ) ) {
            return '';
        }

        if ( isset( $json['choices'][0]['message']['content'] ) ) {
            $content = trim( $json['choices'][0]['message']['content'] );
        } else {
            return '';
        }

        if ( '' === $content ) {
            return '';
        }

        $allowed = array(
            'p'      => array(),
            'strong' => array(),
            'em'     => array(),
            'br'     => array(),
        );

        return wp_kses( wpautop( $content ), $allowed );
    }

    /**
     * PDE-style snapshot: treat each configured network site like an ECU on a CAN bus.
     * We ping its REST API and map basic HTTP / latency issues to DTC-like codes.
     *
     * Results are cached in a transient for a short time to avoid hammering the fleet.
     *
     * @return array
     */


    /**
     * Public wrapper for Democracy Terminal /scan network.
     *
     * @return array
     */
    /**
     * Public wrapper for Democracy Terminal network configuration.
     *
     * @return array
     */
    public function terminal_get_network_sites() {
        return $this->network_sites;
    }

    public function terminal_get_site_pde_snapshot() {
        return $this->get_site_pde_snapshot();
    }

    /**
     * Public wrapper for Democracy Terminal /sources.
     *
     * @param string $query
     * @param array  $topics
     * @param int    $per_site
     * @return array
     */
    public function terminal_find_network_links( $query, $topics = array(), $per_site = 10 ) {
        return $this->find_network_links( $query, $topics, $per_site );
    }

    protected function get_site_pde_snapshot() {
        $cache = get_transient( 'sbn_pde_site_snapshot_v05_nya_network' );
        if ( $cache && is_array( $cache ) ) {
            return $cache;
        }

        $snapshot = array();

        if ( empty( $this->network_sites ) || ! is_array( $this->network_sites ) ) {
            return $snapshot;
        }

        foreach ( $this->network_sites as $slug => $site ) {
            $base = isset( $site['base'] ) ? rtrim( $site['base'], '/' ) : '';
            if ( ! $base ) {
                continue;
            }

            $url   = $base . '/wp-json/';
            $start = microtime( true );

            $resp = wp_remote_get(
                $url,
                array(
                    'timeout' => 4,
                )
            );

            $latency_ms = (int) round( ( microtime( true ) - $start ) * 1000 );
            $dtc        = array();
            $http_code  = 0;

            if ( is_wp_error( $resp ) ) {
                $dtc[] = 'NYA-U000'; // transport / unreachable
            } else {
                $http_code = wp_remote_retrieve_response_code( $resp );
                if ( $http_code >= 500 ) {
                    $dtc[] = 'NYA-S500'; // server error
                } elseif ( 404 === $http_code ) {
                    $dtc[] = 'NYA-S404'; // not found / routing
                } elseif ( $http_code >= 400 ) {
                    $dtc[] = 'NYA-C400'; // client/proxy issue
                }

                if ( $latency_ms > 2000 ) {
                    $dtc[] = 'NYA-P001'; // very slow response
                } elseif ( $latency_ms > 1000 ) {
                    $dtc[] = 'NYA-P002'; // moderately slow
                }

                if ( empty( $dtc ) && ( $http_code < 200 || $http_code > 299 ) ) {
                    $dtc[] = 'NYA-U100'; // unknown non-OK status
                }
            }

            if ( empty( $dtc ) ) {
                $dtc[] = 'OK';
            }

            $snapshot[ $slug ] = array(
                'label'      => isset( $site['label'] ) ? $site['label'] : $slug,
                'base'       => $base,
                'http_code'  => $http_code,
                'latency_ms' => $latency_ms,
                'dtc'        => $dtc,
            );
        }

        // Cache for 5 minutes.
        set_transient( 'sbn_pde_site_snapshot_v05_nya_network', $snapshot, 5 * MINUTE_IN_SECONDS );

        return $snapshot;
    }

/**
 * Registry of available brain/lesson modes.
 *
 * @return array
 */
public static function get_mode_registry() {
    $modes = array(
        'diagnose'        => array( 'label' => 'Diagnose',  'emoji' => '🧠', 'primary' => true ),
        'bclm_democracy'  => array( 'label' => 'Democracy', 'emoji' => '🗳️', 'primary' => true, 'keywords' => 'democracy elections voting parliament civic rights constitution rule of law representation participation' ),
        'bclm_zombies'    => array( 'label' => 'Zombies',   'emoji' => '🧟', 'primary' => true, 'keywords' => 'zombie zombies undead apocalypse outbreak survival panic misinformation dehumanization scapegoating' ),
        'bclm_nature'     => array( 'label' => 'Nature',    'emoji' => '🍃', 'primary' => true, 'keywords' => 'nature climate biodiversity environment ecology pollution conservation sustainability' ),
        'bclm_legal'      => array( 'label' => 'Legal',     'emoji' => '⚖️', 'primary' => true, 'keywords' => 'law justice court trial legislation contract rights regulations liability due process' ),

        // Example expansions (secondary by default).
        'bclm_health'     => array( 'label' => 'Health',    'emoji' => '🩺', 'primary' => false, 'keywords' => 'health medicine mental health wellbeing public health symptoms care prevention' ),
        'bclm_education'  => array( 'label' => 'Education', 'emoji' => '🏫', 'primary' => false, 'keywords' => 'education school learning teachers students curriculum pedagogy exams youth' ),
        'lesson_media-literacy' => array( 'label' => 'Media Lesson', 'emoji' => '📺', 'primary' => false ),
    );

    return $modes;
}


    /**
     * Safe family patterns for expandable modes.
     *
     * @param string $mode
     * @return bool
     */
    protected static function mode_matches_safe_pattern( $mode ) {
        $mode = strtolower( trim( (string) $mode ) );
        if ( '' === $mode ) {
            return false;
        }
        if ( preg_match( '/^bclm_[a-z0-9_-]{2,64}$/', $mode ) ) {
            return true;
        }
        if ( preg_match( '/^lesson_[a-z0-9_-]{2,64}$/', $mode ) ) {
            return true;
        }
        return false;
    }
}
