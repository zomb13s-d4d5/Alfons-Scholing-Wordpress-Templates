<?php
/**
 * Main template: render the Some-B Control Room as the entire site.
 */
get_header();

// Render the exact same control-room UI used by the plugin overlay.
echo do_shortcode( '[sbn_control_room]' );

get_footer();
