<?php
/**
 * Plugin Name:  074KU – Some-B Programming Lessons Autoposter
 * Description:  Creates published lesson posts for 074ku.eu that link to free programming courses and docs from MIT OCW, Wikipedia, GitHub, W3C, Python, PHP and more. Each run adds one new published post in a dedicated programming lessons category, and there is a manual “Run now” button under Tools → 074KU Lessons.
 * Version:      1.0.2
 * Author:       NotYouAgain.ai / Alfons Scholing & GPT-5.1 Thinking
 * License:      GPL2+
 * Text Domain:  074ku-lessons-some-b
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SZ_074KU_Programming_Lessons_SomeB {

    const OPTION_LAST_RUN    = 'sz_074ku_lessons_last_run';
    const OPTION_POSTED_IDS  = 'sz_074ku_lessons_posted_ids';
    const CRON_HOOK          = 'sz_074ku_lessons_cron_hook';
    const CATEGORY_SLUG      = '074ku-programming-lessons';
    const NONCE_ACTION       = 'sz_074ku_lessons_manual_run';
    const MAX_PER_RUN        = 1;

    /**
     * Wire up WordPress hooks.
     */
    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'register_tools_page' ) );
        add_action( 'admin_init', array( __CLASS__, 'maybe_manual_run' ) );
        add_action( self::CRON_HOOK, array( __CLASS__, 'run_autoposter' ) );
        add_action( 'init', array( __CLASS__, 'maybe_schedule_cron' ) );
        add_action( 'init', array( __CLASS__, 'maybe_run_on_init' ) );
    }

    /**
     * On activation, set up a recurring cron event.
     */
    public static function activate() {
        self::maybe_schedule_cron();
    }

    /**
     * On deactivation, unschedule our cron hook.
     */
    public static function deactivate() {
        $timestamp = wp_next_scheduled( self::CRON_HOOK );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, self::CRON_HOOK );
        }
    }

    /**
     * Ensure our cron event exists (hourly).
     */
    public static function maybe_schedule_cron() {
        if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
            // small delay so activation doesn’t immediately fire the ajax/cron
            wp_schedule_event( time() + 5 * MINUTE_IN_SECONDS, 'hourly', self::CRON_HOOK );
        }
    }

    /**
     * Simple fallback so lessons keep appearing even without real cron configured.
     * Runs at most every 30 minutes on normal page loads.
     */
    public static function maybe_run_on_init() {
        if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
            return;
        }
        if ( defined( 'DOING_CRON' ) && DOING_CRON ) {
            return;
        }

        $last_run = (int) get_option( self::OPTION_LAST_RUN, 0 );
        $interval = 30 * MINUTE_IN_SECONDS;

        if ( $last_run && ( time() - $last_run ) < $interval ) {
            return;
        }

        if ( php_sapi_name() === 'cli' ) {
            return;
        }

        self::run_autoposter();
    }

    /**
     * Main autoposter logic. Creates up to MAX_PER_RUN new published posts.
     */
    public static function run_autoposter() {
        $lessons = self::get_all_lessons();
        if ( empty( $lessons ) || ! is_array( $lessons ) ) {
            update_option( self::OPTION_LAST_RUN, time() );
            return;
        }

        $posted = get_option( self::OPTION_POSTED_IDS, array() );
        if ( ! is_array( $posted ) ) {
            $posted = array();
        }

        $created = 0;

        foreach ( $lessons as $id => $lesson ) {
            if ( in_array( $id, $posted, true ) ) {
                continue;
            }

            $post_id = self::create_post_from_lesson( $id, $lesson );
            if ( $post_id ) {
                $posted[] = $id;
                $created++;
            }

            if ( $created >= self::MAX_PER_RUN ) {
                break;
            }
        }

        if ( $created > 0 ) {
            update_option( self::OPTION_POSTED_IDS, $posted );
        }

        update_option( self::OPTION_LAST_RUN, time() );
    }

    /**
     * Add a Tools → 074KU Lessons screen.
     */
    public static function register_tools_page() {
        add_management_page(
            __( '074KU Programming Lessons', '074ku-lessons-some-b' ),
            __( '074KU Lessons', '074ku-lessons-some-b' ),
            'manage_options',
            'sz-074ku-lessons',
            array( __CLASS__, 'render_tools_page' )
        );
    }

    /**
     * Render the Tools screen.
     */
    public static function render_tools_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'You do not have permission to access this page.', '074ku-lessons-some-b' ) );
        }

        $last_run  = (int) get_option( self::OPTION_LAST_RUN, 0 );
        $posted    = get_option( self::OPTION_POSTED_IDS, array() );
        if ( ! is_array( $posted ) ) {
            $posted = array();
        }
        $lessons   = self::get_all_lessons();
        $total     = is_array( $lessons ) ? count( $lessons ) : 0;
        $remaining = max( 0, $total - count( $posted ) );
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( '074KU – Some-B Programming Lessons Autoposter', '074ku-lessons-some-b' ); ?></h1>

            <p><?php esc_html_e( 'This helper creates published lesson posts for 074ku.eu by linking to free programming courses and documentation from MIT OCW, Wikipedia, GitHub, W3C, Python, PHP and other reputable sources. Each run adds one new published post in the 074KU Programming Lessons category.', '074ku-lessons-some-b' ); ?></p>

            <p><strong><?php esc_html_e( 'Total curated lessons:', '074ku-lessons-some-b' ); ?></strong> <?php echo (int) $total; ?></p>
            <p><strong><?php esc_html_e( 'Already created:', '074ku-lessons-some-b' ); ?></strong> <?php echo (int) count( $posted ); ?></p>
            <p><strong><?php esc_html_e( 'Remaining:', '074ku-lessons-some-b' ); ?></strong> <?php echo (int) $remaining; ?></p>
            <p><strong><?php esc_html_e( 'Last run:', '074ku-lessons-some-b' ); ?></strong>
                <?php
                if ( $last_run ) {
                    echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $last_run ) );
                } else {
                    esc_html_e( 'Never', '074ku-lessons-some-b' );
                }
                ?>
            </p>

            <form method="post">
                <?php wp_nonce_field( self::NONCE_ACTION, 'sz_074ku_lessons_nonce' ); ?>
                <p>
                    <input type="submit" name="sz_074ku_lessons_run_now" class="button button-primary" value="<?php esc_attr_e( 'Run now (publish next lesson)', '074ku-lessons-some-b' ); ?>" />
                </p>
            </form>

            <p><em><?php esc_html_e( "Lessons are published immediately in the '074KU Programming Lessons' category. You can still edit or unpublish them afterwards if needed.", '074ku-lessons-some-b' ); ?></em></p>
        </div>
        <?php
    }

    /**
     * Handle the manual Run Now button.
     */
    public static function maybe_manual_run() {
        if ( empty( $_POST['sz_074ku_lessons_run_now'] ) ) {
            return;
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        if ( empty( $_POST['sz_074ku_lessons_nonce'] ) || ! wp_verify_nonce( $_POST['sz_074ku_lessons_nonce'], self::NONCE_ACTION ) ) {
            return;
        }

        self::run_autoposter();

        add_action(
            'admin_notices',
            function () {
                ?>
                <div class="notice notice-success is-dismissible">
                    <p><?php esc_html_e( '074KU Lessons autoposter has run. A new programming lesson should now be published.', '074ku-lessons-some-b' ); ?></p>
                </div>
                <?php
            }
        );
    }

    /**
     * Ensure the special category exists and return its ID.
     *
     * @return int
     */
    protected static function ensure_category_id() {
        $cat = get_category_by_slug( self::CATEGORY_SLUG );
        if ( $cat && ! is_wp_error( $cat ) ) {
            return (int) $cat->term_id;
        }

        $result = wp_insert_term(
            '074KU Programming Lessons',
            'category',
            array(
                'slug'        => self::CATEGORY_SLUG,
                'description' => 'Autogenerated lesson posts that link to free programming courses and documentation.',
            )
        );

        if ( is_wp_error( $result ) ) {
            return 0;
        }

        return (int) $result['term_id'];
    }

    /**
     * Build a tiny "mini lesson" text based on the main language / topic.
     *
     * @param string $language
     * @param string $topic
     * @return string
     */
    protected static function build_mini_lesson( $language, $topic ) {
        $language_lc = strtolower( trim( $language ) );

        if ( $language_lc === 'python' ) {
            return 'Open a Python shell or notebook. Write a small program that asks for your name and age, prints a greeting, and then prints the age in dog years (age * 7). Change it so it only prints the dog-years line when age is greater than 10.';
        }

        if ( $language_lc === 'php' ) {
            return 'Create a tiny PHP file that prints today’s date and the message “Hello 074KU”. Then change it so the message is taken from a PHP variable and printed in upper-case.';
        }

        if ( $language_lc === 'css' ) {
            return 'Make a simple HTML page with a headline and a button. Use CSS to increase the line-height of the headline and add a hover effect on the button that slightly changes its background color and adds a subtle shadow.';
        }

        // For mixed / conceptual / multiple-language articles.
        if ( $topic ) {
            return 'After reading the first part of this resource, write down in your own words one core idea you learned about “' . $topic . '” and one question you still have. Keep both very short.';
        }

        return 'Read the first 10–15 minutes of this resource. Then write a two-line summary in your own words and one short question you would ask a mentor about it.';
    }

    /**
     * Turn a curated lesson entry into a published WordPress post.
     *
     * @param string $id
     * @param array  $lesson
     * @return int Post ID or 0 on failure.
     */
    protected static function create_post_from_lesson( $id, $lesson ) {
        $category_id = self::ensure_category_id();

        $title    = isset( $lesson['title'] ) ? $lesson['title'] : '';
        $source   = isset( $lesson['source'] ) ? $lesson['source'] : '';
        $level    = isset( $lesson['level'] ) ? $lesson['level'] : '';
        $language = isset( $lesson['language'] ) ? $lesson['language'] : '';
        $url      = isset( $lesson['url'] ) ? $lesson['url'] : '';
        $summary  = isset( $lesson['summary'] ) ? $lesson['summary'] : '';
        $topic    = isset( $lesson['topic'] ) ? $lesson['topic'] : '';

        if ( ! $title || ! $url ) {
            return 0;
        }

        $post_title = $source ? sprintf( '%s – %s', $source, $title ) : $title;

        $lines = array();

        if ( $source ) {
            $lines[] = '<p><strong>Source:</strong> ' . esc_html( $source ) . '</p>';
        }

        if ( $summary ) {
            $lines[] = '<p><strong>Why this matters:</strong> ' . esc_html( $summary ) . '</p>';
        }

        $meta_bits = array();
        if ( $language ) {
            $meta_bits[] = 'Language: ' . $language;
        }
        if ( $level ) {
            $meta_bits[] = 'Level: ' . $level;
        }
        if ( $topic ) {
            $meta_bits[] = 'Theme: ' . $topic;
        }

        if ( ! empty( $meta_bits ) ) {
            $lines[] = '<p><strong>Lesson snapshot:</strong> ' . esc_html( implode( ' · ', $meta_bits ) ) . '</p>';
        }

        $lines[] = '<p><a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer">Open the original free course / documentation</a></p>';

        if ( ! empty( $lesson['attribution'] ) ) {
            $lines[] = '<p><em>' . esc_html( $lesson['attribution'] ) . '</em></p>';
        }

        // Replace the autoposter disclaimer with a small concrete micro-lesson.
        $mini_lesson = self::build_mini_lesson( $language, $topic );
        if ( $mini_lesson ) {
            $lines[] = '<hr />';
            $lines[] = '<p><strong>Mini lesson for 074KU:</strong> ' . esc_html( $mini_lesson ) . '</p>';
        }

        $content = implode( "\n\n", $lines );

        $postarr = array(
            'post_title'   => $post_title,
            'post_content' => $content,
            'post_status'  => 'publish',
            'post_type'    => 'post',
        );

        if ( $category_id ) {
            $postarr['post_category'] = array( $category_id );
        }

        $post_id = wp_insert_post( $postarr, true );

        if ( is_wp_error( $post_id ) ) {
            return 0;
        }

        add_post_meta( $post_id, '_sz_074ku_lesson_id', sanitize_text_field( $id ), true );

        if ( ! empty( $lesson['tags'] ) && is_array( $lesson['tags'] ) ) {
            $tags = array();
            foreach ( $lesson['tags'] as $tag ) {
                $tag = sanitize_text_field( $tag );
                if ( $tag !== '' ) {
                    $tags[] = $tag;
                }
            }
            if ( ! empty( $tags ) ) {
                wp_set_post_terms( $post_id, $tags, 'post_tag', true );
            }
        }

        return (int) $post_id;
    }

    /**
     * Static curated list of excellent free programming resources.
     * Each entry becomes one possible lesson post.
     *
     * @return array
     */
    protected static function get_all_lessons() {
        $lessons = array(
            'mit-6-0001-intro-python' => array(
                'source'  => 'MIT OpenCourseWare',
                'title'   => '6.0001 Introduction to Computer Science and Programming in Python',
                'url'     => 'https://ocw.mit.edu/courses/6-0001-introduction-to-computer-science-and-programming-in-python-fall-2016/',
                'summary' => 'A complete introductory MIT course that teaches fundamental computer science ideas through hands-on Python programming.',
                'level'   => 'Introductory',
                'language'=> 'Python',
                'topic'   => 'Computer science foundations',
                'tags'    => array( 'python', 'mit-ocw', 'intro', 'cs-fundamentals' ),
                'attribution' => 'Based on materials from MIT OpenCourseWare. Always check the original page for current license terms.',
            ),
            'mit-6-0002-computational-thinking' => array(
                'source'  => 'MIT OpenCourseWare',
                'title'   => '6.0002 Introduction to Computational Thinking and Data Science',
                'url'     => 'https://ocw.mit.edu/courses/electrical-engineering-and-computer-science/6-0002-introduction-to-computational-thinking-and-data-science-fall-2016/',
                'summary' => 'Follow-up to 6.0001 that introduces data science, simulations and optimization while staying very practical.',
                'level'   => 'Intermediate',
                'language'=> 'Python',
                'topic'   => 'Computational thinking and data science',
                'tags'    => array( 'python', 'data-science', 'mit-ocw' ),
                'attribution' => 'Based on materials from MIT OpenCourseWare. Always check the original page for current license terms.',
            ),
            'mit-6-100l-intro-cs-python' => array(
                'source'  => 'MIT OpenCourseWare',
                'title'   => '6.100L Introduction to CS and Programming using Python',
                'url'     => 'https://ocw.mit.edu/courses/6-100l-introduction-to-cs-and-programming-using-python-fall-2022/',
                'summary' => 'Modern, slower-paced MIT introduction aimed at absolute beginners who want extra practice and gentle pacing.',
                'level'   => 'Introductory',
                'language'=> 'Python',
                'topic'   => 'Gentle intro to CS with Python',
                'tags'    => array( 'python', 'mit-ocw', 'beginner' ),
                'attribution' => 'Based on materials from MIT OpenCourseWare. Always check the original page for current license terms.',
            ),
            'mit-introductory-programming-collection' => array(
                'source'  => 'MIT OpenCourseWare',
                'title'   => 'Introductory Programming Collection',
                'url'     => 'https://ocw.mit.edu/collections/introductory-programming/',
                'summary' => 'Gateway page that groups MIT’s core introductory programming and follow-up courses in one place.',
                'level'   => 'Mixed',
                'language'=> 'Python and more',
                'topic'   => 'Route map of MIT intro programming courses',
                'tags'    => array( 'mit-ocw', 'overview', 'python', 'intro' ),
                'attribution' => 'Based on materials from MIT OpenCourseWare. Always check the original page for current license terms.',
            ),
            'python-official-tutorial' => array(
                'source'  => 'Python.org',
                'title'   => 'The Python Tutorial (Official Docs)',
                'url'     => 'https://docs.python.org/3/tutorial/index.html',
                'summary' => 'Official language tutorial that walks through Python syntax, control flow and core built-in types with many small examples.',
                'level'   => 'Introductory–Intermediate',
                'language'=> 'Python',
                'topic'   => 'Core Python language and standard patterns',
                'tags'    => array( 'python', 'official-docs', 'syntax' ),
                'attribution' => 'Uses the official Python documentation as a reference. See docs.python.org for full details and license.',
            ),
            'python-beginners-guide' => array(
                'source'  => 'Python Wiki',
                'title'   => 'Beginner’s Guide to Python',
                'url'     => 'https://wiki.python.org/moin/BeginnersGuide',
                'summary' => 'Curated starting point with links to carefully chosen beginner-friendly Python tutorials and resources.',
                'level'   => 'Introductory',
                'language'=> 'Python',
                'topic'   => 'Choosing a first Python learning path',
                'tags'    => array( 'python', 'beginner', 'curated-links' ),
                'attribution' => 'Based on resources listed on the official Python Wiki.',
            ),
            'python-programiz-track' => array(
                'source'  => 'Programiz',
                'title'   => 'Learn Python Programming (Step-by-step Track)',
                'url'     => 'https://www.programiz.com/python-programming',
                'summary' => 'Free structured Python track that covers syntax, data structures, functions, OOP and common real-world tasks.',
                'level'   => 'Introductory–Intermediate',
                'language'=> 'Python',
                'topic'   => 'End-to-end Python basics and beyond',
                'tags'    => array( 'python', 'tutorial-series', 'practice' ),
                'attribution' => 'Links to free tutorials hosted on Programiz. Review their site for terms of use.',
            ),
            'php-manual-getting-started' => array(
                'source'  => 'PHP.net',
                'title'   => 'PHP Manual – Getting Started + Simple Tutorial',
                'url'     => 'https://www.php.net/manual/en/index.php',
                'summary' => 'Official PHP manual index including an introductory tutorial and explanations of how PHP works on the web.',
                'level'   => 'Introductory',
                'language'=> 'PHP',
                'topic'   => 'Server-side scripting fundamentals',
                'tags'    => array( 'php', 'web', 'server-side' ),
                'attribution' => 'References the official PHP manual available on php.net.',
            ),
            'w3c-css-firstcss' => array(
                'source'  => 'W3C',
                'title'   => 'CSS tutorial – starting with HTML + CSS',
                'url'     => 'https://www.w3.org/Style/Examples/011/firstcss.en.html',
                'summary' => 'Short, standards-focused tutorial that shows how to style a simple HTML page using modern CSS.',
                'level'   => 'Introductory',
                'language'=> 'CSS',
                'topic'   => 'First steps with CSS and page styling',
                'tags'    => array( 'css', 'w3c', 'web-design' ),
                'attribution' => 'Based on examples from the World Wide Web Consortium (W3C).',
            ),
            'w3c-css-learning-hub' => array(
                'source'  => 'W3C',
                'title'   => 'Learning CSS – W3C resource hub',
                'url'     => 'https://www.w3.org/Style/CSS/learning.en.html',
                'summary' => 'W3C hub that points to books, tutorials and historical context around Cascading Style Sheets.',
                'level'   => 'Introductory–Reference',
                'language'=> 'CSS',
                'topic'   => 'Deepening CSS skills with curated links',
                'tags'    => array( 'css', 'w3c', 'reference' ),
                'attribution' => 'Based on the W3C learning page for CSS; always visit the original for the most current pointers.',
            ),
            'github-ossu-computer-science' => array(
                'source'  => 'GitHub – Open Source Society University',
                'title'   => 'OSSU: Path to a free self-taught education in Computer Science',
                'url'     => 'https://github.com/ossu/computer-science',
                'summary' => 'Open-source “university” curriculum that assembles free online courses into a full CS degree-style roadmap.',
                'level'   => 'Introductory–Advanced',
                'language'=> 'Multiple',
                'topic'   => 'Complete CS curriculum with free courses',
                'tags'    => array( 'github', 'curriculum', 'computer-science' ),
                'attribution' => 'Links to an open-source curriculum hosted on GitHub. Respect each referenced course’s own license.',
            ),
            'github-awesome-courses' => array(
                'source'  => 'GitHub – Awesome Courses',
                'title'   => 'Awesome University Courses for Learning Computer Science',
                'url'     => 'https://github.com/prakhar1989/awesome-courses',
                'summary' => 'Community-maintained list of high-quality university CS courses, including many with full lecture videos and assignments.',
                'level'   => 'Intermediate–Advanced',
                'language'=> 'Multiple',
                'topic'   => 'Curated advanced CS course list',
                'tags'    => array( 'github', 'awesome-list', 'courses' ),
                'attribution' => 'Points to a GitHub awesome-list; each linked course has its own terms.',
            ),
            'github-awesome-coding-camps' => array(
                'source'  => 'GitHub – Awesome Coding Camps',
                'title'   => 'Awesome Coding Camps and Practice Platforms',
                'url'     => 'https://github.com/theodesp/awesome-coding-camps',
                'summary' => 'Directory of camps, online judges and game-like sites for practicing programming through problems and competitions.',
                'level'   => 'Practice-focused',
                'language'=> 'Multiple',
                'topic'   => 'Deliberate practice and coding challenges',
                'tags'    => array( 'github', 'practice', 'competitions' ),
                'attribution' => 'Links to a community list of coding camps and judges on GitHub.',
            ),
            'wikipedia-computer-programming' => array(
                'source'  => 'Wikipedia',
                'title'   => 'Computer programming – Overview article',
                'url'     => 'https://en.wikipedia.org/wiki/Computer_programming',
                'summary' => 'Broad overview of what programming is, where it came from, and how people learn and practice it today.',
                'level'   => 'Conceptual overview',
                'language'=> 'Multiple',
                'topic'   => 'History and context of programming',
                'tags'    => array( 'wikipedia', 'overview', 'history' ),
                'attribution' => 'Summary-style link to a Wikipedia article. Content there is available under Creative Commons licenses.',
            ),
            'wikipedia-programming-language' => array(
                'source'  => 'Wikipedia',
                'title'   => 'Programming language – Overview article',
                'url'     => 'https://en.wikipedia.org/wiki/Programming_language',
                'summary' => 'Conceptual explanation of what programming languages are, why they differ and how they are classified.',
                'level'   => 'Conceptual overview',
                'language'=> 'Multiple',
                'topic'   => 'Programming language theory at a high level',
                'tags'    => array( 'wikipedia', 'languages', 'theory' ),
                'attribution' => 'Summary-style link to a Wikipedia article. Content there is available under Creative Commons licenses.',
            ),
            'wikiversity-introduction-to-programming' => array(
                'source'  => 'Wikiversity',
                'title'   => 'Introduction to Programming (Open Course)',
                'url'     => 'https://en.wikiversity.org/wiki/Introduction_to_Programming',
                'summary' => 'Open-licensed introduction to programming that is structured as a self-study course on Wikiversity.',
                'level'   => 'Introductory',
                'language'=> 'Multiple',
                'topic'   => 'First structured programming course for self-learners',
                'tags'    => array( 'wikiversity', 'intro', 'course' ),
                'attribution' => 'Links to an open educational resource on Wikiversity.',
            ),
        );

        return $lessons;
    }
}

// Wire up lifecycle hooks.
add_action( 'plugins_loaded', array( 'SZ_074KU_Programming_Lessons_SomeB', 'init' ) );
register_activation_hook( __FILE__, array( 'SZ_074KU_Programming_Lessons_SomeB', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'SZ_074KU_Programming_Lessons_SomeB', 'deactivate' ) );
