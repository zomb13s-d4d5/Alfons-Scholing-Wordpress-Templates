<?php
/**
 * Plugin Name: SBZ End-Boss Zombie Lesson Autoposter
 * Description: Fetches European news RSS sources, clusters headlines by topic, and auto-posts kid-friendly (but sharp) "End-Boss Zombie" rhetoric lessons for SurroundedByZombies. Image-light, code-heavy.
 * Version: 1.0.0
 * Author: NotYouAgain.ai / Some-B Network
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) { exit; }

define('SBZ_EBZ_VERSION', '1.0.0');
define('SBZ_EBZ_SLUG', 'sbz-ebz');
define('SBZ_EBZ_DIR', plugin_dir_path(__FILE__));
define('SBZ_EBZ_URL', plugin_dir_url(__FILE__));

require_once SBZ_EBZ_DIR . 'includes/sources.php';
require_once SBZ_EBZ_DIR . 'includes/generator.php';
require_once SBZ_EBZ_DIR . 'includes/admin.php';

register_activation_hook(__FILE__, function() {
  sbz_ebz_register_cpt();
  flush_rewrite_rules();
  sbz_ebz_ensure_defaults();
  sbz_ebz_schedule();
});

register_deactivation_hook(__FILE__, function() {
  sbz_ebz_unschedule();
  flush_rewrite_rules();
});

add_action('init', 'sbz_ebz_register_cpt');
function sbz_ebz_register_cpt() {
  $labels = array(
    'name' => 'Zombie Lessons',
    'singular_name' => 'Zombie Lesson',
  );
  register_post_type('sbn_lesson', array(
    'labels' => $labels,
    'public' => true,
    'show_in_rest' => true,
    'has_archive' => true,
    'rewrite' => array('slug' => 'zombie-lessons'),
    'supports' => array('title','editor','excerpt','author','thumbnail','custom-fields'),
    'menu_icon' => 'dashicons-megaphone',
  ));
}

add_filter('cron_schedules', function($schedules){
  if (!isset($schedules['sbz_ebz_weekly'])) {
    $schedules['sbz_ebz_weekly'] = array('interval' => 7*24*60*60, 'display' => 'Once Weekly (SBZ)');
  }
  return $schedules;
});

add_action('sbz_ebz_cron_tick', function(){
  sbz_ebz_run_autopost(false);
});

function sbz_ebz_ensure_defaults() {
  $defaults = array(
    'enabled' => 1,
    'frequency' => 'daily', // daily|weekly
    'time_hhmm' => '09:30',
    'status' => 'publish', // publish|draft
    'category' => 'Zombie Lessons',
    'tag' => 'zombie-rhetoric',
    'voice_pack' => 'sidekick_endboss',
    'language' => 'en',
    'max_items_per_feed' => 12,
    'max_feeds' => 80,
    'cluster_min_similarity' => 0.25,
    'cluster_pick' => 'largest', // largest|random
    'sources_mode' => 'curated', // curated|custom|opml
    'custom_sources' => array(),
    'opml_url' => '',
    'last_posted_guids' => array(),
    'lesson_rotation' => 0,
  );
  $opt = get_option('sbz_ebz_options');
  if (!is_array($opt)) { $opt = array(); }
  $merged = array_merge($defaults, $opt);
  update_option('sbz_ebz_options', $merged, false);
}

function sbz_ebz_schedule() {
  $opt = get_option('sbz_ebz_options');
  if (!is_array($opt)) { sbz_ebz_ensure_defaults(); $opt = get_option('sbz_ebz_options'); }

  sbz_ebz_unschedule();

  if (empty($opt['enabled'])) { return; }

  $freq = ($opt['frequency'] === 'weekly') ? 'sbz_ebz_weekly' : 'daily';
  $hhmm = isset($opt['time_hhmm']) ? $opt['time_hhmm'] : '09:30';

  $tz = wp_timezone();
  $now = new DateTime('now', $tz);
  $run = DateTime::createFromFormat('Y-m-d H:i', $now->format('Y-m-d') . ' ' . $hhmm, $tz);
  if (!$run) { $run = clone $now; $run->modify('+5 minutes'); }
  if ($run <= $now) {
    $run->modify('+1 day');
  }
  wp_schedule_event($run->getTimestamp(), $freq, 'sbz_ebz_cron_tick');
}

function sbz_ebz_unschedule() {
  $ts = wp_next_scheduled('sbz_ebz_cron_tick');
  while ($ts) {
    wp_unschedule_event($ts, 'sbz_ebz_cron_tick');
    $ts = wp_next_scheduled('sbz_ebz_cron_tick');
  }
}

/**
 * Runs one autopost pass.
 * @param bool $force_post_even_if_empty if true, will post an empty "No loot found" lesson.
 */
function sbz_ebz_run_autopost($force_post_even_if_empty = false) {
  $opt = get_option('sbz_ebz_options');
  if (empty($opt['enabled']) && !$force_post_even_if_empty) { return array('ok'=>false,'msg'=>'Disabled'); }

  // Ensure category exists
  $cat_id = 0;
  $cat_name = sanitize_text_field($opt['category']);
  if ($cat_name) {
    $term = term_exists($cat_name, 'category');
    if (!$term) {
      $created = wp_insert_term($cat_name, 'category');
      if (!is_wp_error($created) && isset($created['term_id'])) { $cat_id = (int)$created['term_id']; }
    } else {
      $cat_id = (int)(is_array($term) ? $term['term_id'] : $term);
    }
  }

  $sources = sbz_ebz_get_sources($opt);
  $items = sbz_ebz_fetch_items($sources, (int)$opt['max_items_per_feed'], (int)$opt['max_feeds']);

  // Filter out already-used GUIDs
  $used = isset($opt['last_posted_guids']) && is_array($opt['last_posted_guids']) ? $opt['last_posted_guids'] : array();
  $fresh = array();
  foreach ($items as $it) {
    if (!empty($it['guid']) && in_array($it['guid'], $used, true)) continue;
    $fresh[] = $it;
  }

  if (empty($fresh) && !$force_post_even_if_empty) {
    return array('ok'=>false,'msg'=>'No new items');
  }

  $cluster = sbz_ebz_pick_cluster($fresh, $opt);
  $lesson = sbz_ebz_generate_lesson($cluster, $opt);

  $postarr = array(
    'post_type' => 'sbn_lesson',
    'post_title' => $lesson['title'],
    'post_content' => $lesson['content'],
    'post_status' => ($opt['status'] === 'draft') ? 'draft' : 'publish',
    'post_category' => $cat_id ? array($cat_id) : array(),
    'tags_input' => array_filter(array_map('sanitize_text_field', array($opt['tag']))),
  );

  $post_id = wp_insert_post($postarr, true);
  if (is_wp_error($post_id)) {
    return array('ok'=>false,'msg'=>$post_id->get_error_message());
  }

  // Store a small GUID history to prevent repeats
  foreach ($cluster as $it) {
    if (!empty($it['guid'])) { $used[] = $it['guid']; }
  }
  $used = array_values(array_unique($used));
  if (count($used) > 400) { $used = array_slice($used, -400); }
  $opt['last_posted_guids'] = $used;

  // advance rotation
  $opt['lesson_rotation'] = (int)$opt['lesson_rotation'] + 1;

  update_option('sbz_ebz_options', $opt, false);

  return array('ok'=>true,'msg'=>'Posted','post_id'=>$post_id);
}
