=== SBZ End-Boss Zombie Lesson Autoposter ===
Contributors: notyouagain
Tags: rss, autopost, education, media literacy, rhetoric
Requires at least: 6.0
Tested up to: 6.7
Stable tag: 1.0.0
License: GPLv2 or later

Fetch European news RSS sources, cluster headlines by topic, and auto-post kid-friendly "End-Boss Zombie" rhetoric lessons for SurroundedByZombies.

IMPORTANT: The plugin only republishes HEADLINE + LINK from feeds, then writes original lesson text. It does not copy full articles.

== Installation ==
1. Upload ZIP in WP Admin -> Plugins -> Add New -> Upload Plugin
2. Activate
3. Tools -> SBZ End-Boss Autoposter

== Sources ==
- Curated pack includes BBC, France 24, DW, Euronews, NOS, RTVE, RaiNews, NRK, Yle, Eurotopics.
- You can switch to OPML mode and use any OPML URL (e.g., Plenary awesome-rss-feeds raw OPML files).
- Or paste your own list.

== Scheduling ==
Uses WP-Cron. Ensure your site has traffic or a real cron ping to wp-cron.php.

== Changelog ==
= 1.0.0 =
Initial release.
