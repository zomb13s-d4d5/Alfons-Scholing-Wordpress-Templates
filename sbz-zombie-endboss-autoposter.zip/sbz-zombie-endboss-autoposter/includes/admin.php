<?php
if (!defined('ABSPATH')) { exit; }

add_action('admin_menu', function(){
  add_submenu_page(
    'tools.php',
    'SBZ End‑Boss Lesson Autoposter',
    'SBZ End‑Boss Autoposter',
    'manage_options',
    'sbz-ebz',
    'sbz_ebz_admin_page'
  );
});

add_action('admin_init', function(){
  register_setting('sbz_ebz_group', 'sbz_ebz_options', array(
    'type' => 'array',
    'sanitize_callback' => 'sbz_ebz_sanitize_options',
    'default' => array(),
  ));
});

function sbz_ebz_sanitize_options($in) {
  $opt = get_option('sbz_ebz_options');
  if (!is_array($opt)) $opt = array();
  $out = is_array($opt) ? $opt : array();

  $out['enabled'] = !empty($in['enabled']) ? 1 : 0;
  $out['frequency'] = in_array($in['frequency'] ?? 'daily', array('daily','weekly'), true) ? $in['frequency'] : 'daily';
  $out['time_hhmm'] = preg_match('/^\d{2}:\d{2}$/', $in['time_hhmm'] ?? '') ? $in['time_hhmm'] : '09:30';
  $out['status'] = ($in['status'] ?? 'publish') === 'draft' ? 'draft' : 'publish';
  $out['category'] = sanitize_text_field($in['category'] ?? 'Zombie Lessons');
  $out['tag'] = sanitize_text_field($in['tag'] ?? 'zombie-rhetoric');
  $out['voice_pack'] = sanitize_text_field($in['voice_pack'] ?? 'sidekick_endboss');
  $out['language'] = sanitize_text_field($in['language'] ?? 'en');

  $out['max_items_per_feed'] = max(1, min(30, intval($in['max_items_per_feed'] ?? 12)));
  $out['max_feeds'] = max(1, min(250, intval($in['max_feeds'] ?? 80)));
  $out['cluster_min_similarity'] = max(0.10, min(0.60, floatval($in['cluster_min_similarity'] ?? 0.25)));
  $out['cluster_pick'] = ($in['cluster_pick'] ?? 'largest') === 'random' ? 'random' : 'largest';

  $out['sources_mode'] = in_array($in['sources_mode'] ?? 'curated', array('curated','custom','opml'), true) ? $in['sources_mode'] : 'curated';
  $out['opml_url'] = esc_url_raw($in['opml_url'] ?? '');

  // Custom sources: expect newline list "Name | URL | Country"
  $out['custom_sources'] = array();
  $raw = $in['custom_sources_text'] ?? '';
  if (is_string($raw) && trim($raw) !== '') {
    $lines = preg_split('/\r\n|\r|\n/', $raw);
    foreach ($lines as $ln) {
      $ln = trim($ln);
      if ($ln === '') continue;
      $parts = array_map('trim', explode('|', $ln));
      $name = sanitize_text_field($parts[0] ?? 'Source');
      $url = esc_url_raw($parts[1] ?? '');
      $cty = sanitize_text_field($parts[2] ?? '');
      if ($url) {
        $out['custom_sources'][] = array('name'=>$name, 'url'=>$url, 'country'=>$cty, 'type'=>'custom');
      }
    }
  }

  return $out;
}

function sbz_ebz_admin_page() {
  if (!current_user_can('manage_options')) return;

  $opt = get_option('sbz_ebz_options');
  if (!is_array($opt)) { sbz_ebz_ensure_defaults(); $opt = get_option('sbz_ebz_options'); }

  // Handle manual run
  $notice = '';
  if (isset($_POST['sbz_ebz_run_now']) && check_admin_referer('sbz_ebz_run_now')) {
    $res = sbz_ebz_run_autopost(true);
    $notice = $res['ok'] ? '✅ Posted a lesson.' : ('⚠️ ' . esc_html($res['msg']));
  }
  if (isset($_POST['sbz_ebz_reschedule']) && check_admin_referer('sbz_ebz_reschedule')) {
    sbz_ebz_schedule();
    $notice = '🕒 Schedule updated.';
  }

  $custom_text = '';
  if (!empty($opt['custom_sources']) && is_array($opt['custom_sources'])) {
    foreach ($opt['custom_sources'] as $s) {
      $custom_text .= ($s['name'] ?? 'Source') . ' | ' . ($s['url'] ?? '') . ' | ' . ($s['country'] ?? '') . "\n";
    }
  }

  ?>
  <div class="wrap">
    <h1>SBZ End‑Boss Zombie Lesson Autoposter</h1>

    <?php if ($notice): ?>
      <div class="notice notice-info"><p><?php echo $notice; ?></p></div>
    <?php endif; ?>

    <form method="post" action="options.php">
      <?php settings_fields('sbz_ebz_group'); ?>
      <?php $o = $opt; ?>

      <table class="form-table" role="presentation">
        <tr>
          <th scope="row">Enabled</th>
          <td><label><input type="checkbox" name="sbz_ebz_options[enabled]" value="1" <?php checked(!empty($o['enabled'])); ?> /> Auto-post lessons</label></td>
        </tr>

        <tr>
          <th scope="row">Frequency</th>
          <td>
            <select name="sbz_ebz_options[frequency]">
              <option value="daily" <?php selected($o['frequency'],'daily'); ?>>Daily</option>
              <option value="weekly" <?php selected($o['frequency'],'weekly'); ?>>Weekly</option>
            </select>
          </td>
        </tr>

        <tr>
          <th scope="row">Time (site timezone)</th>
          <td><input type="text" name="sbz_ebz_options[time_hhmm]" value="<?php echo esc_attr($o['time_hhmm']); ?>" placeholder="09:30" /></td>
        </tr>

        <tr>
          <th scope="row">Post status</th>
          <td>
            <select name="sbz_ebz_options[status]">
              <option value="publish" <?php selected($o['status'],'publish'); ?>>Publish</option>
              <option value="draft" <?php selected($o['status'],'draft'); ?>>Draft</option>
            </select>
          </td>
        </tr>

        <tr>
          <th scope="row">Category</th>
          <td><input type="text" name="sbz_ebz_options[category]" value="<?php echo esc_attr($o['category']); ?>" /></td>
        </tr>

        <tr>
          <th scope="row">Tag</th>
          <td><input type="text" name="sbz_ebz_options[tag]" value="<?php echo esc_attr($o['tag']); ?>" /></td>
        </tr>

        <tr>
          <th scope="row">Voice pack</th>
          <td>
            <select name="sbz_ebz_options[voice_pack]">
              <option value="sidekick_endboss" <?php selected($o['voice_pack'],'sidekick_endboss'); ?>>Sidekick vs End‑Boss Zombie</option>
            </select>
          </td>
        </tr>

        <tr>
          <th scope="row">Sources</th>
          <td>
            <fieldset>
              <label><input type="radio" name="sbz_ebz_options[sources_mode]" value="curated" <?php checked($o['sources_mode'],'curated'); ?> /> Curated Europe pack (PSM/EU-wide)</label><br/>
              <label><input type="radio" name="sbz_ebz_options[sources_mode]" value="opml" <?php checked($o['sources_mode'],'opml'); ?> /> Import OPML URL</label>
              <div style="margin:6px 0 12px 20px;">
                <input type="text" style="width:520px" name="sbz_ebz_options[opml_url]" value="<?php echo esc_attr($o['opml_url']); ?>" placeholder="https://raw.githubusercontent.com/.../Germany.opml" />
                <p class="description">Tip: use Plenary's CC0 OPML country files for Europe and mix them on your side.</p>
              </div>
              <label><input type="radio" name="sbz_ebz_options[sources_mode]" value="custom" <?php checked($o['sources_mode'],'custom'); ?> /> Custom list</label>
              <div style="margin:6px 0 0 20px;">
                <textarea name="sbz_ebz_options[custom_sources_text]" rows="8" style="width:520px" placeholder="Name | URL | Country"><?php echo esc_textarea($custom_text); ?></textarea>
                <p class="description">One per line. We only use headline + link from feeds.</p>
              </div>
            </fieldset>
          </td>
        </tr>

        <tr>
          <th scope="row">Topic clustering</th>
          <td>
            <label>Max feeds: <input type="number" name="sbz_ebz_options[max_feeds]" value="<?php echo esc_attr($o['max_feeds']); ?>" min="1" max="250" /></label><br/>
            <label>Items per feed: <input type="number" name="sbz_ebz_options[max_items_per_feed]" value="<?php echo esc_attr($o['max_items_per_feed']); ?>" min="1" max="30" /></label><br/>
            <label>Min similarity: <input type="text" name="sbz_ebz_options[cluster_min_similarity]" value="<?php echo esc_attr($o['cluster_min_similarity']); ?>" /></label><br/>
            <label>Pick cluster:
              <select name="sbz_ebz_options[cluster_pick]">
                <option value="largest" <?php selected($o['cluster_pick'],'largest'); ?>>Largest topic</option>
                <option value="random" <?php selected($o['cluster_pick'],'random'); ?>>Random topic</option>
              </select>
            </label>
          </td>
        </tr>
      </table>

      <?php submit_button('Save settings'); ?>
    </form>

    <form method="post">
      <?php wp_nonce_field('sbz_ebz_run_now'); ?>
      <p><button class="button button-primary" name="sbz_ebz_run_now" value="1">Post next lesson now</button></p>
    </form>

    <form method="post">
      <?php wp_nonce_field('sbz_ebz_reschedule'); ?>
      <p><button class="button" name="sbz_ebz_reschedule" value="1">Reschedule Cron</button></p>
    </form>

    <hr/>
    <p><strong>Feeds & rights note:</strong> many public broadcasters allow showing headlines + links, but restrict republishing full content. This plugin sticks to headline+link and adds your own lesson text.</p>
  </div>
  <?php
}
