<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Pick a cluster of related headlines.
 * Clustering is title-based (bag-of-words Jaccard). Lightweight & offline.
 */
function sbz_ebz_pick_cluster($items, $opt) {
  $min_sim = isset($opt['cluster_min_similarity']) ? floatval($opt['cluster_min_similarity']) : 0.25;
  $pick = isset($opt['cluster_pick']) ? $opt['cluster_pick'] : 'largest';

  // Keep it bounded for performance
  $items = array_slice($items, 0, 200);

  $clusters = array(); // each: ['tokens'=>set, 'items'=>[]]
  foreach ($items as $it) {
    $tok = sbz_ebz_tokens($it['title']);
    $placed = false;
    foreach ($clusters as &$cl) {
      $sim = sbz_ebz_jaccard($tok, $cl['tokens']);
      if ($sim >= $min_sim) {
        $cl['items'][] = $it;
        // expand tokens a bit
        foreach ($tok as $t => $_) { $cl['tokens'][$t] = 1; }
        $placed = true;
        break;
      }
    }
    if (!$placed) {
      $clusters[] = array('tokens'=>$tok, 'items'=>array($it));
    }
  }

  if (empty($clusters)) { return array(); }

  if ($pick === 'random') {
    $idx = array_rand($clusters);
    return sbz_ebz_cluster_diverse($clusters[$idx]['items']);
  }

  // largest
  usort($clusters, function($a,$b){ return count($b['items']) <=> count($a['items']); });
  return sbz_ebz_cluster_diverse($clusters[0]['items']);
}

/**
 * Keep at most 5 items, prefer different countries/sources.
 */
function sbz_ebz_cluster_diverse($items) {
  $out = array();
  $seen_src = array();
  foreach ($items as $it) {
    $key = ($it['source_country'] ?? '') . '|' . ($it['source_name'] ?? '');
    if (isset($seen_src[$key])) continue;
    $seen_src[$key] = 1;
    $out[] = $it;
    if (count($out) >= 5) break;
  }
  if (count($out) < 3) {
    // pad with earliest from cluster if too few
    foreach ($items as $it) {
      if (count($out) >= 5) break;
      $already = false;
      foreach ($out as $o) { if ($o['guid'] === $it['guid']) { $already = true; break; } }
      if (!$already) $out[] = $it;
    }
  }
  return $out;
}

function sbz_ebz_tokens($text) {
  $text = strtolower($text);
  $text = preg_replace('/[^\p{L}\p{N}\s]+/u', ' ', $text);
  $parts = preg_split('/\s+/', $text, -1, PREG_SPLIT_NO_EMPTY);

  $stop = array('the'=>1,'a'=>1,'an'=>1,'and'=>1,'or'=>1,'but'=>1,'to'=>1,'of'=>1,'in'=>1,'on'=>1,'for'=>1,'with'=>1,'as'=>1,'at'=>1,'by'=>1,'from'=>1,'is'=>1,'are'=>1,'was'=>1,'were'=>1,'be'=>1,'been'=>1,'it'=>1,'this'=>1,'that'=>1,'these'=>1,'those'=>1,'after'=>1,'before'=>1,'over'=>1,'under'=>1,'into'=>1,'about'=>1,'up'=>1,'down'=>1,'new'=>1,'says'=>1,'say'=>1,'said'=>1);
  $tok = array();
  foreach ($parts as $p) {
    if (mb_strlen($p) < 3) continue;
    if (isset($stop[$p])) continue;
    $tok[$p] = 1;
  }
  return $tok;
}

function sbz_ebz_jaccard($a, $b) {
  if (empty($a) || empty($b)) return 0.0;
  $inter = 0;
  foreach ($a as $k => $_) { if (isset($b[$k])) $inter++; }
  $union = count($a) + count($b) - $inter;
  if ($union <= 0) return 0.0;
  return $inter / $union;
}

/**
 * Generate the "End Boss Zombie" lesson post.
 * Output: ['title'=>..., 'content'=>...]
 */
function sbz_ebz_generate_lesson($cluster, $opt) {
  $voice = isset($opt['voice_pack']) ? $opt['voice_pack'] : 'sidekick_endboss';

  $topic = sbz_ebz_topic_from_cluster($cluster);
  $lesson = sbz_ebz_pick_lesson_type($cluster, $opt);

  $title = sbz_ebz_make_long_title($topic, $lesson, $voice);

  $content = sbz_ebz_make_content($cluster, $topic, $lesson, $voice);

  return array('title'=>$title, 'content'=>$content);
}

function sbz_ebz_topic_from_cluster($cluster) {
  if (empty($cluster)) return 'today\'s chaos';
  // choose the newest title and lightly sanitize
  $t = $cluster[0]['title'] ?? 'today\'s chaos';
  // shorten only for topic line; title itself is long anyway
  $t = preg_replace('/\s+/', ' ', trim($t));
  if (mb_strlen($t) > 80) $t = mb_substr($t, 0, 77) . '…';
  return $t;
}

function sbz_ebz_pick_lesson_type($cluster, $opt) {
  $rot = isset($opt['lesson_rotation']) ? (int)$opt['lesson_rotation'] : 0;

  // Keyword heuristics to pick a rhetoric "boss move"
  $all = '';
  foreach ($cluster as $it) { $all .= ' ' . strtolower($it['title'] ?? ''); }

  $map = array(
    'gish_gallop' => array('flood','wave','series of','multiple','dozens','many','countless'),
    'whataboutism' => array('what about','meanwhile','while','instead'),
    'motte_bailey' => array('clarifies','walks back','backtracks','softens'),
    'sealioning' => array('questions','asks','demands','calls for answers'),
    'firehose' => array('claims','alleges','conspiracy','rumor','viral'),
    'false_binary' => array('either','or else','only way'),
    'labeling' => array('traitor','enemy','extremist','radical','parasite'),
    'data_laundering' => array('report','study','numbers','figures','leak','document'),
    'outrage_bait' => array('shocking','outrage','furious','slam','blasts'),
    'fake_balance' => array('both sides','critics say','supporters say'),
    'conspiracy_glue' => array('plot','secret','shadow','deep state','cover-up'),
    'exit_skill' => array('debate','argument','row','spat','online')
  );

  foreach ($map as $k => $needles) {
    foreach ($needles as $n) {
      if (strpos($all, $n) !== false) return $k;
    }
  }

  // rotate through a stable order if no signal
  $order = array('firehose','gish_gallop','whataboutism','motte_bailey','sealioning','false_binary','labeling','data_laundering','fake_balance','conspiracy_glue','outrage_bait','exit_skill');
  return $order[$rot % count($order)];
}

function sbz_ebz_make_long_title($topic, $lesson, $voice) {
  $boss = sbz_ebz_boss_name();
  $move = sbz_ebz_move_name($lesson);

  $hooks = array(
    "🚨 LEVEL 99 ALERT: ",
    "🎮 BOSS ROOM OPENED: ",
    "🧟‍♂️ END-BOSS ENCOUNTER: ",
    "⚠️ RAGE-QUIT PREVENTION GUIDE: ",
    "🕹️ PATCH NOTES FOR YOUR BRAIN: ",
  );

  $underground = sbz_ebz_underground_refs();

  // Make it intentionally long & descriptive for youth
  $title =
    $hooks[array_rand($hooks)] .
    "My Sidekick Handbook for Surviving “{$boss}” While It Spams the {$move} Move — " .
    "Because Today’s Headlines About “{$topic}” Are Basically a Glitchy After‑Midnight Arcade Quest (" .
    $underground[array_rand($underground)] .
    ")";

  return $title;
}

function sbz_ebz_make_content($cluster, $topic, $lesson, $voice) {
  $boss = sbz_ebz_boss_name();
  $move = sbz_ebz_move_name($lesson);
  $how = sbz_ebz_counter_move($lesson);
  $quest = sbz_ebz_mini_quest($lesson);
  $vibes = sbz_ebz_sidekick_lines();

  $html = '';
  $html .= "<p><strong>Sidekick voice on.</strong> We just pushed open the big creaky door and—yep—there it is: <strong>{$boss}</strong>, the End‑Boss Zombie of Rhetoric.</p>";
  $html .= "<p>Today’s arena: <em>{$topic}</em>. The boss isn’t fighting with muscles. It’s fighting with <strong>words</strong>. And its favorite attack right now is: <strong>{$move}</strong>.</p>";

  $html .= "<hr/>";
  $html .= "<h2>🧪 Loot Table: headlines we picked up in the dungeon</h2>";
  $html .= "<ul>";
  foreach ($cluster as $it) {
    $t = esc_html($it['title'] ?? 'Headline');
    $l = esc_url($it['link'] ?? '#');
    $src = esc_html($it['source_name'] ?? 'Source');
    $cty = esc_html($it['source_country'] ?? '');
    $meta = trim($cty ? "{$src} ({$cty})" : $src);
    $html .= "<li><a href=\"{$l}\" target=\"_blank\" rel=\"noopener\">{$t}</a> <em>— {$meta}</em></li>";
  }
  $html .= "</ul>";

  $html .= "<hr/>";
  $html .= "<h2>🧟 Boss Move Spotted: {$move}</h2>";
  $html .= "<p>{$vibes[array_rand($vibes)]}</p>";
  $html .= "<p><strong>What it is:</strong> " . esc_html(sbz_ebz_move_explain_kid($lesson)) . "</p>";

  $html .= "<h3>🛡️ How to Parry (the anti‑zombie combo)</h3>";
  $html .= "<ol>";
  foreach ($how as $step) {
    $html .= "<li>" . esc_html($step) . "</li>";
  }
  $html .= "</ol>";

  $html .= "<h3>🎒 Mini Quest (you do this in 2 minutes)</h3>";
  $html .= "<ul>";
  foreach ($quest as $q) {
    $html .= "<li>" . esc_html($q) . "</li>";
  }
  $html .= "</ul>";

  $html .= "<h3>🧠 XP Bonus: the one sentence rule</h3>";
  $html .= "<blockquote><p><strong>Kill the idea, not the person.</strong> Name the move → do the move → leave if it stays undead.</p></blockquote>";

  $html .= "<p><em>Note:</em> We only show headlines + links from sources, then we teach our own lesson on top. No copying full articles.</p>";

  return $html;
}

function sbz_ebz_boss_name() {
  $names = array(
    'The Patch‑Proof Zombie King',
    'The Algorithmic Grave‑Knight',
    'The Clickbait Necromancer',
    'The Fact‑Dodging Lich',
    'The Drama Wraith (Premium Edition)',
  );
  return $names[array_rand($names)];
}

function sbz_ebz_underground_refs() {
  return array(
    "the secret modded server where everyone speedruns and nobody tells the teachers",
    "that weird indie rhythm game that only exists in screenshots and vibes",
    "a cursed handheld dungeon crawler you found behind the skatepark",
    "a late‑night cartoon you swear only aired once at 02:00",
    "a bootleg comic zine traded like treasure at school",
  );
}

function sbz_ebz_sidekick_lines() {
  return array(
    "Okay okay okay—don’t panic. I’ve read the boss patterns. We’re not getting combo’d today.",
    "That’s the move! See it? It’s trying to make your brain slip on a banana peel made of words.",
    "If this was a boss fight, the health bar would say: ‘CONFUSION’ in glitter letters.",
    "Breathe. Shield up. We’re doing clean hits, not wild button‑mashing.",
    "I’m not saying the boss is cheating… but the boss is definitely cheating.",
  );
}

function sbz_ebz_move_name($lesson) {
  $names = array(
    'firehose' => 'Firehose of Nonsense (Spam Spray)',
    'gish_gallop' => 'Gish Gallop (20 Attacks in 5 Seconds)',
    'whataboutism' => 'Whataboutism (Teleport Away From The Point)',
    'motte_bailey' => 'Motte‑and‑Bailey (Retreat To Safety Castle)',
    'sealioning' => 'Sealioning (Polite Stamina Drain)',
    'false_binary' => 'False Binary (Two Doors, Both Traps)',
    'labeling' => 'Loaded Labels (Sticker Bomb Debuff)',
    'data_laundering' => 'Data Laundering (Numbers With Fake Mustaches)',
    'fake_balance' => 'Fake Balance (Both‑Sides Smoke Screen)',
    'conspiracy_glue' => 'Conspiracy Glue (Everything Is Connected… Somehow)',
    'outrage_bait' => 'Outrage Bait (Rage Meter Fill‑Up)',
    'exit_skill' => 'Arena Lock (Never‑Ending Argument Trap)',
  );
  return $names[$lesson] ?? 'Zombie Move';
}

function sbz_ebz_move_explain_kid($lesson) {
  $ex = array(
    'firehose' => "The boss sprays you with a LOT of claims really fast so you give up checking any of them.",
    'gish_gallop' => "The boss throws 20 arguments at once so you can’t answer them all, then pretends you lost.",
    'whataboutism' => "The boss dodges the question by shouting ‘BUT WHAT ABOUT…’ and changing the topic.",
    'motte_bailey' => "The boss says something extreme, then runs back to a safer softer version when you ask for proof.",
    'sealioning' => "The boss keeps asking ‘just questions’ forever to drain your energy, not to learn.",
    'false_binary' => "The boss says there are only two choices, even when real life has 50 choices.",
    'labeling' => "The boss replaces thinking with name-calling labels so nobody asks ‘what actually happened?’",
    'data_laundering' => "The boss waves numbers or ‘a report’ so it looks official, even if it’s missing the real source.",
    'fake_balance' => "The boss acts like every side has equal evidence even when one side is just vibes and shouting.",
    'conspiracy_glue' => "The boss sticks unrelated things together until it becomes a story that can’t be tested.",
    'outrage_bait' => "The boss tries to make you angry first so your brain stops checking facts.",
    'exit_skill' => "The boss tries to keep you arguing forever because your attention is its food.",
  );
  return $ex[$lesson] ?? "It’s a word-trick that makes your brain trip.";
}

function sbz_ebz_counter_move($lesson) {
  // Steps are intentionally short, kid-readable, action-like.
  $steps = array(
    'firehose' => array(
      "Pick ONE claim from the spray. Only one.",
      "Ask: ‘What’s the original source link?’ (not a screenshot).",
      "Timebox: 3 minutes of checking, then stop.",
      "Say the clean fact out loud once and move on."
    ),
    'gish_gallop' => array(
      "Say: ‘Choose your best 1–2 points. We’ll do those.’",
      "Write the chosen claim in one sentence.",
      "Check evidence for that claim only.",
      "If they add more points, pause the fight: ‘Not until this one is solved.’"
    ),
    'whataboutism' => array(
      "Name it: ‘That’s a topic jump.’",
      "Park it: ‘We’ll come back after we finish the first claim.’",
      "Repeat the original question.",
      "If it keeps jumping, end the conversation."
    ),
    'motte_bailey' => array(
      "Ask: ‘Which exact claim do you stand behind?’",
      "Get it in writing (one sentence).",
      "Don’t chase the softer version if they meant the extreme one.",
      "If they won’t hold still, that’s the tell."
    ),
    'sealioning' => array(
      "Set rules: one question at a time, maximum 3 rounds.",
      "Ask them to provide ONE source first.",
      "If they ignore your answer, stop feeding the seal.",
      "Save your energy for real learners."
    ),
    'false_binary' => array(
      "Add the missing options: ‘There are more than two.’",
      "Ask: ‘What evidence would change your mind?’",
      "Look for a third path (or a spectrum).",
    ),
    'labeling' => array(
      "Translate the label into a concrete action: ‘What did they do?’",
      "Ask for dates, places, and direct quotes.",
      "If it’s only labels, it’s not information."
    ),
    'data_laundering' => array(
      "Trace: who made the numbers, when, and with what method?",
      "Find a second independent source.",
      "Check whether the headline matches the data."
    ),
    'fake_balance' => array(
      "Compare evidence quality, not ‘teams’.",
      "Ask: ‘Which side has documents, data, or direct witnesses?’",
      "If one side is only vibes, say that plainly."
    ),
    'conspiracy_glue' => array(
      "Ask for a testable prediction.",
      "Ask: ‘What would prove this wrong?’",
      "If the answer is ‘nothing’, it’s a story, not a claim."
    ),
    'outrage_bait' => array(
      "Pause 10 seconds. Breathe.",
      "Separate feelings from facts: ‘What do we actually know?’",
      "Check two sources before sharing."
    ),
    'exit_skill' => array(
      "Notice the loop: same point, new volume.",
      "Say: ‘I’m done. Come back with evidence.’",
      "Leave. Attention is your currency."
    ),
  );
  return $steps[$lesson] ?? array("Name the move.", "Ask for the source.", "Don’t chase the chaos.");
}

function sbz_ebz_mini_quest($lesson) {
  return array(
    "Find the first headline link above. Ask: ‘What’s the claim in ONE sentence?’",
    "Open a second link from a different country. Ask: ‘What’s the same and what’s different?’",
    "Circle any label-words (traitor, disaster, slam, etc.). Replace them with plain verbs (did/said/wrote).",
  );
}
