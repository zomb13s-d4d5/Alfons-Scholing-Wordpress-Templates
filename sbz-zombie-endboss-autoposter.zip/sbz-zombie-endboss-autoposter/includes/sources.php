<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Returns a list of RSS sources. Each source is:
 * [ 'name' => string, 'url' => string, 'country' => string, 'type' => 'psm'|'wire'|'mag'|'eu' ]
 */
function sbz_ebz_get_sources($opt) {
  $mode = isset($opt['sources_mode']) ? $opt['sources_mode'] : 'curated';

  if ($mode === 'custom' && !empty($opt['custom_sources']) && is_array($opt['custom_sources'])) {
    return array_values(array_filter($opt['custom_sources'], function($s){
      return is_array($s) && !empty($s['url']);
    }));
  }

  if ($mode === 'opml' && !empty($opt['opml_url'])) {
    $opml_sources = sbz_ebz_sources_from_opml($opt['opml_url']);
    if (!empty($opml_sources)) { return $opml_sources; }
  }

  // Curated "national-ish" + EU-wide sources with known RSS endpoints.
  // IMPORTANT: We only republish headline+link, not the original article text.
  return array(
    array('name'=>'BBC News (UK) - World', 'url'=>'http://newsrss.bbc.co.uk/rss/newsonline_uk_edition/world/rss.xml', 'country'=>'UK', 'type'=>'psm'),
    array('name'=>'BBC News (UK) - UK Politics', 'url'=>'http://newsrss.bbc.co.uk/rss/newsonline_uk_edition/uk_politics/rss.xml', 'country'=>'UK', 'type'=>'psm'),
    array('name'=>'France 24 (FR) - Europe', 'url'=>'https://www.france24.com/en/europe/rss', 'country'=>'FR', 'type'=>'psm'),
    array('name'=>'France 24 (FR) - International', 'url'=>'https://www.france24.com/en/rss', 'country'=>'FR', 'type'=>'psm'),
    array('name'=>'Deutsche Welle (DE) - All', 'url'=>'https://rss.dw.com/rdf/rss-en-all', 'country'=>'DE', 'type'=>'psm'),
    array('name'=>'Deutsche Welle (DE) - World', 'url'=>'https://rss.dw.com/rdf/rss-en-world', 'country'=>'DE', 'type'=>'psm'),
    array('name'=>'Euronews - World News (MRSS)', 'url'=>'https://www.euronews.com/rss?format=mrss&level=theme&name=news', 'country'=>'EU', 'type'=>'eu'),
    array('name'=>'NOS (NL) - Algemeen', 'url'=>'http://feeds.nos.nl/nosnieuwsalgemeen', 'country'=>'NL', 'type'=>'psm'),
    array('name'=>'ORF (AT) - News', 'url'=>'https://rss.orf.at/news.xml', 'country'=>'AT', 'type'=>'psm'),
    array('name'=>'SRF (CH) - Das Neueste', 'url'=>'https://www.srf.ch/news/bnf/rss/19032223', 'country'=>'CH', 'type'=>'psm'),
    array('name'=>'RTVE (ES) - Noticias', 'url'=>'https://www.rtve.es/rss/temas_noticias.xml', 'country'=>'ES', 'type'=>'psm'),
        array('name'=>'NRK (NO) - Siste', 'url'=>'https://www.nrk.no/nyheter/siste.rss', 'country'=>'NO', 'type'=>'psm'),
    array('name'=>'YLE (FI) - Tuoreimmat', 'url'=>'https://yle.fi/rss/uutiset/tuoreimmat', 'country'=>'FI', 'type'=>'psm'),
    array('name'=>'Eurotopics - Debates (press review)', 'url'=>'https://www.eurotopics.net/en/149399/rss', 'country'=>'EU', 'type'=>'eu'),
  );
}

/**
 * Fetch items from RSS list using WP's SimplePie.
 * Returns normalized items: [title, link, date, source_name, source_country, guid]
 */
function sbz_ebz_fetch_items($sources, $max_items_per_feed = 12, $max_feeds = 80) {
  if (!function_exists('fetch_feed')) {
    require_once ABSPATH . WPINC . '/feed.php';
  }

  $out = array();
  $sources = array_slice($sources, 0, max(1, (int)$max_feeds));

  foreach ($sources as $s) {
    $url = isset($s['url']) ? esc_url_raw($s['url']) : '';
    if (!$url) continue;

    $feed = fetch_feed($url);
    if (is_wp_error($feed)) { continue; }

    $feed->set_item_limit((int)$max_items_per_feed);
    $items = $feed->get_items(0, (int)$max_items_per_feed);
    foreach ($items as $item) {
      $title = wp_strip_all_tags($item->get_title());
      $link = esc_url_raw($item->get_link());
      $date = $item->get_date('U');
      $guid = $item->get_id();
      if (!$guid) { $guid = sha1($url . '|' . $title . '|' . $link); }

      // IMPORTANT: Do not republish full descriptions from many PSM feeds (terms vary).
      $out[] = array(
        'title' => $title,
        'link' => $link,
        'date' => $date ? (int)$date : 0,
        'guid' => $guid,
        'source_name' => isset($s['name']) ? sanitize_text_field($s['name']) : 'Source',
        'source_country' => isset($s['country']) ? sanitize_text_field($s['country']) : '',
        'source_type' => isset($s['type']) ? sanitize_text_field($s['type']) : '',
      );
    }
  }

  // Sort newest first
  usort($out, function($a,$b){ return ($b['date'] ?? 0) <=> ($a['date'] ?? 0); });
  return $out;
}

/**
 * OPML import (basic). Accepts OPML URL, returns sources.
 * We keep it simple: parse <outline xmlUrl="..."> and use title/text.
 */
function sbz_ebz_sources_from_opml($opml_url) {
  $opml_url = esc_url_raw($opml_url);
  if (!$opml_url) return array();

  $resp = wp_remote_get($opml_url, array('timeout'=>15));
  if (is_wp_error($resp)) return array();
  $body = wp_remote_retrieve_body($resp);
  if (!$body) return array();

  $doc = new DOMDocument();
  libxml_use_internal_errors(true);
  if (!$doc->loadXML($body)) { return array(); }

  $nodes = $doc->getElementsByTagName('outline');
  $sources = array();
  foreach ($nodes as $node) {
    $xmlUrl = $node->getAttribute('xmlUrl');
    if (!$xmlUrl) continue;
    $title = $node->getAttribute('title');
    if (!$title) $title = $node->getAttribute('text');
    if (!$title) $title = 'OPML Source';
    $sources[] = array('name'=> $title, 'url'=>$xmlUrl, 'country'=>'', 'type'=>'opml');
  }

  // de-dupe
  $seen = array();
  $clean = array();
  foreach ($sources as $s) {
    $u = $s['url'];
    if (isset($seen[$u])) continue;
    $seen[$u] = 1;
    $clean[] = $s;
  }
  return $clean;
}
