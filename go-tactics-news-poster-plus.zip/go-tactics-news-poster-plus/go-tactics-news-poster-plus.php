<?php
/*
Plugin Name: Go Tactics News Poster Plus
Description: Auto-posts Go (Baduk/Weiqi) tactic content from RSS feeds. Categorizes by tactic (Tesuji, Life & Death, Joseki, Fuseki, Yose, Shape) and tags posts with Playing Color, Game Phase, and Skill Level. Based on the Chess Tactics News Poster Plus structure.
Version: 1.0.0
Author: NotYouAgain.ai Studio
License: GPL2+
*/

if (!defined('ABSPATH')) { exit; }

class Go_Tactics_News_Poster_Plus {

    const OPTION_POSTED = 'go_tactics_posted_links_plus';
    const CRON_HOOK     = 'go_tactics_news_poster_plus_event';
    const BOT_USERNAME  = 'GoNewsBotPlus';
    const BOT_DISPLAY   = 'Go News Bot Plus';
    const BOT_EMAIL     = 'go-news-bot@example.com';

    private $feed_urls = array(
        // Per request: use the same sources as the original plugin by default.
        // These can be filtered via 'go_tactics_feed_urls' to customize.
        'https://www.euronews.com/rss?format=mrss',
        'https://feeds.bbci.co.uk/news/rss.xml',
        'https://www.reuters.com/rssFeed/worldNews',
        'https://rss.nytimes.com/services/xml/rss/nyt/World.xml',
        'https://www.aljazeera.com/xml/rss/all.xml'
    );

    private $tactic_mapping = array(
        'tesuji' => array('tesuji'),
        'life-and-death' => array('life and death','life-and-death','tsumego','kill group','make two eyes','two eyes'),
        'joseki' => array('joseki','corner sequence'),
        'fuseki' => array('fuseki','opening strategy','whole-board opening','opening framework'),
        'yose' => array('yose','endgame','end-game'),
        'shape' => array('shape','good shape','bad shape','katachi')
    );

    private $tactic_descriptions = array(
        'tesuji' => 'Tesuji — a skillful tactical move that achieves the best local result. Finding a tesuji often requires reading a few moves ahead and spotting the vital point.',
        'life-and-death' => 'Life & Death (Tsumego) — determine whether a group of stones can live (form two eyes) or will be captured. Practicing tsumego sharpens reading skills.',
        'joseki' => 'Joseki — established corner sequences in the opening that lead to a balanced result for both sides when played correctly.',
        'fuseki' => 'Fuseki — whole-board opening strategy: developing frameworks, staking out corners, and balancing influence and territory.',
        'yose' => 'Yose — the endgame in Go: precise plays that maximize points by closing borders, reducing, and sente/gote trades.',
        'shape' => 'Shape — efficient stone arrangement. Good shape improves connectivity and efficiency; exploiting bad shape creates weaknesses to attack.'
    );

    private $closings = array(
        'Even the strongest pros started with simple tsumego — keep practicing!',
        'One sharp tesuji can change the whole board. Stay alert.',
        'Good shape, strong connections, and steady reading win games.',
        'Fuseki sets the stage; yose seals the win. Play the whole board.',
        'Read carefully: when in doubt, look for the vital point.'
    );

    public function __construct() {
        add_action('init', array($this, 'register_taxonomies'));
        add_action('plugins_loaded', array($this, 'maybe_init_storage'));
        add_filter('cron_schedules', array($this, 'add_fifteen_minute_schedule'));
        add_action(self::CRON_HOOK, array($this, 'cron_run'));
        add_action('admin_init', array($this, 'maybe_schedule_event'));
        // Allow filters to customize feeds and mappings
        $this->feed_urls = apply_filters('go_tactics_feed_urls', $this->feed_urls);
        $this->tactic_mapping = apply_filters('go_tactics_tactic_mapping', $this->tactic_mapping);
    }

    public static function activate() {
        $self = new self();
        $self->ensure_bot_user();
        $self->register_taxonomies();
        $self->ensure_terms_and_categories();
        $self->maybe_init_storage();
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + 60, 'fifteen_minutes', self::CRON_HOOK);
        }
    }

    public static function deactivate() {
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }
    }

    public function add_fifteen_minute_schedule($schedules) {
        if (!isset($schedules['fifteen_minutes'])) {
            $schedules['fifteen_minutes'] = array(
                'interval' => 15 * 60,
                'display'  => __('Every 15 Minutes', 'go-tactics-news-poster-plus')
            );
        }
        return $schedules;
    }

    public function maybe_schedule_event() {
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + 60, 'fifteen_minutes', self::CRON_HOOK);
        }
    }

    private function ensure_bot_user() {
        if (username_exists(self::BOT_USERNAME)) { return; }
        $user_id = wp_create_user(self::BOT_USERNAME, wp_generate_password(16), self::BOT_EMAIL);
        if (!is_wp_error($user_id)) {
            wp_update_user(array(
                'ID' => $user_id,
                'display_name' => self::BOT_DISPLAY,
                'role' => 'author'
            ));
        }
    }

    public function maybe_init_storage() {
        if (false === get_option(self::OPTION_POSTED)) {
            add_option(self::OPTION_POSTED, array(), '', 'no');
        }
    }

    public function register_taxonomies() {
        // Playing Color
        register_taxonomy('go_color', 'post', array(
            'labels' => array('name' => 'Playing Color', 'singular_name' => 'Playing Color'),
            'public' => true, 'show_ui' => true, 'show_in_rest' => true, 'hierarchical' => false
        ));
        // Game Phase
        register_taxonomy('go_phase', 'post', array(
            'labels' => array('name' => 'Game Phase', 'singular_name' => 'Game Phase'),
            'public' => true, 'show_ui' => true, 'show_in_rest' => true, 'hierarchical' => false
        ));
        // Skill Level
        register_taxonomy('go_skill', 'post', array(
            'labels' => array('name' => 'Skill Level', 'singular_name' => 'Skill Level'),
            'public' => true, 'show_ui' => true, 'show_in_rest' => true, 'hierarchical' => false
        ));
    }

    private function ensure_terms_and_categories() {
        // Ensure tactic categories exist
        foreach ($this->tactic_mapping as $slug => $keywords) {
            if (!term_exists($slug, 'category')) {
                wp_insert_term(ucwords(str_replace(array('-', '_'), ' ', $slug)), 'category', array('slug' => $slug));
            }
        }
        // Ensure color terms
        $colors = array('Black','White');
        foreach ($colors as $c) {
            if (!term_exists($c, 'go_color')) { wp_insert_term($c, 'go_color'); }
        }
        // Ensure phase terms
        $phases = array('Opening','Middle Game','Endgame');
        foreach ($phases as $p) {
            if (!term_exists($p, 'go_phase')) { wp_insert_term($p, 'go_phase'); }
        }
        // Ensure skill terms
        $skills = array('Beginner','Intermediate','Advanced','Professional');
        foreach ($skills as $s) {
            if (!term_exists($s, 'go_skill')) { wp_insert_term($s, 'go_skill'); }
        }
    }

    public function cron_run() {
        if (!function_exists('fetch_feed')) { require_once ABSPATH . WPINC . '/feed.php'; }
        $posted = get_option(self::OPTION_POSTED, array());
        $posted = is_array($posted) ? $posted : array();

        foreach ($this->feed_urls as $url) {
            $feed = fetch_feed($url);
            if (is_wp_error($feed)) { continue; }

            $maxitems = $feed->get_item_quantity(5);
            $items = $feed->get_items(0, $maxitems);
            foreach ($items as $item) {
                $link = esc_url_raw($item->get_link());
                if (!$link || in_array($link, $posted, true)) { continue; }

                $title = $item->get_title();
                $content = $item->get_content();
                $desc = $item->get_description();
                $blob = strtolower(wp_strip_all_tags($title . ' ' . $desc . ' ' . $content));

                list($best_slug, $score) = $this->detect_tactic($blob);

                $postarr = $this->build_post($item, $best_slug);
                $post_id = wp_insert_post($postarr);
                if (!is_wp_error($post_id)) {
                    $this->attach_featured_image_random($post_id);
                    // Taxonomies
                    $phase = $this->infer_phase($best_slug);
                    $color = (rand(0,1) === 0) ? 'Black' : 'White';
                    $skill = $this->infer_skill($best_slug);

                    if ($best_slug) { wp_set_post_terms($post_id, array($best_slug), 'category', false); }
                    wp_set_post_terms($post_id, array($phase), 'go_phase', false);
                    wp_set_post_terms($post_id, array($color), 'go_color', false);
                    wp_set_post_terms($post_id, array($skill), 'go_skill', false);

                    $posted[] = $link;
                    update_option(self::OPTION_POSTED, array_slice(array_unique($posted), -1000));
                    return; // Post only one item per run
                }
            }
        }
    }

    private function detect_tactic($text) {
        $best_slug = '';
        $best_score = 0;
        foreach ($this->tactic_mapping as $slug => $keywords) {
            $score = 0;
            foreach ($keywords as $kw) {
                // word boundary-ish search
                if (preg_match('/\b' . preg_quote(strtolower($kw), '/') . '\b/', $text)) {
                    $score++;
                }
            }
            if ($score > $best_score) {
                $best_score = $score;
                $best_slug = $slug;
            }
        }
        return array($best_slug, $best_score);
    }

    private function build_post($item, $tactic_slug) {
        $author_id = $this->get_bot_user_id();
        $title = sanitize_text_field($item->get_title());
        $link  = esc_url_raw($item->get_link());
        $desc  = wp_strip_all_tags($item->get_description());
        $content = wp_strip_all_tags($item->get_content());
        $text = trim($desc) ? $desc : $content;
        $snippet = $this->truncate_words($text, 80);

        $source_p = '<p><a href="' . esc_url($link) . '" target="_blank" rel="nofollow noopener">Read the full article at the source</a>.</p>';

        $ex = '';
        if (!empty($tactic_slug) && isset($this->tactic_descriptions[$tactic_slug])) {
            $ex = '<p><strong>About this tactic:</strong> ' . esc_html($this->tactic_descriptions[$tactic_slug]) . '</p>';
        }

        $closing = '<p><em>' . esc_html($this->closings[array_rand($this->closings)]) . '</em></p>';

        $post_content = '<p>' . esc_html($snippet) . '...</p>' . $source_p . $ex . $closing;

        $post_status = 'publish';

        $postarr = array(
            'post_title'   => $this->decorate_title_with_tactic($title, $tactic_slug),
            'post_content' => $post_content,
            'post_status'  => $post_status,
            'post_author'  => $author_id,
            'post_category'=> array() // set later
        );
        return $postarr;
    }

    private function decorate_title_with_tactic($title, $slug) {
        if (empty($slug)) { return $title; }
        $pretty = ucwords(str_replace(array('-', '_'), ' ', $slug));
        return '[' . $pretty . '] ' . $title;
    }

    private function infer_phase($slug) {
        if ($slug === 'joseki' || $slug === 'fuseki') return 'Opening';
        if ($slug === 'yose') return 'Endgame';
        return 'Middle Game';
    }

    private function infer_skill($slug) {
        switch ($slug) {
            case 'life-and-death': return 'Beginner';
            case 'shape': return 'Intermediate';
            case 'tesuji': return 'Intermediate';
            case 'joseki': return 'Advanced';
            case 'fuseki': return 'Advanced';
            case 'yose': return 'Advanced';
            default: return array('Beginner','Intermediate','Advanced','Professional')[rand(0,3)];
        }
    }

    private function attach_featured_image_random($post_id) {
        $q = new WP_Query(array(
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => 1,
            'orderby' => 'rand',
            'post_mime_type' => 'image'
        ));
        if ($q->have_posts()) {
            $img = $q->posts[0]->ID;
            if (function_exists('set_post_thumbnail')) {
                set_post_thumbnail($post_id, $img);
            }
        }
        wp_reset_postdata();
    }

    private function truncate_words($text, $limit) {
        $words = preg_split('/\s+/', trim($text));
        if (count($words) <= $limit) return trim($text);
        return implode(' ', array_slice($words, 0, $limit));
    }

    private function get_bot_user_id() {
        $user = get_user_by('login', self::BOT_USERNAME);
        if ($user) return $user->ID;
        $this->ensure_bot_user();
        $user = get_user_by('login', self::BOT_USERNAME);
        return $user ? $user->ID : get_current_user_id();
    }
}

register_activation_hook(__FILE__, array('Go_Tactics_News_Poster_Plus', 'activate'));
register_deactivation_hook(__FILE__, array('Go_Tactics_News_Poster_Plus', 'deactivate'));

new Go_Tactics_News_Poster_Plus();
