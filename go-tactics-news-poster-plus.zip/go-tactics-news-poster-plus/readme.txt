=== Go Tactics News Poster Plus ===
Contributors: notyouagain.ai
Tags: go, baduk, weiqi, tactics, auto-post, rss, cron
Requires at least: 5.2
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Automatically scans RSS feeds and posts Go tactics content categorized by tactic with metadata for Playing Color, Game Phase, and Skill Level.

== Description ==
- Detects Go tactics keywords in feed items (Tesuji, Life & Death/Tsumego, Joseki, Fuseki, Yose, Shape).
- Auto-categorizes posts and adds taxonomies for Playing Color, Game Phase, and Skill Level.
- Adds intro snippet, source attribution, tactic explanation, and a Go-themed closing remark.
- Runs via WP-Cron every 15 minutes (filterable).

== Installation ==
1. Upload the ZIP via Plugins → Add New → Upload Plugin.
2. Activate the plugin. Categories and taxonomies are created; a bot author is created if needed.
3. The plugin will begin posting when matching items appear in feeds.

== Filters ==
- `go_tactics_feed_urls` to adjust RSS sources.
- `go_tactics_tactic_mapping` to extend keywords.

== Notes ==
This plugin defaults to general news feeds (as requested to use same sources).
For best results, filter the feed list to Go-centric sources.
