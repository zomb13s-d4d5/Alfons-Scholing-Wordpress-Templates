<?php get_header(); ?>
<main class="sbz-section">
  <div class="sbz-wrap">
    <?php $archive_object = get_queried_object(); $archive_image = sbz_clay_archive_context_image($archive_object); ?>
    <article class="sbz-entry sbz-archive-entry" style="margin-bottom:28px">
      <div class="sbz-featured"><img src="<?php echo esc_url($archive_image); ?>" alt=""></div>
      <p class="sbz-kicker"><?php echo esc_html(is_category() ? __('Category', 'sbz-clay') : __('Archive', 'sbz-clay')); ?></p>
      <h1><?php the_archive_title(); ?></h1>
      <div class="sbz-entry-content"><?php the_archive_description(); ?></div>
    </article>
    <div class="sbz-article-grid">
      <?php $card_index = 0; if (have_posts()) : while (have_posts()) : the_post(); ?>
        <a class="sbz-card" href="<?php the_permalink(); ?>">
          <div class="sbz-thumb"><?php if (has_post_thumbnail()) { the_post_thumbnail('sbz-card'); } else { ?><img src="<?php echo esc_url(sbz_clay_fallback_article_image($card_index, get_the_ID(), is_category() ? single_cat_title('', false) : '')); ?>" alt=""><?php } ?></div>
          <div class="sbz-card-body"><div class="sbz-kicker"><?php $c=get_the_category(); echo esc_html($c ? $c[0]->name : __('Story','sbz-clay')); ?></div><h3><?php the_title(); ?></h3><div class="sbz-meta"><?php echo esc_html(get_the_date()); ?> · <?php echo esc_html(sbz_clay_reading_time()); ?></div></div>
        </a>
      <?php $card_index++; endwhile; else : ?><p><?php esc_html_e('No posts found.', 'sbz-clay'); ?></p><?php endif; ?>
    </div>
    <?php the_posts_pagination(array('mid_size'=>1, 'prev_text'=>'‹', 'next_text'=>'›', 'class'=>'sbz-pagination')); ?>
  </div>
</main>
<?php get_footer(); ?>
