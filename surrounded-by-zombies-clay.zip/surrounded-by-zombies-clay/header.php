<?php if (!defined('ABSPATH')) { exit; } ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="sbz-browser">
<header class="sbz-site-header">
  <div class="sbz-wrap sbz-header-inner">
    <a class="sbz-brand" href="<?php echo esc_url(home_url('/')); ?>" rel="home" aria-label="<?php bloginfo('name'); ?>">
      <span class="sbz-home-button" aria-hidden="true"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/home-button-logo.png'); ?>" alt=""></span>
      <span class="sbz-brand-text">Surrounded<strong>by Zombies</strong></span>
    </a>
    <button class="sbz-menu-toggle" aria-expanded="false" aria-controls="primary-menu"><?php esc_html_e('Menu', 'sbz-clay'); ?></button>
    <?php
      if (has_nav_menu('primary')) {
        wp_nav_menu(array(
          'theme_location'=>'primary',
          'container'=>false,
          'menu_class'=>'sbz-main-nav',
          'menu_id'=>'primary-menu',
          'fallback_cb'=>'sbz_clay_nav_fallback',
          'depth'=>1,
        ));
      } else {
        sbz_clay_nav_fallback();
      }
    ?>
  </div>
</header>
