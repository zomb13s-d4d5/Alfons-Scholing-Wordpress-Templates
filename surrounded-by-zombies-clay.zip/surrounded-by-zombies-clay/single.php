<?php get_header(); ?>
<main class="sbz-section">
  <div class="sbz-wrap sbz-content-layout">
    <section>
      <?php while (have_posts()) : the_post(); ?>
      <article <?php post_class('sbz-entry'); ?>>
        <?php if (has_post_thumbnail()) : ?><div class="sbz-featured"><?php the_post_thumbnail('sbz-hero'); ?></div><?php endif; ?>
        <p class="sbz-kicker"><?php $c=get_the_category(); echo esc_html($c ? $c[0]->name : __('Story','sbz-clay')); ?></p>
        <h1><?php the_title(); ?></h1>
        <p class="sbz-meta"><?php echo esc_html(get_the_date()); ?> · <?php echo esc_html(sbz_clay_reading_time()); ?></p>
        <div class="sbz-entry-content"><?php the_content(); ?></div>
        <?php wp_link_pages(); ?>
      </article>
      <?php if (comments_open() || get_comments_number()) { comments_template(); } ?>
      <?php endwhile; ?>
    </section>
    <?php get_sidebar(); ?>
  </div>
</main>
<?php get_footer(); ?>
