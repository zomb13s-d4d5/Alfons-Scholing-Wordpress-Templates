<?php get_header(); ?>
<main class="sbz-section">
  <div class="sbz-wrap sbz-content-layout">
    <section class="sbz-post-list">
      <article class="sbz-entry">
        <h1><?php printf(esc_html__('Search: %s', 'sbz-clay'), esc_html(get_search_query())); ?></h1>
        <?php get_search_form(); ?>
      </article>
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <article <?php post_class('sbz-entry'); ?>>
          <?php if (has_post_thumbnail()) : ?><a class="sbz-featured" href="<?php the_permalink(); ?>"><?php the_post_thumbnail('sbz-hero'); ?></a><?php endif; ?>
          <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
          <p class="sbz-meta"><?php echo esc_html(get_the_date()); ?> · <?php echo esc_html(sbz_clay_reading_time()); ?></p>
          <div class="sbz-entry-content"><?php the_excerpt(); ?></div>
        </article>
      <?php endwhile; the_posts_pagination(array('mid_size'=>1, 'prev_text'=>'‹', 'next_text'=>'›', 'class'=>'sbz-pagination')); else : ?>
        <article class="sbz-entry"><p><?php esc_html_e('No results found.', 'sbz-clay'); ?></p></article>
      <?php endif; ?>
    </section>
    <?php get_sidebar(); ?>
  </div>
</main>
<?php get_footer(); ?>
