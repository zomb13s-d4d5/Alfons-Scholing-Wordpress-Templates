<?php get_header(); ?>
<main class="sbz-section">
  <div class="sbz-wrap">
    <?php while (have_posts()) : the_post(); ?>
      <article <?php post_class('sbz-entry'); ?>>
        <div class="sbz-featured"><?php if (has_post_thumbnail()) { the_post_thumbnail('sbz-hero'); } else { ?><img src="<?php echo esc_url(sbz_clay_default_hero_image()); ?>" alt=""><?php } ?></div>
        <p class="sbz-kicker"><?php esc_html_e('Page', 'sbz-clay'); ?></p>
        <h1><?php the_title(); ?></h1>
        <div class="sbz-entry-content"><?php the_content(); ?></div>
      </article>
      <?php if (comments_open() || get_comments_number()) { comments_template(); } ?>
    <?php endwhile; ?>
  </div>
</main>
<?php get_footer(); ?>
