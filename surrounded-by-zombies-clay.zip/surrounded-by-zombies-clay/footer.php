<?php if (!defined('ABSPATH')) { exit; } ?>
<footer class="sbz-footer">
  <div class="sbz-wrap">
    <div class="sbz-footer-grid">
      <section>
        <h2>Surrounded<br><span style="color:var(--sbz-lime)">by Zombies</span></h2>
        <p><?php esc_html_e('Smart entertainment for a kinder, braver world.', 'sbz-clay'); ?></p>
      </section>
      <section id="dr-zombie">
        <h3><?php esc_html_e('Stay in the lab', 'sbz-clay'); ?></h3>
        <p><?php esc_html_e('Get fresh stories, experiments and ideas straight to your inbox.', 'sbz-clay'); ?></p>
        <form class="sbz-subscribe" action="#" method="post">
          <label class="screen-reader-text" for="sbz-email"><?php esc_html_e('Email address', 'sbz-clay'); ?></label>
          <input id="sbz-email" type="email" placeholder="<?php esc_attr_e('Your email address', 'sbz-clay'); ?>">
          <button type="submit"><?php esc_html_e('Subscribe', 'sbz-clay'); ?></button>
        </form>
      </section>
      <section>
        <h3><?php esc_html_e('Connect', 'sbz-clay'); ?></h3>
        <div class="sbz-social" aria-label="Social links">
          <a href="#" aria-label="Mastodon">∞</a><a href="#" aria-label="X">X</a><a href="#" aria-label="YouTube">▶</a><a href="#" aria-label="Instagram">◎</a>
        </div>
        <?php if (has_nav_menu('footer')) { wp_nav_menu(array('theme_location'=>'footer','container'=>false,'menu_class'=>'sbz-footer-menu','depth'=>1)); } ?>
      </section>
    </div>
    <p class="sbz-footer-small">© <?php echo esc_html(date_i18n('Y')); ?> <?php bloginfo('name'); ?>. <?php esc_html_e('All rights reserved.', 'sbz-clay'); ?></p>
  </div>
</footer>
</div>
<?php wp_footer(); ?>
</body>
</html>
