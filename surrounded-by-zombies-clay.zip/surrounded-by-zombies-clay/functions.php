<?php
/**
 * Surrounded by Zombies Clay Lab functions.
 */
if (!defined('ABSPATH')) { exit; }

define('SBZ_CLAY_VERSION', '1.12.0');

function sbz_clay_setup() {
    load_theme_textdomain('sbz-clay', get_template_directory() . '/languages');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('automatic-feed-links');
    add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
    add_theme_support('custom-logo', array('height'=>120,'width'=>320,'flex-height'=>true,'flex-width'=>true));
    add_theme_support('customize-selective-refresh-widgets');
    register_nav_menus(array('primary' => __('Primary Menu', 'sbz-clay'), 'footer' => __('Footer Menu', 'sbz-clay')));
    add_image_size('sbz-card', 820, 462, true);
    add_image_size('sbz-hero', 1600, 900, true);
}
add_action('after_setup_theme', 'sbz_clay_setup');

function sbz_clay_enqueue() {
    wp_enqueue_style('sbz-clay-style', get_stylesheet_uri(), array(), SBZ_CLAY_VERSION);
    wp_enqueue_script('sbz-clay-js', get_template_directory_uri() . '/assets/js/theme.js', array(), SBZ_CLAY_VERSION, true);
    $hero = sbz_clay_default_hero_image();
    $custom_css = ':root{--sbz-hero-image:url("' . esc_url($hero) . '");}';
    wp_add_inline_style('sbz-clay-style', $custom_css);
}
add_action('wp_enqueue_scripts', 'sbz_clay_enqueue');

function sbz_clay_excerpt_length($length) { return 24; }
add_filter('excerpt_length', 'sbz_clay_excerpt_length');
function sbz_clay_excerpt_more($more) { return '…'; }
add_filter('excerpt_more', 'sbz_clay_excerpt_more');

function sbz_clay_customize_register($wp_customize) {
    $wp_customize->add_section('sbz_home', array(
        'title' => __('SBZ Clay Homepage', 'sbz-clay'),
        'priority' => 30,
    ));
    $fields = array(
        'sbz_hero_label' => array('Online lab magazine', 'Hero label'),
        'sbz_hero_title' => array('Surrounded|by Zombies', 'Hero title — use | for line break'),
        'sbz_hero_tagline' => array('Education and Entertainment about toxicity', 'Hero tagline'),
        'sbz_primary_cta_text' => array('Explore stories', 'Primary button text'),
        'sbz_primary_cta_url' => array('#latest', 'Primary button URL'),
        'sbz_secondary_cta_text' => array('Meet Dr. Zombie', 'Secondary button text'),
        'sbz_secondary_cta_url' => array('#dr-zombie', 'Secondary button URL'),
    );
    foreach ($fields as $id => $data) {
        $wp_customize->add_setting($id, array('default' => $data[0], 'sanitize_callback' => 'sanitize_text_field'));
        $wp_customize->add_control($id, array('label' => __($data[1], 'sbz-clay'), 'section' => 'sbz_home', 'type' => 'text'));
    }
    $wp_customize->add_setting('sbz_hero_image', array(
        'default' => get_template_directory_uri() . '/assets/images/dr-zombie-hero-clean.jpg',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'sbz_hero_image', array(
        'label' => __('Hero background image', 'sbz-clay'),
        'section' => 'sbz_home',
    )));
}
add_action('customize_register', 'sbz_clay_customize_register');

function sbz_clay_categories() {
    return array(
        array('title'=>'Ask La Gaffe', 'slug'=>'ask-la-gaffe', 'desc'=>'Advice for tricky problems and toxic situations.', 'icon'=>'☏', 'class'=>'', 'url'=>'/category/ask-la-gaffe/', 'image'=>'category-1.jpg'),
        array('title'=>'Pawn Army', 'slug'=>'pawn-army', 'desc'=>'Mobilising ideas and voices for positive change.', 'icon'=>'★', 'class'=>'army', 'url'=>'/category/pawn-army/', 'image'=>'category-2.jpg'),
        array('title'=>'Mini Mensa', 'slug'=>'mini-mensa', 'desc'=>'Big ideas for curious young minds.', 'icon'=>'☁', 'class'=>'purple', 'url'=>'/category/mini-mensa/', 'image'=>'category-3.jpg'),
        array('title'=>'074KU Programming', 'slug'=>'074ku-programming', 'desc'=>'Coding, AI and creative tech experiments.', 'icon'=>'</>', 'class'=>'teal', 'url'=>'/category/074ku-programming/', 'image'=>'category-4.jpg'),
        array('title'=>'One Snack A Day', 'slug'=>'one-snack-a-day', 'desc'=>'Daily bites of wisdom, fun and wellbeing.', 'icon'=>'●', 'class'=>'orange', 'url'=>'/category/one-snack-a-day/', 'image'=>'category-5.jpg'),
        array('title'=>'Open Democratic Debate', 'slug'=>'open-democratic-debate', 'desc'=>'Civil, open and constructive debate for all.', 'icon'=>'□', 'class'=>'blue', 'url'=>'/category/open-democratic-debate/', 'image'=>'category-6.jpg'),
    );
}

function sbz_clay_category_image_by_term($term) {
    if (empty($term)) {
        return '';
    }

    $term_slug = '';
    $term_name = '';

    if (is_object($term)) {
        $term_slug = isset($term->slug) ? sanitize_title($term->slug) : '';
        $term_name = isset($term->name) ? sanitize_title($term->name) : '';
    } else {
        $term_slug = sanitize_title($term);
        $term_name = $term_slug;
    }

    foreach (sbz_clay_categories() as $category) {
        $config_slug = sanitize_title($category['slug']);
        $config_title = sanitize_title($category['title']);
        if ($term_slug === $config_slug || $term_slug === $config_title || $term_name === $config_slug || $term_name === $config_title) {
            return get_template_directory_uri() . '/assets/images/' . $category['image'];
        }
    }

    return '';
}


function sbz_clay_default_hero_image() {
    return get_theme_mod('sbz_hero_image', get_template_directory_uri() . '/assets/images/dr-zombie-hero-clean.jpg');
}

function sbz_clay_archive_context_image($object = null) {
    if (!$object) {
        $object = get_queried_object();
    }

    if ($object && isset($object->term_id)) {
        $image = sbz_clay_category_image_by_term($object);
        if ($image) {
            return $image;
        }
    }

    return sbz_clay_default_hero_image();
}


function sbz_clay_category_url($category_config) {
    $title = isset($category_config['title']) ? $category_config['title'] : '';
    $slug = isset($category_config['slug']) ? $category_config['slug'] : '';
    $fallback = isset($category_config['url']) ? $category_config['url'] : '/';

    /*
     * First preference: use the exact URL from the Primary Menu.
     * This keeps the homepage category cards synced with whatever the admin
     * configured in Appearance → Menus.
     */
    $locations = get_nav_menu_locations();
    if (isset($locations['primary'])) {
        $menu = wp_get_nav_menu_object($locations['primary']);
        if ($menu) {
            $items = wp_get_nav_menu_items($menu->term_id);
            if (!empty($items) && !is_wp_error($items)) {
                foreach ($items as $item) {
                    $item_title = isset($item->title) ? sanitize_title($item->title) : '';
                    $item_object = isset($item->object) ? sanitize_title($item->object) : '';
                    $item_object_id = isset($item->object_id) ? absint($item->object_id) : 0;

                    if (
                        $item_title === sanitize_title($title) ||
                        $item_title === sanitize_title($slug) ||
                        ($item_object === 'category' && $item_object_id && (
                            sanitize_title(get_cat_name($item_object_id)) === sanitize_title($title) ||
                            sanitize_title(get_cat_name($item_object_id)) === sanitize_title($slug)
                        ))
                    ) {
                        return $item->url;
                    }
                }
            }
        }
    }

    /*
     * Second preference: resolve a real WordPress category by slug or name.
     */
    $term = get_category_by_slug($slug);
    if (!$term && $title) {
        $term = get_term_by('name', $title, 'category');
    }
    if (!$term && $slug) {
        $term = get_term_by('slug', sanitize_title($slug), 'category');
    }
    if ($term && !is_wp_error($term)) {
        return get_category_link($term);
    }

    /*
     * Last fallback: old static path.
     */
    return home_url($fallback);
}


function sbz_clay_fallback_article_image($index = 0, $post_id = 0, $category_hint = '') {
    if ($post_id) {
        $categories = get_the_category($post_id);
        if (!empty($categories) && !is_wp_error($categories)) {
            foreach ($categories as $category) {
                $image = sbz_clay_category_image_by_term($category);
                if ($image) {
                    return $image;
                }
            }
        }
    }

    if (!empty($category_hint)) {
        $image = sbz_clay_category_image_by_term($category_hint);
        if ($image) {
            return $image;
        }
    }

    $images = array('article-fallback-1.jpg','article-fallback-2.jpg','article-fallback-3.jpg');
    $image = $images[absint($index) % count($images)];
    return get_template_directory_uri() . '/assets/images/' . $image;
}

function sbz_clay_nav_fallback() {
    echo '<div class="sbz-main-nav">';
    $items = sbz_clay_categories();
    echo '<a href="' . esc_url(home_url('/')) . '">Home</a>';
    foreach ($items as $item) {
        echo '<a href="' . esc_url(sbz_clay_category_url($item)) . '">' . esc_html($item['title']) . '</a>';
    }
    echo '</div>';
}

function sbz_clay_reading_time() {
    $words = str_word_count(wp_strip_all_tags(get_the_content()));
    $minutes = max(1, ceil($words / 220));
    return sprintf(_n('%s min read', '%s min read', $minutes, 'sbz-clay'), number_format_i18n($minutes));
}
