<?php if (post_password_required()) { return; } ?>
<section id="comments" class="comments-area">
  <?php if (have_comments()) : ?>
    <h2><?php comments_number(__('No lab replies yet', 'sbz-clay'), __('One lab reply', 'sbz-clay'), __('% lab replies', 'sbz-clay')); ?></h2>
    <ol class="comment-list"><?php wp_list_comments(array('style'=>'ol','short_ping'=>true)); ?></ol>
    <?php the_comments_pagination(); ?>
  <?php endif; ?>
  <?php if (comments_open()) { comment_form(); } ?>
</section>
