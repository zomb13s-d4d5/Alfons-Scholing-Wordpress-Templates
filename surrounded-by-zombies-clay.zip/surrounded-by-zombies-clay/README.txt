Surrounded by Zombies Clay Lab — WordPress Theme
Version: 1.0.0

Install:
1. In WordPress admin, go to Appearance > Themes > Add New > Upload Theme.
2. Upload surrounded-by-zombies-clay.zip.
3. Activate the theme.
4. Optional: go to Appearance > Customize > SBZ Clay Homepage to edit hero label, title, tagline, buttons and hero image.
5. Optional: assign a primary menu under Appearance > Menus. If no menu is assigned, the theme uses the built-in SBZ network menu.

Included templates:
- front-page.php
- index.php
- single.php
- page.php
- archive.php
- search.php
- 404.php
- comments.php

Design direction:
British stop-motion clay 3D / Dr. Zombie editorial lab magazine style, with category tiles for Ask La Gaffe, Pawn Army, Mini Mensa, 074KU Programming, One Snack A Day, and Open Democratic Debate.


Version 1.1.0 fixes: clean hero image without duplicated baked-in headline, clay image category cards, real fallback thumbnails for posts without featured images, and improved iPad article grid.
