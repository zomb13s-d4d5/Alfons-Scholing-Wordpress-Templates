(function(){
  const button = document.querySelector('.sbz-menu-toggle');
  const nav = document.querySelector('.sbz-main-nav');
  if(button && nav){
    button.addEventListener('click', function(){
      const open = nav.classList.toggle('is-open');
      button.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }
})();
