<aside class="sbz-sidebar">
  <h2><?php esc_html_e('Dr. Zombie’s lab notes', 'sbz-clay'); ?></h2>
  <p><?php esc_html_e('A curated dispatch on media, debate, code, games and everyday antidotes to toxicity.', 'sbz-clay'); ?></p>
  <h3><?php esc_html_e('Worlds', 'sbz-clay'); ?></h3>
  <ul>
    <?php foreach (sbz_clay_categories() as $cat) : ?>
      <li><a href="<?php echo esc_url(home_url($cat['url'])); ?>"><?php echo esc_html($cat['title']); ?></a></li>
    <?php endforeach; ?>
  </ul>
</aside>
