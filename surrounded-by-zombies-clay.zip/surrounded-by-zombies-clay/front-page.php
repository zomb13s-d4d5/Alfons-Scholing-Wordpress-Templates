<?php get_header(); ?>
<main id="primary">
  <section class="sbz-hero">
    <div class="sbz-wrap">
      <div class="sbz-hero-content">
        <span class="sbz-pill">⚗ <?php echo esc_html(get_theme_mod('sbz_hero_label','Online lab magazine')); ?></span>
        <?php $title = explode('|', get_theme_mod('sbz_hero_title','Surrounded|by Zombies')); ?>
        <h1><?php echo esc_html($title[0] ?? 'Surrounded'); ?> <em><?php echo esc_html($title[1] ?? 'by Zombies'); ?></em></h1>
        <p><?php echo esc_html(get_theme_mod('sbz_hero_tagline','Education and Entertainment about toxicity')); ?></p>
        <div class="sbz-actions">
          <a class="sbz-button sbz-button-primary" href="<?php echo esc_url(get_theme_mod('sbz_primary_cta_url','#latest')); ?>"><?php echo esc_html(get_theme_mod('sbz_primary_cta_text','Explore stories')); ?> →</a>
          <a class="sbz-button sbz-button-light" href="<?php echo esc_url(get_theme_mod('sbz_secondary_cta_url','#dr-zombie')); ?>"><?php echo esc_html(get_theme_mod('sbz_secondary_cta_text','Meet Dr. Zombie')); ?> ●</a>
        </div>
      </div>
    </div>
  </section>

  <section class="sbz-wrap" aria-label="Content worlds">
    <div class="sbz-category-grid">
      <?php foreach (sbz_clay_categories() as $cat) : ?>
        <a class="sbz-category-card" href="<?php echo esc_url(sbz_clay_category_url($cat)); ?>">
          <span class="sbz-category-media" aria-hidden="true"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/' . $cat['image']); ?>" alt=""></span>
          <span class="sbz-category-copy"><h3><?php echo esc_html($cat['title']); ?></h3><p><?php echo esc_html($cat['desc']); ?></p></span>
          <span class="sbz-badge <?php echo esc_attr($cat['class']); ?>"><?php echo esc_html($cat['icon']); ?></span>
        </a>
      <?php endforeach; ?>
    </div>
  </section>

  <section id="latest" class="sbz-section">
    <div class="sbz-wrap">
      <div class="sbz-section-title">
        <h2><?php esc_html_e('Latest articles', 'sbz-clay'); ?></h2>
        <a class="sbz-view-all" href="<?php echo esc_url(get_permalink(get_option('page_for_posts')) ?: home_url('/blog/')); ?>"><?php esc_html_e('View all articles', 'sbz-clay'); ?> ›</a>
      </div>
      <div class="sbz-article-grid">
      <?php
        $latest = new WP_Query(array('posts_per_page'=>6, 'ignore_sticky_posts'=>true));
        $card_index = 0;
        if ($latest->have_posts()) : while ($latest->have_posts()) : $latest->the_post(); ?>
          <a class="sbz-card" href="<?php the_permalink(); ?>">
            <div class="sbz-thumb"><?php if (has_post_thumbnail()) { the_post_thumbnail('sbz-card'); } else { ?><img src="<?php echo esc_url(sbz_clay_fallback_article_image($card_index, get_the_ID())); ?>" alt=""><?php } ?></div>
            <div class="sbz-card-body">
              <div class="sbz-kicker"><?php $c=get_the_category(); echo esc_html($c ? $c[0]->name : __('Story','sbz-clay')); ?></div>
              <h3><?php the_title(); ?></h3>
              <div class="sbz-meta"><?php echo esc_html(get_the_date()); ?> · <?php echo esc_html(sbz_clay_reading_time()); ?></div>
            </div>
          </a>
        <?php $card_index++; endwhile; wp_reset_postdata(); else :
          $fallbacks = array(
            array('Ask La Gaffe','How to ask for help before things get toxic'),
            array('Pawn Army','Small moves that can change the whole board'),
            array('Mini Mensa','Big ideas for curious young minds'),
            array('074KU Programming','Teaching AI to be helpful, not harmful'),
            array('One Snack A Day','Mindful snacks for a less toxic day'),
            array('Open Democratic Debate','Why civil debate is our strongest defence'),
          );
          foreach ($fallbacks as $loop_index => $fallback) : ?>
            <article class="sbz-card"><div class="sbz-thumb"><img src="<?php echo esc_url(sbz_clay_fallback_article_image($loop_index ?? 0, 0, $fallback[0])); ?>" alt=""></div><div class="sbz-card-body"><div class="sbz-kicker"><?php echo esc_html($fallback[0]); ?></div><h3><?php echo esc_html($fallback[1]); ?></h3><div class="sbz-meta"><?php esc_html_e('Draft sample', 'sbz-clay'); ?></div></div></article>
          <?php endforeach; endif; ?>
      </div>
    </div>
  </section>
</main>
<?php get_footer(); ?>
