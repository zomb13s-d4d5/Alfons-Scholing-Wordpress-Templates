<?php get_header(); ?>
<main class="sbz-section"><div class="sbz-wrap"><article class="sbz-entry"><h1><?php esc_html_e('Lost in the zombie alley', 'sbz-clay'); ?></h1><p><?php esc_html_e('This page wandered off. Try the menu or search the lab.', 'sbz-clay'); ?></p><?php get_search_form(); ?></article></div></main>
<?php get_footer(); ?>
