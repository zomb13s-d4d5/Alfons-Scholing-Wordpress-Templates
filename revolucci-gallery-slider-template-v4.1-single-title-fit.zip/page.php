<?php get_header(); ?>
<?php while (have_posts()): the_post(); ?>
  <main class="content-shell">
    <h1 class="archive-title"><?php the_title(); ?></h1>
    <div class="entry-content"><?php the_content(); ?></div>
  </main>
<?php endwhile; ?>
<?php get_footer(); ?>
