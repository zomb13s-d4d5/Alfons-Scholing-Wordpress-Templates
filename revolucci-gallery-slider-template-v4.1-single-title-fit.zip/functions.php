<?php
if (!defined('ABSPATH')) { exit; }

function revolucci_slider_setup() {
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
  add_theme_support('responsive-embeds');
  register_nav_menus(array('primary' => __('Primary Menu', 'revolucci-slider')));
}
add_action('after_setup_theme', 'revolucci_slider_setup');

function revolucci_slider_assets() {
  wp_enqueue_style('revolucci-google-fonts', 'https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible:wght@400;700&family=IBM+Plex+Mono:wght@500;700&family=Oswald:wght@500;600;700&display=swap', array(), null);
  wp_enqueue_style('revolucci-slider-style', get_stylesheet_uri(), array('revolucci-google-fonts'), wp_get_theme()->get('Version'));
  wp_enqueue_script('revolucci-slider-js', get_template_directory_uri() . '/assets/js/slider.js', array(), wp_get_theme()->get('Version'), true);
  wp_enqueue_script('revolucci-lightbox-js', get_template_directory_uri() . '/assets/js/lightbox.js', array(), wp_get_theme()->get('Version'), true);
}
add_action('wp_enqueue_scripts', 'revolucci_slider_assets');

function revolucci_img($file) {
  return get_template_directory_uri() . '/assets/img/' . $file;
}

function revolucci_category_definitions() {
  return array(
    'commercial' => array(
      'title' => 'Commercial Art',
      'slug' => 'commercial-art',
      'match' => array('commercial', 'branding', 'campaign'),
      'image' => 'revolucci-commercial-art-banner.webp',
      'thumb' => 'revolucci-commercial-art-banner.webp',
      'desc' => 'Brand strategy, visual language, layout, campaigns, editorial systems, and commercial studio work.'
    ),
    'pinups' => array(
      'title' => 'Erotic Pin-Ups',
      'slug' => 'erotic-pin-ups',
      'match' => array('pin', 'pinup', 'pin-up', 'erotic'),
      'image' => 'revolucci-pinups-banner.webp',
      'thumb' => 'revolucci-pinups-banner.webp',
      'desc' => 'Character studies, portrait work, figure studies, and ethical AI visual experiments presented with clarity and respect.'
    ),
    'lyrics' => array(
      'title' => 'Lyrics & Stories',
      'slug' => 'lyrics-stories',
      'match' => array('lyric', 'lyrics', 'story', 'stories'),
      'image' => 'revolucci-lyrics-stories-banner.webp',
      'thumb' => 'revolucci-lyrics-stories-banner.webp',
      'desc' => 'Lyrics, stories, scene notes, visual culture, cinema fragments, and narrative communication.'
    ),
    'poetry' => array(
      'title' => 'Street Poetry',
      'slug' => 'street-poetry',
      'match' => array('street', 'poetry', 'poem', 'spoken'),
      'image' => 'revolucci-street-poetry-banner.webp',
      'thumb' => 'revolucci-street-poetry-banner.webp',
      'desc' => 'Spoken word, rhythm, city-level observations, stage voice, and direct cultural communication.'
    ),
  );
}

function revolucci_find_category_for_definition($definition) {
  $categories = get_categories(array('hide_empty' => false));
  foreach ($categories as $cat) {
    $haystack = strtolower($cat->name . ' ' . $cat->slug);
    foreach ($definition['match'] as $match) {
      if (strpos($haystack, strtolower($match)) !== false) { return $cat; }
    }
  }
  return null;
}

function revolucci_defined_category_slides() {
  $slides = array();
  foreach (revolucci_category_definitions() as $key => $definition) {
    $cat = revolucci_find_category_for_definition($definition);
    $term_id = $cat ? (int) $cat->term_id : 0;
    $desc = $cat ? trim(wp_strip_all_tags(category_description($term_id))) : '';
    $slides[] = (object) array(
      'key' => $key,
      'term_id' => $term_id,
      'name' => $cat ? $cat->name : $definition['title'],
      'slug' => $cat ? $cat->slug : $definition['slug'],
      'description' => $desc ? $desc : $definition['desc'],
      'url' => $cat ? get_category_link($term_id) : home_url('/category/' . $definition['slug'] . '/'),
      'image' => revolucci_img($definition['image']),
    );
  }
  return $slides;
}

function revolucci_home_categories_ordered() {
  $slides = revolucci_defined_category_slides();
  $seen = array();
  foreach ($slides as $slide) {
    if ($slide->term_id) { $seen[] = (int) $slide->term_id; }
  }
  $extras = get_categories(array('hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC'));
  foreach ($extras as $cat) {
    if (!in_array((int) $cat->term_id, $seen, true)) { $slides[] = $cat; }
  }
  return $slides;
}

function revolucci_main_hero_url() {
  $custom = get_theme_mod('revolucci_main_hero_url');
  return esc_url($custom ? $custom : revolucci_img('revolucci-main-hero-banner.webp'));
}

function revolucci_ink_stripe_url() {
  return revolucci_img('revolucci-ink-stripe.webp');
}

function revolucci_asset_images() {
  return array(
    revolucci_img('revolucci-commercial-art-banner.webp'),
    revolucci_img('revolucci-pinups-banner.webp'),
    revolucci_img('revolucci-lyrics-stories-banner.webp'),
    revolucci_img('revolucci-street-poetry-banner.webp'),
    revolucci_img('revolucci-main-hero-banner.webp'),
  );
}

function revolucci_category_image_url($term_id, $index = 0) {
  $custom = $term_id ? get_term_meta($term_id, 'revolucci_category_image_url', true) : '';
  if ($custom) { return esc_url($custom); }

  $name = $term_id ? strtolower(get_term_field('name', $term_id)) : '';
  $slug = $term_id ? strtolower(get_term_field('slug', $term_id)) : '';
  $key = $name . ' ' . $slug;

  if (strpos($key, 'commercial') !== false) { return esc_url(revolucci_img('revolucci-commercial-art-banner.webp')); }
  if (strpos($key, 'pin') !== false || strpos($key, 'erotic') !== false) { return esc_url(revolucci_img('revolucci-pinups-banner.webp')); }
  if (strpos($key, 'lyric') !== false || strpos($key, 'story') !== false) { return esc_url(revolucci_img('revolucci-lyrics-stories-banner.webp')); }
  if (strpos($key, 'greeting') !== false || strpos($key, 'main') !== false || strpos($key, 'home') !== false) { return esc_url(revolucci_img('revolucci-main-hero-banner.webp')); }
  if (strpos($key, 'poetry') !== false || strpos($key, 'street') !== false) { return esc_url(revolucci_img('revolucci-street-poetry-banner.webp')); }

  $images = revolucci_asset_images();
  return esc_url($images[$index % count($images)]);
}

function revolucci_category_field($term = null) {
  $value = $term ? get_term_meta($term->term_id, 'revolucci_category_image_url', true) : '';
  ?>
  <tr class="form-field term-group-wrap">
    <th scope="row"><label for="revolucci_category_image_url"><?php esc_html_e('Revolucci category image URL', 'revolucci-slider'); ?></label></th>
    <td>
      <input type="url" id="revolucci_category_image_url" name="revolucci_category_image_url" value="<?php echo esc_attr($value); ?>" style="width:100%;" />
      <p class="description"><?php esc_html_e('Paste a Media Library image URL. If empty, the theme maps known Revolucci categories to the supplied hero/category artwork.', 'revolucci-slider'); ?></p>
    </td>
  </tr>
  <?php
}
add_action('category_add_form_fields', 'revolucci_category_field');
add_action('category_edit_form_fields', 'revolucci_category_field');

function revolucci_save_category_field($term_id) {
  if (isset($_POST['revolucci_category_image_url'])) {
    update_term_meta($term_id, 'revolucci_category_image_url', esc_url_raw($_POST['revolucci_category_image_url']));
  }
}
add_action('created_category', 'revolucci_save_category_field');
add_action('edited_category', 'revolucci_save_category_field');

function revolucci_first_content_image_url($post_id) {
  $thumb = get_the_post_thumbnail_url($post_id, 'large');
  if ($thumb) { return esc_url($thumb); }
  $content = get_post_field('post_content', $post_id);
  if (preg_match('/<img[^>]+src=["\']([^"\']+)["\']/i', $content, $matches)) {
    return esc_url($matches[1]);
  }
  $cats = get_the_category($post_id);
  if ($cats) { return revolucci_category_image_url($cats[0]->term_id, 0); }
  return esc_url(revolucci_main_hero_url());
}


function revolucci_post_gallery_image_urls($post_id, $limit = 48) {
  $urls = array();
  $add = function($url) use (&$urls, $limit) {
    $url = trim((string) $url);
    if (!$url || count($urls) >= $limit) { return; }
    $url = html_entity_decode($url, ENT_QUOTES);
    if (!in_array($url, $urls, true)) { $urls[] = esc_url($url); }
  };

  $content = get_post_field('post_content', $post_id);

  /*
   * v3.9 explicit-gallery guard:
   * A normal image placed in the article text must remain a text image.
   * It should NOT be promoted into the single article gallery rail.
   * Only real WordPress galleries are harvested here:
   * - classic [gallery ids="..."] shortcodes
   * - block editor wp:gallery blocks containing wp:image IDs or image tags
   */
  if (preg_match_all('/\[gallery[^\]]*ids=["\']([^"\']+)["\'][^\]]*\]/i', $content, $shortcodes)) {
    foreach ($shortcodes[1] as $ids_csv) {
      foreach (preg_split('/\s*,\s*/', $ids_csv) as $id) {
        $src = wp_get_attachment_image_url((int) $id, 'full');
        if ($src) { $add($src); }
      }
    }
  }

  if (preg_match_all('/<!--\s+wp:gallery\b.*?-->(.*?)<!--\s+\/wp:gallery\s+-->/is', $content, $blocks)) {
    foreach ($blocks[1] as $block_html) {
      if (preg_match_all('/wp-image-([0-9]+)/i', $block_html, $ids)) {
        foreach (array_unique($ids[1]) as $id) {
          $src = wp_get_attachment_image_url((int) $id, 'full');
          if ($src) { $add($src); }
        }
      }
      if (preg_match_all('/<img[^>]+(?:data-large-file|data-full-url|src)=["\']([^"\']+)["\'][^>]*>/i', $block_html, $matches)) {
        foreach ($matches[1] as $src) { $add($src); }
      }
    }
  }

  return array_slice($urls, 0, $limit);
}

function revolucci_category_gallery_urls($term_id, $fallback_index = 0, $limit = 4) {
  $urls = array();
  if ($term_id) {
    $q = new WP_Query(array(
      'cat' => $term_id,
      'posts_per_page' => 8,
      'post_status' => 'publish',
      'ignore_sticky_posts' => true,
    ));
    if ($q->have_posts()) {
      while ($q->have_posts() && count($urls) < $limit) {
        $q->the_post();
        foreach (revolucci_post_gallery_image_urls(get_the_ID(), 8) as $img) {
          if (!in_array($img, $urls, true)) { $urls[] = $img; }
          if (count($urls) >= $limit) { break; }
        }
      }
      wp_reset_postdata();
    }
  }
  if (!count($urls)) { $urls[] = revolucci_category_image_url($term_id, $fallback_index); }
  while (count($urls) < $limit) {
    $urls[] = revolucci_category_image_url($term_id, $fallback_index + count($urls));
  }
  return array_slice($urls, 0, $limit);
}

function revolucci_excerpt($length = 24) {
  return wp_trim_words(get_the_excerpt(), $length, '...');
}
