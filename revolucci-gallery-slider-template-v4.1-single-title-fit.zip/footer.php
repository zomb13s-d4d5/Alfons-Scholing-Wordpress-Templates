  <footer class="site-footer-poster" aria-label="<?php esc_attr_e('Revolucci footer', 'revolucci-slider'); ?>">
    <div class="footer-ink-stripe" aria-hidden="true"></div>
    <div class="footer-poster-inner">
      <div class="footer-motto"><strong>Story.</strong><span>We start with meaning.</span></div>
      <div class="footer-motto"><strong>Vision.</strong><span>We see what others miss.</span></div>
      <div class="footer-motto"><strong>Impact.</strong><span>We create what lasts.</span></div>
      <div class="footer-brand"><strong>REVOLUCCI.ART</strong><span>Built by hand. Backed by purpose.</span></div>
    </div>
  </footer>
  <?php wp_footer(); ?>
</body>
</html>
