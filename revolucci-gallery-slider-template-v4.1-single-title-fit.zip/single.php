<?php get_header(); ?>
<?php while (have_posts()): the_post();
  $gallery = revolucci_post_gallery_image_urls(get_the_ID(), 80);
  $title_text = wp_strip_all_tags(get_the_title());
  $title_length = function_exists('mb_strlen') ? mb_strlen($title_text) : strlen($title_text);
  $title_word_count = str_word_count($title_text);
  $title_class = 'poster-title-box';
  if ($title_length > 92 || $title_word_count > 13) {
    $title_class .= ' is-title-very-long';
  } elseif ($title_length > 58 || $title_word_count > 8) {
    $title_class .= ' is-title-long';
  }

  /*
   * v3.9 inline-image/gallery guard:
   * Do not use the first inline content image as the article hero, because that
   * makes a post with one uploaded/inserted image appear as two images: once in
   * the layout/gallery area and once again inside the text content.
   * Hero now prefers the real Featured Image, then category fallback, then main hero.
   */
  $featured_hero = get_the_post_thumbnail_url(get_the_ID(), 'full');
  $cats = get_the_category(get_the_ID());
  $fallback_hero = $cats ? revolucci_category_image_url($cats[0]->term_id, 0) : revolucci_main_hero_url();
  $hero = $featured_hero ? $featured_hero : $fallback_hero;

  /* Only create a separate gallery rail when the editor inserted a real gallery with more than one image. */
  $show_gallery = count($gallery) > 1;
?>
  <article <?php post_class('single-gallery-first single-viewport-story'); ?>>
    <div class="single-top-viewport">
    <header class="single-article-board revolucci-panel revolucci-panel--hero" style="background-image:url('<?php echo esc_url($hero); ?>')">
      <div class="single-board-copy">
        <span class="poster-kicker"><?php echo esc_html(get_the_date()); ?></span>
        <h1 class="<?php echo esc_attr($title_class); ?>"><?php echo esc_html($title_text); ?></h1>
      </div>
      <nav class="single-post-neighbours" aria-label="<?php esc_attr_e('Article navigation', 'revolucci-slider'); ?>">
        <?php $prev_post = get_previous_post(true); $next_post = get_next_post(true); ?>
        <?php if ($prev_post): ?>
          <a class="prev-post-link" href="<?php echo esc_url(get_permalink($prev_post)); ?>">‹ <span><?php echo esc_html(get_the_title($prev_post)); ?></span></a>
        <?php else: ?>
          <a class="prev-post-link is-disabled" href="#" aria-disabled="true">‹ <span><?php esc_html_e('Previous article', 'revolucci-slider'); ?></span></a>
        <?php endif; ?>
        <?php if ($next_post): ?>
          <a class="next-post-link" href="<?php echo esc_url(get_permalink($next_post)); ?>"><span><?php echo esc_html(get_the_title($next_post)); ?></span> ›</a>
        <?php else: ?>
          <a class="next-post-link is-disabled" href="#" aria-disabled="true"><span><?php esc_html_e('Next article', 'revolucci-slider'); ?></span> ›</a>
        <?php endif; ?>
      </nav>
    </header>

    <?php if ($show_gallery): ?>
      <section class="single-gallery-slider-section" aria-label="<?php esc_attr_e('Artwork gallery slider', 'revolucci-slider'); ?>">
        <div class="single-gallery-topline">
          <span><?php esc_html_e('Image gallery', 'revolucci-slider'); ?></span>
          <strong><?php echo esc_html(count($gallery)); ?> <?php esc_html_e('images', 'revolucci-slider'); ?></strong>
          <div class="single-gallery-controls">
            <button class="nav-button" type="button" data-gallery-prev aria-label="<?php esc_attr_e('Previous image', 'revolucci-slider'); ?>">‹</button>
            <button class="nav-button" type="button" data-gallery-next aria-label="<?php esc_attr_e('Next image', 'revolucci-slider'); ?>">›</button>
          </div>
        </div>
        <div class="single-gallery-rail" data-single-gallery tabindex="0">
          <?php foreach ($gallery as $i => $img): ?>
            <figure class="single-gallery-slide revolucci-panel revolucci-panel--gallery" data-gallery-slide="<?php echo esc_attr($i); ?>">
              <img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr(get_the_title() . ' artwork ' . ($i + 1)); ?>" loading="<?php echo $i < 3 ? 'eager' : 'lazy'; ?>">
            </figure>
          <?php endforeach; ?>
        </div>
        <div class="single-gallery-dots" aria-hidden="false">
          <?php foreach ($gallery as $i => $img): if ($i >= 14) { break; } ?>
            <button class="gallery-dot<?php echo $i === 0 ? ' is-active' : ''; ?>" type="button" data-gallery-dot="<?php echo esc_attr($i); ?>" aria-label="<?php echo esc_attr__('Open image ', 'revolucci-slider') . esc_attr($i + 1); ?>"></button>
          <?php endforeach; ?>
        </div>
      </section>
    <?php endif; ?>
    </div>

    <section class="text-second-panel" aria-label="<?php esc_attr_e('Text, poetry, and notes', 'revolucci-slider'); ?>">
      <div class="text-second-header">
        <span><?php esc_html_e('Text / poetry / notes', 'revolucci-slider'); ?></span>
        <p><?php esc_html_e('Scroll for the written part. Inline article images stay inside the text. Inline images stay visible here. Only real gallery blocks become the gallery slider above.', 'revolucci-slider'); ?></p>
      </div>
      <div class="entry-content">
        <?php the_content(); ?>
      </div>
    </section>

    <?php if (comments_open() || get_comments_number()): comments_template(); endif; ?>
  </article>
<?php endwhile; ?>
<?php get_footer(); ?>
