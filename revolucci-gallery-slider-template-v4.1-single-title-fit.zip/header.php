<!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header site-header-poster">
  <div class="site-branding site-branding-poster">
    <a class="brand-logo" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php esc_attr_e('Revolucci home', 'revolucci-slider'); ?>">
      <img src="<?php echo esc_url(revolucci_img('revolucci-main-hero.jpeg')); ?>" alt="" aria-hidden="true">
      <span class="brand-copy">
        <span class="brand-title-box">REVOLUCCI.ART</span>
        <span class="brand-subtitle">Caribbean x Dutch street studio aesthetics · Story · Vision · Impact</span>
      </span>
    </a>
  </div>
  <nav class="site-nav" aria-label="<?php esc_attr_e('Primary menu', 'revolucci-slider'); ?>">
    <?php wp_nav_menu(array('theme_location'=>'primary','container'=>false,'fallback_cb'=>'revolucci_fallback_menu')); ?>
  </nav>
  <div class="site-action"><a class="ink-button" href="<?php echo esc_url(home_url('/about/')); ?>">About</a></div>
</header>
<?php
function revolucci_fallback_menu(){
  echo '<ul><li><a href="' . esc_url(home_url('/')) . '">Home</a></li><li><a href="' . esc_url(home_url('/category/commercial-art/')) . '">Commercial Art</a></li><li><a href="' . esc_url(home_url('/category/erotic-pin-ups/')) . '">Pinups</a></li><li><a href="' . esc_url(home_url('/about/')) . '">About</a></li></ul>';
}
?>
