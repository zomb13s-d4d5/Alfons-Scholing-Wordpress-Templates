<?php get_header(); ?>
<?php
$archive_title = is_category() ? single_cat_title('', false) : get_the_archive_title();
$hero_url = '';
$desc = '';
if (is_category()) {
  $term = get_queried_object();
  if ($term && !is_wp_error($term)) {
    $hero_url = revolucci_category_image_url($term->term_id, 0);
    $desc = trim(wp_strip_all_tags(category_description($term->term_id)));
  }
}
if (!$hero_url) { $hero_url = revolucci_main_hero_url(); }
?>
<main class="archive-viewport-board" aria-label="<?php echo esc_attr($archive_title); ?>">
  <header class="archive-hero revolucci-panel revolucci-panel--hero" style="background-image:url('<?php echo esc_url($hero_url); ?>')">
    <div class="archive-hero-copy">
      <h1 class="archive-title"><?php echo esc_html($archive_title); ?></h1>
      <?php if ($desc): ?><p class="archive-hero-desc"><?php echo esc_html($desc); ?></p><?php endif; ?>
    </div>
  </header>
  <section class="content-shell archive-card-shell" id="latest" aria-label="<?php esc_attr_e('Category articles', 'revolucci-slider'); ?>">
    <div class="stage-header">
      <div class="stage-title"><?php esc_html_e('Explore articles', 'revolucci-slider'); ?></div>
      <span class="stage-count"><?php echo esc_html($GLOBALS['wp_query']->found_posts); ?> <?php esc_html_e('posts', 'revolucci-slider'); ?></span>
      <div class="stage-line" aria-hidden="true"></div>
      <div class="slider-controls">
        <button class="nav-button" type="button" data-archive-prev aria-label="<?php esc_attr_e('Previous articles', 'revolucci-slider'); ?>">‹</button>
        <button class="nav-button" type="button" data-archive-next aria-label="<?php esc_attr_e('Next articles', 'revolucci-slider'); ?>">›</button>
      </div>
    </div>
    <div class="archive-grid" data-archive-rail tabindex="0">
      <?php if (have_posts()): while (have_posts()): the_post(); ?>
        <?php $post_gallery = revolucci_post_gallery_image_urls(get_the_ID(), 4); if (!count($post_gallery)) { $post_gallery = array(revolucci_first_content_image_url(get_the_ID())); } ?>
        <a class="post-card revolucci-panel revolucci-panel--article" href="<?php the_permalink(); ?>">
          <?php $post_card_img = count($post_gallery) ? $post_gallery[0] : revolucci_first_content_image_url(get_the_ID()); ?>
          <span class="post-card-gallery panel-media" aria-hidden="true" style="background-image:url('<?php echo esc_url($post_card_img); ?>')">
            <img class="post-card-image" src="<?php echo esc_url($post_card_img); ?>" alt="" loading="lazy">
          </span>
          <span class="post-card-copy">
            <h2><?php the_title(); ?></h2>
            <p><?php echo esc_html(revolucci_excerpt(18)); ?></p>
          </span>
        </a>
      <?php endwhile; else: ?>
        <p><?php esc_html_e('No work found yet.', 'revolucci-slider'); ?></p>
      <?php endif; ?>
    </div>
    <div class="archive-dots" aria-label="<?php esc_attr_e('Article slider position', 'revolucci-slider'); ?>">
      <?php $dot_count = min(12, max(1, (int) $GLOBALS['wp_query']->post_count)); for ($dot_i = 0; $dot_i < $dot_count; $dot_i++): ?>
        <button class="archive-dot<?php echo $dot_i === 0 ? ' is-active' : ''; ?>" type="button" data-archive-dot="<?php echo esc_attr($dot_i); ?>" aria-label="<?php echo esc_attr__('Open article position ', 'revolucci-slider') . esc_attr($dot_i + 1); ?>"></button>
      <?php endfor; ?>
    </div>
  </section>
</main>
<?php get_footer(); ?>
