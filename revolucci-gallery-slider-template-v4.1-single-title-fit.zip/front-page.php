<?php get_header();
$hero_slides = revolucci_defined_category_slides();
$cats = revolucci_home_categories_ordered();
if (!$cats) {
  $cats = $hero_slides;
}
?>
<main class="home-shell" aria-label="<?php esc_attr_e('Revolucci homepage', 'revolucci-slider'); ?>">
  <section class="hero-revolucci hero-category-slider" aria-label="<?php esc_attr_e('Featured Revolucci categories', 'revolucci-slider'); ?>">
    <div class="hero-slides" data-hero-slider>
      <?php foreach ($hero_slides as $i => $slide): ?>
        <a class="hero-slide<?php echo $i === 0 ? ' is-active' : ''; ?>" href="<?php echo esc_url($slide->url); ?>" data-hero-slide="<?php echo esc_attr($i); ?>" style="background-image:url('<?php echo esc_url($slide->image); ?>')">
          <span class="hero-slide-shade" aria-hidden="true"></span>
          <span class="hero-slide-copy">
            <span class="hero-kicker">Revolucci Art</span>
            <span class="hero-title hero-slide-title"><?php echo esc_html($slide->name); ?></span>
            <span class="hero-sub"><?php echo esc_html(wp_trim_words($slide->description, 22, '...')); ?></span>
            <span class="button-ink">Open category →</span>
          </span>
        </a>
      <?php endforeach; ?>
    </div>
    <div class="hero-slider-controls" aria-label="<?php esc_attr_e('Hero slider controls', 'revolucci-slider'); ?>">
      <button class="nav-button hero-nav" type="button" data-hero-prev aria-label="<?php esc_attr_e('Previous hero category', 'revolucci-slider'); ?>">‹</button>
      <div class="hero-dots">
        <?php foreach ($hero_slides as $i => $slide): ?>
          <button class="hero-dot<?php echo $i === 0 ? ' is-active' : ''; ?>" type="button" data-hero-dot="<?php echo esc_attr($i); ?>" aria-label="<?php echo esc_attr($slide->name); ?>"></button>
        <?php endforeach; ?>
      </div>
      <button class="nav-button hero-nav" type="button" data-hero-next aria-label="<?php esc_attr_e('Next hero category', 'revolucci-slider'); ?>">›</button>
    </div>
  </section>

  <section id="categories" class="category-stage">
    <div class="stage-header">
      <div class="stage-title">Explore categories</div>
      <div class="stage-line" aria-hidden="true"></div>
      <div class="slider-controls">
        <button class="nav-button" type="button" data-prev aria-label="Previous category">‹</button>
        <button class="nav-button" type="button" data-next aria-label="Next category">›</button>
      </div>
    </div>
    <div class="category-rail" id="revolucciSlider" tabindex="0">
      <?php foreach ($cats as $i => $cat):
        $term_id = isset($cat->term_id) ? (int) $cat->term_id : 0;
        $url = isset($cat->url) ? $cat->url : ($term_id ? get_category_link($term_id) : home_url('/'));
        $img = isset($cat->image) ? $cat->image : revolucci_category_image_url($term_id, $i);
        $gallery = array($img);
        $desc = '';
        if ($term_id) { $desc = trim(wp_strip_all_tags(category_description($term_id))); }
        if (!$desc && isset($cat->description)) { $desc = $cat->description; }
        if (!$desc) { $desc = 'Story, vision, impact — ideas shape worlds.'; }
      ?>
        <a class="category-card revolucci-panel revolucci-panel--category" href="<?php echo esc_url($url); ?>" data-slide="<?php echo esc_attr($i); ?>">
          <span class="category-card-gallery panel-media" aria-hidden="true" style="background-image:url('<?php echo esc_url($img); ?>')">
            <img class="category-card-img" src="<?php echo esc_url($img); ?>" alt="" loading="<?php echo $i < 4 ? 'eager' : 'lazy'; ?>">
          </span>
          <span class="category-card-copy">
            <h2><?php echo esc_html($cat->name); ?></h2>
            <p><?php echo esc_html(wp_trim_words($desc, 18, '...')); ?></p>
            <span class="card-arrow">→</span>
          </span>
        </a>
      <?php endforeach; ?>
    </div>
    <div class="slider-dots">
      <?php foreach ($cats as $i => $cat): ?>
        <button class="dot<?php echo $i === 0 ? ' is-active' : ''; ?>" type="button" data-dot="<?php echo esc_attr($i); ?>" aria-label="<?php echo esc_attr($cat->name); ?>"></button>
      <?php endforeach; ?>
    </div>
  </section>
</main>
<?php get_footer(); ?>
