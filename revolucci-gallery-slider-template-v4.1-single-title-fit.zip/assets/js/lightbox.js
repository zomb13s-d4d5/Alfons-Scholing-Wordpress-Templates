(function(){
  'use strict';
  const selectors = '.single-gallery-slide img, .revolucci-gallery-lead img, .entry-content img, .wp-block-gallery img, .gallery img, .entry-content p, .entry-content blockquote, .entry-content pre, .entry-content li';
  let items = [];
  let index = 0;
  let lb, inner;

  function setup(){
    items = Array.from(document.querySelectorAll(selectors)).filter(el=>{
      const text = (el.innerText || el.alt || '').trim();
      return el.tagName === 'IMG' || text.length > 20;
    });
    if (!items.length) return;
    lb = document.createElement('div');
    lb.className = 'revolucci-lightbox';
    lb.innerHTML = '<button class="revolucci-lightbox-close" aria-label="Close">×</button><button class="revolucci-lightbox-prev" aria-label="Previous">‹</button><div class="revolucci-lightbox-inner"></div><button class="revolucci-lightbox-next" aria-label="Next">›</button>';
    document.body.appendChild(lb);
    inner = lb.querySelector('.revolucci-lightbox-inner');
    lb.querySelector('.revolucci-lightbox-close').addEventListener('click', close);
    lb.querySelector('.revolucci-lightbox-prev').addEventListener('click', ()=>show(index-1));
    lb.querySelector('.revolucci-lightbox-next').addEventListener('click', ()=>show(index+1));
    lb.addEventListener('click', e=>{ if (e.target === lb) close(); });
    items.forEach((el,i)=>{ el.setAttribute('tabindex','0'); el.addEventListener('click', ()=>open(i)); el.addEventListener('keydown', e=>{ if(e.key==='Enter'){ open(i); }}); });
    window.addEventListener('keydown', keys);
  }
  function open(i){ show(i); lb.classList.add('is-open'); document.documentElement.classList.add('revolucci-lightbox-open'); }
  function close(){ if(!lb) return; lb.classList.remove('is-open'); document.documentElement.classList.remove('revolucci-lightbox-open'); }
  function show(i){ if(!items.length) return; index = (i + items.length) % items.length; const el = items[index]; inner.innerHTML=''; if (el.tagName === 'IMG'){ const img = document.createElement('img'); img.src = el.currentSrc || el.src; img.alt = el.alt || ''; inner.appendChild(img); } else { const div = document.createElement('div'); div.className='revolucci-lightbox-text'; div.innerHTML = el.innerHTML; inner.appendChild(div); } }
  function keys(e){ if(!document.documentElement.classList.contains('revolucci-lightbox-open')) return; if(e.key==='Escape') close(); if(e.key==='ArrowRight'||e.key==='ArrowDown'){ e.preventDefault(); show(index+1); } if(e.key==='ArrowLeft'||e.key==='ArrowUp'){ e.preventDefault(); show(index-1); } }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', setup); else setup();
})();
