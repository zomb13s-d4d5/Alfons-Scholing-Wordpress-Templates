(function(){
  'use strict';
  const track = document.getElementById('revolucciSlider');
  if (!track) return;
  const slides = Array.from(track.querySelectorAll('.category-card'));
  const dots = Array.from(document.querySelectorAll('[data-dot]'));
  const prev = document.querySelector('[data-prev]');
  const next = document.querySelector('[data-next]');
  if (!slides.length) return;

  let active = 0;
  let ticking = false;
  let wheelLocked = false;
  let wheelTimer = null;
  let wheelAccumulator = 0;

  function lightboxIsOpen(){ return document.documentElement.classList.contains('revolucci-lightbox-open'); }
  function isEditableTarget(target){ return !!(target && target.closest('input, textarea, select, [contenteditable="true"]')); }
  function updateDots(){ dots.forEach((d,i)=>{ d.classList.toggle('is-active', i === active); d.setAttribute('aria-current', i === active ? 'true' : 'false'); }); }
  function go(index){ active = Math.max(0, Math.min(slides.length - 1, index)); track.scrollTo({left:slides[active].offsetLeft, behavior:'smooth'}); updateDots(); }
  function nearestSlide(){ const center = track.scrollLeft + track.clientWidth / 2; let best = 0, dist = Infinity; slides.forEach((slide,i)=>{ const d = Math.abs((slide.offsetLeft + slide.offsetWidth / 2) - center); if (d < dist){dist=d;best=i;} }); active=best; updateDots(); }
  function releaseWheelLock(){ clearTimeout(wheelTimer); wheelTimer = setTimeout(()=>{ wheelLocked=false; wheelAccumulator=0; }, 360); }

  dots.forEach(d=>d.addEventListener('click', ()=>go(Number(d.dataset.dot))));
  if (prev) prev.addEventListener('click', ()=>go(active - 1));
  if (next) next.addEventListener('click', ()=>go(active + 1));

  window.addEventListener('keydown', function(e){
    if (lightboxIsOpen() || isEditableTarget(e.target)) return;
    if (['ArrowRight','ArrowDown'].includes(e.key)){ e.preventDefault(); go(active + 1); }
    if (['ArrowLeft','ArrowUp'].includes(e.key)){ e.preventDefault(); go(active - 1); }
    if (e.key === 'Home'){ e.preventDefault(); go(0); }
    if (e.key === 'End'){ e.preventDefault(); go(slides.length - 1); }
  });

  track.addEventListener('wheel', function(e){
    if (lightboxIsOpen()) return;
    const horizontalIntent = Math.abs(e.deltaX) > Math.abs(e.deltaY);
    const delta = horizontalIntent ? e.deltaX : e.deltaY;
    if (Math.abs(delta) < 3) return;
    e.preventDefault();
    wheelAccumulator += delta;
    if (wheelLocked || Math.abs(wheelAccumulator) < 28){ releaseWheelLock(); return; }
    wheelLocked = true;
    go(active + (wheelAccumulator > 0 ? 1 : -1));
    releaseWheelLock();
  }, {passive:false});

  track.addEventListener('scroll', function(){
    if (ticking) return;
    requestAnimationFrame(()=>{ nearestSlide(); ticking=false; });
    ticking=true;
  }, {passive:true});

  window.addEventListener('resize', ()=>go(active), {passive:true});
  updateDots();
})();

(function(){
  'use strict';
  const wrap = document.querySelector('[data-hero-slider]');
  if (!wrap) return;
  const slides = Array.from(wrap.querySelectorAll('[data-hero-slide]'));
  const dots = Array.from(document.querySelectorAll('[data-hero-dot]'));
  const prev = document.querySelector('[data-hero-prev]');
  const next = document.querySelector('[data-hero-next]');
  if (!slides.length) return;

  let active = Math.max(0, slides.findIndex(s => s.classList.contains('is-active')));
  let timer = null;
  let paused = false;
  const interval = 6200;

  function set(index){
    active = (index + slides.length) % slides.length;
    slides.forEach((slide, i) => slide.classList.toggle('is-active', i === active));
    dots.forEach((dot, i) => {
      dot.classList.toggle('is-active', i === active);
      dot.setAttribute('aria-current', i === active ? 'true' : 'false');
    });
  }
  function stop(){ if (timer) { clearInterval(timer); timer = null; } }
  function start(){
    stop();
    if (slides.length < 2 || paused) return;
    timer = setInterval(() => set(active + 1), interval);
  }
  function restart(){ stop(); start(); }

  dots.forEach(dot => dot.addEventListener('click', function(e){ e.preventDefault(); set(Number(dot.dataset.heroDot)); restart(); }));
  if (prev) prev.addEventListener('click', function(e){ e.preventDefault(); set(active - 1); restart(); });
  if (next) next.addEventListener('click', function(e){ e.preventDefault(); set(active + 1); restart(); });

  wrap.addEventListener('mouseenter', () => { paused = true; stop(); });
  wrap.addEventListener('mouseleave', () => { paused = false; start(); });
  wrap.addEventListener('focusin', () => { paused = true; stop(); });
  wrap.addEventListener('focusout', () => { paused = false; start(); });
  document.addEventListener('visibilitychange', () => { document.hidden ? stop() : start(); });

  set(active);
  start();
})();

(function(){
  'use strict';
  const track = document.querySelector('[data-single-gallery]');
  if (!track) return;
  const slides = Array.from(track.querySelectorAll('[data-gallery-slide]'));
  const dots = Array.from(document.querySelectorAll('[data-gallery-dot]'));
  const prev = document.querySelector('[data-gallery-prev]');
  const next = document.querySelector('[data-gallery-next]');
  if (!slides.length) return;
  let active = 0;
  let ticking = false;
  let wheelLocked = false;
  let wheelTimer = null;
  let wheelAccumulator = 0;
  function lightboxIsOpen(){ return document.documentElement.classList.contains('revolucci-lightbox-open'); }
  function update(){ dots.forEach((d,i)=>{ d.classList.toggle('is-active', i===active); d.setAttribute('aria-current', i===active?'true':'false'); }); }
  function go(index){ active = Math.max(0, Math.min(slides.length-1, index)); track.scrollTo({left:slides[active].offsetLeft, behavior:'smooth'}); update(); }
  function nearest(){ const center = track.scrollLeft + track.clientWidth/2; let best=0, dist=Infinity; slides.forEach((s,i)=>{ const d=Math.abs((s.offsetLeft+s.offsetWidth/2)-center); if(d<dist){dist=d;best=i;} }); active=best; update(); }
  function release(){ clearTimeout(wheelTimer); wheelTimer=setTimeout(()=>{ wheelLocked=false; wheelAccumulator=0; }, 330); }
  dots.forEach(d=>d.addEventListener('click', ()=>go(Number(d.dataset.galleryDot))));
  if (prev) prev.addEventListener('click', ()=>go(active-1));
  if (next) next.addEventListener('click', ()=>go(active+1));
  track.addEventListener('scroll', ()=>{ if(ticking) return; requestAnimationFrame(()=>{ nearest(); ticking=false; }); ticking=true; }, {passive:true});
  track.addEventListener('wheel', function(e){
    if (lightboxIsOpen()) return;
    const delta = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
    if (Math.abs(delta) < 3) return;
    e.preventDefault(); wheelAccumulator += delta;
    if (wheelLocked || Math.abs(wheelAccumulator) < 28){ release(); return; }
    wheelLocked = true; go(active + (wheelAccumulator > 0 ? 1 : -1)); release();
  }, {passive:false});
  window.addEventListener('keydown', function(e){
    if (lightboxIsOpen() || !track.matches(':hover') && document.activeElement !== track) return;
    if (e.key === 'ArrowRight' || e.key === 'ArrowDown'){ e.preventDefault(); go(active+1); }
    if (e.key === 'ArrowLeft' || e.key === 'ArrowUp'){ e.preventDefault(); go(active-1); }
  });
  window.addEventListener('resize', ()=>go(active), {passive:true});
  update();
})();


(function(){
  'use strict';
  const track = document.querySelector('[data-archive-rail]');
  if (!track) return;
  const slides = Array.from(track.querySelectorAll('.post-card'));
  const dots = Array.from(document.querySelectorAll('[data-archive-dot]'));
  const prev = document.querySelector('[data-archive-prev]');
  const next = document.querySelector('[data-archive-next]');
  if (!slides.length) return;
  let active = 0;
  let ticking = false;
  let wheelLocked = false;
  let wheelTimer = null;
  let wheelAccumulator = 0;
  function lightboxIsOpen(){ return document.documentElement.classList.contains('revolucci-lightbox-open'); }
  function update(){
    const dotIndex = Math.min(active, dots.length - 1);
    dots.forEach((d,i)=>{ d.classList.toggle('is-active', i === dotIndex); d.setAttribute('aria-current', i === dotIndex ? 'true' : 'false'); });
  }
  function go(index){
    active = Math.max(0, Math.min(slides.length - 1, index));
    track.scrollTo({left:slides[active].offsetLeft, behavior:'smooth'});
    update();
  }
  function nearest(){
    const center = track.scrollLeft + track.clientWidth / 2;
    let best = 0, dist = Infinity;
    slides.forEach((s,i)=>{ const d = Math.abs((s.offsetLeft + s.offsetWidth/2) - center); if (d < dist){ dist = d; best = i; } });
    active = best;
    update();
  }
  function release(){ clearTimeout(wheelTimer); wheelTimer = setTimeout(()=>{ wheelLocked=false; wheelAccumulator=0; }, 330); }
  dots.forEach((d,i)=>d.addEventListener('click', ()=>go(i)));
  if (prev) prev.addEventListener('click', ()=>go(active - 1));
  if (next) next.addEventListener('click', ()=>go(active + 1));
  track.addEventListener('scroll', ()=>{ if (ticking) return; requestAnimationFrame(()=>{ nearest(); ticking=false; }); ticking=true; }, {passive:true});
  track.addEventListener('wheel', function(e){
    if (lightboxIsOpen()) return;
    const delta = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
    if (Math.abs(delta) < 3) return;
    e.preventDefault();
    wheelAccumulator += delta;
    if (wheelLocked || Math.abs(wheelAccumulator) < 28){ release(); return; }
    wheelLocked = true;
    go(active + (wheelAccumulator > 0 ? 1 : -1));
    release();
  }, {passive:false});
  window.addEventListener('keydown', function(e){
    if (lightboxIsOpen()) return;
    const isFocused = document.activeElement === track || track.contains(document.activeElement);
    if (!isFocused) return;
    if (e.key === 'ArrowRight' || e.key === 'ArrowDown'){ e.preventDefault(); go(active+1); }
    if (e.key === 'ArrowLeft' || e.key === 'ArrowUp'){ e.preventDefault(); go(active-1); }
    if (e.key === 'Home'){ e.preventDefault(); go(0); }
    if (e.key === 'End'){ e.preventDefault(); go(slides.length-1); }
  });
  window.addEventListener('resize', ()=>go(active), {passive:true});
  update();
})();

(function(){
  'use strict';
  const animatedHeaders = Array.from(document.querySelectorAll('.hero-slide-copy, .archive-hero-copy, .single-board-copy'));
  if (!animatedHeaders.length) return;
  const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduceMotion) return;
  function replay(el){
    if (!el) return;
    el.classList.add('rev-fx-replay');
    void el.offsetWidth;
    el.classList.remove('rev-fx-replay');
  }
  document.addEventListener('click', function(e){
    if (e.target.closest('[data-hero-prev], [data-hero-next], [data-hero-dot]')){
      requestAnimationFrame(function(){
        const activeCopy = document.querySelector('.hero-slide.is-active .hero-slide-copy');
        replay(activeCopy);
      });
    }
  }, true);
})();
