=== NYA Terminal Day-1 Education Pack ===
Contributors: nya
Tags: terminal, education, some-b, nya
Requires at least: 6.0
Tested up to: 6.6
Stable tag: 1.5.0
License: GPL-2.0-or-later

Adds Day-1 education-first commands to the Some-B Ask-the-Network theme:

/outline
/brief (aliases: /5min, /tl;dr)
/roast
/quiz
/flash
/factlane (alias: /verifylist)
/rootcard

This plugin injects commands into NYA_Command_Registry via Reflection
and provides lightweight handler functions without modifying theme files.

Commands use BCLM v0.4 meta (when available) to show that the slang/jargon
bridge and Bushmaster rule are active in the background.
