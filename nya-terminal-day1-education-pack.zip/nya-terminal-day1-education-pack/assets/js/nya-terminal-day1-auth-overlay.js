// NYA Terminal Day-1 Auth Overlay
// Intercepts /login and /register in the Some-B terminal input
// and opens a native glass-style login panel (no iframe).

(function() {
    if (typeof window === 'undefined') return;

    document.addEventListener('DOMContentLoaded', function() {
        var shell    = document.querySelector('.sbn-fullscreen-shell');
        var form     = shell ? shell.querySelector('form') : null;
        var textarea = document.getElementById('sbn-question');

        if (!shell || !form || !textarea) return;
        if (typeof NYATerminalAuth === 'undefined') return;

        function removeExistingOverlay() {
            var existing = document.querySelector('.nya-auth-overlay');
            if (existing && existing.parentNode) {
                existing.parentNode.removeChild(existing);
            }
        }

        function openAuthOverlay() {
            removeExistingOverlay();

            var overlay = document.createElement('div');
            overlay.className = 'nya-auth-overlay';

            var panel = document.createElement('div');
            panel.className = 'nya-auth-panel';

            var closeBtn = document.createElement('button');
            closeBtn.type = 'button';
            closeBtn.className = 'nya-auth-close';
            closeBtn.innerHTML = '\u2715';

            var heading = document.createElement('h2');
            heading.className = 'nya-auth-heading';
            heading.textContent = "Welcome back. Let\u2019s get you logged in without zombie logic.";

            var frameWrap = document.createElement('div');
            frameWrap.className = 'nya-auth-frame-wrap';

            var loginForm = document.createElement('form');
            loginForm.className = 'nya-auth-form';

            loginForm.innerHTML = '' +
                '<label for="nya-auth-username">Username or Email Address</label>' +
                '<input type="text" id="nya-auth-username" name="username" autocomplete="username" required />' +
                '<label for="nya-auth-password">Password</label>' +
                '<input type="password" id="nya-auth-password" name="password" autocomplete="current-password" required />' +
                '<div class="nya-auth-remember-wrap">' +
                    '<label class="nya-auth-remember">' +
                        '<input type="checkbox" id="nya-auth-remember" name="remember" />' +
                        '<span>Remember Me</span>' +
                    '</label>' +
                '</div>' +
                '<div class="nya-auth-error" aria-live="polite"></div>' +
                '<button type="submit" class="nya-auth-submit">Log In</button>';

            frameWrap.appendChild(loginForm);
            panel.appendChild(closeBtn);
            panel.appendChild(heading);
            panel.appendChild(frameWrap);
            overlay.appendChild(panel);

            (document.body || document.documentElement).appendChild(overlay);

            closeBtn.addEventListener('click', function() {
                removeExistingOverlay();
            });

            overlay.addEventListener('click', function(e) {
                if (e.target === overlay) {
                    removeExistingOverlay();
                }
            });

            loginForm.addEventListener('submit', function(e) {
                e.preventDefault();

                var username = loginForm.querySelector('#nya-auth-username').value || '';
                var password = loginForm.querySelector('#nya-auth-password').value || '';
                var remember = loginForm.querySelector('#nya-auth-remember').checked ? '1' : '0';
                var errorBox = loginForm.querySelector('.nya-auth-error');

                errorBox.textContent = '';

                if (!username || !password) {
                    errorBox.textContent = 'Please fill in both username and password.';
                    return;
                }

                var payload = new URLSearchParams();
                payload.append('action', 'nya_terminal_day1_login');
                payload.append('username', username);
                payload.append('password', password);
                payload.append('remember', remember);
                payload.append('login_nonce', NYATerminalAuth.nonce);

                fetch(NYATerminalAuth.ajax_url, {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    },
                    body: payload.toString()
                })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data && data.success) {
                        removeExistingOverlay();
                        window.location.reload();
                    } else {
                        var msg = (data && data.error) ? data.error : 'Login failed. Please check your details.';
                        errorBox.textContent = msg;
                    }
                })
                .catch(function(err) {
                    console.error('NYA auth AJAX error', err);
                    errorBox.textContent = 'Network error. Please try again.';
                });
            });
        }

        form.addEventListener('submit', function(e) {
            var question = (textarea.value || '').trim();
            if (!question) return;

            var lower = question.toLowerCase();
            var isLogin    = (lower === '/login' || lower === 'login');
            var isRegister = (lower === '/register' || lower === 'register');

            if (!isLogin && !isRegister) {
                return; // let normal handler run
            }

            e.preventDefault();
            if (typeof e.stopImmediatePropagation === 'function') {
                e.stopImmediatePropagation();
            }

            // Handle /register: redirect to registration URL in the main window.
            if (isRegister) {
                if (typeof window.typewriterLog === 'function') {
                    window.typewriterLog(
                        'Some-B',
                        "<p>Not a zombie? Good. I\u2019ll send you to the registration desk in this tab.</p>",
                        'local_pde'
                    );
                }
                textarea.value = '';
                var regUrl = NYATerminalAuth.registerUrl || (window.location.origin + '/wp-login.php?action=register');
                window.location.href = regUrl;
                return;
            }

            // If already logged in, don\u2019t show the panel again.
            if (NYATerminalAuth.loggedIn) {
                if (typeof window.typewriterLog === 'function') {
                    window.typewriterLog(
                        'Some-B',
                        "<p>You\u2019re already logged in. No need to open another panel.</p>",
                        'local_pde'
                    );
                }
                textarea.value = '';
                return;
            }

            // Normal /login path: open overlay.
            if (typeof window.typewriterLog === 'function') {
                window.typewriterLog(
                    'Some-B',
                    "<p>Opening a secure login panel for you on this site.</p>",
                    'local_pde'
                );
            }

            textarea.value = '';
            openAuthOverlay();
        }, true);
    });
})();
