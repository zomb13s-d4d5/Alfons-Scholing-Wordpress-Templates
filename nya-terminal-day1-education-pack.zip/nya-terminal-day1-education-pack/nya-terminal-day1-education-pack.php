<?php
/**
 * Plugin Name: NYA Terminal Day-1 Education Pack
 * Description: Adds education-first Democracy Terminal commands (/outline, /brief, /roast, /quiz, /flash, /factlane, /rootcard) on top of the Some-B Ask-the-Network theme without modifying theme files.
 * Version: 1.5.0
 * Author: NotYouAgain.ai Studio
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'NYA_Terminal_Day1_Pack' ) ) {

    /**
     * Inject Day-1 commands into NYA_Command_Registry via Reflection.
     *
     * This avoids modifying theme files and keeps the Democracy Terminal
     * registry as the single source of truth for command metadata.
     */
    class NYA_Terminal_Day1_Pack {

        public static function bootstrap() {
            // Run late enough that the theme has loaded its own registry.
            add_action( 'plugins_loaded', [ __CLASS__, 'extend_registry' ], 20 );
        }

        public static function extend_registry() {
            if ( ! class_exists( 'NYA_Command_Registry' ) ) {
                return;
            }

            try {
                $ref = new ReflectionClass( 'NYA_Command_Registry' );
                if ( ! $ref->hasProperty( 'commands' ) ) {
                    return;
                }

                $prop = $ref->getProperty( 'commands' );
                $prop->setAccessible( true );
                $commands = $prop->getValue();
                if ( ! is_array( $commands ) ) {
                    $commands = [];
                }

                $day1 = [
                    'outline'  => [
                        'level'   => 'guest',
                        'handler' => 'nya_cmd_outline',
                        'summary' => 'Simple 3‑part outline for a topic.',
                        'usage'   => '/outline [topic]',
                        'aliases' => [],
                    ],
                    'brief'    => [
                        'level'   => 'guest',
                        'handler' => 'nya_cmd_brief',
                        'summary' => 'Short digest from top local posts.',
                        'usage'   => '/brief [topic]',
                        'aliases' => [ '5min', 'tl;dr' ],
                    ],
                    'roast'    => [
                        'level'   => 'citizen',
                        'handler' => 'nya_cmd_roast',
                        'summary' => 'Idea-focused critique with a cleaner rewrite.',
                        'usage'   => '/roast [claim]',
                        'aliases' => [],
                    ],
                    'quiz'     => [
                        'level'   => 'guest',
                        'handler' => 'nya_cmd_quiz',
                        'summary' => 'Simple 3‑question check based on key concepts.',
                        'usage'   => '/quiz [topic]',
                        'aliases' => [],
                    ],
                    'flash'    => [
                        'level'   => 'guest',
                        'handler' => 'nya_cmd_flash',
                        'summary' => '3 flash notes you can screenshot and save.',
                        'usage'   => '/flash [topic]',
                        'aliases' => [],
                    ],
                    'factlane' => [
                        'level'   => 'guest',
                        'handler' => 'nya_cmd_factlane',
                        'summary' => 'Checklist of facts to verify for a topic.',
                        'usage'   => '/factlane [topic]',
                        'aliases' => [ 'verifylist' ],
                    ],
                    'rootcard' => [
                        'level'   => 'guest',
                        'handler' => 'nya_cmd_rootcard',
                        'summary' => 'One main post plus 3–4 siblings as a mini lesson root.',
                        'usage'   => '/rootcard [topic]',
                        'aliases' => [],
                    ],
                ];

                // Merge, but do not overwrite commands that already exist.
                foreach ( $day1 as $name => $config ) {
                    if ( ! isset( $commands[ $name ] ) ) {
                        $commands[ $name ] = $config;
                    }
                }

                $prop->setValue( $commands );
            } catch ( Throwable $e ) {
                // Fail silently: terminal will keep working, just without this pack.
            }
        }
    }

    NYA_Terminal_Day1_Pack::bootstrap();
}

/**
 * Helper: normalize topic / keyword from argline or current post title.
 */
if ( ! function_exists( 'nya_terminal_day1_normalize_topic' ) ) {
    function nya_terminal_day1_normalize_topic( $argline ) {
        $topic = trim( (string) $argline );
        if ( $topic === '' ) {
            $post = get_post();
            if ( $post ) {
                $topic = get_the_title( $post );
            }
        }
        return sanitize_text_field( $topic );
    }
}

/**
 * Helper: fetch local posts for a topic.
 */
if ( ! function_exists( 'nya_terminal_day1_local_posts_for_topic' ) ) {
    function nya_terminal_day1_local_posts_for_topic( $topic, $limit = 5 ) {
        if ( $topic === '' ) {
            return [];
        }

        $args  = [
            's'              => $topic,
            'posts_per_page' => max( 1, (int) $limit ),
            'post_status'    => 'publish',
        ];
        $posts = get_posts( $args );

        return is_array( $posts ) ? $posts : [];
    }
}

/**
 * Helper: small BCLM footer so users see the OS mode.
 */
if ( ! function_exists( 'nya_terminal_day1_bclm_footer' ) ) {
    function nya_terminal_day1_bclm_footer() {
        if ( ! class_exists( 'NYA_BCLM_Registry' ) ) {
            return '';
        }

        $meta = method_exists( 'NYA_BCLM_Registry', 'get_meta' )
            ? NYA_BCLM_Registry::get_meta()
            : [];

        $bits = [];
        if ( ! empty( $meta['bclm_version'] ) ) {
            $bits[] = 'BCLM ' . $meta['bclm_version'];
        }
        if ( ! empty( $meta['slang_bridge_enabled'] ) ) {
            $bits[] = 'slang/jargon bridge: on';
        }
        if ( ! empty( $meta['bushmaster_rule_enabled'] ) ) {
            $bits[] = 'bushmaster rule: on';
        }

        if ( empty( $bits ) ) {
            return '';
        }

        return "\n\n" . implode( ' | ', $bits );
    }
}

/**
 * /outline [topic] – 3-part outline.
 */
if ( ! function_exists( 'nya_cmd_outline' ) ) {
    function nya_cmd_outline( $argline, $meta, $user_level, $context = null ) {
        $topic = nya_terminal_day1_normalize_topic( $argline );
        if ( $topic === '' ) {
            return [
                'type'    => 'system',
                'message' => 'Usage: /outline [topic]',
            ];
        }

        $msg  = "Outline for “{$topic}”:\n";
        $msg .= "1) What it is (definition + example).\n";
        $msg .= "2) Why it matters (risk, benefit, people involved).\n";
        $msg .= "3) What to watch (rights, duty of care, red flags).";
        $msg .= nya_terminal_day1_bclm_footer();

        return [
            'type'    => 'result',
            'message' => $msg,
        ];
    }
}

/**
 * /brief [topic] – short digest from local posts.
 */
if ( ! function_exists( 'nya_cmd_brief' ) ) {
    function nya_cmd_brief( $argline, $meta, $user_level, $context = null ) {
        $topic = nya_terminal_day1_normalize_topic( $argline );
        if ( $topic === '' ) {
            return [
                'type'    => 'system',
                'message' => 'Usage: /brief [topic]',
            ];
        }

        $posts = nya_terminal_day1_local_posts_for_topic( $topic, 3 );
        if ( ! $posts ) {
            return [
                'type'    => 'system',
                'message' => "No posts found for “{$topic}”.",
            ];
        }

        $lines = [];
        foreach ( $posts as $p ) {
            $title   = get_the_title( $p );
            $excerpt = wp_trim_words( wp_strip_all_tags( $p->post_content ), 40 );
            $lines[] = "- {$title}: {$excerpt}";
        }

        $msg  = "Brief for “{$topic}” (local content):\n";
        $msg .= implode( "\n\n", $lines );
        $msg .= nya_terminal_day1_bclm_footer();

        return [
            'type'    => 'result',
            'message' => $msg,
        ];
    }
}

/**
 * /rootcard [topic] – main + siblings as a lesson root.
 */
if ( ! function_exists( 'nya_cmd_rootcard' ) ) {
    function nya_cmd_rootcard( $argline, $meta, $user_level, $context = null ) {
        $topic = nya_terminal_day1_normalize_topic( $argline );
        if ( $topic === '' ) {
            return [
                'type'    => 'system',
                'message' => 'Usage: /rootcard [topic]',
            ];
        }

        $posts = nya_terminal_day1_local_posts_for_topic( $topic, 4 );
        if ( ! $posts ) {
            return [
                'type'    => 'system',
                'message' => "No posts found for “{$topic}”.",
            ];
        }

        $main     = $posts[0];
        $siblings = array_slice( $posts, 1 );

        $msg  = "Rootcard for “{$topic}” (local):\n";
        $msg .= "Main:\n- " . get_the_title( $main ) . "\n\n";

        if ( $siblings ) {
            $msg .= "Siblings:\n";
            foreach ( $siblings as $s ) {
                $msg .= "- " . get_the_title( $s ) . "\n";
            }
        }

        $msg .= nya_terminal_day1_bclm_footer();

        return [
            'type'    => 'result',
            'message' => trim( $msg ),
        ];
    }
}

/**
 * /quiz [topic] – three open questions.
 */
if ( ! function_exists( 'nya_cmd_quiz' ) ) {
    function nya_cmd_quiz( $argline, $meta, $user_level, $context = null ) {
        $topic = nya_terminal_day1_normalize_topic( $argline );
        if ( $topic === '' ) {
            return [
                'type'    => 'system',
                'message' => 'Usage: /quiz [topic]',
            ];
        }

        $msg  = "Mini quiz for “{$topic}”:\n";
        $msg .= "1) In your own words, what is this really about?\n";
        $msg .= "2) Who could be helped or harmed here (benefit, harm, risk)?\n";
        $msg .= "3) Do you spot any fairness or power issues (rights, duty of care, discrimination)?";
        $msg .= nya_terminal_day1_bclm_footer();

        return [
            'type'    => 'result',
            'message' => $msg,
        ];
    }
}

/**
 * /flash [topic] – 3 screenshot-friendly notes.
 */
if ( ! function_exists( 'nya_cmd_flash' ) ) {
    function nya_cmd_flash( $argline, $meta, $user_level, $context = null ) {
        $topic = nya_terminal_day1_normalize_topic( $argline );
        if ( $topic === '' ) {
            return [
                'type'    => 'system',
                'message' => 'Usage: /flash [topic]',
            ];
        }

        $msg  = "Flash notes for “{$topic}” (screenshot and save):\n";
        $msg .= "• One key idea to remember.\n";
        $msg .= "• One question to ask an expert or teacher.\n";
        $msg .= "• One action you could take or habit you could try.";
        $msg .= nya_terminal_day1_bclm_footer();

        return [
            'type'    => 'result',
            'message' => $msg,
        ];
    }
}

/**
 * /factlane [topic] – verification checklist.
 */
if ( ! function_exists( 'nya_cmd_factlane' ) ) {
    function nya_cmd_factlane( $argline, $meta, $user_level, $context = null ) {
        $topic = nya_terminal_day1_normalize_topic( $argline );
        if ( $topic === '' ) {
            return [
                'type'    => 'system',
                'message' => 'Usage: /factlane [topic]',
            ];
        }

        $msg  = "Fact lane for “{$topic}” – things to check:\n";
        $msg .= "• Who is making the claim (person, group, institution)?\n";
        $msg .= "• What are the exact facts they state (not just opinions)?\n";
        $msg .= "• What evidence is shown, and can you find an independent source?\n";
        $msg .= "• Are there clear risks, harms, or people left out of the story?\n";
        $msg .= "• What would count as fair redress if something goes wrong?";
        $msg .= nya_terminal_day1_bclm_footer();

        return [
            'type'    => 'result',
            'message' => $msg,
        ];
    }
}

/**
 * /roast [claim] – idea-focused critique only.
 */
if ( ! function_exists( 'nya_cmd_roast' ) ) {
    function nya_cmd_roast( $argline, $meta, $user_level, $context = null ) {
        if ( $user_level !== 'citizen' ) {
            return [
                'type'    => 'system',
                'message' => 'Command /roast requires a civic keycard (registration).',
            ];
        }

        $claim = trim( (string) $argline );
        if ( $claim === '' ) {
            return [
                'type'    => 'system',
                'message' => 'Usage: /roast [claim]',
            ];
        }

        $msg  = "Roast (idea only, not person):\n";
        $msg .= "- Original claim: {$claim}\n";
        $msg .= "- Check facts vs opinions. Where are the unproven claims?\n";
        $msg .= "- Look for bias or missing context (who benefits, who is at risk?).\n";
        $msg .= "- Try rewriting the claim more carefully, using specific facts and limits.";
        $msg .= nya_terminal_day1_bclm_footer();

        return [
            'type'    => 'result',
            'message' => $msg,
        ];
    }
}


/**
 * Enqueue Day-1 auth overlay assets (login/register glass panels).
 */
if ( ! function_exists( 'nya_terminal_day1_enqueue_auth_overlay_assets' ) ) {
    function nya_terminal_day1_enqueue_auth_overlay_assets() {
        if ( is_admin() ) {
            return;
        }

        wp_enqueue_style(
            'nya-terminal-day1-auth-overlay',
            plugins_url( 'assets/css/nya-terminal-day1-auth-overlay.css', __FILE__ ),
            array(),
            '1.5.0'
        );

        wp_enqueue_script(
            'nya-terminal-day1-auth-overlay',
            plugins_url( 'assets/js/nya-terminal-day1-auth-overlay.js', __FILE__ ),
            array( 'sbn-frontend' ),
            '1.5.0',
            true
        );

        wp_localize_script(
            'nya-terminal-day1-auth-overlay',
            'NYATerminalAuth',
            array(
                'ajax_url'    => admin_url( 'admin-ajax.php' ),
                'nonce'       => wp_create_nonce( 'nya-terminal-login-nonce' ),
                'registerUrl' => function_exists( 'wp_registration_url' ) ? wp_registration_url() : wp_login_url(),
                'loggedIn'    => is_user_logged_in(),
            )
        );
    }
}
add_action( 'wp_enqueue_scripts', 'nya_terminal_day1_enqueue_auth_overlay_assets', 20 );




/**
 * AJAX login handler for the auth overlay.
 */
if ( ! function_exists( 'nya_terminal_day1_ajax_login' ) ) {
    function nya_terminal_day1_ajax_login() {

        if ( empty( $_POST['login_nonce'] ) || ! wp_verify_nonce( $_POST['login_nonce'], 'nya-terminal-login-nonce' ) ) {
            wp_send_json(
                array(
                    'success' => false,
                    'error'   => __( 'Security check failed. Please refresh and try again.', 'nya-terminal-day1' ),
                )
            );
        }

        $username = isset( $_POST['username'] ) ? sanitize_user( wp_unslash( $_POST['username'] ) ) : '';
        $password = isset( $_POST['password'] ) ? (string) wp_unslash( $_POST['password'] ) : '';
        $remember = ! empty( $_POST['remember'] );

        if ( $username === '' || $password === '' ) {
            wp_send_json(
                array(
                    'success' => false,
                    'error'   => __( 'Please provide both username and password.', 'nya-terminal-day1' ),
                )
            );
        }

        $creds = array(
            'user_login'    => $username,
            'user_password' => $password,
            'remember'      => $remember,
        );

        $user = wp_signon( $creds, false );

        if ( is_wp_error( $user ) ) {
            wp_send_json(
                array(
                    'success' => false,
                    'error'   => $user->get_error_message(),
                )
            );
        }

        wp_set_current_user( $user->ID );

        wp_send_json(
            array(
                'success' => true,
            )
        );
    }
}
add_action( 'wp_ajax_nopriv_nya_terminal_day1_login', 'nya_terminal_day1_ajax_login' );
add_action( 'wp_ajax_nya_terminal_day1_login', 'nya_terminal_day1_ajax_login' );

/**
 * Skin the native WordPress login/register screens to better match
 * the Some-B / Democracy Terminal branding.
 */
if ( ! function_exists( 'nya_terminal_day1_brand_login_screen' ) ) {
    function nya_terminal_day1_brand_login_screen() {
        wp_enqueue_style(
            'nya-terminal-day1-login-skin',
            plugins_url( 'assets/css/nya-terminal-day1-login-skin.css', __FILE__ ),
            array(),
            '1.5.0'
        );
    }
}
add_action( 'login_enqueue_scripts', 'nya_terminal_day1_brand_login_screen', 20 );

// Optional: point the login header link back to the site home.
if ( ! function_exists( 'nya_terminal_day1_login_headerurl' ) ) {
    function nya_terminal_day1_login_headerurl( $url ) {
        return home_url( '/' );
    }
}
add_filter( 'login_headerurl', 'nya_terminal_day1_login_headerurl' );

if ( ! function_exists( 'nya_terminal_day1_login_headertext' ) ) {
    function nya_terminal_day1_login_headertext( $text ) {
        return get_bloginfo( 'name' );
    }
}
add_filter( 'login_headertext', 'nya_terminal_day1_login_headertext' );
