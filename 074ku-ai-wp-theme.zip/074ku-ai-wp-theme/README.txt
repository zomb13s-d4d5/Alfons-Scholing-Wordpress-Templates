074KU.ai Socialist Otaku Street System WordPress Theme
Version: 1.0.0

Install:
1. Upload 074ku-ai-wp-theme.zip via Appearance > Themes > Add New > Upload Theme.
2. Activate the theme.
3. Optional: install WooCommerce for the shop grid.
4. Optional: install the 074KU.ai Otaku Street Auto Poster plugin to auto-fill category posts.
5. Go to Appearance > Menus and assign your menu to Primary Menu, or let the theme use the 074KU category fallback menu.

Included:
- Classic installable WordPress theme.
- WooCommerce-ready product styling.
- Homepage category hero system.
- Default hero assets for Punk, Hip Hop, Metal, BMX, Skate, Surf, Inline, Android, Accessories and Design Principles.
- Category icon assets.
- Blog/archive/single/page/search/404 templates.
- Theme-generated category setup on activation.

Notes:
The theme is intentionally graphic and asset-heavy, but included images were optimized to WebP for web use.


== v1.2.0 updates ==

* Removed email subscription UI.
* Added minimal member login/register actions.
* Converted hero, category menu, latest shop items, category icons and journal cards into animated auto sliders.
* Added loading/progress animation for slider movement.
* Improved mobile slider behavior to reduce stacking.


Version 1.5 adds a graphic header blast for non-home pages and a stronger WooCommerce spacing pass for cleaner shop/product layouts.


Version 1.6 integrates the custom manga-graffiti banner as the header/menu background and tightens WooCommerce padding, gutters and product card spacing.


Version 1.7 makes the header background image visibly stronger, reduces the menu/header footprint, and adds an iOS-first responsive pass for phone, iPad portrait, iPad landscape, laptop and desktop.


Version 1.8 fixes iOS navigation overflow: the menu is now constrained inside a clipped/scrolling rail and cannot force the header wider than the viewport.


Version 1.9 integrates the custom dark footer mural as the footer background, cropped cover-style, and adds footer login/register/account actions without disrupting the main styling.


Version 1.10 integrates the 19x19 explanatory typography grid as the body background. The image is centered and tuned responsively for portrait and landscape views while preserving readability across the site.


Version 1.10.1 changes the body guide background from scroll-based to a fixed, viewport-centered background using a dedicated pseudo-element, so it stays centered while the content scrolls.


Version 1.11 adds a final gutter/margin system, restores the fixed body background visibility, reduces the logo/header footprint, and adds scroll-aware header behavior so the logo collapses while the navigation remains sticky.


Version 1.12 adds a dedicated WooCommerce shop body padding shell. Instead of relying only on individual product/card padding, the whole shop area now gets a clean inset so shop content can never sit flush against the edges.

Version 1.18 restores the homepage featured shop as a full-width one-product-at-a-time hero slider with oversized product cards.


1.18.1: Surgical WooCommerce shop panel alignment repair. Preserves v1.18 working slider/header visuals; centers the shop archive shell, adds desktop/iOS padding to the filter panel, and resets top WooCommerce floats.


== v1.19.0 header integration ==
- Rebuilt the responsive header hierarchy.
- Logo is fixed to the top-left header position.
- White shop/account buttons are fixed to the top-right header position.
- Black category items now sit directly underneath as a non-wrapping horizontal carousel.
- Auto-slide behavior is strengthened with iPad/touch support and manual left/right chevrons.
- Legacy mobile hamburger collapse is overridden so portrait keeps the same visual hierarchy.


== v1.19.1 shop/header parity ==
- Forced the same integrated header/menu styling on WooCommerce shop, product archive, product category, product tag, and single product pages.
- Increased the logo wordmark/custom-logo scale inside the logo box and reduced the feeling of empty padding.
- Renamed the header CSS file to v191 to help bypass browser/theme cache.


== v1.20.0 harmonica scroll reveal ==
- Added front-page scroll animation: homepage sections start folded/hidden and unfold automatically when entering the viewport.
- Individual category panels, product cards, icons, journal cards, and feature tiles appear in a staggered accordion/harmonica rhythm.
- Respects prefers-reduced-motion for accessibility.


== v1.21.0 exact same header on Shop ==
- Removed the old non-home rule that hid the logo outside the homepage.
- Added a final all-pages header stylesheet loaded last.
- Shop, product archive, category, tag, and single product pages now use the exact same logo/header/menu slider structure as the homepage.
- Black menu slider is forced full-width under the logo/action row everywhere.


== v1.22.0 emergency header repair ==
- Isolated the header with new ku074-main-header classes.
- Disabled the v1.21 all-pages header override that broke the shop header.
- Forces the homepage header hierarchy everywhere without relying on legacy .site-header rules.
- Shop now uses the same logo / white buttons / black horizontal slider structure as the homepage.
- Added admin-bar offset so the WordPress admin bar does not eat the sticky header.


== v1.23.0 full-width menu strip ==
- Keeps the v1.22 repaired header.
- Makes the black menu item row fill the full header/menu width instead of clustering.
- Maintains horizontal slider/overflow behavior when the menu is wider than the viewport.


== v1.24.0 real menu rebuild ==
- Rebuilt the black menu strip mechanics instead of only stretching the old compact carousel.
- The menu strip now fills the header width.
- Visible menu items distribute across the whole strip.
- Overflow still scrolls/auto-slides to reveal the remaining menu items.
- Arrows are positioned at the strip edges instead of consuming menu layout space.


== v1.25.0 force rebuilt menu on Shop ==
- Adds a WooCommerce/shop-specific version of the rebuilt full-width menu rules.
- Also prints those rules inline on WooCommerce/shop pages at wp_head priority 1001, after earlier inline Woo fixes.
- This prevents shop pages from falling back to the older compact/clipped menu.


== v1.26.0 global header/menu audit and reset ==
- Disabled the stacked header patches from v1.19-v1.25 that caused page-specific differences.
- Added ONE global header/menu stylesheet used site-wide.
- Prints the global header/menu CSS inline on every page so archives/categories/shop cannot miss it.
- Applies the same logo/actions/full-width black menu slider to homepage, shop, Woo category/tag/product pages, normal WordPress category pages, archives, search, pages, and posts.


== v1.27.0 fixed identical header menu source ==
- Header no longer uses wp_nav_menu for the main top menu.
- Renders one fixed 074KU header menu everywhere from theme data: Home, Shop, category set, Streetwear.
- Prevents WordPress menu assignment/current-page behavior from showing only a sliced subset on category pages.
- Adjusted menu strip so it starts from the same beginning everywhere.


== v1.28.0 star/skull fold-out menu redesign ==
- Replaces the problematic horizontal header menu slider with a compact 50x50 star/skull menu button.
- Button sits in the lower-right area of the header/menu region on every page and screen size.
- Menu items are now hidden behind the star button and unfold in a harmonica-style panel.
- Includes new optimized menu-star-skull image assets.
- Uses the same fixed menu source globally.


== v1.29.0 corrected star/skull menu asset ==
- Replaced the menu button asset with the correct first emblem: total black background, red star/skull, white outline.
- Removed the app-icon-style baked shadow/rounded-square look from the asset.
- The 50x50 menu button shadow is now CSS-only.


== v1.30.0 fold-out menu functional fix ==
- Changed the star menu panel from hidden-attribute-only behavior to a class-based open/closed state.
- Replaced the star menu JavaScript with a DOM-ready, event-safe script.
- Added a footer fallback script so the button still works if external JS is delayed or optimized.
- Escape closes the panel; outside click closes the panel.


== v1.31.0 normal fold-out menu ==
- The star/skull button now opens a normal vertical fold-out menu.
- Removed slider/carousel behavior from the opened menu panel.
- Menu items stack as regular full-width buttons.
- Auto-slider script explicitly ignores anything inside the star fold-out panel.


== v1.32.0 CSS-only working star menu ==
- Replaced the dead JS-only button with a CSS checkbox toggle.
- Star/skull menu now opens even if JavaScript fails.
- JavaScript only enhances close behavior: Escape, outside click, link click.
- Keeps the normal vertical fold-out menu, not a slider.


== v1.33.0 anchor-target star menu ==
- Replaced checkbox toggle with a normal anchor link: star links to #ku074-star-menu-panel.
- Menu opens with CSS :target, so it does not depend on JavaScript or checkbox behavior.
- Close control links back to #ku074-star-menu.
- Keeps normal vertical fold-out menu.
