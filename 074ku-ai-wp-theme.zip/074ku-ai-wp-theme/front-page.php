<?php get_header(); ?>
<main id="primary" class="site-main">
    <section class="hero-system">
        <div class="ku074-container">
            <div class="hero-mast">
                <div>
                    <div class="hero-kicker">074<span>KU</span>.ai</div>
                    <p class="hero-tagline"><?php echo esc_html(get_theme_mod('ku074_hero_tagline', 'WE ARE LOYAL TO EACH OTHER, NOT TO THE SYSTEM.')); ?></p>
                </div>
                <div class="system-stamp"><span lang="ja">反体制</span><br><?php esc_html_e('Anti System Community', 'ku074'); ?></div>
            </div>
            <div class="ku074-slider-shell ku074-slider-shell--hero">
                <div class="category-hero-grid ku074-auto-slider" data-ku-autoslider data-slider-step="panel" aria-label="<?php esc_attr_e('074KU category heroes', 'ku074'); ?>">
                    <?php foreach (ku074_category_data() as $cat) : ?>
                        <a class="category-panel" href="<?php echo esc_url(ku074_category_link($cat['slug'])); ?>" style="--accent:<?php echo esc_attr($cat['accent']); ?>;background-image:url('<?php echo esc_url(ku074_asset_uri('img/heroes/' . $cat['slug'] . '.webp')); ?>')">
                            <span class="category-panel__copy">
                                <span class="category-panel__title"><?php echo esc_html($cat['label']); ?></span>
                                <span class="category-panel__jp"><?php echo esc_html($cat['jp']); ?></span>
                                <span class="category-panel__desc"><?php echo esc_html($cat['desc']); ?></span>
                            </span>
                        </a>
                    <?php endforeach; ?>
                </div>
                <span class="ku074-slider-loader" aria-hidden="true"></span>
            </div>
        </div>
    </section>

    <section class="ku074-container">
        <div class="section-band">
            <h2 class="section-title"><?php esc_html_e('Featured products', 'ku074'); ?> <span lang="ja">注目商品</span></h2>
            <?php if (class_exists('WooCommerce')) : ?><a class="ku074-button ku074-button--red" href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>"><?php esc_html_e('View all products', 'ku074'); ?> →</a><?php endif; ?>
        </div>
        <div class="ku074-slider-shell ku074-slider-shell--products">
            <div class="ku074-product-slider ku074-auto-slider" data-ku-autoslider data-slider-step="card">
                <?php if (class_exists('WooCommerce')) : ?>
                    <?php echo do_shortcode('[products limit="12" columns="4" orderby="date" order="DESC" visibility="visible"]'); ?>
                <?php else : ?>
                    <div class="post-grid">
                    <?php
                    $latest = new WP_Query(array('posts_per_page' => 10, 'ignore_sticky_posts' => true));
                    while ($latest->have_posts()) : $latest->the_post();
                        get_template_part('template-parts/card', 'post');
                    endwhile; wp_reset_postdata();
                    ?>
                    </div>
                <?php endif; ?>
            </div>
            <span class="ku074-slider-loader" aria-hidden="true"></span>
        </div>
    </section>

    <section class="ku074-container">
        <div class="section-band">
            <h2 class="section-title"><?php esc_html_e('Browse the system', 'ku074'); ?> <span lang="ja">システムを選ぶ</span></h2>
        </div>
        <div class="ku074-slider-shell ku074-slider-shell--icons">
            <div class="category-icon-row ku074-auto-slider" data-ku-autoslider data-slider-step="icon">
                <?php foreach (ku074_category_data() as $cat) : ?>
                    <a class="category-icon" href="<?php echo esc_url(ku074_category_link($cat['slug'])); ?>" style="--accent:<?php echo esc_attr($cat['accent']); ?>;background-image:url('<?php echo esc_url(ku074_asset_uri('img/icons/' . $cat['slug'] . '.webp')); ?>')"><span><?php echo esc_html($cat['label']); ?></span></a>
                <?php endforeach; ?>
            </div>
            <span class="ku074-slider-loader" aria-hidden="true"></span>
        </div>
    </section>

    <section class="ku074-container">
        <div class="section-band">
            <h2 class="section-title"><?php esc_html_e('Field Notes // 074KU Journal', 'ku074'); ?> <span lang="ja">現場ノート</span></h2>
            <a class="ku074-button ku074-button--light" href="<?php echo esc_url(get_permalink(get_option('page_for_posts')) ?: home_url('/blog/')); ?>"><?php esc_html_e('View all articles', 'ku074'); ?> →</a>
        </div>
        <div class="ku074-slider-shell ku074-slider-shell--journal">
            <div class="journal-layout ku074-auto-slider" data-ku-autoslider data-slider-step="card">
                <?php
                $journal = new WP_Query(array('posts_per_page' => 8, 'ignore_sticky_posts' => true));
                while ($journal->have_posts()) : $journal->the_post();
                    get_template_part('template-parts/card', 'post');
                endwhile; wp_reset_postdata();
                ?>
                <aside class="promo-poster"><strong><?php esc_html_e('No borders no bosses just people', 'ku074'); ?></strong><p lang="ja">境界なし・ボスなし・ただ人々</p></aside>
            </div>
            <span class="ku074-slider-loader" aria-hidden="true"></span>
        </div>
    </section>

    <section class="ku074-container resistance-strip resistance-strip--members">
        <div><p><?php esc_html_e('Join the', 'ku074'); ?></p><h2><?php esc_html_e('System', 'ku074'); ?></h2><p lang="ja">参加・ログイン・登録</p></div>
        <div class="member-actions" aria-label="<?php esc_attr_e('Member actions', 'ku074'); ?>">
            <?php if (is_user_logged_in()) : ?>
                <a class="ku074-button ku074-button--red" href="<?php echo esc_url(ku074_account_url()); ?>"><?php esc_html_e('My account', 'ku074'); ?> →</a>
                <a class="ku074-button ku074-button--light" href="<?php echo esc_url(wp_logout_url(home_url('/'))); ?>"><?php esc_html_e('Log out', 'ku074'); ?> →</a>
            <?php else : ?>
                <a class="ku074-button ku074-button--red" href="<?php echo esc_url(wp_login_url()); ?>"><?php esc_html_e('Log in', 'ku074'); ?> →</a>
                <a class="ku074-button ku074-button--light" href="<?php echo esc_url(ku074_register_url()); ?>"><?php esc_html_e('Register', 'ku074'); ?> →</a>
            <?php endif; ?>
        </div>
    </section>

    <section class="ku074-container feature-row">
        <div class="feature-item"><strong><?php esc_html_e('Printed with purpose', 'ku074'); ?></strong><?php esc_html_e('Eco inks and ethical production.', 'ku074'); ?></div>
        <div class="feature-item"><strong><?php esc_html_e('Built for the streets', 'ku074'); ?></strong><?php esc_html_e('Durable. Timeless. Rebellious.', 'ku074'); ?></div>
        <div class="feature-item"><strong><?php esc_html_e('Community first', 'ku074'); ?></strong><?php esc_html_e('We support culture, not corporations.', 'ku074'); ?></div>
        <div class="feature-item"><strong><?php esc_html_e('Worldwide shipping', 'ku074'); ?></strong><?php esc_html_e('From our hands to your streets.', 'ku074'); ?></div>
    </section>
</main>
<?php get_footer(); ?>
