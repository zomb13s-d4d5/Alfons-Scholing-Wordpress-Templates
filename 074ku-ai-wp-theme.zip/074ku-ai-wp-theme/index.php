<?php get_header(); ?>
<main id="primary" class="site-main page-shell">
    <div class="ku074-container">
        <header class="archive-header">
            <h1 class="page-title"><?php single_post_title('', true); ?></h1>
            <p><?php esc_html_e('Field notes from the 074KU.ai street system.', 'ku074'); ?></p>
        </header>
        <?php if (have_posts()) : ?>
            <div class="post-grid">
                <?php while (have_posts()) : the_post(); get_template_part('template-parts/card', 'post'); endwhile; ?>
            </div>
            <?php the_posts_navigation(); ?>
        <?php else : ?>
            <p><?php esc_html_e('No posts found.', 'ku074'); ?></p>
        <?php endif; ?>
    </div>
</main>
<?php get_footer(); ?>
