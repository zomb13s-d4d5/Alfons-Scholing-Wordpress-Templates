<?php get_header(); ?>
<main id="primary" class="site-main page-shell">
    <div class="ku074-container">
        <section class="archive-header">
            <h1 class="page-title"><?php esc_html_e('404 // System gap', 'ku074'); ?></h1>
            <p><?php esc_html_e('This poster got torn off the wall. Try searching the archive.', 'ku074'); ?></p>
            <?php get_search_form(); ?>
        </section>
    </div>
</main>
<?php get_footer(); ?>
