<article id="post-<?php the_ID(); ?>" <?php post_class('post-card'); ?>>
    <a href="<?php the_permalink(); ?>" aria-label="<?php the_title_attribute(); ?>">
        <img class="post-card__image" src="<?php echo esc_url(ku074_post_thumbnail_url()); ?>" alt="<?php the_title_attribute(); ?>">
    </a>
    <div class="post-card__body">
        <div class="post-card__meta"><?php echo esc_html(get_the_date()); ?></div>
        <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        <p><?php echo esc_html(ku074_excerpt(18)); ?></p>
        <a class="ku074-button ku074-button--light" href="<?php the_permalink(); ?>"><?php esc_html_e('Read more', 'ku074'); ?> →</a>
    </div>
</article>
