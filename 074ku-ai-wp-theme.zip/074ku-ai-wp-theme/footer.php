<?php /** Theme footer. */ ?>
<footer class="site-footer">
    <div class="ku074-container footer-grid">
        <div class="footer-panel footer-panel--brand">
            <div class="footer-wordmark">074<span style="color:var(--ku-red)">KU</span>.ai</div>
            <p><strong><?php esc_html_e('Socialist Otaku Street System', 'ku074'); ?></strong><br><span lang="ja"><?php esc_html_e('社会主義・オタク・ストリート・システム', 'ku074'); ?></span></p>
            <p><?php esc_html_e('For the culture, by the culture.', 'ku074'); ?></p>
        </div>
        <div class="footer-panel">
            <h3><?php esc_html_e('Info', 'ku074'); ?></h3>
            <?php wp_nav_menu(array('theme_location' => 'footer', 'container' => false, 'fallback_cb' => false)); ?>
        </div>
        <div class="footer-panel">
            <h3><?php esc_html_e('System', 'ku074'); ?></h3>
            <p><?php esc_html_e('Unite. Resist. Express.', 'ku074'); ?></p>
            <p><?php esc_html_e('We are loyal to each other, not to the system.', 'ku074'); ?></p>
        </div>
        <div class="footer-panel footer-panel--account">
            <h3><?php esc_html_e('Members', 'ku074'); ?></h3>
            <p><?php esc_html_e('Access the system from the footer.', 'ku074'); ?></p>
            <div class="footer-auth">
                <?php if (is_user_logged_in()) : ?>
                    <a href="<?php echo esc_url(function_exists('wc_get_page_permalink') ? wc_get_page_permalink('myaccount') : admin_url()); ?>"><?php esc_html_e('Account', 'ku074'); ?></a>
                    <a href="<?php echo esc_url(wp_logout_url(home_url('/'))); ?>"><?php esc_html_e('Logout', 'ku074'); ?></a>
                <?php else : ?>
                    <a href="<?php echo esc_url(wp_login_url()); ?>"><?php esc_html_e('Login', 'ku074'); ?></a>
                    <?php if (get_option('users_can_register')) : ?>
                        <a href="<?php echo esc_url(wp_registration_url()); ?>"><?php esc_html_e('Register', 'ku074'); ?></a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <p class="footer-follow">Instagram · TikTok · YouTube · Discord</p>
            <p>&copy; <?php echo esc_html(gmdate('Y')); ?> <?php bloginfo('name'); ?></p>
        </div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
