<?php
/**
 * 074KU.ai Socialist Otaku Street System theme functions.
 */
if (!defined('ABSPATH')) {
    exit;
}

const KU074_THEME_VERSION = '1.19.2';

function ku074_asset_uri($path = '') {
    return get_template_directory_uri() . '/assets/' . ltrim($path, '/');
}

function ku074_category_data() {
    return array(
        array('slug' => 'punk', 'label' => 'Punk', 'jp' => 'パンク', 'desc' => 'DIY / REPAIR / REBEL', 'accent' => '#ff2e91'),
        array('slug' => 'hip-hop', 'label' => 'Hip Hop', 'jp' => 'ヒップホップ', 'desc' => 'LAYER / RHYTHM / STATUS', 'accent' => '#ff7a00'),
        array('slug' => 'metal', 'label' => 'Metal', 'jp' => 'メタル', 'desc' => 'BLACK / HARDWARE / STAGE', 'accent' => '#d9231f'),
        array('slug' => 'bmx', 'label' => 'BMX', 'jp' => 'BMX', 'desc' => 'UTILITY / MOTION / IMPACT', 'accent' => '#ffc400'),
        array('slug' => 'skate', 'label' => 'Skate', 'jp' => 'スケート', 'desc' => 'LOOSE / DURABLE / ABRASION', 'accent' => '#00a7e1'),
        array('slug' => 'surf', 'label' => 'Surf', 'jp' => 'サーフ', 'desc' => 'FADED / SALT / SUN', 'accent' => '#00b8b2'),
        array('slug' => 'inline', 'label' => 'Inline', 'jp' => 'インライン', 'desc' => 'SPEED / ARMOR / FLOW', 'accent' => '#ff3b9f'),
        array('slug' => 'android', 'label' => 'Android', 'jp' => 'アンドロイド', 'desc' => 'SOFT / TECH / COMPANION', 'accent' => '#7ed321'),
        array('slug' => 'accessories', 'label' => 'Accessories', 'jp' => 'アクセサリー', 'desc' => 'DETAIL / SYMBOL / CARRY', 'accent' => '#c7a24b'),
        array('slug' => 'design-principles', 'label' => 'Design Principles', 'jp' => 'デザイン原則', 'desc' => 'FORM / TEXTURE / FUNCTION', 'accent' => '#e4312b'),
    );
}

function ku074_setup() {
    load_theme_textdomain('ku074', get_template_directory() . '/languages');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('automatic-feed-links');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));
    add_theme_support('custom-logo', array('height' => 240, 'width' => 800, 'flex-height' => true, 'flex-width' => true));
    add_theme_support('align-wide');
    add_theme_support('responsive-embeds');
    add_theme_support('editor-styles');
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');

    register_nav_menus(array(
        'primary' => __('Primary Menu', 'ku074'),
        'footer'  => __('Footer Menu', 'ku074'),
    ));

    add_image_size('ku074-card', 720, 540, true);
    add_image_size('ku074-hero', 1200, 1600, true);
}
add_action('after_setup_theme', 'ku074_setup');

function ku074_enqueue_assets() {
    wp_enqueue_style(
        'ku074-google-fonts',
        'https://fonts.googleapis.com/css2?family=Bebas+Neue&family=IBM+Plex+Mono:wght@400;500;600;700&family=Noto+Sans+JP:wght@400;500;700;900&display=swap',
        array(),
        null
    );
    wp_enqueue_style('ku074-theme', ku074_asset_uri('css/theme.css'), array('ku074-google-fonts'), KU074_THEME_VERSION);
    wp_enqueue_style('ku074-wc-spacing-audit', ku074_asset_uri('css/wc-spacing-audit.css'), array('ku074-theme'), KU074_THEME_VERSION);
    wp_enqueue_style('ku074-wc-viewport-lock', ku074_asset_uri('css/wc-viewport-lock-v16.css'), array('ku074-wc-spacing-audit'), KU074_THEME_VERSION . '-' . filemtime(get_template_directory() . '/assets/css/wc-viewport-lock-v16.css'));
    wp_enqueue_style('ku074-layout-hotfix-v17', ku074_asset_uri('css/layout-hotfix-v17.css'), array('ku074-wc-viewport-lock'), KU074_THEME_VERSION . '-' . filemtime(get_template_directory() . '/assets/css/layout-hotfix-v17.css'));
    wp_enqueue_style('ku074-wc-shop-panel-center-v181', ku074_asset_uri('css/wc-shop-panel-center-v181.css'), array('ku074-layout-hotfix-v17'), KU074_THEME_VERSION . '-' . filemtime(get_template_directory() . '/assets/css/wc-shop-panel-center-v181.css'));
    wp_enqueue_style('ku074-harmonica-reveal-v120', ku074_asset_uri('css/harmonica-reveal-v120.css'), array('ku074-wc-shop-panel-center-v181'), KU074_THEME_VERSION . '-' . filemtime(get_template_directory() . '/assets/css/harmonica-reveal-v120.css'));
    wp_enqueue_style('ku074-global-header-system-v126', ku074_asset_uri('css/global-header-system-v126.css'), array('ku074-harmonica-reveal-v120'), KU074_THEME_VERSION . '-' . filemtime(get_template_directory() . '/assets/css/global-header-system-v126.css'));
    wp_enqueue_style('ku074-fixed-header-menu-v127', ku074_asset_uri('css/fixed-header-menu-v127.css'), array('ku074-global-header-system-v126'), KU074_THEME_VERSION . '-' . filemtime(get_template_directory() . '/assets/css/fixed-header-menu-v127.css'));
    wp_enqueue_style('ku074-star-foldout-menu-v128', ku074_asset_uri('css/star-foldout-menu-v128.css'), array('ku074-fixed-header-menu-v127'), KU074_THEME_VERSION . '-' . filemtime(get_template_directory() . '/assets/css/star-foldout-menu-v128.css'));
    wp_enqueue_style('ku074-single-article-panel-v134', ku074_asset_uri('css/single-article-panel-v134.css'), array('ku074-star-foldout-menu-v128'), KU074_THEME_VERSION . '-' . filemtime(get_template_directory() . '/assets/css/single-article-panel-v134.css'));
    wp_enqueue_script('ku074-theme', ku074_asset_uri('js/theme.js'), array(), KU074_THEME_VERSION, true);
}

function ku074_wc_inline_viewport_lock() {
    $critical = get_template_directory() . '/assets/css/wc-viewport-lock-v16.css';
    if (file_exists($critical)) {
        echo '
<style id="ku074-wc-viewport-lock-inline">
' . file_get_contents($critical) . '
</style>
';
    }
}
add_action('wp_head', 'ku074_wc_inline_viewport_lock', 999);
add_action('wp_enqueue_scripts', 'ku074_enqueue_assets');

function ku074_widgets_init() {
    register_sidebar(array(
        'name'          => __('Footer Widgets', 'ku074'),
        'id'            => 'footer-widgets',
        'before_widget' => '<section class="footer-widget">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'ku074_widgets_init');

function ku074_ensure_categories() {
    $root = term_exists('074KU', 'category');
    if (!$root) {
        wp_insert_term('074KU', 'category', array('description' => 'OTAKU / STREET / SYSTEM'));
    }
    foreach (ku074_category_data() as $cat) {
        if (!term_exists($cat['label'], 'category')) {
            wp_insert_term($cat['label'], 'category', array(
                'slug' => $cat['slug'],
                'description' => $cat['desc'],
            ));
        }
    }
}
add_action('after_switch_theme', 'ku074_ensure_categories');


function ku074_account_url() {
    if (class_exists('WooCommerce') && function_exists('wc_get_page_id') && wc_get_page_id('myaccount') > 0) {
        return get_permalink(wc_get_page_id('myaccount'));
    }
    return admin_url('profile.php');
}

function ku074_register_url() {
    if (class_exists('WooCommerce') && function_exists('wc_get_page_id') && wc_get_page_id('myaccount') > 0) {
        return get_permalink(wc_get_page_id('myaccount'));
    }
    if (get_option('users_can_register')) {
        return wp_registration_url();
    }
    return wp_login_url() . '?action=register';
}

function ku074_category_link($slug) {
    $term = get_category_by_slug($slug);
    if ($term) {
        return get_category_link($term);
    }
    return home_url('/category/' . $slug . '/');
}



function ku074_header_menu_items() {
    $items = array();

    $current_url = '';
    if (!empty($_SERVER['REQUEST_URI'])) {
        $current_url = home_url(wp_unslash($_SERVER['REQUEST_URI']));
    }

    $items[] = array(
        'label' => 'Home',
        'url' => home_url('/'),
        'current' => is_front_page() || is_home(),
    );

    $shop_url = class_exists('WooCommerce') && function_exists('wc_get_page_id') && wc_get_page_id('shop') > 0
        ? get_permalink(wc_get_page_id('shop'))
        : home_url('/shop/');

    $items[] = array(
        'label' => 'Shop',
        'url' => $shop_url,
        'current' => function_exists('is_shop') && is_shop(),
    );

    foreach (ku074_category_data() as $cat) {
        $term = get_category_by_slug($cat['slug']);
        $is_current = false;

        if (is_category() && $term) {
            $queried = get_queried_object();
            $is_current = $queried && !empty($queried->term_id) && intval($queried->term_id) === intval($term->term_id);
        }

        if (is_singular('post') && $term) {
            $is_current = has_category($term->term_id, get_the_ID());
        }

        $items[] = array(
            'label' => $cat['label'],
            'url' => ku074_category_link($cat['slug']),
            'current' => $is_current,
        );
    }

    $streetwear_url = class_exists('WooCommerce') && function_exists('get_term_by')
        ? get_term_link('streetwear', 'product_cat')
        : home_url('/product-category/streetwear/');

    if (is_wp_error($streetwear_url)) {
        $streetwear_url = home_url('/product-category/streetwear/');
    }

    $items[] = array(
        'label' => 'Streetwear',
        'url' => $streetwear_url,
        'current' => function_exists('is_product_category') && is_product_category('streetwear'),
    );

    return apply_filters('ku074_header_menu_items', $items);
}

function ku074_excerpt($words = 22) {
    return wp_trim_words(get_the_excerpt() ?: wp_strip_all_tags(get_the_content()), $words, '…');
}

function ku074_category_object($slug_or_name) {
    foreach (ku074_category_data() as $cat) {
        if ($cat['slug'] === $slug_or_name || strtolower($cat['label']) === strtolower($slug_or_name)) {
            return $cat;
        }
    }
    return null;
}

function ku074_category_image_uri($slug = 'design-principles', $folder = 'heroes') {
    $cat = ku074_category_object($slug);
    $slug = $cat ? $cat['slug'] : 'design-principles';
    $folder = $folder === 'icons' ? 'icons' : 'heroes';
    return ku074_asset_uri('img/' . $folder . '/' . $slug . '.webp');
}

function ku074_post_category_slug($post_id = null) {
    $post_id = $post_id ?: get_the_ID();
    $supported = array_column(ku074_category_data(), 'slug');

    if (is_category()) {
        $queried = get_queried_object();
        if ($queried && !empty($queried->slug) && in_array($queried->slug, $supported, true) && has_category($queried->term_id, $post_id)) {
            return $queried->slug;
        }
    }

    $terms = get_the_terms($post_id, 'category');
    if (!empty($terms) && !is_wp_error($terms)) {
        foreach ($terms as $term) {
            if (in_array($term->slug, $supported, true)) {
                return $term->slug;
            }
        }
    }

    if (is_category()) {
        $queried = get_queried_object();
        if ($queried && !empty($queried->slug) && in_array($queried->slug, $supported, true)) {
            return $queried->slug;
        }
    }

    return 'design-principles';
}

function ku074_post_thumbnail_url($size = 'ku074-card', $post_id = null) {
    $post_id = $post_id ?: get_the_ID();
    if (has_post_thumbnail($post_id)) {
        return get_the_post_thumbnail_url($post_id, $size);
    }
    return ku074_category_image_uri(ku074_post_category_slug($post_id), 'heroes');
}

function ku074_body_classes($classes) {
    $classes[] = 'ku074-theme';
    return $classes;
}
add_filter('body_class', 'ku074_body_classes');

function ku074_customize_register($wp_customize) {
    $wp_customize->add_section('ku074_home', array(
        'title' => __('074KU Homepage', 'ku074'),
        'priority' => 30,
    ));
    $wp_customize->add_setting('ku074_hero_tagline', array(
        'default' => 'WE ARE LOYAL TO EACH OTHER, NOT TO THE SYSTEM.',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('ku074_hero_tagline', array(
        'label' => __('Hero tagline', 'ku074'),
        'section' => 'ku074_home',
        'type' => 'text',
    ));
}
add_action('customize_register', 'ku074_customize_register');

// WooCommerce wrappers.
remove_action('woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action('woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);
add_action('woocommerce_before_main_content', function () {
    echo '<main id="primary" class="site-main page-shell shop-shell"><div class="ku074-container">';
}, 10);
add_action('woocommerce_after_main_content', function () {
    echo '</div></main>';
}, 10);

/**
 * 074KU v1.3 WooCommerce shop enhancements.
 */
function ku074_wc_product_category_terms() {
    if (!taxonomy_exists('product_cat')) {
        return array();
    }
    $terms = get_terms(array(
        'taxonomy' => 'product_cat',
        'hide_empty' => true,
        'orderby' => 'name',
        'order' => 'ASC',
    ));
    return (!is_wp_error($terms) && is_array($terms)) ? $terms : array();
}

function ku074_shop_tools() {
    if (!function_exists('is_shop') || (!is_shop() && !is_product_taxonomy())) {
        return;
    }
    $terms = ku074_wc_product_category_terms();
    $shop_url = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : home_url('/shop/');
    ?>
    <section class="ku074-shop-tools" aria-label="<?php esc_attr_e('Shop tools', 'ku074'); ?>">
        <div class="ku074-shop-tools__mast">
            <span class="ku074-shop-tools__kicker">074KU SHOP SYSTEM</span>
            <strong><?php esc_html_e('Fold out, filter, move.', 'ku074'); ?></strong>
        </div>
        <div class="ku074-shop-accordions">
            <details class="ku074-foldout" open>
                <summary><?php esc_html_e('Categories', 'ku074'); ?></summary>
                <div class="ku074-filter-pills">
                    <a href="<?php echo esc_url($shop_url); ?>"><?php esc_html_e('All items', 'ku074'); ?></a>
                    <?php if ($terms) : ?>
                        <?php foreach ($terms as $term) : ?>
                            <a href="<?php echo esc_url(get_term_link($term)); ?>"><?php echo esc_html($term->name); ?></a>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <?php foreach (ku074_category_data() as $cat) : ?>
                            <a href="<?php echo esc_url(ku074_category_link($cat['slug'])); ?>" style="--accent: <?php echo esc_attr($cat['accent']); ?>"><?php echo esc_html($cat['label']); ?></a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </details>
            <details class="ku074-foldout">
                <summary><?php esc_html_e('Item type', 'ku074'); ?></summary>
                <div class="ku074-filter-pills ku074-filter-pills--quiet">
                    <?php foreach (array('T-shirts','Hoodies','Outerwear','Bottoms','Caps','Bags','Accessories','Stickers') as $type) : ?>
                        <span><?php echo esc_html($type); ?></span>
                    <?php endforeach; ?>
                </div>
            </details>
            <details class="ku074-foldout">
                <summary><?php esc_html_e('Quick help', 'ku074'); ?></summary>
                <p><?php esc_html_e('Use sorting above the grid. Open a product, then use previous / next product navigation to keep browsing without returning to the shop index.', 'ku074'); ?></p>
            </details>
        </div>
    </section>
    <?php
}
add_action('woocommerce_before_shop_loop', 'ku074_shop_tools', 4);

function ku074_single_product_nav() {
    if (!function_exists('is_product') || !is_product()) {
        return;
    }
    $prev = get_previous_post(false, '', 'product_cat');
    $next = get_next_post(false, '', 'product_cat');
    if (!$prev) {
        $prev = get_previous_post(false, '');
    }
    if (!$next) {
        $next = get_next_post(false, '');
    }
    if (!$prev && !$next) {
        return;
    }
    ?>
    <nav class="ku074-product-nav" aria-label="<?php esc_attr_e('Product navigation', 'ku074'); ?>">
        <div>
            <?php if ($prev) : ?>
                <a class="ku074-product-nav__link ku074-product-nav__link--prev" href="<?php echo esc_url(get_permalink($prev)); ?>">
                    <span>← <?php esc_html_e('Previous item', 'ku074'); ?></span>
                    <strong><?php echo esc_html(get_the_title($prev)); ?></strong>
                </a>
            <?php endif; ?>
        </div>
        <div>
            <?php if ($next) : ?>
                <a class="ku074-product-nav__link ku074-product-nav__link--next" href="<?php echo esc_url(get_permalink($next)); ?>">
                    <span><?php esc_html_e('Next item', 'ku074'); ?> →</span>
                    <strong><?php echo esc_html(get_the_title($next)); ?></strong>
                </a>
            <?php endif; ?>
        </div>
    </nav>
    <?php
}
add_action('woocommerce_after_single_product_summary', 'ku074_single_product_nav', 4);




function ku074_global_header_system_inline() {
    $critical = get_template_directory() . '/assets/css/global-header-system-v126.css';
    if (file_exists($critical)) {
        echo "\n<style id=\"ku074-global-header-system-inline\">\n" . file_get_contents($critical) . "\n</style>\n";
    }
}
add_action('wp_head', 'ku074_global_header_system_inline', 1002);


function ku074_fixed_header_menu_inline() {
    $critical = get_template_directory() . '/assets/css/fixed-header-menu-v127.css';
    if (file_exists($critical)) {
        echo "\n<style id=\"ku074-fixed-header-menu-inline\">\n" . file_get_contents($critical) . "\n</style>\n";
    }
}
add_action('wp_head', 'ku074_fixed_header_menu_inline', 1003);


function ku074_star_foldout_menu_inline() {
    $critical = get_template_directory() . '/assets/css/star-foldout-menu-v128.css';
    if (file_exists($critical)) {
        echo "\n<style id=\"ku074-star-foldout-menu-inline\">\n" . file_get_contents($critical) . "\n</style>\n";
    }
}
add_action('wp_head', 'ku074_star_foldout_menu_inline', 1004);




