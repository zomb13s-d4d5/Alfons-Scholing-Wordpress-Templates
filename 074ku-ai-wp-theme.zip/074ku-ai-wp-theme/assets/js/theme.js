(function(){
  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const toggle = document.querySelector('[data-menu-toggle]');
  const nav = document.querySelector('.primary-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function(){
      const open = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  function sliderStep(slider){
    const mode = slider.getAttribute('data-slider-step');
    let item = null;
    if (mode === 'nav') item = slider.querySelector('li');
    else if (mode === 'panel') item = slider.querySelector('.category-panel');
    else if (mode === 'icon') item = slider.querySelector('.category-icon');
    else item = slider.querySelector('.product, .post-card, .promo-poster, .ku-card, li');

    if (!item) return Math.max(240, Math.round(slider.clientWidth * 0.75));
    const rect = item.getBoundingClientRect();
    const styles = window.getComputedStyle(slider.querySelector('ul') || slider);
    const gap = parseFloat(styles.columnGap || styles.gap || '0') || 0;
    return Math.max(120, Math.round(rect.width + gap));
  }

  function updateOverflow(shell, slider){
    if (!shell || !slider) return;
    shell.classList.toggle('has-overflow', slider.scrollWidth > slider.clientWidth + 8);
    shell.classList.toggle('is-at-start', slider.scrollLeft <= 4);
    shell.classList.toggle('is-at-end', slider.scrollLeft + slider.clientWidth >= slider.scrollWidth - 8);
  }

  function moveSlider(slider, dir){
    const step = sliderStep(slider) * (dir || 1);
    const atEnd = slider.scrollLeft + slider.clientWidth >= slider.scrollWidth - Math.abs(step);
    const target = (dir > 0 && atEnd) ? 0 : Math.max(0, slider.scrollLeft + step);
    slider.scrollTo({ left: target, behavior: prefersReduced ? 'auto' : 'smooth' });
  }

  const sliders = Array.from(document.querySelectorAll('[data-ku-autoslider]')).filter(function(el){ return !el.closest('.ku074-star-menu__panel'); });
  sliders.forEach(function(slider, index){
    const shell = slider.closest('[data-ku-nav-shell]') || slider.closest('.ku074-slider-shell') || slider.closest('.nav-slider-wrap') || slider.parentElement;
    const loader = shell ? shell.querySelector('.ku074-slider-loader') : null;
    const prev = shell ? shell.querySelector('[data-ku-slider-prev]') : null;
    const nextBtn = shell ? shell.querySelector('[data-ku-slider-next]') : null;
    let paused = false;
    const speed = slider.classList.contains('nav-slider') ? 2500 : 3600;

    function setLoading(){
      if (!loader) return;
      loader.classList.remove('is-loading');
      void loader.offsetWidth;
      loader.classList.add('is-loading');
    }

    function tick(){
      updateOverflow(shell, slider);
      if (paused || slider.scrollWidth <= slider.clientWidth + 8) {
        setLoading();
        return;
      }
      moveSlider(slider, 1);
      setLoading();
      window.setTimeout(function(){ updateOverflow(shell, slider); }, 500);
    }

    if (prev) prev.addEventListener('click', function(){ paused = true; moveSlider(slider, -1); setLoading(); window.setTimeout(function(){ paused = false; }, 1600); });
    if (nextBtn) nextBtn.addEventListener('click', function(){ paused = true; moveSlider(slider, 1); setLoading(); window.setTimeout(function(){ paused = false; }, 1600); });

    slider.addEventListener('mouseenter', function(){ paused = true; });
    slider.addEventListener('mouseleave', function(){ paused = false; setLoading(); });
    slider.addEventListener('focusin', function(){ paused = true; });
    slider.addEventListener('focusout', function(){ paused = false; setLoading(); });
    slider.addEventListener('touchstart', function(){ paused = true; }, { passive:true });
    slider.addEventListener('touchend', function(){ window.setTimeout(function(){ paused = false; setLoading(); }, 1800); }, { passive:true });
    slider.addEventListener('scroll', function(){
      slider.classList.add('is-moving');
      updateOverflow(shell, slider);
      clearTimeout(slider._kuScrollStop);
      slider._kuScrollStop = setTimeout(function(){ slider.classList.remove('is-moving'); updateOverflow(shell, slider); }, 300);
    }, { passive:true });

    window.addEventListener('resize', function(){ updateOverflow(shell, slider); }, { passive:true });

    window.setTimeout(function(){ updateOverflow(shell, slider); setLoading(); }, 60 + index * 120);
    if (!prefersReduced) window.setInterval(tick, speed + (index * 130));
  });

  document.body.classList.remove('ku074-scrolled');
  document.documentElement.classList.add('ku074-no-collapse-header');
})();


/* 074KU v1.20.0: front-page harmonica scroll reveal */
(function(){
  const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const main = document.querySelector('body.home main#primary, body.front-page main#primary, main.site-main');
  if (!main) return;

  const revealTargets = Array.from(main.querySelectorAll(
    '.hero-system, main#primary > .ku074-container, main#primary > .resistance-strip, main#primary > .feature-row'
  ));

  if (!revealTargets.length) return;

  function prepareItems(section){
    const items = Array.from(section.querySelectorAll(
      '.category-panel, .category-icon, .post-card, .promo-poster, .feature-item, li.product, .product'
    ));
    items.forEach(function(item, index){
      item.style.setProperty('--ku-reveal-index', String(Math.min(index, 14)));
    });
  }

  revealTargets.forEach(function(section){
    section.classList.add('ku074-reveal');
    prepareItems(section);
  });

  if (reduce || !('IntersectionObserver' in window)) {
    revealTargets.forEach(function(section){ section.classList.add('is-visible'); });
    return;
  }

  const observer = new IntersectionObserver(function(entries){
    entries.forEach(function(entry){
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, {
    root: null,
    rootMargin: '0px 0px -12% 0px',
    threshold: 0.14
  });

  revealTargets.forEach(function(section, index){
    if (index === 0) {
      window.setTimeout(function(){ section.classList.add('is-visible'); }, 120);
    } else {
      observer.observe(section);
    }
  });
})();



/* 074KU v1.33.0: anchor star menu enhancer only; opening works without JS */
(function(){
  function initKu074AnchorStarMenu(){
    const panel = document.querySelector('[data-ku-star-menu-panel]');
    const openLink = document.querySelector('[data-ku-star-menu-anchor]');
    if (!panel || !openLink || panel.dataset.kuAnchorReady === '1') return;
    panel.dataset.kuAnchorReady = '1';

    Array.from(panel.querySelectorAll('.ku074-star-menu__list > li')).forEach(function(item, index){
      item.style.setProperty('--ku-star-index', String(Math.min(index, 18)));
    });

    openLink.addEventListener('click', function(){
      window.setTimeout(function(){ panel.focus({preventScroll:true}); }, 40);
    });

    document.addEventListener('keydown', function(event){
      if (event.key === 'Escape' && window.location.hash === '#ku074-star-menu-panel') {
        window.location.hash = '#ku074-star-menu';
        openLink.focus();
      }
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initKu074AnchorStarMenu);
  else initKu074AnchorStarMenu();
  window.addEventListener('load', initKu074AnchorStarMenu);
})();

