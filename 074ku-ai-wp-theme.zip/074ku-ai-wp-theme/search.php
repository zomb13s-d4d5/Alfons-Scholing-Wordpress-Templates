<?php get_header(); ?>
<main id="primary" class="site-main page-shell">
    <div class="ku074-container">
        <header class="archive-header">
            <h1 class="page-title"><?php printf(esc_html__('Search: %s', 'ku074'), esc_html(get_search_query())); ?></h1>
            <?php get_search_form(); ?>
        </header>
        <?php if (have_posts()) : ?>
            <div class="post-grid">
                <?php while (have_posts()) : the_post(); get_template_part('template-parts/card', 'post'); endwhile; ?>
            </div>
            <?php the_posts_navigation(); ?>
        <?php else : ?>
            <p><?php esc_html_e('No matching results.', 'ku074'); ?></p>
        <?php endif; ?>
    </div>
</main>
<?php get_footer(); ?>
