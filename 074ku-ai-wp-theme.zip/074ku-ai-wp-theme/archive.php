<?php get_header(); ?>
<main id="primary" class="site-main page-shell">
    <div class="ku074-container">
        <header class="archive-header">
            <h1 class="page-title"><?php the_archive_title(); ?></h1>
            <?php the_archive_description('<p>', '</p>'); ?>
        </header>
        <?php if (have_posts()) : ?>
            <div class="post-grid">
                <?php while (have_posts()) : the_post(); get_template_part('template-parts/card', 'post'); endwhile; ?>
            </div>
            <?php the_posts_navigation(); ?>
        <?php else : ?>
            <p><?php esc_html_e('No entries yet. The system is warming up.', 'ku074'); ?></p>
        <?php endif; ?>
    </div>
</main>
<?php get_footer(); ?>
