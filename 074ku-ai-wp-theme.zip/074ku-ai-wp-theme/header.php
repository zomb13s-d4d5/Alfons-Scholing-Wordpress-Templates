<?php
/** Theme header. */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class('ku074-header-integrated'); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text" href="#primary"><?php esc_html_e('Skip to content', 'ku074'); ?></a>

<header class="site-header site-header--integrated ku074-main-header">
    <div class="ku074-container site-header__main ku074-main-header__grid">
        <a class="site-branding ku074-main-header__brand" href="<?php echo esc_url(home_url('/')); ?>" rel="home" aria-label="<?php bloginfo('name'); ?>">
            <?php if (has_custom_logo()) : ?>
                <?php the_custom_logo(); ?>
            <?php else : ?>
                <span class="site-wordmark">074<span class="ku">KU</span>.ai</span>
            <?php endif; ?>
            <span class="site-subtitle"><?php esc_html_e('Socialist Otaku Street System', 'ku074'); ?><br><span lang="ja">社会主義・オタク・ストリート・システム</span></span>
        </a>

        <div class="header-actions ku074-main-header__actions" aria-label="<?php esc_attr_e('Shop and account menu', 'ku074'); ?>">
            <a class="header-actions__search" href="<?php echo esc_url(home_url('/?s=')); ?>" aria-label="<?php esc_attr_e('Search', 'ku074'); ?>">⌕</a>
            <?php if (is_user_logged_in()) : ?>
                <a href="<?php echo esc_url(ku074_account_url()); ?>"><?php esc_html_e('Account', 'ku074'); ?></a>
            <?php else : ?>
                <a href="<?php echo esc_url(wp_login_url()); ?>"><?php esc_html_e('Login', 'ku074'); ?></a>
                <a href="<?php echo esc_url(ku074_register_url()); ?>"><?php esc_html_e('Register', 'ku074'); ?></a>
            <?php endif; ?>
            <?php if (class_exists('WooCommerce')) : ?>
                <a href="<?php echo esc_url(wc_get_cart_url()); ?>"><?php esc_html_e('Cart', 'ku074'); ?></a>
            <?php else : ?>
                <a href="<?php echo esc_url(home_url('/cart/')); ?>"><?php esc_html_e('Cart', 'ku074'); ?></a>
            <?php endif; ?>
        </div>

        <nav id="ku074-star-menu" class="ku074-main-header__nav ku074-star-menu" aria-label="<?php esc_attr_e('Primary menu', 'ku074'); ?>">
            <a class="ku074-star-menu__button" href="#ku074-star-menu-panel" data-ku-star-menu-anchor aria-controls="ku074-star-menu-panel">
                <img src="<?php echo esc_url(ku074_asset_uri('img/menu-star-skull-100.webp')); ?>" alt="" width="50" height="50" loading="eager" decoding="async">
                <span class="screen-reader-text"><?php esc_html_e('Open menu', 'ku074'); ?></span>
            </a>

            <div id="ku074-star-menu-panel" class="ku074-star-menu__panel" data-ku-star-menu-panel tabindex="-1">
                <div class="ku074-star-menu__panel-inner">
                    <div class="ku074-star-menu__mast">
                        <span><?php esc_html_e('074KU SYSTEM MENU', 'ku074'); ?></span>
                        <a class="ku074-star-menu__close" href="#ku074-star-menu" data-ku-star-menu-close aria-label="<?php esc_attr_e('Close menu', 'ku074'); ?>">×</a>
                    </div>
                    <?php
                    $header_items = ku074_header_menu_items();
                    echo '<ul class="ku074-star-menu__list">';
                    foreach ($header_items as $item) {
                        $classes = array();
                        if (!empty($item['current'])) {
                            $classes[] = 'current-menu-item';
                        }
                        printf(
                            '<li class="%s"><a href="%s">%s</a></li>',
                            esc_attr(implode(' ', $classes)),
                            esc_url($item['url']),
                            esc_html($item['label'])
                        );
                    }
                    echo '</ul>';
                    ?>
                </div>
            </div>
        </nav>
    </div>
</header>


<?php if (!is_front_page()) : ?>
<?php
    $blast_title = get_bloginfo('name');
    $blast_kicker = __('OTAKU STREET SYSTEM', 'ku074');
    $blast_note = __('Poster culture / manga energy / anti system graphics', 'ku074');

    if (function_exists('is_shop') && is_shop()) {
        $blast_title = __('074KU SHOP SYSTEM', 'ku074');
        $blast_kicker = __('Streetwear / Prints / Gear', 'ku074');
        $blast_note = __('Fold out / filter / move / collect', 'ku074');
    } elseif (function_exists('is_product') && is_product()) {
        $blast_title = __('PRODUCT LOADOUT', 'ku074');
        $blast_kicker = get_the_title();
        $blast_note = __('Graphic object / wearable poster / anti system goods', 'ku074');
    } elseif (is_archive()) {
        $blast_title = wp_strip_all_tags(get_the_archive_title());
        $blast_kicker = __('Category Broadcast', 'ku074');
        $blast_note = __('Field notes / category system / visual resistance', 'ku074');
    } elseif (is_singular('post')) {
        $blast_title = __('074KU FIELD NOTE', 'ku074');
        $blast_kicker = get_the_title();
        $blast_note = __('Editorial system / category archive / design note', 'ku074');
    } elseif (is_page()) {
        $blast_title = get_the_title();
        $blast_kicker = __('074KU PAGE SYSTEM', 'ku074');
        $blast_note = __('Culture / utility / visual communication', 'ku074');
    }
?>
<section class="ku074-header-blast" aria-label="<?php esc_attr_e('Header graphic', 'ku074'); ?>">
    <div class="ku074-container">
        <div class="ku074-header-blast__inner">
            <div class="ku074-header-blast__copy">
                <span class="ku074-header-blast__eyebrow"><?php echo esc_html($blast_kicker); ?></span>
                <h1 class="ku074-header-blast__title"><?php echo esc_html($blast_title); ?></h1>
                <p class="ku074-header-blast__note"><?php echo esc_html($blast_note); ?></p>
                <div class="ku074-header-blast__tags">
                    <span><?php esc_html_e('Graffiti', 'ku074'); ?></span>
                    <span><?php esc_html_e('Manga', 'ku074'); ?></span>
                    <span><?php esc_html_e('Street System', 'ku074'); ?></span>
                </div>
            </div>
            <div class="ku074-header-blast__art" aria-hidden="true">
                <span class="ku074-header-blast__poster ku074-header-blast__poster--a" style="background-image:url('<?php echo esc_url(ku074_asset_uri('img/heroes/punk.webp')); ?>')"></span>
                <span class="ku074-header-blast__poster ku074-header-blast__poster--b" style="background-image:url('<?php echo esc_url(ku074_asset_uri('img/heroes/bmx.webp')); ?>')"></span>
                <span class="ku074-header-blast__poster ku074-header-blast__poster--c" style="background-image:url('<?php echo esc_url(ku074_asset_uri('img/heroes/android.webp')); ?>')"></span>
                <span class="ku074-header-blast__stamp">ANTI<br>SYSTEM</span>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

