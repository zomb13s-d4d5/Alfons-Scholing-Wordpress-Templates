<?php get_header(); ?>
<main id="primary" class="site-main page-shell">
    <div class="ku074-container">
        <?php while (have_posts()) : the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <header class="single-header">
                    <div><?php echo esc_html(get_the_date()); ?> · <?php the_category(' / '); ?></div>
                    <h1 class="entry-title"><?php the_title(); ?></h1>
                    <?php if (has_excerpt()) : ?><p><?php echo esc_html(get_the_excerpt()); ?></p><?php endif; ?>
                </header>
                <figure class="single-featured">
                    <?php if (has_post_thumbnail()) : ?>
                        <?php the_post_thumbnail('full'); ?>
                    <?php else : ?>
                        <img src="<?php echo esc_url(ku074_post_thumbnail_url('full', get_the_ID())); ?>" alt="<?php the_title_attribute(); ?>">
                    <?php endif; ?>
                </figure>
                <div class="entry-content">
                    <?php the_content(); ?>
                    <?php wp_link_pages(array('before' => '<div class="page-links">', 'after' => '</div>')); ?>
                </div>
                <footer class="entry-footer">
                    <?php the_tags('<p class="post-tags">', ' ', '</p>'); ?>
                </footer>
            </article>
            <?php the_post_navigation(); ?>
            <?php if (comments_open() || get_comments_number()) { comments_template(); } ?>
        <?php endwhile; ?>
    </div>
</main>
<?php get_footer(); ?>
