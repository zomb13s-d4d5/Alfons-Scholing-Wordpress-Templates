<form role="search" method="get" class="search-form ku074-search-form" action="<?php echo esc_url(home_url('/')); ?>">
    <label class="screen-reader-text" for="s"><?php esc_html_e('Search for:', 'ku074'); ?></label>
    <input type="search" id="s" name="s" value="<?php echo get_search_query(); ?>" placeholder="<?php esc_attr_e('Search the system', 'ku074'); ?>">
    <button type="submit">→</button>
</form>
