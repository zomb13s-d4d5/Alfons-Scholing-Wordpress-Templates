<?php get_header(); ?>
<main id="primary" class="site-main page-shell">
    <div class="ku074-container">
        <?php while (have_posts()) : the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <header class="single-header">
                    <h1 class="entry-title"><?php the_title(); ?></h1>
                </header>
                <?php if (has_post_thumbnail()) : ?>
                    <figure class="single-featured"><?php the_post_thumbnail('full'); ?></figure>
                <?php endif; ?>
                <div class="entry-content">
                    <?php the_content(); ?>
                    <?php wp_link_pages(array('before' => '<div class="page-links">', 'after' => '</div>')); ?>
                </div>
            </article>
            <?php if (comments_open() || get_comments_number()) { comments_template(); } ?>
        <?php endwhile; ?>
    </div>
</main>
<?php get_footer(); ?>
