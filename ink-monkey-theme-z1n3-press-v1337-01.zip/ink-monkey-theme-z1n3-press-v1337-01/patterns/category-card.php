<?php
/**
 * Title: Z1N3 Category Intro
 * Slug: z1n3-press/category-intro
 * Categories: featured
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">
	<!-- wp:paragraph {"textColor":"accent","style":{"typography":{"fontFamily":"var:preset|font-family|ui-mono","textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
	<p class="has-accent-color has-text-color" style="font-family:var(--wp--preset--font-family--ui-mono);text-transform:uppercase;letter-spacing:0.08em">REC • category</p>
	<!-- /wp:paragraph -->
	<!-- wp:query-title {"type":"archive"} /-->
</div>
<!-- /wp:group -->
