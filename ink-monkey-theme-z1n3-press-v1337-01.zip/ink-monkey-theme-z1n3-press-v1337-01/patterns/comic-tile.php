<?php
/**
 * Title: Z1N3 Comic Tile
 * Slug: z1n3-press/comic-tile
 * Categories: posts
 */
?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"12px","right":"12px","bottom":"16px","left":"12px"}},"border":{"radius":"18px","color":"var:preset|color|border","width":"1px"}},"backgroundColor":"surface-2","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-surface-2-background-color has-background" style="border-color:var(--wp--preset--color--border);border-width:1px;border-radius:18px;padding-top:12px;padding-right:12px;padding-bottom:16px;padding-left:12px">
	<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"3/4"} /-->
	<!-- wp:post-title {"isLink":true,"level":3} /-->
	<!-- wp:post-date {"textColor":"text-3"} /-->
</div>
<!-- /wp:group -->
