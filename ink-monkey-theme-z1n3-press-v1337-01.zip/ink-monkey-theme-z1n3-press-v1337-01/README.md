# Ink Monkey Theme Z1N3 Press v1337-01

A complete new WordPress block theme/template for z1n3.press based on the existing z1n3.press Inkmonkey theme, rebuilt around the approved black-and-white concept direction.

## Production pass: 1337-01

- Theme name: **Ink Monkey Theme Z1N3 Press v1337-01**
- Version: **1337.01**
- iOS-first viewport layout
- Homepage hero with black gradient fade overlays
- Latest article cards with centered navigation underneath
- Tiny monkey/skull logo bullets for pagination and navigation markers
- Snappy full-screen overlay menu with large responsive tiles
- Category/archive slider page
- Single post page with hero, comments preview, gallery strip, and next-story card
- Lightbox/gallery slider retains slow / medium / fast slider controls
- Comments are forced open for posts by theme filter

Install this ZIP in WordPress via Appearance → Themes → Add New → Upload Theme.
