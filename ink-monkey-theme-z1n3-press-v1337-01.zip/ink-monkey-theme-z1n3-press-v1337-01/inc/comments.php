<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function z1n3_press_comment_form_defaults( $defaults ) {
	$defaults['class_form']         = trim( ( $defaults['class_form'] ?? '' ) . ' z1n3-comment-form' );
	$defaults['class_submit']       = 'wp-element-button z1n3-comment-submit';
	$defaults['title_reply_before'] = '<h3 id="reply-title" class="comment-reply-title z1n3-comments__title">';
	$defaults['title_reply_after']  = '</h3>';
	$defaults['comment_notes_before'] = '<p class="z1n3-comments__note">' . esc_html__( 'Your email address will not be published.', 'z1n3-press' ) . '</p>';
	$defaults['comment_field'] = '<p class="comment-form-comment"><label for="comment">' . esc_html__( 'Comment', 'z1n3-press' ) . '</label><textarea id="comment" name="comment" cols="45" rows="6" maxlength="65525" required="required"></textarea></p>';
	$defaults['label_submit'] = esc_html__( 'Post comment', 'z1n3-press' );
	return $defaults;
}
add_filter( 'comment_form_defaults', 'z1n3_press_comment_form_defaults' );

function z1n3_press_comment_fields( $fields ) {
	$commenter = wp_get_current_commenter();
	$req       = get_option( 'require_name_email' );
	$aria_req  = $req ? " aria-required='true' required='required'" : '';

	$fields['author'] = '<p class="comment-form-author"><label for="author">' . esc_html__( 'Name', 'z1n3-press' ) . '</label><input id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ?? '' ) . '" size="30" maxlength="245"' . $aria_req . ' /></p>';
	$fields['email']  = '<p class="comment-form-email"><label for="email">' . esc_html__( 'Email', 'z1n3-press' ) . '</label><input id="email" name="email" type="email" value="' . esc_attr( $commenter['comment_author_email'] ?? '' ) . '" size="30" maxlength="100"' . $aria_req . ' /></p>';
	$fields['url']    = '<p class="comment-form-url"><label for="url">' . esc_html__( 'Website', 'z1n3-press' ) . '</label><input id="url" name="url" type="url" value="' . esc_attr( $commenter['comment_author_url'] ?? '' ) . '" size="30" maxlength="200" /></p>';

	return $fields;
}
add_filter( 'comment_form_default_fields', 'z1n3_press_comment_fields' );

function z1n3_press_comment_markup( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	?>
	<li <?php comment_class( 'z1n3-comment-card' ); ?> id="comment-<?php comment_ID(); ?>">
		<article class="z1n3-comment-card__inner">
			<header class="z1n3-comment-card__header">
				<div>
					<h4 class="z1n3-comment-card__author"><?php comment_author_link(); ?></h4>
					<p class="z1n3-comment-card__meta">
						<a href="<?php echo esc_url( get_comment_link( $comment ) ); ?>">
							<time datetime="<?php comment_time( 'c' ); ?>"><?php printf( esc_html__( '%1$s at %2$s', 'z1n3-press' ), esc_html( get_comment_date( '', $comment ) ), esc_html( get_comment_time( '', $comment ) ) ); ?></time>
						</a>
					</p>
				</div>
				<?php edit_comment_link( esc_html__( 'Edit', 'z1n3-press' ), '<span class="z1n3-comment-card__edit">', '</span>' ); ?>
			</header>

			<?php if ( '0' === $comment->comment_approved ) : ?>
				<p class="z1n3-comments__note"><?php esc_html_e( 'Your comment is awaiting moderation.', 'z1n3-press' ); ?></p>
			<?php endif; ?>

			<div class="z1n3-comment-card__content">
				<?php comment_text(); ?>
			</div>

			<div class="z1n3-comment-card__reply">
				<?php comment_reply_link( array_merge( $args, array(
					'depth'     => $depth,
					'max_depth' => $args['max_depth'],
					'reply_text'=> esc_html__( 'Reply', 'z1n3-press' ),
				) ) ); ?>
			</div>
		</article>
	<?php
}

function z1n3_press_render_recent_comments( $count = 5 ) {
	$comments = get_comments( array(
		'status'  => 'approve',
		'number'  => absint( $count ),
		'type'    => 'comment',
	) );

	ob_start();
	?>
	<section class="z1n3-comments-latest">
		<div class="z1n3-comments-latest__header">
			<p class="z1n3-comments__eyebrow"><?php esc_html_e( 'Across the site', 'z1n3-press' ); ?></p>
			<h3 class="z1n3-comments__title"><?php esc_html_e( 'Latest comments', 'z1n3-press' ); ?></h3>
		</div>
		<?php if ( empty( $comments ) ) : ?>
			<p class="z1n3-comments__empty"><?php esc_html_e( 'No comments yet. Be the first to start the conversation.', 'z1n3-press' ); ?></p>
		<?php else : ?>
			<ul class="z1n3-comments-latest__list">
				<?php foreach ( $comments as $comment ) : ?>
					<li class="z1n3-comments-latest__item">
						<a class="z1n3-comments-latest__link" href="<?php echo esc_url( get_comment_link( $comment ) ); ?>">
							<span class="z1n3-comments-latest__author"><?php echo esc_html( get_comment_author( $comment ) ); ?></span>
							<span class="z1n3-comments-latest__post"><?php echo esc_html( get_the_title( $comment->comment_post_ID ) ); ?></span>
							<span class="z1n3-comments-latest__excerpt"><?php echo esc_html( wp_html_excerpt( wp_strip_all_tags( $comment->comment_content ), 120, '…' ) ); ?></span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</section>
	<?php
	return ob_get_clean();
}

function z1n3_press_comments_shortcode() {
	if ( ! is_singular() ) {
		return '';
	}

	global $post;
	if ( ! $post instanceof WP_Post ) {
		return '';
	}

	if ( post_password_required( $post ) ) {
		return '';
	}

	if ( ! comments_open( $post ) && ! get_comments_number( $post ) ) {
		return z1n3_press_render_recent_comments();
	}

	ob_start();
	?>
	<section class="z1n3-comments-shell">
		<div class="z1n3-comments-card">
			<div class="z1n3-comments-card__header">
				<p class="z1n3-comments__eyebrow"><?php esc_html_e( 'Discussion', 'z1n3-press' ); ?></p>
				<h2 class="z1n3-comments__title"><?php comments_number( esc_html__( 'Leave a comment', 'z1n3-press' ), esc_html__( '1 Comment', 'z1n3-press' ), esc_html__( '% Comments', 'z1n3-press' ) ); ?></h2>
			</div>

			<?php if ( have_comments() ) : ?>
				<ol class="z1n3-comment-list">
					<?php wp_list_comments( array(
						'style'      => 'ol',
						'short_ping' => true,
						'avatar_size'=> 0,
						'callback'   => 'z1n3_press_comment_markup',
					) ); ?>
				</ol>
				<?php the_comments_pagination( array(
					'prev_text' => esc_html__( 'Older comments', 'z1n3-press' ),
					'next_text' => esc_html__( 'Newer comments', 'z1n3-press' ),
				) ); ?>
			<?php else : ?>
				<p class="z1n3-comments__empty"><?php esc_html_e( 'No comments yet. Be the first to start the conversation.', 'z1n3-press' ); ?></p>
			<?php endif; ?>

			<?php if ( comments_open( $post ) ) : ?>
				<div class="z1n3-comments-form-wrap">
					<?php comment_form( array( 'title_reply' => esc_html__( 'Add your voice', 'z1n3-press' ) ) ); ?>
				</div>
			<?php endif; ?>
		</div>

		<?php echo z1n3_press_render_recent_comments(); ?>
	</section>
	<?php
	return ob_get_clean();
}
add_shortcode( 'z1n3_comments_section', 'z1n3_press_comments_shortcode' );

function z1n3_press_force_post_comments_open( $open, $post_id ) {
	$post = get_post( $post_id );
	if ( $post instanceof WP_Post && 'post' === $post->post_type ) {
		return true;
	}
	return $open;
}
add_filter( 'comments_open', 'z1n3_press_force_post_comments_open', 10, 2 );
