<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function z1n3_press_category_image_url( $term_id ) {
	$q = new WP_Query( array(
		'post_type'           => 'post',
		'posts_per_page'      => 1,
		'ignore_sticky_posts' => true,
		'cat'                 => intval( $term_id ),
		'meta_query'          => array(
			array(
				'key'     => '_thumbnail_id',
				'compare' => 'EXISTS',
			),
		),
	) );

	if ( $q->have_posts() ) {
		$q->the_post();
		$img = get_the_post_thumbnail_url( get_the_ID(), 'z1n3-card' );
		wp_reset_postdata();
		if ( $img ) {
			return $img;
		}
	}

	wp_reset_postdata();
	return z1n3_press_fallback_thumbnail();
}

function z1n3_press_category_grid_shortcode() {
	$terms = get_categories( array(
		'hide_empty' => true,
		'orderby'    => 'count',
		'order'      => 'DESC',
	) );

	if ( empty( $terms ) ) {
		return '<p>' . esc_html__( 'No categories yet.', 'z1n3-press' ) . '</p>';
	}

	ob_start();
	echo '<section class="z1n3-slider z1n3-category-slider" data-z1n3-slider data-autoplay="true" data-autoplay-delay="2800" aria-label="' . esc_attr__( 'Categories', 'z1n3-press' ) . '">';
	echo '<div class="z1n3-slider__head">';
	echo '<p class="z1n3-slider__eyebrow">' . esc_html__( 'Category slider', 'z1n3-press' ) . '</p>';
	echo '<div class="z1n3-slider__controls">';
	echo '<button type="button" class="z1n3-slider__button" data-z1n3-prev aria-label="' . esc_attr__( 'Previous categories', 'z1n3-press' ) . '">‹</button>';
	echo '<button type="button" class="z1n3-slider__button" data-z1n3-next aria-label="' . esc_attr__( 'Next categories', 'z1n3-press' ) . '">›</button>';
	echo '</div>';
	echo '</div>';
	echo '<div class="z1n3-slider__viewport" data-z1n3-viewport><div class="z1n3-slider__track">';
	foreach ( $terms as $term ) {
		$link   = get_category_link( $term );
		$count  = intval( $term->count );
		$bg_url = z1n3_press_category_image_url( $term->term_id );
		$style  = $bg_url ? '--z-card-bg:url(' . esc_url( $bg_url ) . ');' : '';
		echo '<a class="z1n3-category-card z1n3-slider__slide" href="' . esc_url( $link ) . '" style="' . esc_attr( $style ) . '">';
		echo '<span class="z1n3-category-card__meta">REC • ' . esc_html( strtoupper( $term->slug ) ) . '</span>';
		echo '<strong class="z1n3-category-card__title">' . esc_html( $term->name ) . '</strong>';
		echo '<span class="z1n3-category-card__count">' . esc_html( sprintf( _n( '%s comic', '%s comics', $count, 'z1n3-press' ), number_format_i18n( $count ) ) ) . '</span>';
		echo '</a>';
	}
	echo '</div></div>';
	echo '<div class="z1n3-slider__footer z1n3-slider__footer--center">';
	echo '<button type="button" class="z1n3-slider__button is-wide" data-z1n3-prev aria-label="' . esc_attr__( 'Previous categories', 'z1n3-press' ) . '">‹</button>';
	echo '<div class="z1n3-slider__pager"><div class="z1n3-slider__dots" data-z1n3-dots aria-label="' . esc_attr__( 'Category pages', 'z1n3-press' ) . '"></div><span class="z1n3-slider__status" data-z1n3-status>1 / 1</span></div>';
	echo '<button type="button" class="z1n3-slider__button is-wide" data-z1n3-next aria-label="' . esc_attr__( 'Next categories', 'z1n3-press' ) . '">›</button>';
	echo '</div>';
	echo '</section>';
	return ob_get_clean();
}
add_shortcode( 'z1n3_category_grid', 'z1n3_press_category_grid_shortcode' );

function z1n3_press_reader_nav_shortcode() {
	if ( ! is_single() ) {
		return '';
	}
	$cats    = get_the_category( get_the_ID() );
	$prev    = get_previous_post( true, '', 'category' );
	$next    = get_next_post( true, '', 'category' );
	$current = ! empty( $cats ) ? $cats[0]->name : __( 'All posts', 'z1n3-press' );

	ob_start();
	echo '<nav class="z1n3-reader-nav" aria-label="' . esc_attr__( 'Comic navigation', 'z1n3-press' ) . '">';
	echo '<span class="z1n3-reader-nav__label">' . esc_html( $current ) . '</span>';

	if ( $prev ) {
		echo '<a class="z1n3-reader-nav__button is-prev" href="' . esc_url( get_permalink( $prev ) ) . '" rel="prev" data-reader-prev="1">← ' . esc_html( get_the_title( $prev ) ) . '</a>';
	} else {
		echo '<span class="z1n3-reader-nav__button is-disabled">← ' . esc_html__( 'Start of category', 'z1n3-press' ) . '</span>';
	}

	if ( $next ) {
		echo '<a class="z1n3-reader-nav__button is-next" href="' . esc_url( get_permalink( $next ) ) . '" rel="next" data-reader-next="1">' . esc_html( get_the_title( $next ) ) . ' →</a>';
	} else {
		echo '<span class="z1n3-reader-nav__button is-disabled">' . esc_html__( 'End of category', 'z1n3-press' ) . ' →</span>';
	}
	echo '</nav>';
	return ob_get_clean();
}
add_shortcode( 'z1n3_reader_nav', 'z1n3_press_reader_nav_shortcode' );

function z1n3_press_post_tile_shortcode( $atts ) {
	$atts = shortcode_atts( array(
		'count' => 12,
	), $atts, 'z1n3_post_tiles' );

	$q = new WP_Query( array(
		'post_type'           => 'post',
		'posts_per_page'      => absint( $atts['count'] ),
		'ignore_sticky_posts' => true,
	) );

	if ( ! $q->have_posts() ) {
		return '';
	}

	ob_start();
	echo '<section class="z1n3-slider z1n3-post-slider" data-z1n3-slider data-autoplay="true" data-autoplay-delay="3600" aria-label="' . esc_attr__( 'Latest comics', 'z1n3-press' ) . '">';
	echo '<div class="z1n3-slider__viewport" data-z1n3-viewport><div class="z1n3-slider__track">';
	while ( $q->have_posts() ) {
		$q->the_post();
		$thumb = get_the_post_thumbnail_url( get_the_ID(), 'z1n3-card' );
		if ( ! $thumb ) {
			$thumb = z1n3_press_fallback_thumbnail();
		}
		echo '<article class="z1n3-post-tile z1n3-slider__slide">';
		echo '<a class="z1n3-post-tile__image" href="' . esc_url( get_permalink() ) . '"><img src="' . esc_url( $thumb ) . '" alt="" loading="lazy" decoding="async"></a>';
		echo '<div class="z1n3-post-tile__body">';
		echo '<span class="z1n3-post-tile__date">' . esc_html( get_the_date() ) . '</span>';
		echo '<h3><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h3>';
		echo '<a class="z1n3-post-tile__readmore" href="' . esc_url( get_permalink() ) . '">' . esc_html__( 'Read more', 'z1n3-press' ) . '</a>';
		echo '</div>';
		echo '</article>';
	}
	wp_reset_postdata();
	echo '</div></div>';
	echo '<div class="z1n3-slider__footer z1n3-slider__footer--center">';
	echo '<button type="button" class="z1n3-slider__button is-wide" data-z1n3-prev aria-label="' . esc_attr__( 'Previous posts', 'z1n3-press' ) . '">‹</button>';
	echo '<div class="z1n3-slider__pager"><div class="z1n3-slider__dots" data-z1n3-dots aria-label="' . esc_attr__( 'Article pages', 'z1n3-press' ) . '"></div><span class="z1n3-slider__status" data-z1n3-status>1 / 1</span></div>';
	echo '<button type="button" class="z1n3-slider__button is-wide" data-z1n3-next aria-label="' . esc_attr__( 'Next posts', 'z1n3-press' ) . '">›</button>';
	echo '<a class="z1n3-read-more-articles" href="' . esc_url( function_exists( 'z1n3_ink_posts_index_url' ) ? z1n3_ink_posts_index_url( 2 ) : home_url( '/page/2/' ) ) . '">' . esc_html__( 'Read more articles', 'z1n3-press' ) . '</a>';
	echo '</div>';
	echo '</section>';
	return ob_get_clean();
}
add_shortcode( 'z1n3_post_tiles', 'z1n3_press_post_tile_shortcode' );

function z1n3_press_footer_network_links() {
	$raw = (string) get_theme_mod( 'z1n3_press_footer_network_links', '' );
	$lines = preg_split( '/\r\n|\r|\n/', $raw );
	$links = array();

	foreach ( $lines as $line ) {
		$line = trim( $line );
		if ( ! $line || strpos( $line, '|' ) === false ) {
			continue;
		}
		list( $label, $url ) = array_map( 'trim', explode( '|', $line, 2 ) );
		$url = esc_url_raw( $url );
		if ( $label && $url ) {
			$links[] = array( 'label' => $label, 'url' => $url );
		}
	}

	return $links;
}

function z1n3_press_footer_meta_shortcode() {
	$logo = get_template_directory_uri() . '/assets/img/logo-user-supplied.webp';
	$terms = get_categories( array(
		'hide_empty' => true,
		'orderby'    => 'count',
		'order'      => 'DESC',
		'number'     => 8,
	) );

	$post_count = wp_count_posts( 'post' );
	$published  = isset( $post_count->publish ) ? intval( $post_count->publish ) : 0;
	$updated    = get_posts( array(
		'post_type'      => 'post',
		'posts_per_page' => 1,
		'post_status'    => 'publish',
		'orderby'        => 'modified',
		'order'          => 'DESC',
		'fields'         => 'ids',
	) );
	$about = trim( wp_strip_all_tags( (string) get_theme_mod( 'z1n3_press_footer_about', '' ) ) );
	if ( '' === $about ) {
		$about = get_bloginfo( 'description' ) ?: __( 'A category-first comics reader with a cinematic background system and compact archive browsing.', 'z1n3-press' );
	}
	$network_links = z1n3_press_footer_network_links();

	ob_start();
	echo '<div class="z1n3-footer-intro">';
	echo '<p class="z1n3-footer-intro__eyebrow">REC • CATEGORY-FIRST READER</p>';
	echo '<h2 class="z1n3-footer-intro__title">' . esc_html( get_bloginfo( 'name' ) ) . '</h2>';
	echo '<p class="z1n3-footer-intro__text">A tighter mobile-first dark theme for comics, sequential art, and category-led reading with rotating backgrounds and compact browsing.</p>';
	echo '</div>';
	echo '<div class="z1n3-footer-meta">';
	echo '<div class="z1n3-footer-meta__mark"><img src="' . esc_url( $logo ) . '" alt="" width="148" height="148" decoding="async"></div>';

	echo '<div class="z1n3-footer-meta__group">';
	echo '<span class="z1n3-footer-meta__label">' . esc_html__( 'About', 'z1n3-press' ) . '</span>';
	echo '<div class="z1n3-footer-meta__text"><span>' . esc_html( $about ) . '</span></div>';
	echo '</div>';

	echo '<div class="z1n3-footer-meta__group">';
	echo '<span class="z1n3-footer-meta__label">' . esc_html__( 'Categories', 'z1n3-press' ) . '</span>';
	echo '<div class="z1n3-footer-meta__links">';
	foreach ( $terms as $term ) {
		echo '<a href="' . esc_url( get_category_link( $term ) ) . '">' . esc_html( $term->name ) . '</a>';
	}
	echo '</div>';
	echo '</div>';

	echo '<div class="z1n3-footer-meta__group">';
	echo '<span class="z1n3-footer-meta__label">' . esc_html__( 'Copyright', 'z1n3-press' ) . '</span>';
	echo '<div class="z1n3-footer-meta__text">';
	echo '<span>© ' . esc_html( gmdate( 'Y' ) ) . ' ' . esc_html( get_bloginfo( 'name' ) ) . '</span>';
	echo '<span>' . esc_html( sprintf( _n( '%s post', '%s posts', $published, 'z1n3-press' ), number_format_i18n( $published ) ) ) . '</span>';
	if ( ! empty( $updated ) ) {
		echo '<span>' . esc_html__( 'Updated', 'z1n3-press' ) . ' ' . esc_html( get_the_modified_date( get_option( 'date_format' ), $updated[0] ) ) . '</span>';
	}
	echo '</div>';
	echo '</div>';

	echo '<div class="z1n3-footer-meta__group">';
	echo '<span class="z1n3-footer-meta__label">' . esc_html__( 'Network', 'z1n3-press' ) . '</span>';
	echo '<div class="z1n3-footer-meta__links">';
	if ( ! empty( $network_links ) ) {
		foreach ( $network_links as $link ) {
			echo '<a href="' . esc_url( $link['url'] ) . '">' . esc_html( $link['label'] ) . '</a>';
		}
	} else {
		echo '<a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'z1n3-press' ) . '</a>';
		echo '<a href="' . esc_url( get_post_type_archive_link( 'post' ) ?: home_url( '/' ) ) . '">' . esc_html__( 'Archive', 'z1n3-press' ) . '</a>';
		echo '<a href="' . esc_url( get_feed_link() ) . '">' . esc_html__( 'RSS', 'z1n3-press' ) . '</a>';
	}
	echo '</div>';
	echo '</div>';

	echo '</div>';
	return ob_get_clean();
}
add_shortcode( 'z1n3_footer_meta', 'z1n3_press_footer_meta_shortcode' );


function z1n3_press_archive_slider_shortcode( $atts ) {
	$atts = shortcode_atts( array(
		'count' => 16,
	), $atts, 'z1n3_archive_slider' );

	$args = array(
		'post_type'           => 'post',
		'posts_per_page'      => absint( $atts['count'] ),
		'ignore_sticky_posts' => true,
	);

	$queried = get_queried_object();
	if ( $queried instanceof WP_Term && 'category' === $queried->taxonomy ) {
		$args['cat'] = intval( $queried->term_id );
	}

	$q = new WP_Query( $args );
	if ( ! $q->have_posts() ) {
		return '<p>' . esc_html__( 'No articles found.', 'z1n3-press' ) . '</p>';
	}

	$title = ( $queried instanceof WP_Term ) ? $queried->name : __( 'Articles', 'z1n3-press' );
	$description = ( $queried instanceof WP_Term ) ? term_description( $queried ) : '';

	ob_start();
	echo '<section class="z1n3-archive-stage" aria-label="' . esc_attr( $title ) . '">';
	echo '<header class="z1n3-archive-stage__header">';
	echo '<p class="z1n3-slider__eyebrow">' . esc_html__( 'iOS first archive slider', 'z1n3-press' ) . '</p>';
	echo '<h1>' . esc_html( $title ) . '</h1>';
	if ( $description ) {
		echo '<div class="z1n3-archive-stage__description">' . wp_kses_post( $description ) . '</div>';
	}
	echo '</header>';
	echo '<div class="z1n3-slider z1n3-archive-slider" data-z1n3-slider data-autoplay="true" data-autoplay-delay="4200" aria-label="' . esc_attr__( 'Article slider', 'z1n3-press' ) . '">';
	echo '<div class="z1n3-slider__viewport" data-z1n3-viewport><div class="z1n3-slider__track">';
	while ( $q->have_posts() ) {
		$q->the_post();
		$thumb = get_the_post_thumbnail_url( get_the_ID(), 'z1n3-comic' );
		if ( ! $thumb ) {
			$thumb = z1n3_press_fallback_thumbnail();
		}
		echo '<article class="z1n3-archive-card z1n3-slider__slide">';
		echo '<a class="z1n3-archive-card__image" href="' . esc_url( get_permalink() ) . '"><img src="' . esc_url( $thumb ) . '" alt="" loading="lazy" decoding="async"></a>';
		echo '<div class="z1n3-archive-card__body">';
		echo '<span class="z1n3-post-tile__date">' . esc_html( get_the_date() ) . '</span>';
		echo '<h2><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h2>';
		echo '<div class="z1n3-archive-card__excerpt">' . wp_kses_post( wpautop( get_the_excerpt() ) ) . '</div>';
		echo '<a class="z1n3-post-tile__readmore" href="' . esc_url( get_permalink() ) . '">' . esc_html__( 'Read more', 'z1n3-press' ) . '</a>';
		echo '</div>';
		echo '</article>';
	}
	wp_reset_postdata();
	echo '</div></div>';
	echo '<div class="z1n3-slider__footer z1n3-slider__footer--center">';
	echo '<button type="button" class="z1n3-slider__button is-wide" data-z1n3-prev aria-label="' . esc_attr__( 'Previous articles', 'z1n3-press' ) . '">‹</button>';
	echo '<div class="z1n3-slider__pager"><div class="z1n3-slider__dots" data-z1n3-dots aria-label="' . esc_attr__( 'Article pages', 'z1n3-press' ) . '"></div><span class="z1n3-slider__status" data-z1n3-status>1 / 1</span></div>';
	echo '<button type="button" class="z1n3-slider__button is-wide" data-z1n3-next aria-label="' . esc_attr__( 'Next articles', 'z1n3-press' ) . '">›</button>';
	echo '<a class="z1n3-read-more-articles" href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Back to main page', 'z1n3-press' ) . '</a>';
	echo '</div>';
	echo '</div>';
	echo '</section>';
	return ob_get_clean();
}
add_shortcode( 'z1n3_archive_slider', 'z1n3_press_archive_slider_shortcode' );
