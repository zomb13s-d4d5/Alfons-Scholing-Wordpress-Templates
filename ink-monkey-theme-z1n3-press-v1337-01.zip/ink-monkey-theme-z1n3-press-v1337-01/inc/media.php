<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Default image sizes.
 */
function z1n3_press_image_sizes() {
	add_image_size( 'z1n3-comic', 1600, 0, false );
	add_image_size( 'z1n3-card', 900, 1200, true );
}
add_action( 'after_setup_theme', 'z1n3_press_image_sizes' );

/**
 * Light-touch upload renaming for new uploads.
 * Uses timestamp + original slug because attachment IDs are not available before the first write.
 */
function z1n3_press_upload_prefilter( $file ) {
	if ( empty( $file['name'] ) ) {
		return $file;
	}
	$info = pathinfo( $file['name'] );
	$ext  = isset( $info['extension'] ) ? '.' . strtolower( $info['extension'] ) : '';
	$name = sanitize_title( $info['filename'] );
	$file['name'] = 'z1n3-' . gmdate( 'Ymd-His' ) . '-' . wp_generate_password( 4, false, false ) . '-' . $name . $ext;
	return $file;
}
add_filter( 'wp_handle_upload_prefilter', 'z1n3_press_upload_prefilter' );

/**
 * Populate caption and alt text from EXIF/IPTC or filename.
 */
function z1n3_press_attachment_defaults( $post_id ) {
	$file = get_attached_file( $post_id );
	if ( ! $file || ! wp_attachment_is_image( $post_id ) ) {
		return;
	}

	require_once ABSPATH . 'wp-admin/includes/image.php';
	$meta    = wp_read_image_metadata( $file );
	$title   = get_the_title( $post_id );
	$caption = get_post_field( 'post_excerpt', $post_id );
	$alt     = get_post_meta( $post_id, '_wp_attachment_image_alt', true );

	if ( empty( $caption ) && ! empty( $meta['caption'] ) ) {
		$caption = wp_strip_all_tags( $meta['caption'] );
	}
	if ( empty( $caption ) && ! empty( $meta['title'] ) ) {
		$caption = wp_strip_all_tags( $meta['title'] );
	}
	if ( empty( $caption ) ) {
		$filename = pathinfo( $file, PATHINFO_FILENAME );
		$caption  = ucwords( str_replace( array( '-', '_' ), ' ', $filename ) );
	}

	if ( empty( $alt ) ) {
		$alt = $caption ?: $title;
	}

	wp_update_post( array(
		'ID'           => $post_id,
		'post_excerpt' => wp_trim_words( $caption, 24, '' ),
	) );

	if ( ! empty( $alt ) ) {
		update_post_meta( $post_id, '_wp_attachment_image_alt', wp_strip_all_tags( $alt ) );
	}
}
add_action( 'add_attachment', 'z1n3_press_attachment_defaults' );

/**
 * Encourage browser loading optimization.
 */
function z1n3_press_attachment_image_attributes( $attr, $attachment, $size ) {
	if ( ! empty( $attr['class'] ) && false !== strpos( $attr['class'], 'wp-post-image' ) ) {
		$attr['fetchpriority'] = 'high';
	}
	$attr['decoding'] = 'async';
	return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'z1n3_press_attachment_image_attributes', 10, 3 );

/**
 * Default fallback image when a post has no thumbnail.
 */
function z1n3_press_fallback_thumbnail() {
	return get_template_directory_uri() . '/assets/img/logo-user-supplied.webp';
}
