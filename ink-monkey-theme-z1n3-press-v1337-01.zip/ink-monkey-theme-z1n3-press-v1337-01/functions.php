<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once get_template_directory() . '/inc/media.php';
require_once get_template_directory() . '/inc/shortcodes.php';
require_once get_template_directory() . '/inc/comments.php';

function z1n3_press_setup() {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'html5', array( 'comment-form', 'comment-list', 'gallery', 'caption', 'search-form', 'script', 'style' ) );
	add_theme_support( 'custom-logo', array(
		'height'      => 512,
		'width'       => 512,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'z1n3-press' ),
	) );
	add_editor_style( 'assets/css/app.css' );
}
add_action( 'after_setup_theme', 'z1n3_press_setup' );

function z1n3_press_customize_register( $wp_customize ) {
	$wp_customize->add_section( 'z1n3_press_theme_options', array(
		'title'       => __( 'Z1N3 Press Theme Options', 'z1n3-press' ),
		'priority'    => 35,
		'description' => __( 'Fine tuning for rotating backgrounds and footer content.', 'z1n3-press' ),
	) );

	for ( $i = 1; $i <= 6; $i++ ) {
		$wp_customize->add_setting( 'z1n3_press_background_image_' . $i, array(
			'default'           => 0,
			'sanitize_callback' => 'absint',
		) );

		$wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, 'z1n3_press_background_image_' . $i, array(
			'label'       => sprintf( __( 'Background image %d', 'z1n3-press' ), $i ),
			'description' => 1 === $i ? __( 'Choose images from the Media Library. Selected images rotate behind the dark overlay.', 'z1n3-press' ) : '',
			'section'     => 'z1n3_press_theme_options',
			'mime_type'   => 'image',
		) ) );
	}

	$wp_customize->add_setting( 'z1n3_press_background_rotation_speed', array(
		'default'           => 8,
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( 'z1n3_press_background_rotation_speed', array(
		'label'       => __( 'Background rotation speed (seconds)', 'z1n3-press' ),
		'section'     => 'z1n3_press_theme_options',
		'type'        => 'number',
		'input_attrs' => array(
			'min'  => 4,
			'max'  => 30,
			'step' => 1,
		),
	) );

	$wp_customize->add_setting( 'z1n3_press_footer_about', array(
		'default'           => '',
		'sanitize_callback' => 'z1n3_press_sanitize_textarea',
	) );
	$wp_customize->add_control( 'z1n3_press_footer_about', array(
		'label'       => __( 'Footer about text', 'z1n3-press' ),
		'description' => __( 'Short text for the About area in the footer.', 'z1n3-press' ),
		'section'     => 'z1n3_press_theme_options',
		'type'        => 'textarea',
	) );

	$wp_customize->add_setting( 'z1n3_press_footer_network_links', array(
		'default'           => '',
		'sanitize_callback' => 'z1n3_press_sanitize_textarea',
	) );
	$wp_customize->add_control( 'z1n3_press_footer_network_links', array(
		'label'       => __( 'Footer network links', 'z1n3-press' ),
		'description' => __( 'One link per line in this format: Label|https://example.com', 'z1n3-press' ),
		'section'     => 'z1n3_press_theme_options',
		'type'        => 'textarea',
	) );
}
add_action( 'customize_register', 'z1n3_press_customize_register' );

function z1n3_press_sanitize_textarea( $value ) {
	return trim( wp_kses_post( $value ) );
}

function z1n3_press_background_images() {
	$images = array();

	for ( $i = 1; $i <= 6; $i++ ) {
		$attachment_id = absint( get_theme_mod( 'z1n3_press_background_image_' . $i, 0 ) );
		if ( $attachment_id ) {
			$url = wp_get_attachment_image_url( $attachment_id, 'full' );
			if ( $url ) {
				$images[] = $url;
			}
		}
	}

	if ( empty( $images ) ) {
		$lines = preg_split( '/
|
|
/', (string) get_theme_mod( 'z1n3_press_background_images', '' ) );
		foreach ( $lines as $line ) {
			$url = esc_url_raw( trim( $line ) );
			if ( $url ) {
				$images[] = $url;
			}
		}
	}

	if ( empty( $images ) ) {
		$images[] = get_template_directory_uri() . '/assets/img/background-skull-square-center.webp';
	}

	return array_values( array_unique( $images ) );
}

function z1n3_press_assets() {
	$ver = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'z1n3-press-fonts', 'https://fonts.googleapis.com/css2?family=Anton&family=Bricolage+Grotesque:opsz,wdth,wght@10..48,75..100,200..800&family=Space+Grotesk:wght@300..700&display=swap', array(), null );
	wp_enqueue_style( 'z1n3-press-app', get_template_directory_uri() . '/assets/css/app.css', array( 'z1n3-press-fonts' ), $ver );
	wp_enqueue_script( 'z1n3-press-app', get_template_directory_uri() . '/assets/js/app.js', array(), $ver, true );
	wp_enqueue_script( 'z1n3-press-reader', get_template_directory_uri() . '/assets/js/reader-swipe.js', array(), $ver, true );

	wp_localize_script( 'z1n3-press-app', 'z1n3Press', array(
		'backgroundImages' => z1n3_press_background_images(),
		'backgroundSpeed'  => max( 4, absint( get_theme_mod( 'z1n3_press_background_rotation_speed', 8 ) ) ) * 1000,
		'monkeyBullet'     => get_template_directory_uri() . '/assets/img/logo-monkey-bullet.webp',
	) );

	wp_localize_script( 'z1n3-press-reader', 'z1n3Reader', array(
		'isSingular' => is_single(),
	) );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'z1n3_press_assets' );

function z1n3_press_preload_logo() {
	$logo = get_template_directory_uri() . '/assets/img/logo-user-supplied.webp';
	echo '<link rel="preload" as="image" href="' . esc_url( $logo ) . '">' . "\n";
	foreach ( array_slice( z1n3_press_background_images(), 0, 2 ) as $bg ) {
		echo '<link rel="preload" as="image" href="' . esc_url( $bg ) . '">' . "\n";
	}
}
add_action( 'wp_head', 'z1n3_press_preload_logo', 1 );

function z1n3_press_display_name() {
	$host = wp_parse_url( home_url( '/' ), PHP_URL_HOST );
	$host = $host ? preg_replace( '/^www\./i', '', $host ) : '';
	if ( $host ) {
		return strtoupper( $host );
	}
	$name = trim( (string) get_bloginfo( 'name' ) );
	return $name ? strtoupper( $name ) : 'Z1N3.PRESS';
}


function z1n3_ink_paged_url( $base_url, $page = 2 ) {
	$page = max( 1, absint( $page ) );
	$base_url = $base_url ?: home_url( '/' );
	if ( $page <= 1 ) {
		return $base_url;
	}
	if ( get_option( 'permalink_structure' ) ) {
		return trailingslashit( $base_url ) . user_trailingslashit( 'page/' . $page, 'paged' );
	}
	return add_query_arg( 'paged', $page, $base_url );
}

function z1n3_ink_posts_index_url( $page = 1 ) {
	$page_for_posts = absint( get_option( 'page_for_posts' ) );
	$front_page     = absint( get_option( 'page_on_front' ) );
	$base           = '';
	if ( $page_for_posts && $page_for_posts !== $front_page ) {
		$base = get_permalink( $page_for_posts );
	}
	$base = $base ?: home_url( '/' );
	return z1n3_ink_paged_url( $base, $page );
}

function z1n3_press_site_brand( $atts = 'menu' ) {
	$action = is_array( $atts ) ? ( $atts['action'] ?? 'menu' ) : $atts;
	$custom_logo_id = get_theme_mod( 'custom_logo' );
	$src = $custom_logo_id ? wp_get_attachment_image_url( $custom_logo_id, 'full' ) : get_template_directory_uri() . '/assets/img/logo-user-supplied.webp';
	$name = get_bloginfo( 'name' );
	$display_name = z1n3_press_display_name();
	$description = get_bloginfo( 'description' );
	$action = in_array( $action, array( 'menu', 'home' ), true ) ? $action : 'menu';

	ob_start();
	if ( 'home' === $action ) :
		?>
		<a class="z1n3-site-brand z1n3-site-brand--home" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Go to %s home', 'z1n3-press' ), $name ) ); ?>">
			<img src="<?php echo esc_url( $src ); ?>" alt="" width="176" height="176" decoding="async">
			<span class="z1n3-site-brand__stack">
				<span class="z1n3-site-brand__text"><?php echo esc_html( $display_name ); ?></span><span class="z1n3-site-brand__version">INK MONKEY<br>1337-01</span>
				<?php if ( $description ) : ?>
					<span class="z1n3-site-brand__hint"><?php echo esc_html( $description ); ?></span>
				<?php else : ?>
					<span class="z1n3-site-brand__hint"><?php echo esc_html__( 'Ink monkey studio comics', 'z1n3-press' ); ?></span>
				<?php endif; ?>
			</span>
		</a>
		<?php
	else :
		?>
		<button class="z1n3-site-brand z1n3-site-brand--compact" type="button" data-z1n3-open-menu aria-expanded="false" aria-controls="z1n3-foldout-menu" aria-label="<?php echo esc_attr( sprintf( __( 'Open %s menu', 'z1n3-press' ), $name ) ); ?>">
			<img src="<?php echo esc_url( $src ); ?>" alt="" width="176" height="176" decoding="async">
			<span class="z1n3-site-brand__stack">
				<span class="z1n3-site-brand__text"><?php echo esc_html( $display_name ); ?></span><span class="z1n3-site-brand__version">INK MONKEY<br>1337-01</span>
				<span class="z1n3-site-brand__hint"><?php echo esc_html( $description ?: __( 'Tap logo for menu', 'z1n3-press' ) ); ?></span>
			</span>
			<span class="z1n3-site-brand__menu-word" aria-hidden="true"><?php esc_html_e( 'Menu', 'z1n3-press' ); ?></span>
		</button>
		<?php
	endif;
	return ob_get_clean();
}

function z1n3_press_home_link() {
	$url  = home_url( '/' );
	return '<a class="z1n3-header-home" href="' . esc_url( $url ) . '" aria-label="' . esc_attr__( 'Home', 'z1n3-press' ) . '">⌂</a>';
}

function z1n3_press_primary_menu_markup() {
	$menu = wp_nav_menu( array(
		'theme_location' => 'primary',
		'container'      => false,
		'menu_class'     => 'z1n3-wp-menu__list',
		'fallback_cb'    => false,
		'echo'           => false,
		'depth'          => 2,
	) );

	if ( $menu ) {
		return '<nav class="z1n3-wp-menu" aria-label="' . esc_attr__( 'Primary menu', 'z1n3-press' ) . '">' . $menu . '</nav>';
	}

	$pages = wp_list_pages( array(
		'title_li' => '',
		'echo'     => false,
		'depth'    => 1,
	) );

	if ( $pages ) {
		return '<nav class="z1n3-wp-menu" aria-label="' . esc_attr__( 'Pages', 'z1n3-press' ) . '"><ul class="z1n3-wp-menu__list">' . $pages . '</ul></nav>';
	}

	return do_shortcode( '[z1n3_category_grid]' );
}

function z1n3_press_overlay_menu_markup() {
	$name = get_bloginfo( 'name' );
	$description = get_bloginfo( 'description' );
	?>
	<div id="z1n3-foldout-menu" class="z1n3-foldout-menu z1n3-ink-menu" hidden data-z1n3-menu-panel>
		<div class="z1n3-foldout-menu__inner z1n3-ink-menu__inner">
			<header class="z1n3-foldout-menu__header z1n3-ink-menu__header">
				<div>
					<p class="z1n3-foldout-menu__eyebrow"><?php esc_html_e( 'WordPress menu', 'z1n3-press' ); ?></p>
					<h2><?php echo esc_html( $name ); ?></h2>
					<?php if ( $description ) : ?>
						<p><?php echo esc_html( $description ); ?></p>
					<?php endif; ?>
				</div>
				<button class="z1n3-menu-close" type="button" data-z1n3-close-menu aria-label="<?php esc_attr_e( 'Close menu', 'z1n3-press' ); ?>">×</button>
			</header>

			<?php echo z1n3_press_primary_menu_markup(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

			<div class="z1n3-foldout-menu__search">
				<?php get_search_form(); ?>
			</div>
		</div>
	</div>
	<?php
}
add_action( 'wp_footer', 'z1n3_press_overlay_menu_markup' );

function z1n3_press_read_more( $more ) {
	$icon = get_template_directory_uri() . '/assets/img/logo-user-supplied.webp';
	return ' <span class="z1n3-read-more"><img src="' . esc_url( $icon ) . '" alt="" width="16" height="16" decoding="async"> ' . esc_html__( 'Read more', 'z1n3-press' ) . '</span>';
}
add_filter( 'excerpt_more', 'z1n3_press_read_more' );

function z1n3_press_body_classes( $classes ) {
	if ( is_single() ) {
		$classes[] = 'z1n3-single-reader';
	}
	return $classes;
}
add_filter( 'body_class', 'z1n3_press_body_classes' );

function z1n3_press_search_form( $form ) {
	$label = esc_attr__( 'Search comics', 'z1n3-press' );
	$button = esc_html__( 'Search', 'z1n3-press' );
	$value = get_search_query();
	return '<form role="search" method="get" class="z1n3-search-form" action="' . esc_url( home_url( '/' ) ) . '">
		<label>
			<span class="screen-reader-text">' . $label . '</span>
			<input type="search" class="z1n3-search-field" placeholder="' . $label . '" value="' . esc_attr( $value ) . '" name="s" />
		</label>
		<button type="submit">' . $button . '</button>
	</form>';
}
add_filter( 'get_search_form', 'z1n3_press_search_form' );

add_shortcode( 'z1n3_site_brand', 'z1n3_press_site_brand' );
add_shortcode( 'z1n3_home_link', 'z1n3_press_home_link' );


/* INK MONKEY 1337-01 production shell */
define( 'Z1N3_INK_MONKEY_NAME', 'INK MONKEY' );
define( 'Z1N3_INK_MONKEY_VERSION', '1337-01' );

function z1n3_ink_logo_url() {
	$custom_logo_id = get_theme_mod( 'custom_logo' );
	$src = $custom_logo_id ? wp_get_attachment_image_url( $custom_logo_id, 'full' ) : '';
	return $src ?: get_template_directory_uri() . '/assets/img/logo-user-supplied.webp';
}

function z1n3_ink_bullet_url() {
	return get_template_directory_uri() . '/assets/img/logo-monkey-bullet.webp';
}

function z1n3_ink_post_image( $post_id = 0, $size = 'z1n3-card' ) {
	$post_id = $post_id ?: get_the_ID();
	$thumb = get_the_post_thumbnail_url( $post_id, $size );
	if ( $thumb ) { return $thumb; }
	$cats = get_the_category( $post_id );
	if ( ! empty( $cats ) ) {
		$cat_img = z1n3_press_category_image_url( $cats[0]->term_id );
		if ( $cat_img ) { return $cat_img; }
	}
	return z1n3_press_fallback_thumbnail();
}

function z1n3_ink_category_label( $post_id = 0 ) {
	$post_id = $post_id ?: get_the_ID();
	$cats = get_the_category( $post_id );
	return ! empty( $cats ) ? $cats[0]->name : __( 'Webcomics', 'z1n3-press' );
}

function z1n3_ink_excerpt( $post_id = 0, $words = 18 ) {
	$post_id = $post_id ?: get_the_ID();
	$raw = has_excerpt( $post_id ) ? get_the_excerpt( $post_id ) : get_post_field( 'post_content', $post_id );
	return wp_trim_words( wp_strip_all_tags( $raw ), $words, '…' );
}


function z1n3_ink_gallery_images( $post_id = 0, $limit = 4, $size = 'thumbnail' ) {
	$post_id = $post_id ?: get_the_ID();
	$limit   = max( 1, absint( $limit ) );
	$images  = array();
	$featured_id = get_post_thumbnail_id( $post_id );

	/*
	 * Gallery-first behavior:
	 * Do NOT prepend the featured image / thumbnail. That was causing the
	 * first visible gallery item to be a thumbnail-like cover image instead
	 * of the first real panel from the post gallery.
	 */

	$content = (string) get_post_field( 'post_content', $post_id );
	if ( preg_match_all( '/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/i', $content, $matches ) && ! empty( $matches[1] ) ) {
		foreach ( $matches[1] as $src ) {
			$src = trim( $src );
			if ( $src ) {
				$images[] = $src;
			}
		}
	}

	if ( count( $images ) < $limit ) {
		$attachments = get_attached_media( 'image', $post_id );
		foreach ( $attachments as $attachment ) {
			if ( $featured_id && intval( $attachment->ID ) === intval( $featured_id ) ) {
				continue;
			}
			$src = wp_get_attachment_image_url( $attachment->ID, $size );
			if ( $src ) {
				$images[] = $src;
			}
		}
	}

	$images = array_values( array_unique( array_filter( $images ) ) );

	/*
	 * Only use the featured image as a fallback when the post has no gallery
	 * images at all. This keeps cards populated but prevents the thumbnail
	 * from becoming "image 1" in real galleries.
	 */
	if ( empty( $images ) && $featured_id ) {
		$featured = wp_get_attachment_image_url( $featured_id, $size );
		if ( $featured ) {
			$images[] = $featured;
		}
	}

	if ( empty( $images ) ) {
		$images = array( z1n3_ink_post_image( $post_id, 'z1n3-card' ) );
	}

	return array_slice( $images, 0, $limit );
}



function z1n3_ink_bullets( $total = 5, $active = 1, $class = '' ) {
	$total = max( 1, min( 9, absint( $total ) ) );
	$active = max( 1, min( $total, absint( $active ) ) );
	$src = z1n3_ink_bullet_url();
	$out = '<div class="z1n3-ink-bullets ' . esc_attr( $class ) . '" aria-hidden="true">';
	for ( $i = 1; $i <= $total; $i++ ) {
		$out .= '<span class="z1n3-ink-bullet' . ( $i === $active ? ' is-active' : '' ) . '"><img src="' . esc_url( $src ) . '" alt="" loading="lazy" decoding="async"></span>';
	}
	$out .= '</div>';
	return $out;
}

function z1n3_ink_article_card( $post_id, $compact = false ) {
	$title  = get_the_title( $post_id );
	$url    = get_permalink( $post_id );
	$img    = z1n3_ink_post_image( $post_id );
	$cat    = z1n3_ink_category_label( $post_id );
	$thumbs = function_exists( 'z1n3_ink_gallery_images' ) ? z1n3_ink_gallery_images( $post_id, $compact ? 3 : 4, 'thumbnail' ) : array( $img );
	ob_start();
	?>
	<article class="z1n3-ink-card <?php echo $compact ? 'is-compact' : ''; ?>" style="--ink-img:url('<?php echo esc_url( $img ); ?>')">
		<a href="<?php echo esc_url( $url ); ?>" class="z1n3-ink-card__link" aria-label="<?php echo esc_attr( sprintf( __( 'Read %s', 'z1n3-press' ), $title ) ); ?>">
			<span class="z1n3-ink-card__shade"></span>
			<span class="z1n3-ink-card__content">
				<span class="z1n3-ink-kicker"><?php echo esc_html( $cat ); ?></span>
				<strong class="z1n3-ink-card__title"><?php echo esc_html( $title ); ?></strong>
				<span class="z1n3-ink-card__thumbs" aria-hidden="true"><?php foreach ( $thumbs as $thumb ) : ?><img src="<?php echo esc_url( $thumb ); ?>" alt="" loading="lazy" decoding="async"><?php endforeach; ?></span>
				<span class="z1n3-ink-readline"><?php esc_html_e( 'Read article', 'z1n3-press' ); ?> <b aria-hidden="true">→</b></span>
			</span>
		</a>
	</article>
	<?php
	return ob_get_clean();
}


function z1n3_ink_category_image( $term_id, $size = 'z1n3-comic' ) {
	$term_id = absint( $term_id );
	if ( ! $term_id ) {
		return z1n3_press_fallback_thumbnail();
	}
	$cat_img = z1n3_press_category_image_url( $term_id );
	if ( $cat_img ) {
		return $cat_img;
	}
	$latest_in_cat = get_posts(
		array(
			'post_type'           => 'post',
			'posts_per_page'      => 1,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
			'tax_query'           => array(
				array(
					'taxonomy' => 'category',
					'field'    => 'term_id',
					'terms'    => array( $term_id ),
				),
			),
		)
	);
	if ( ! empty( $latest_in_cat ) ) {
		return z1n3_ink_post_image( $latest_in_cat[0]->ID, $size );
	}
	return z1n3_press_fallback_thumbnail();
}

function z1n3_ink_category_thumbs( $term_id, $limit = 4, $size = 'thumbnail' ) {
	$term_id = absint( $term_id );
	$limit   = max( 1, absint( $limit ) );
	$thumbs  = array();
	$posts   = get_posts(
		array(
			'post_type'           => 'post',
			'posts_per_page'      => $limit,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
			'tax_query'           => array(
				array(
					'taxonomy' => 'category',
					'field'    => 'term_id',
					'terms'    => array( $term_id ),
				),
			),
		)
	);
	foreach ( $posts as $post_obj ) {
		$images = z1n3_ink_gallery_images( $post_obj->ID, 1, $size );
		if ( ! empty( $images[0] ) ) {
			$thumbs[] = $images[0];
		}
	}
	$thumbs = array_values( array_unique( array_filter( $thumbs ) ) );
	if ( empty( $thumbs ) ) {
		$thumbs[] = z1n3_ink_category_image( $term_id, $size );
	}
	return array_slice( $thumbs, 0, $limit );
}

function z1n3_ink_bottom_nav_shortcode() {
	$items = array(
		array( 'label' => __( 'Home', 'z1n3-press' ), 'url' => home_url( '/' ), 'key' => 'home' ),
		array( 'label' => __( 'Comics', 'z1n3-press' ), 'url' => get_post_type_archive_link( 'post' ) ?: home_url( '/' ), 'key' => 'comics' ),
		array( 'label' => __( 'Stories', 'z1n3-press' ), 'url' => home_url( '/?s=story' ), 'key' => 'stories' ),
		array( 'label' => __( 'Collections', 'z1n3-press' ), 'url' => home_url( '/?s=collection' ), 'key' => 'collections' ),
		array( 'label' => __( 'About', 'z1n3-press' ), 'url' => home_url( '/about/' ), 'key' => 'about' ),
	);
	$src = z1n3_ink_bullet_url();
	$out = '<nav class="z1n3-ink-bottom-nav" aria-label="' . esc_attr__( 'Bottom navigation', 'z1n3-press' ) . '">';
	foreach ( $items as $item ) {
		$active = ( 'home' === $item['key'] && is_front_page() ) || ( 'comics' === $item['key'] && ( is_archive() || is_category() ) );
		$out .= '<a class="' . ( $active ? 'is-active' : '' ) . '" href="' . esc_url( $item['url'] ) . '"><img src="' . esc_url( $src ) . '" alt="" loading="lazy" decoding="async"><span>' . esc_html( $item['label'] ) . '</span></a>';
	}
	$out .= '</nav>';
	return $out;
}
add_shortcode( 'z1n3_ink_bottom_nav', 'z1n3_ink_bottom_nav_shortcode' );

function z1n3_ink_home_shortcode() {
	$hero_categories = get_categories(
		array(
			'taxonomy'   => 'category',
			'hide_empty' => true,
			'number'     => 5,
			'orderby'    => 'count',
			'order'      => 'DESC',
			'exclude'    => array( 1 ),
		)
	);
	$hero_total = max( 1, count( $hero_categories ) );
	$latest = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => 6, 'ignore_sticky_posts' => true ) );
	$latest_total = max( 1, intval( $latest->post_count ) );
	$more_articles_url = z1n3_ink_posts_index_url( 2 );
	ob_start();
	?>
	<main class="z1n3-ink-home z1n3-ink-viewport" aria-label="<?php esc_attr_e( 'Ink Monkey homepage', 'z1n3-press' ); ?>">
		<section class="z1n3-ink-hero-slider" data-z1n3-slider data-autoplay="true" data-autoplay-delay="4200" aria-label="<?php esc_attr_e( 'Featured category slider', 'z1n3-press' ); ?>">
			<div class="z1n3-ink-hero-slider__viewport" data-z1n3-viewport>
				<div class="z1n3-ink-hero-slider__track">
				<?php if ( ! empty( $hero_categories ) ) : foreach ( $hero_categories as $term ) :
					$hero_title  = $term->name;
					$hero_url    = get_category_link( $term );
					$hero_img    = z1n3_ink_category_image( $term->term_id, 'z1n3-comic' );
					$hero_thumbs = z1n3_ink_category_thumbs( $term->term_id, 4, 'thumbnail' );
					?>
					<section class="z1n3-ink-hero z1n3-ink-hero-slide" style="--ink-img:url('<?php echo esc_url( $hero_img ); ?>')">
						<a class="z1n3-ink-hero__link" href="<?php echo esc_url( $hero_url ); ?>">
							<span class="z1n3-ink-hero__shade"></span>
							<span class="z1n3-ink-hero__copy"><span class="z1n3-ink-kicker"><?php esc_html_e( 'Category', 'z1n3-press' ); ?></span><strong><?php echo esc_html( $hero_title ); ?></strong><span class="z1n3-ink-hero__thumbs" aria-hidden="true"><?php foreach ( $hero_thumbs as $thumb ) : ?><img src="<?php echo esc_url( $thumb ); ?>" alt="" loading="lazy" decoding="async"><?php endforeach; ?></span><span class="z1n3-ink-button"><?php esc_html_e( 'Open category', 'z1n3-press' ); ?> <b>→</b></span></span>
						</a>
					</section>
				<?php endforeach; else : ?>
					<section class="z1n3-ink-hero z1n3-ink-hero-slide" style="--ink-img:url('<?php echo esc_url( z1n3_press_fallback_thumbnail() ); ?>')"><a class="z1n3-ink-hero__link" href="<?php echo esc_url( home_url( '/' ) ); ?>"><span class="z1n3-ink-hero__shade"></span><span class="z1n3-ink-hero__copy"><span class="z1n3-ink-kicker"><?php esc_html_e( 'Category', 'z1n3-press' ); ?></span><strong><?php esc_html_e( 'Webcomics', 'z1n3-press' ); ?></strong><span class="z1n3-ink-button"><?php esc_html_e( 'Open category', 'z1n3-press' ); ?> <b>→</b></span></span></a></section>
				<?php endif; ?>
				</div>
			</div>
			<div class="z1n3-ink-under-nav z1n3-ink-hero-nav"><div class="z1n3-ink-bullets" data-z1n3-dots aria-label="<?php esc_attr_e( 'Hero slider pages', 'z1n3-press' ); ?>"></div><span class="z1n3-ink-page-count" data-z1n3-status>1 / <?php echo esc_html( $hero_total ); ?></span></div>
		</section>

		<section class="z1n3-ink-latest z1n3-ink-latest-slider" data-z1n3-slider data-autoplay="true" data-autoplay-delay="3600" aria-label="<?php esc_attr_e( 'Latest articles', 'z1n3-press' ); ?>">
			<div class="z1n3-ink-section-head"><h2><?php esc_html_e( 'Latest articles', 'z1n3-press' ); ?></h2></div>
			<div class="z1n3-ink-latest-slider__viewport" data-z1n3-viewport>
				<div class="z1n3-ink-card-row z1n3-ink-latest-slider__track">
				<?php
				if ( $latest->have_posts() ) {
					while ( $latest->have_posts() ) {
						$latest->the_post();
						echo z1n3_ink_article_card( get_the_ID(), false );
					}
				} else {
					echo '<article class="z1n3-ink-card is-empty"><div class="z1n3-ink-card__link"><span class="z1n3-ink-card__shade"></span><span class="z1n3-ink-card__content"><span class="z1n3-ink-kicker">' . esc_html__( 'Articles', 'z1n3-press' ) . '</span><strong class="z1n3-ink-card__title">' . esc_html__( 'No articles yet', 'z1n3-press' ) . '</strong></span></div></article>';
				}
				wp_reset_postdata();
				?>
				</div>
			</div>
			<div class="z1n3-ink-under-nav"><div class="z1n3-ink-bullets" data-z1n3-dots aria-label="<?php esc_attr_e( 'Latest article pages', 'z1n3-press' ); ?>"></div><span class="z1n3-ink-page-count" data-z1n3-status>1 / <?php echo esc_html( $latest_total ); ?></span><a class="z1n3-ink-more" href="<?php echo esc_url( $more_articles_url ); ?>"><?php esc_html_e( 'Read more articles', 'z1n3-press' ); ?> <b>→</b></a></div>
		</section>
	</main>
	<?php
	return ob_get_clean();
}
add_shortcode( 'z1n3_ink_home', 'z1n3_ink_home_shortcode' );

function z1n3_ink_archive_shortcode() {
	$queried = get_queried_object();
	$is_cat  = $queried instanceof WP_Term;
	$title   = $is_cat ? $queried->name : ( is_search() ? sprintf( __( 'Search: %s', 'z1n3-press' ), get_search_query() ) : __( 'All articles', 'z1n3-press' ) );
	$paged   = max( 1, absint( get_query_var( 'paged' ) ?: get_query_var( 'page' ) ?: 1 ) );
	$per_page = 5;
	$args    = array(
		'post_type'           => 'post',
		'posts_per_page'      => $per_page,
		'paged'               => $paged,
		'ignore_sticky_posts' => true,
	);
	if ( $is_cat ) { $args['cat'] = $queried->term_id; }
	if ( is_search() ) { $args['s'] = get_search_query(); }
	$q = new WP_Query( $args );
	$total_pages = max( 1, intval( $q->max_num_pages ) );
	$base_url = $is_cat ? get_category_link( $queried ) : z1n3_ink_posts_index_url( 1 );
	$older_url = $paged < $total_pages ? z1n3_ink_paged_url( $base_url, $paged + 1 ) : '';
	$newer_url = $paged > 1 ? z1n3_ink_paged_url( $base_url, $paged - 1 ) : '';
	ob_start();
	?>
	<main class="z1n3-ink-archive z1n3-ink-viewport">
		<header class="z1n3-ink-page-title"><span><?php echo $is_cat ? esc_html__( 'Category', 'z1n3-press' ) : esc_html__( 'Archives', 'z1n3-press' ); ?></span><h1><?php echo esc_html( $title ); ?></h1></header>
		<section class="z1n3-ink-feature-slider" data-z1n3-slider data-autoplay="true" data-autoplay-delay="3600">
			<div class="z1n3-ink-feature-slider__viewport" data-z1n3-viewport><div class="z1n3-ink-feature-slider__track">
			<?php
			if ( $q->have_posts() ) {
				while ( $q->have_posts() ) { $q->the_post(); echo z1n3_ink_article_card( get_the_ID(), false ); }
			} else {
				echo '<p class="z1n3-ink-empty">' . esc_html__( 'No articles yet.', 'z1n3-press' ) . '</p>';
			}
			wp_reset_postdata();
			?>
			</div></div>
			<div class="z1n3-ink-under-nav z1n3-ink-archive-nav">
				<div class="z1n3-ink-bullets" data-z1n3-dots aria-label="<?php esc_attr_e( 'Archive slider pages', 'z1n3-press' ); ?>"></div>
				<span class="z1n3-ink-page-count" data-z1n3-status><?php echo esc_html( $paged ); ?> / <?php echo esc_html( $total_pages ); ?></span>
				<div class="z1n3-ink-archive-links">
					<?php if ( $newer_url ) : ?><a class="z1n3-ink-more" href="<?php echo esc_url( $newer_url ); ?>">← <?php esc_html_e( 'Newer articles', 'z1n3-press' ); ?></a><?php endif; ?>
					<?php if ( $older_url ) : ?><a class="z1n3-ink-more" href="<?php echo esc_url( $older_url ); ?>"><?php echo esc_html( $is_cat ? sprintf( __( 'More in %s', 'z1n3-press' ), $title ) : __( 'Read more articles', 'z1n3-press' ) ); ?> <b>→</b></a><?php endif; ?>
				</div>
			</div>
		</section>
	</main>
	<?php
	return ob_get_clean();
}
add_shortcode( 'z1n3_ink_archive', 'z1n3_ink_archive_shortcode' );

function z1n3_ink_single_shortcode() {
	if ( ! is_singular( 'post' ) ) { return ''; }
	$post_id = get_the_ID();
	$img     = z1n3_ink_post_image( $post_id, 'z1n3-comic' );
	$next    = get_next_post( true, '', 'category' );
	$thumbs  = function_exists( 'z1n3_ink_gallery_images' ) ? z1n3_ink_gallery_images( $post_id, 12, 'thumbnail' ) : array( $img );
	ob_start();
	?>
	<main class="z1n3-ink-single z1n3-ink-viewport">
		<article class="z1n3-ink-single-card">
			<header class="z1n3-ink-single-hero" style="--ink-img:url('<?php echo esc_url( $img ); ?>')"><span class="z1n3-ink-hero__shade"></span><div><span class="z1n3-ink-kicker"><?php echo esc_html( z1n3_ink_category_label( $post_id ) ); ?></span><h1><?php the_title(); ?></h1><p class="z1n3-ink-meta">☷ <?php echo esc_html( get_the_date() ); ?> · ◷ <?php echo esc_html( max( 1, absint( str_word_count( wp_strip_all_tags( get_post_field( 'post_content', $post_id ) ) ) / 220 ) ) ); ?> <?php esc_html_e( 'min read', 'z1n3-press' ); ?> · <?php esc_html_e( 'By Ink Monkey', 'z1n3-press' ); ?></p></div></header>
			<section class="z1n3-single-gallery-shell" aria-label="<?php esc_attr_e( 'Article image slider', 'z1n3-press' ); ?>">
				<div class="z1n3-single-gallery-viewport" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Article image slider', 'z1n3-press' ); ?>">
					<div class="z1n3-ink-thumb-strip z1n3-single-gallery-track" data-z1n3-single-gallery><?php foreach ( $thumbs as $t ) : ?><a href="<?php echo esc_url( $t ); ?>"><img src="<?php echo esc_url( $t ); ?>" alt="" loading="lazy" decoding="async"></a><?php endforeach; ?></div>
				</div>
				<div class="z1n3-single-gallery-nav"><button type="button" data-single-gallery-prev aria-label="<?php esc_attr_e( 'Previous gallery image', 'z1n3-press' ); ?>">←</button><span data-single-gallery-status>1 / <?php echo esc_html( max( 1, count( $thumbs ) ) ); ?></span><button type="button" data-single-gallery-next aria-label="<?php esc_attr_e( 'Next gallery image', 'z1n3-press' ); ?>">→</button></div>
			</section>
		</article>
		<?php echo do_shortcode( '[z1n3_comments_section]' ); ?>
		<?php if ( $next ) : ?><a class="z1n3-ink-next" href="<?php echo esc_url( get_permalink( $next ) ); ?>" style="--ink-img:url('<?php echo esc_url( z1n3_ink_post_image( $next->ID ) ); ?>')"><span><?php esc_html_e( 'Next story', 'z1n3-press' ); ?></span><strong><?php echo esc_html( get_the_title( $next ) ); ?></strong><b>→</b></a><?php endif; ?>
		<div class="z1n3-ink-under-nav"><?php echo z1n3_ink_bullets( count( $thumbs ), 1 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
	</main>
	<?php
	return ob_get_clean();
}
add_shortcode( 'z1n3_ink_single', 'z1n3_ink_single_shortcode' );

/* replace the older overlay with the INK MONKEY overlay */
remove_action( 'wp_footer', 'z1n3_press_overlay_menu_markup' );
function z1n3_ink_overlay_menu_markup() {
	$logo = z1n3_ink_logo_url();
	$links = array();
	$links[] = array(
		'label' => __( 'Home', 'z1n3-press' ),
		'url'   => home_url( '/' ),
		'img'   => z1n3_press_fallback_thumbnail(),
	);

	$menu_locations = get_nav_menu_locations();
	$primary_items  = array();
	if ( ! empty( $menu_locations['primary'] ) ) {
		$primary_items = wp_get_nav_menu_items( $menu_locations['primary'] );
	}

	if ( ! empty( $primary_items ) ) {
		foreach ( $primary_items as $item ) {
			if ( empty( $item->url ) || empty( $item->title ) ) {
				continue;
			}
			$img = z1n3_press_fallback_thumbnail();
			if ( 'category' === $item->object && ! empty( $item->object_id ) ) {
				$cat_img = z1n3_press_category_image_url( absint( $item->object_id ) );
				if ( $cat_img ) {
					$img = $cat_img;
				}
			}
			$links[] = array(
				'label' => $item->title,
				'url'   => $item->url,
				'img'   => $img,
			);
		}
	} else {
		$terms = get_categories( array( 'hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC' ) );
		foreach ( $terms as $term ) {
			$cat_img = z1n3_press_category_image_url( $term->term_id );
			$links[] = array(
				'label' => $term->name,
				'url'   => get_category_link( $term ),
				'img'   => $cat_img ?: z1n3_press_fallback_thumbnail(),
			);
		}
	}

	$seen = array();
	$links = array_values( array_filter( $links, function( $link ) use ( &$seen ) {
		$key = strtolower( trim( wp_strip_all_tags( $link['label'] ) ) ) . '|' . esc_url_raw( $link['url'] );
		if ( isset( $seen[ $key ] ) ) {
			return false;
		}
		$seen[ $key ] = true;
		return true;
	} ) );
	?>
	<div id="z1n3-foldout-menu" class="z1n3-foldout-menu z1n3-ink-menu" hidden data-z1n3-menu-panel>
		<div class="z1n3-ink-menu__inner">
			<header class="z1n3-ink-menu__header"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( $logo ); ?>" alt="" decoding="async"><strong><?php echo esc_html( z1n3_press_display_name() ); ?></strong><span><?php echo esc_html( Z1N3_INK_MONKEY_NAME ); ?><br><?php echo esc_html( Z1N3_INK_MONKEY_VERSION ); ?></span></a><button class="z1n3-menu-close" type="button" data-z1n3-close-menu aria-label="<?php esc_attr_e( 'Close menu', 'z1n3-press' ); ?>">×</button></header>
			<nav class="z1n3-ink-menu__tiles" aria-label="<?php esc_attr_e( 'Ink Monkey menu', 'z1n3-press' ); ?>">
			<?php foreach ( $links as $link ) : ?>
				<a class="z1n3-ink-menu-tile" href="<?php echo esc_url( $link['url'] ); ?>" style="--ink-img:url('<?php echo esc_url( $link['img'] ); ?>')"><img src="<?php echo esc_url( z1n3_ink_bullet_url() ); ?>" alt="" loading="lazy" decoding="async"><span><?php echo esc_html( $link['label'] ); ?></span><b>→</b></a>
			<?php endforeach; ?>
			</nav>
			<div class="z1n3-ink-menu__footer"><span><?php esc_html_e( 'Follow Ink Monkey', 'z1n3-press' ); ?></span><i>◎</i><i>𝕏</i><i>✉</i><small>© <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php echo esc_html( z1n3_press_display_name() ); ?> — <?php echo esc_html( Z1N3_INK_MONKEY_NAME . ' ' . Z1N3_INK_MONKEY_VERSION ); ?></small></div>
		</div>
	</div>
	<?php
}
add_action( 'wp_footer', 'z1n3_ink_overlay_menu_markup' );

/* Make post comments open by default for the new theme pass. */
add_filter( 'comments_open', function( $open, $post_id ) { return 'post' === get_post_type( $post_id ) ? true : $open; }, 20, 2 );
