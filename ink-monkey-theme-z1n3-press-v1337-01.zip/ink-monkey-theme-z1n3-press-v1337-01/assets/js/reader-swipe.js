(() => {
  if (!window.z1n3Reader?.isSingular) return;

  const root = document.querySelector('.z1n3-reader');
  if (!root) return;

  let startX = 0;
  let startY = 0;
  let pointerActive = false;

  const prevLink = document.querySelector('[data-reader-prev="1"]');
  const nextLink = document.querySelector('[data-reader-next="1"]');

  const isInteractiveSwipeArea = (target) => {
    return !!(target && target.closest && target.closest([
      '.wp-block-gallery',
      '.blocks-gallery-grid',
      '.z1n3-gallery-slider',
      '.z1n3-lightbox',
      '[data-z1n3-viewport]',
      '[data-z1n3-hero-viewport]',
      '.z1n3-ink-card-row',
      '.z1n3-ink-feature-slider__viewport'
    ].join(',')));
  };

  root.addEventListener('pointerdown', (event) => {
    if (isInteractiveSwipeArea(event.target)) {
      pointerActive = false;
      return;
    }
    pointerActive = true;
    startX = event.clientX;
    startY = event.clientY;
  }, { passive: true });

  root.addEventListener('pointerup', (event) => {
    if (!pointerActive) return;
    pointerActive = false;
    const dx = event.clientX - startX;
    const dy = event.clientY - startY;

    if (Math.abs(dx) < 60 || Math.abs(dy) > 80) return;

    if (dx < 0 && nextLink) {
      window.location.href = nextLink.href;
    } else if (dx > 0 && prevLink) {
      window.location.href = prevLink.href;
    }
  }, { passive: true });
})();
