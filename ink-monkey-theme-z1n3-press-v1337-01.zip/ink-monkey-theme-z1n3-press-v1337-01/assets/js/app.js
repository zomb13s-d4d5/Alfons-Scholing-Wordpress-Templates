(() => {
  const unlockPageScrollIfIdle = () => {
    const activeMenu = document.getElementById('z1n3-foldout-menu')?.hasAttribute('data-open');
    const activeLightbox = !!document.querySelector('.z1n3-lightbox[open]');
    if (!activeMenu && !activeLightbox) {
      document.documentElement.classList.remove('z1n3-menu-open');
      document.documentElement.style.overflowY = '';
      document.body.style.overflowY = '';
      document.body.style.position = '';
    }
  };
  unlockPageScrollIfIdle();
  window.addEventListener('pageshow', unlockPageScrollIfIdle);
  window.addEventListener('focus', unlockPageScrollIfIdle);
  const menuPanel = document.getElementById('z1n3-foldout-menu') || document.getElementById('z1n3-overlay-menu');
  const openButtons = Array.from(document.querySelectorAll('[data-z1n3-open-menu]'));
  const closeButton = menuPanel?.querySelector('[data-z1n3-close-menu]');

  if (menuPanel && openButtons.length) {
    // Keep the overlay as a direct child of <body>. This avoids iOS/Safari
    // treating the fixed popup as relative to a transformed/preview wrapper,
    // which made it dock to the left side of the viewport.
    if (menuPanel.parentElement !== document.body) {
      document.body.appendChild(menuPanel);
    }

    const setExpanded = (expanded) => {
      openButtons.forEach((button) => button.setAttribute('aria-expanded', expanded ? 'true' : 'false'));
    };

    const syncClosedState = () => {
      menuPanel.hidden = true;
      menuPanel.removeAttribute('data-open');
      menuPanel.setAttribute('aria-hidden', 'true');
      document.documentElement.classList.remove('z1n3-menu-open');
      document.documentElement.style.overflowY = '';
      document.body.style.overflowY = '';
      document.body.style.position = '';
      setExpanded(false);
    };

    const openMenu = () => {
      menuPanel.hidden = false;
      menuPanel.setAttribute('data-open', 'true');
      menuPanel.setAttribute('aria-hidden', 'false');
      document.documentElement.classList.add('z1n3-menu-open');
      setExpanded(true);
      const firstLink = menuPanel.querySelector('a, button, input, [tabindex]:not([tabindex="-1"])');
      if (firstLink) window.setTimeout(() => firstLink.focus(), 20);
    };

    const closeMenu = () => {
      menuPanel.removeAttribute('data-open');
      menuPanel.setAttribute('aria-hidden', 'true');
      document.documentElement.classList.remove('z1n3-menu-open');
      setExpanded(false);
      window.setTimeout(() => {
        if (!menuPanel.hasAttribute('data-open')) menuPanel.hidden = true;
      }, 160);
    };

    syncClosedState();
    window.addEventListener('pageshow', syncClosedState);

    const toggleMenu = () => {
      if (menuPanel.hasAttribute('data-open')) closeMenu();
      else openMenu();
    };

    openButtons.forEach((button) => {
      button.addEventListener('click', (event) => {
        event.preventDefault();
        toggleMenu();
      });
    });

    closeButton?.addEventListener('click', closeMenu);
    menuPanel.addEventListener('click', (event) => {
      if (event.target === menuPanel) closeMenu();
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && menuPanel.hasAttribute('data-open')) closeMenu();
    });
    document.addEventListener('click', (event) => {
      if (!menuPanel.hasAttribute('data-open')) return;
      const target = event.target;
      const clickedTrigger = openButtons.some((button) => button.contains(target));
      if (!clickedTrigger && !menuPanel.contains(target)) closeMenu();
    });
  }

  const bgImages = Array.isArray(window.z1n3Press?.backgroundImages) ? window.z1n3Press.backgroundImages : [];
  if (bgImages.length) {
    let index = 0;
    const applyBg = (nextIndex) => {
      document.body.style.setProperty('--z-rotating-bg', `url("${bgImages[nextIndex]}")`);
    };
    applyBg(0);
    if (bgImages.length > 1) {
      window.setInterval(() => {
        index = (index + 1) % bgImages.length;
        applyBg(index);
      }, Number(window.z1n3Press?.backgroundSpeed) || 8000);
    }
  }

  const sliders = Array.from(document.querySelectorAll('[data-z1n3-slider]'));
  sliders.forEach((slider) => {
    const viewport = slider.querySelector('[data-z1n3-viewport]');
    const prev = slider.querySelector('[data-z1n3-prev]');
    const next = slider.querySelector('[data-z1n3-next]');
    const status = slider.querySelector('[data-z1n3-status]');
    const dots = slider.querySelector('[data-z1n3-dots]');
    if (!viewport) return;

    const getTrack = () => viewport.firstElementChild;
    const getSlides = () => {
      const track = getTrack();
      return track ? Array.from(track.children).filter((child) => child.nodeType === 1) : [];
    };
    const getGap = () => {
      const track = getTrack();
      if (!track) return 0;
      const styles = window.getComputedStyle(track);
      return parseFloat(styles.columnGap || styles.gap || '0') || 0;
    };
    const pageSize = () => {
      const slides = getSlides();
      if (!slides.length) return Math.max(viewport.clientWidth, 1);
      const rect = slides[0].getBoundingClientRect();
      return Math.max(1, rect.width + getGap());
    };
    const pageCount = () => Math.max(1, getSlides().length);
    const currentPage = () => Math.min(pageCount(), Math.max(1, Math.round(viewport.scrollLeft / pageSize()) + 1));
    const goToPage = (pageIndex) => {
      viewport.scrollTo({ left: pageSize() * pageIndex, behavior: 'smooth' });
    };

    const buildDots = () => {
      if (!dots) return;
      const total = pageCount();
      if (dots.children.length === total) return;
      dots.innerHTML = '';
      for (let i = 0; i < total; i += 1) {
        const dot = document.createElement('button');
        dot.type = 'button';
        dot.className = 'z1n3-ink-bullet';
        dot.setAttribute('aria-label', `Go to page ${i + 1}`);
        const img = document.createElement('img');
        img.src = window.z1n3Press?.monkeyBullet || '';
        img.alt = '';
        img.decoding = 'async';
        img.loading = 'lazy';
        dot.appendChild(img);
        dot.addEventListener('click', () => {
          goToPage(i);
        });
        dots.appendChild(dot);
      }
    };

    const update = () => {
      buildDots();
      const page = currentPage();
      const total = pageCount();
      if (status) status.textContent = `${page} / ${total}`;
      if (prev) prev.disabled = page <= 1;
      if (next) next.disabled = page >= total;
      if (dots) {
        Array.from(dots.children).forEach((dot, index) => {
          const active = index === page - 1;
          dot.classList.toggle('is-active', active);
          dot.setAttribute('aria-current', active ? 'page' : 'false');
        });
      }
    };

    prev?.addEventListener('click', () => goToPage(currentPage() - 2));
    next?.addEventListener('click', () => goToPage(currentPage()));
    viewport.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update);
    buildDots();
    window.setTimeout(update, 60);
    update();

    if (slider.dataset.autoplay === 'true') {
      const delay = Number(slider.dataset.autoplayDelay) || 3200;
      let interval = window.setInterval(() => {
        const total = pageCount();
        if (total <= 1) return;
        const nextPage = currentPage() >= total ? 0 : currentPage();
        goToPage(nextPage);
      }, delay);

      const stop = () => {
        if (interval) {
          window.clearInterval(interval);
          interval = null;
        }
      };

      ['pointerdown', 'mouseenter', 'focusin', 'touchstart', 'wheel'].forEach((eventName) => {
        slider.addEventListener(eventName, stop, { passive: true });
      });
    }
  });

  const touchColorTimeout = new WeakMap();
  const imageColorTarget = (target) => {
    if (!(target instanceof Element)) return null;
    const selector = [
      '.z1n3-post-tile',
      '.z1n3-category-card',
      '.z1n3-ink-hero__link',
      '.z1n3-ink-card__link',
      '.z1n3-ink-menu-tile',
      '.z1n3-ink-next',
      '.z1n3-ink-single-hero',
      '.z1n3-ink-thumb-strip img',
      '.z1n3-lightbox__frame img',
      '.z1n3-reader .wp-block-post-featured-image img',
      '.z1n3-reader .wp-block-post-content img',
      '.z1n3-reader .wp-block-gallery img',
      'img'
    ].join(', ');
    return target.closest(selector);
  };
  const showColorOnTouch = (element) => {
    if (!element) return;
    element.classList.add('is-touch-color');
    const existing = touchColorTimeout.get(element);
    if (existing) window.clearTimeout(existing);
    const timeout = window.setTimeout(() => {
      element.classList.remove('is-touch-color');
      touchColorTimeout.delete(element);
    }, 900);
    touchColorTimeout.set(element, timeout);
  };
  document.addEventListener('touchstart', (event) => {
    const element = imageColorTarget(event.target);
    if (element) showColorOnTouch(element);
  }, { passive: true, capture: true });
  document.addEventListener('pointerover', (event) => {
    if (event.pointerType && event.pointerType !== 'mouse') return;
    const element = imageColorTarget(event.target);
    if (element) element.classList.add('is-pointer-color');
  }, true);
  document.addEventListener('pointerout', (event) => {
    if (event.pointerType && event.pointerType !== 'mouse') return;
    const element = imageColorTarget(event.target);
    if (element) element.classList.remove('is-pointer-color');
  }, true);

  // Use the restored global lightbox lower in this file. The older per-post
  // wrapper lightbox is intentionally disabled to prevent duplicate gallery
  // click handlers and broken horizontal gallery sliding.
  return;

  const postContent = document.querySelector('.z1n3-reader .wp-block-post-content');
  if (!postContent) return;

  const candidates = Array.from(
    postContent.querySelectorAll('.wp-block-gallery img, .blocks-gallery-item img')
  ).filter((img) => img.currentSrc || img.src);

  if (!candidates.length) return;

  const imageData = candidates.map((img) => ({
    src: img.currentSrc || img.src,
    full: img.dataset.fullUrl || img.closest('a')?.href || img.currentSrc || img.src,
    alt: img.getAttribute('alt') || '',
    caption:
      img.closest('figure')?.querySelector('figcaption')?.textContent?.trim() ||
      img.closest('.blocks-gallery-item')?.querySelector('figcaption')?.textContent?.trim() ||
      ''
  }));

  candidates.forEach((img, index) => {
    const wrapper = document.createElement('button');
    wrapper.type = 'button';
    wrapper.className = 'z1n3-lightbox-toggle';
    wrapper.setAttribute('aria-label', `Open image ${index + 1} in lightbox`);

    const parent = img.parentElement;
    parent.insertBefore(wrapper, img);
    wrapper.appendChild(img);

    if (parent.tagName === 'A') {
      parent.addEventListener('click', (event) => event.preventDefault());
    }

    wrapper.addEventListener('click', () => openLightbox(index));
  });

  const lightbox = document.createElement('dialog');
  lightbox.className = 'z1n3-lightbox';
  lightbox.innerHTML = `
    <div class="z1n3-lightbox__inner" aria-live="polite">
      <div class="z1n3-lightbox__topbar">
        <div class="z1n3-lightbox__index" data-lightbox-index>1 / ${imageData.length}</div>
        <div class="z1n3-lightbox__actions">
          <div class="z1n3-lightbox__speed" role="group" aria-label="Automatic slider speed">
            <button type="button" data-lightbox-speed="slow">Slow slider</button>
            <button type="button" data-lightbox-speed="medium" aria-pressed="true">Medium slider</button>
            <button type="button" data-lightbox-speed="fast">Fast slider</button>
          </div>
          <button class="z1n3-lightbox__play" type="button" data-lightbox-play aria-label="Pause automatic gallery playback" aria-pressed="true">Pause</button>
          <button class="z1n3-lightbox__close" type="button" data-lightbox-close aria-label="Close lightbox">×</button>
        </div>
      </div>
      <div class="z1n3-lightbox__frame">
        <button class="z1n3-lightbox__nav is-prev" type="button" data-lightbox-prev aria-label="Previous image">←</button>
        <img src="" alt="" data-lightbox-image>
        <button class="z1n3-lightbox__nav is-next" type="button" data-lightbox-next aria-label="Next image">→</button>
      </div>
      <div class="z1n3-lightbox__progress" aria-hidden="true"><span data-lightbox-progress></span></div>
      <div class="z1n3-lightbox__meta">
        <div data-lightbox-caption></div>
        <span class="z1n3-lightbox__hint">Auto-play on • swipe, tap arrows, or use keyboard</span>
      </div>
    </div>
  `;
  document.body.appendChild(lightbox);

  const lightboxImg = lightbox.querySelector('[data-lightbox-image]');
  const lightboxCaption = lightbox.querySelector('[data-lightbox-caption]');
  const lightboxIndex = lightbox.querySelector('[data-lightbox-index]');
  const prevButton = lightbox.querySelector('[data-lightbox-prev]');
  const nextButton = lightbox.querySelector('[data-lightbox-next]');
  const closeLightboxButton = lightbox.querySelector('[data-lightbox-close]');
  const playButton = lightbox.querySelector('[data-lightbox-play]');
  const speedButtons = Array.from(lightbox.querySelectorAll('[data-lightbox-speed]'));
  const progressBar = lightbox.querySelector('[data-lightbox-progress]');
  let currentIndex = 0;
  let triggerButton = null;
  let autoplayTimer = null;
  const autoplaySpeeds = { slow: 8000, medium: Number(window.z1n3Press?.lightboxDelay) || 4200, fast: 1800 };
  let autoplaySpeed = 'medium';
  let autoplayDelay = autoplaySpeeds[autoplaySpeed];

  const canAutoplay = () => imageData.length > 1 && !window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const setProgress = () => {
    if (!progressBar) return;
    progressBar.style.animation = 'none';
    progressBar.offsetHeight;
    progressBar.style.animation = autoplayTimer ? `z1n3LightboxProgress ${autoplayDelay}ms linear forwards` : 'none';
  };

  const stopAutoplay = () => {
    if (autoplayTimer) {
      window.clearInterval(autoplayTimer);
      autoplayTimer = null;
    }
    if (playButton) {
      playButton.textContent = 'Play';
      playButton.setAttribute('aria-label', 'Start automatic gallery playback');
      playButton.setAttribute('aria-pressed', 'false');
    }
    setProgress();
  };

  const startAutoplay = () => {
    if (!canAutoplay()) return;
    stopAutoplay();
    autoplayTimer = window.setInterval(() => {
      currentIndex = (currentIndex + 1) % imageData.length;
      renderLightbox();
      setProgress();
    }, autoplayDelay);
    if (playButton) {
      playButton.textContent = 'Pause';
      playButton.setAttribute('aria-label', 'Pause automatic gallery playback');
      playButton.setAttribute('aria-pressed', 'true');
    }
    setProgress();
  };

  const renderLightbox = () => {
    const item = imageData[currentIndex];
    lightboxImg.src = item.full || item.src;
    lightboxImg.alt = item.alt || '';
    lightboxCaption.textContent = item.caption || item.alt || '';
    lightboxIndex.textContent = `${currentIndex + 1} / ${imageData.length}`;
    prevButton.disabled = imageData.length < 2;
    nextButton.disabled = imageData.length < 2;
  };

  const goLightbox = (direction) => {
    if (imageData.length < 2) return;
    currentIndex = (currentIndex + direction + imageData.length) % imageData.length;
    renderLightbox();
    setProgress();
  };

  const openLightbox = (index) => {
    currentIndex = index;
    triggerButton = document.activeElement;
    renderLightbox();
    if (typeof lightbox.showModal === 'function') {
      lightbox.showModal();
    } else {
      lightbox.setAttribute('open', 'open');
    }
    closeLightboxButton.focus();
    startAutoplay();
  };

  const closeLightbox = () => {
    stopAutoplay();
    if (lightbox.open && typeof lightbox.close === 'function') {
      lightbox.close();
    } else {
      lightbox.removeAttribute('open');
    }
    if (triggerButton && typeof triggerButton.focus === 'function') {
      triggerButton.focus();
    }
  };

  prevButton.addEventListener('click', () => goLightbox(-1));
  nextButton.addEventListener('click', () => goLightbox(1));
  playButton?.addEventListener('click', () => {
    if (autoplayTimer) stopAutoplay();
    else startAutoplay();
  });

  speedButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const nextSpeed = button.getAttribute('data-lightbox-speed') || 'medium';
      autoplaySpeed = autoplaySpeeds[nextSpeed] ? nextSpeed : 'medium';
      autoplayDelay = autoplaySpeeds[autoplaySpeed];
      speedButtons.forEach((speedButton) => {
        speedButton.setAttribute('aria-pressed', speedButton === button ? 'true' : 'false');
      });
      if (autoplayTimer) startAutoplay();
      else setProgress();
    });
  });

  closeLightboxButton.addEventListener('click', closeLightbox);
  lightbox.addEventListener('cancel', closeLightbox);

  lightbox.addEventListener('click', (event) => {
    const rect = lightbox.getBoundingClientRect();
    const inDialog =
      rect.top <= event.clientY &&
      event.clientY <= rect.top + rect.height &&
      rect.left <= event.clientX &&
      event.clientX <= rect.left + rect.width;
    if (!inDialog) closeLightbox();
  });

  let lightboxStartX = 0;
  let lightboxStartY = 0;
  let lightboxPointerActive = false;

  lightbox.addEventListener('pointerdown', (event) => {
    lightboxPointerActive = true;
    lightboxStartX = event.clientX;
    lightboxStartY = event.clientY;
  }, { passive: true });

  lightbox.addEventListener('pointerup', (event) => {
    if (!lightboxPointerActive) return;
    lightboxPointerActive = false;
    const dx = event.clientX - lightboxStartX;
    const dy = event.clientY - lightboxStartY;
    if (Math.abs(dx) < 54 || Math.abs(dy) > 80) return;
    goLightbox(dx < 0 ? 1 : -1);
  }, { passive: true });

  window.addEventListener('keydown', (event) => {
    if (!lightbox.open) return;
    if (event.key === 'ArrowLeft') {
      goLightbox(-1);
    } else if (event.key === 'ArrowRight' || event.key === ' ') {
      event.preventDefault();
      goLightbox(1);
    } else if (event.key === 'Escape') {
      closeLightbox();
    }
  });
})();


// INK MONKEY 1337-01: make archive feature slider update the centered page indicator.
(() => {
  const feature = document.querySelector('.z1n3-ink-feature-slider [data-z1n3-viewport]');
  if (!feature) return;
  const status = document.querySelector('.z1n3-ink-feature-slider [data-z1n3-status]');
  const slides = Array.from(feature.querySelectorAll('.z1n3-ink-card'));
  const update = () => {
    if (!slides.length || !status) return;
    const center = feature.scrollLeft + feature.clientWidth / 2;
    let active = 0;
    let best = Infinity;
    slides.forEach((slide, index) => {
      const c = slide.offsetLeft + slide.offsetWidth / 2;
      const dist = Math.abs(c - center);
      if (dist < best) { best = dist; active = index; }
    });
    status.textContent = `${active + 1} / ${slides.length}`;
  };
  feature.addEventListener('scroll', update, { passive: true });
  window.addEventListener('resize', update);
  update();
})();


/* ======================================================================
   v1337-01.2 — INK MONKEY real slider repair.
   Supports the new visual INK templates, which use .z1n3-ink-card-row and
   .z1n3-ink-feature-slider instead of only the older data-z1n3-slider markup.
   ====================================================================== */
(() => {
  const ready = (fn) => {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, { once:true });
    else fn();
  };

  ready(() => {
    const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const getPages = (viewport) => {
      const cards = Array.from(viewport.children).filter((el) => el instanceof HTMLElement);
      if (!cards.length) return [];
      return cards.map((card) => Math.max(0, card.offsetLeft - viewport.offsetLeft));
    };

    const currentIndex = (viewport, pages) => {
      if (!pages.length) return 0;
      const left = viewport.scrollLeft;
      let best = 0;
      let dist = Infinity;
      pages.forEach((x, i) => {
        const d = Math.abs(x - left);
        if (d < dist) { dist = d; best = i; }
      });
      return best;
    };

    const findNav = (root) => {
      const direct = root.querySelector('.z1n3-ink-under-nav');
      if (direct) return direct;
      let n = root.nextElementSibling;
      while (n) {
        if (n.matches && n.matches('.z1n3-ink-under-nav')) return n;
        const inner = n.querySelector && n.querySelector('.z1n3-ink-under-nav');
        if (inner) return inner;
        n = n.nextElementSibling;
      }
      return null;
    };

    const setup = (root, viewport, opts = {}) => {
      if (!root || !viewport || viewport.dataset.inkSliderReady === 'true') return;
      viewport.dataset.inkSliderReady = 'true';

      const nav = opts.nav || findNav(root);
      const bulletWrap = nav ? nav.querySelector('.z1n3-ink-bullets') : null;
      const count = nav ? nav.querySelector('.z1n3-ink-page-count,[data-z1n3-status]') : null;
      const delay = Number(root.dataset.autoplayDelay || opts.delay || 3400);
      const shouldLoop = root.dataset.autoplay !== 'false' && !reduceMotion;

      let timer = null;
      let userPausedUntil = 0;

      const pages = () => getPages(viewport);

      const renderBullets = () => {
        const p = pages();
        if (!bulletWrap || !p.length) return;
        const existing = Array.from(bulletWrap.children);
        if (existing.length !== p.length) {
          const src = existing[0]?.querySelector('img')?.getAttribute('src') ||
            document.querySelector('.z1n3-ink-bullet img')?.getAttribute('src') ||
            '';
          bulletWrap.innerHTML = '';
          p.forEach((_, i) => {
            const b = document.createElement('button');
            b.type = 'button';
            b.className = 'z1n3-ink-bullet';
            b.setAttribute('aria-label', `Go to slide ${i + 1}`);
            if (src) {
              const img = document.createElement('img');
              img.src = src;
              img.alt = '';
              img.loading = 'lazy';
              img.decoding = 'async';
              b.appendChild(img);
            }
            b.addEventListener('click', () => {
              pauseBriefly();
              viewport.scrollTo({ left: p[i], behavior:'smooth' });
            });
            bulletWrap.appendChild(b);
          });
        }
      };

      const update = () => {
        const p = pages();
        if (!p.length) return;
        renderBullets();
        const idx = currentIndex(viewport, p);
        if (count) count.textContent = `${idx + 1} / ${p.length}`;
        if (bulletWrap) {
          Array.from(bulletWrap.children).forEach((b, i) => {
            b.classList.toggle('is-active', i === idx);
            b.setAttribute('aria-current', i === idx ? 'page' : 'false');
          });
        }
      };

      const go = (delta) => {
        const p = pages();
        if (p.length < 2) return;
        const idx = currentIndex(viewport, p);
        const next = (idx + delta + p.length) % p.length;
        viewport.scrollTo({ left:p[next], behavior:'smooth' });
      };

      const pauseBriefly = () => {
        userPausedUntil = Date.now() + 4200;
      };

      ['touchstart','pointerdown','wheel','focusin'].forEach((name) => {
        viewport.addEventListener(name, pauseBriefly, { passive:true });
      });

      viewport.addEventListener('scroll', () => window.requestAnimationFrame(update), { passive:true });
      window.addEventListener('resize', () => window.setTimeout(update, 80));

      renderBullets();
      update();

      if (shouldLoop) {
        timer = window.setInterval(() => {
          if (Date.now() < userPausedUntil) return;
          go(1);
        }, delay);
      }
    };

    document.querySelectorAll('.z1n3-ink-latest').forEach((section) => {
      const row = section.querySelector('.z1n3-ink-card-row');
      if (!row) return;
      section.dataset.autoplay = section.dataset.autoplay || 'true';
      section.dataset.autoplayDelay = section.dataset.autoplayDelay || '3300';
      setup(section, row, { delay:3300 });
    });

    document.querySelectorAll('.z1n3-ink-feature-slider').forEach((section) => {
      const viewport = section.querySelector('.z1n3-ink-feature-slider__viewport');
      const track = section.querySelector('.z1n3-ink-feature-slider__track');
      if (!viewport || !track) return;
      section.dataset.autoplay = section.dataset.autoplay || 'true';
      section.dataset.autoplayDelay = section.dataset.autoplayDelay || '3600';
      // Use the track as the scrolling content if the viewport contains only the track.
      // The viewport scrolls, but the slide offsets live on the track children.
      if (viewport.children.length === 1 && viewport.firstElementChild === track) {
        // Proxy by using a lightweight adapter: read child offsets relative to viewport.
        viewport.dataset.inkSliderReady = 'true';
        const nav = findNav(section);
        const bulletWrap = nav ? nav.querySelector('.z1n3-ink-bullets') : null;
        const count = nav ? nav.querySelector('.z1n3-ink-page-count,[data-z1n3-status]') : null;
        const slides = () => Array.from(track.children).filter((el) => el instanceof HTMLElement);
        const positions = () => slides().map((slide) => Math.max(0, slide.offsetLeft + track.offsetLeft - viewport.offsetLeft));
        const index = () => currentIndex(viewport, positions());
        const render = () => {
          const p = positions();
          if (bulletWrap && bulletWrap.children.length !== p.length) {
            const src = document.querySelector('.z1n3-ink-bullet img')?.getAttribute('src') || '';
            bulletWrap.innerHTML = '';
            p.forEach((_, i) => {
              const b = document.createElement('button');
              b.type = 'button';
              b.className = 'z1n3-ink-bullet';
              b.setAttribute('aria-label', `Go to slide ${i + 1}`);
              if (src) {
                const img = document.createElement('img');
                img.src = src; img.alt = ''; img.loading = 'lazy'; img.decoding = 'async';
                b.appendChild(img);
              }
              b.addEventListener('click', () => viewport.scrollTo({ left:p[i], behavior:'smooth' }));
              bulletWrap.appendChild(b);
            });
          }
          const idx = index();
          if (count) count.textContent = `${idx + 1} / ${p.length || 1}`;
          if (bulletWrap) Array.from(bulletWrap.children).forEach((b, i) => b.classList.toggle('is-active', i === idx));
        };
        let paused = 0;
        ['touchstart','pointerdown','wheel','focusin'].forEach((name) => viewport.addEventListener(name, () => { paused = Date.now() + 4200; }, { passive:true }));
        viewport.addEventListener('scroll', () => window.requestAnimationFrame(render), { passive:true });
        window.addEventListener('resize', () => window.setTimeout(render, 80));
        render();
        if (!reduceMotion) {
          window.setInterval(() => {
            if (Date.now() < paused) return;
            const p = positions();
            if (p.length < 2) return;
            const next = (index() + 1) % p.length;
            viewport.scrollTo({ left:p[next], behavior:'smooth' });
          }, Number(section.dataset.autoplayDelay) || 3600);
        }
        return;
      }
      setup(section, viewport, { delay:3600 });
    });
  });
})();


/* v1337-01.4 — hero slider + monkey-bullet repair */
(() => {
  const ready = (fn) => {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, { once:true });
    else fn();
  };

  ready(() => {
    const bulletSrc = window.z1n3Press?.monkeyBullet || document.querySelector('.z1n3-ink-bullet img')?.getAttribute('src') || '';
    const normalizeBullets = (wrap) => {
      if (!wrap) return;
      Array.from(wrap.children).forEach((b) => {
        b.classList.add('z1n3-ink-bullet');
        if (bulletSrc && !b.querySelector('img')) {
          const img = document.createElement('img');
          img.src = bulletSrc;
          img.alt = '';
          img.loading = 'lazy';
          img.decoding = 'async';
          b.appendChild(img);
        }
      });
    };

    const setupHero = (slider) => {
      const viewport = slider.querySelector('[data-z1n3-hero-viewport]');
      const track = slider.querySelector('.z1n3-ink-hero-slider__track');
      const nav = slider.querySelector('.z1n3-ink-hero-nav');
      const bullets = nav?.querySelector('.z1n3-ink-bullets');
      const status = nav?.querySelector('[data-z1n3-status]');
      if (!viewport || !track || viewport.dataset.heroReady === 'true') return;
      viewport.dataset.heroReady = 'true';

      const slides = () => Array.from(track.children).filter((el) => el instanceof HTMLElement);
      const positions = () => slides().map((slide) => Math.max(0, slide.offsetLeft + track.offsetLeft - viewport.offsetLeft));
      const index = () => {
        const p = positions();
        let best = 0;
        let dist = Infinity;
        p.forEach((x, i) => {
          const d = Math.abs(x - viewport.scrollLeft);
          if (d < dist) { dist = d; best = i; }
        });
        return best;
      };

      const renderBullets = () => {
        const p = positions();
        if (!bullets || !p.length) return;
        if (bullets.children.length !== p.length) {
          bullets.innerHTML = '';
          p.forEach((_, i) => {
            const b = document.createElement('button');
            b.type = 'button';
            b.className = 'z1n3-ink-bullet';
            b.setAttribute('aria-label', `Go to featured slide ${i + 1}`);
            if (bulletSrc) {
              const img = document.createElement('img');
              img.src = bulletSrc;
              img.alt = '';
              img.loading = 'lazy';
              img.decoding = 'async';
              b.appendChild(img);
            }
            b.addEventListener('click', () => {
              pausedUntil = Date.now() + 4200;
              viewport.scrollTo({ left:p[i], behavior:'smooth' });
            });
            bullets.appendChild(b);
          });
        }
        normalizeBullets(bullets);
      };

      const render = () => {
        const p = positions();
        if (!p.length) return;
        renderBullets();
        const idx = index();
        if (status) status.textContent = `${idx + 1} / ${p.length}`;
        if (bullets) Array.from(bullets.children).forEach((b, i) => {
          b.classList.toggle('is-active', i === idx);
          b.setAttribute('aria-current', i === idx ? 'page' : 'false');
        });
      };

      let pausedUntil = 0;
      ['touchstart','pointerdown','wheel','focusin'].forEach((name) => viewport.addEventListener(name, () => { pausedUntil = Date.now() + 4200; }, { passive:true }));
      viewport.addEventListener('scroll', () => window.requestAnimationFrame(render), { passive:true });
      window.addEventListener('resize', () => window.setTimeout(render, 80));
      render();

      if (slider.dataset.autoplay !== 'false' && !(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches)) {
        window.setInterval(() => {
          if (Date.now() < pausedUntil) return;
          const p = positions();
          if (p.length < 2) return;
          const next = (index() + 1) % p.length;
          viewport.scrollTo({ left:p[next], behavior:'smooth' });
        }, Number(slider.dataset.autoplayDelay) || 3800);
      }
    };

    document.querySelectorAll('.z1n3-ink-bullets').forEach(normalizeBullets);
    document.querySelectorAll('[data-z1n3-hero-slider]').forEach(setupHero);
  });
})();

/* v1337-01.19 — restored global gallery lightbox */
(() => {
  const ready = (fn) => {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, { once:true });
    else fn();
  };

  ready(() => {
    if (document.body.dataset.z1n3GlobalLightbox === 'true') return;
    const selectors = [
      '.z1n3-ink-thumb-strip a[href]',
      '.wp-block-gallery a[href]',
      '.blocks-gallery-item a[href]',
      '.wp-block-post-content figure a[href]'
    ];
    const anchors = Array.from(document.querySelectorAll(selectors.join(','))).filter((a) => {
      const href = a.getAttribute('href') || '';
      return /\.(png|jpe?g|gif|webp|avif)(\?.*)?$/i.test(href) || a.querySelector('img');
    });

    const looseImages = Array.from(document.querySelectorAll('.wp-block-gallery img, .blocks-gallery-item img, .z1n3-ink-thumb-strip img'))
      .filter((img) => !img.closest('a'));

    const items = [];
    const addItem = (trigger, src, thumb, alt, caption) => {
      if (!src || items.some((item) => item.full === src && item.trigger === trigger)) return;
      items.push({ trigger, full:src, src:thumb || src, alt:alt || '', caption:caption || alt || '' });
    };

    anchors.forEach((a) => {
      const img = a.querySelector('img');
      const href = a.getAttribute('href') || img?.currentSrc || img?.src;
      addItem(a, href, img?.currentSrc || img?.src || href, img?.alt || '', a.closest('figure')?.querySelector('figcaption')?.textContent?.trim() || '');
    });
    looseImages.forEach((img) => {
      const src = img.dataset.fullUrl || img.currentSrc || img.src;
      addItem(img, src, src, img.alt || '', img.closest('figure')?.querySelector('figcaption')?.textContent?.trim() || '');
    });

    if (!items.length) return;
    document.body.dataset.z1n3GlobalLightbox = 'true';

    const lightbox = document.createElement('dialog');
    lightbox.className = 'z1n3-lightbox z1n3-lightbox--global';
    lightbox.innerHTML = `
      <div class="z1n3-lightbox__inner" aria-live="polite">
        <div class="z1n3-lightbox__topbar">
          <div class="z1n3-lightbox__index" data-lightbox-index>1 / ${items.length}</div>
          <div class="z1n3-lightbox__actions">
            <div class="z1n3-lightbox__speed" role="group" aria-label="Automatic slider speed">
              <button type="button" data-lightbox-speed="slow">Slow slider</button>
              <button type="button" data-lightbox-speed="medium" aria-pressed="true">Medium slider</button>
              <button type="button" data-lightbox-speed="fast">Fast slider</button>
            </div>
            <button class="z1n3-lightbox__play" type="button" data-lightbox-play aria-label="Pause automatic gallery playback" aria-pressed="true">Pause</button>
            <button class="z1n3-lightbox__close" type="button" data-lightbox-close aria-label="Close lightbox">×</button>
          </div>
        </div>
        <div class="z1n3-lightbox__frame">
          <button class="z1n3-lightbox__nav is-prev" type="button" data-lightbox-prev aria-label="Previous image">←</button>
          <img src="" alt="" data-lightbox-image>
          <button class="z1n3-lightbox__nav is-next" type="button" data-lightbox-next aria-label="Next image">→</button>
        </div>
        <div class="z1n3-lightbox__progress" aria-hidden="true"><span data-lightbox-progress></span></div>
        <div class="z1n3-lightbox__meta"><div data-lightbox-caption></div><span class="z1n3-lightbox__hint">Auto-play on • swipe, tap arrows, or use keyboard</span></div>
      </div>`;
    document.body.appendChild(lightbox);

    const img = lightbox.querySelector('[data-lightbox-image]');
    const caption = lightbox.querySelector('[data-lightbox-caption]');
    const counter = lightbox.querySelector('[data-lightbox-index]');
    const progress = lightbox.querySelector('[data-lightbox-progress]');
    const play = lightbox.querySelector('[data-lightbox-play]');
    const speedButtons = Array.from(lightbox.querySelectorAll('[data-lightbox-speed]'));
    const speeds = { slow:8000, medium:4200, fast:1800 };
    let index = 0;
    let speed = 'medium';
    let playing = true;
    let timer = null;
    let progressStart = 0;
    let raf = null;

    const setPressed = () => {
      speedButtons.forEach((button) => button.setAttribute('aria-pressed', button.dataset.lightboxSpeed === speed ? 'true' : 'false'));
      play.setAttribute('aria-pressed', playing ? 'true' : 'false');
      play.textContent = playing ? 'Pause' : 'Play';
    };
    const drawProgress = () => {
      if (!playing || !progress) return;
      const pct = Math.min(100, ((Date.now() - progressStart) / speeds[speed]) * 100);
      progress.style.width = `${pct}%`;
      raf = window.requestAnimationFrame(drawProgress);
    };
    const stopTimer = () => {
      if (timer) window.clearTimeout(timer);
      timer = null;
      if (raf) window.cancelAnimationFrame(raf);
      raf = null;
      if (progress) progress.style.width = '0%';
    };
    const schedule = () => {
      stopTimer();
      setPressed();
      if (!playing || items.length < 2 || !lightbox.open) return;
      progressStart = Date.now();
      drawProgress();
      timer = window.setTimeout(() => show(index + 1, true), speeds[speed]);
    };
    function show(nextIndex, auto = false) {
      index = (nextIndex + items.length) % items.length;
      const item = items[index];
      img.src = item.full || item.src;
      img.alt = item.alt || '';
      caption.textContent = item.caption || item.alt || '';
      counter.textContent = `${index + 1} / ${items.length}`;
      if (!auto) playing = true;
      schedule();
    }
    const open = (i) => {
      index = i;
      playing = true;
      if (typeof lightbox.showModal === 'function') lightbox.showModal();
      else lightbox.setAttribute('open', 'open');
      document.documentElement.classList.add('z1n3-lightbox-open');
      show(index);
    };
    const close = () => {
      stopTimer();
      document.documentElement.classList.remove('z1n3-lightbox-open');
      if (lightbox.open && typeof lightbox.close === 'function') lightbox.close();
      else lightbox.removeAttribute('open');
    };

    items.forEach((item, i) => {
      item.trigger.classList.add('z1n3-lightbox-toggle');
      item.trigger.addEventListener('click', (event) => {
        event.preventDefault();
        open(i);
      });
    });
    lightbox.querySelector('[data-lightbox-prev]').addEventListener('click', () => show(index - 1));
    lightbox.querySelector('[data-lightbox-next]').addEventListener('click', () => show(index + 1));
    lightbox.querySelector('[data-lightbox-close]').addEventListener('click', close);
    play.addEventListener('click', () => { playing = !playing; schedule(); });
    speedButtons.forEach((button) => button.addEventListener('click', () => { speed = button.dataset.lightboxSpeed || 'medium'; playing = true; schedule(); }));
    lightbox.addEventListener('cancel', close);
    lightbox.addEventListener('click', (event) => { if (event.target === lightbox) close(); });
    document.addEventListener('keydown', (event) => {
      if (!lightbox.open) return;
      if (event.key === 'ArrowRight') show(index + 1);
      if (event.key === 'ArrowLeft') show(index - 1);
      if (event.key === ' ') { event.preventDefault(); playing = !playing; schedule(); }
    });
    let startX = 0;
    lightbox.addEventListener('pointerdown', (event) => { startX = event.clientX; }, { passive:true });
    lightbox.addEventListener('pointerup', (event) => {
      const dx = event.clientX - startX;
      if (Math.abs(dx) > 45) show(index + (dx < 0 ? 1 : -1));
    }, { passive:true });
  });
})();

/* v1337-01.21 — article gallery slider repair: isolate gallery swipes and add controls. */
(() => {
  const ready = (fn) => {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, { once:true });
    else fn();
  };

  ready(() => {
    const gallerySelector = '.z1n3-reader .wp-block-post-content .wp-block-gallery, .wp-block-post-content .wp-block-gallery';
    const galleries = Array.from(document.querySelectorAll(gallerySelector));

    const getSlides = (gallery) => {
      const grid = gallery.querySelector(':scope > .blocks-gallery-grid');
      const root = grid || gallery;
      return Array.from(root.children).filter((el) => el instanceof HTMLElement && (el.matches('figure, .wp-block-image, .blocks-gallery-item') || el.querySelector('img')));
    };

    const getPositions = (gallery, slides) => slides.map((slide) => {
      const galleryRect = gallery.getBoundingClientRect();
      const slideRect = slide.getBoundingClientRect();
      return Math.max(0, slideRect.left - galleryRect.left + gallery.scrollLeft);
    });

    const currentIndex = (gallery, positions) => {
      if (!positions.length) return 0;
      let best = 0;
      let distance = Infinity;
      positions.forEach((left, index) => {
        const d = Math.abs(left - gallery.scrollLeft);
        if (d < distance) {
          distance = d;
          best = index;
        }
      });
      return best;
    };

    galleries.forEach((gallery) => {
      if (gallery.dataset.z1n3GalleryReady === 'true') return;
      gallery.dataset.z1n3GalleryReady = 'true';
      gallery.setAttribute('tabindex', gallery.getAttribute('tabindex') || '0');
      gallery.setAttribute('role', gallery.getAttribute('role') || 'region');
      gallery.setAttribute('aria-label', gallery.getAttribute('aria-label') || 'Article image gallery');

      let wrapper = gallery.closest('.z1n3-gallery-slider');
      if (!wrapper) {
        wrapper = document.createElement('div');
        wrapper.className = 'z1n3-gallery-slider';
        gallery.parentNode.insertBefore(wrapper, gallery);
        wrapper.appendChild(gallery);
      }

      if (!wrapper.querySelector('.z1n3-gallery-slider__nav')) {
        const nav = document.createElement('div');
        nav.className = 'z1n3-gallery-slider__nav';
        nav.innerHTML = '<button type="button" class="z1n3-gallery-slider__button" data-gallery-prev aria-label="Previous gallery image">←</button><span class="z1n3-gallery-slider__status" data-gallery-status>1 / 1</span><button type="button" class="z1n3-gallery-slider__button" data-gallery-next aria-label="Next gallery image">→</button>';
        wrapper.appendChild(nav);
      }

      const prev = wrapper.querySelector('[data-gallery-prev]');
      const next = wrapper.querySelector('[data-gallery-next]');
      const status = wrapper.querySelector('[data-gallery-status]');

      const update = () => {
        const slides = getSlides(gallery);
        const positions = getPositions(gallery, slides);
        const index = currentIndex(gallery, positions);
        if (status) status.textContent = `${slides.length ? index + 1 : 0} / ${Math.max(slides.length, 1)}`;
        if (prev) prev.disabled = index <= 0;
        if (next) next.disabled = !slides.length || index >= slides.length - 1;
      };

      const go = (delta) => {
        const slides = getSlides(gallery);
        const positions = getPositions(gallery, slides);
        if (positions.length < 2) return;
        const index = currentIndex(gallery, positions);
        const target = Math.max(0, Math.min(positions.length - 1, index + delta));
        gallery.scrollTo({ left:positions[target], behavior:'smooth' });
      };

      prev?.addEventListener('click', () => go(-1));
      next?.addEventListener('click', () => go(1));
      gallery.addEventListener('scroll', () => window.requestAnimationFrame(update), { passive:true });
      gallery.addEventListener('keydown', (event) => {
        if (event.key === 'ArrowLeft') { event.preventDefault(); go(-1); }
        if (event.key === 'ArrowRight') { event.preventDefault(); go(1); }
      });
      ['pointerdown','touchstart','wheel'].forEach((name) => {
        gallery.addEventListener(name, (event) => event.stopPropagation(), { capture:true, passive:true });
      });
      window.addEventListener('resize', () => window.setTimeout(update, 80));
      window.setTimeout(update, 80);
      update();
    });
  });
})();

/* v1337-01.22 — make the custom INK single article thumb-strip scroll like a gallery. */
(() => {
  const ready = (fn) => {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, { once:true });
    else fn();
  };

  ready(() => {
    document.querySelectorAll('[data-z1n3-single-gallery], .z1n3-ink-single .z1n3-ink-thumb-strip').forEach((strip) => {
      if (!(strip instanceof HTMLElement) || strip.dataset.z1n3SingleGalleryReady === 'true') return;
      strip.dataset.z1n3SingleGalleryReady = 'true';
      strip.setAttribute('tabindex', strip.getAttribute('tabindex') || '0');
      strip.setAttribute('role', strip.getAttribute('role') || 'region');
      strip.setAttribute('aria-label', strip.getAttribute('aria-label') || 'Article image gallery');

      const slides = () => Array.from(strip.querySelectorAll(':scope > a, :scope > figure, :scope > .wp-block-image')).filter((el) => el instanceof HTMLElement);
      const positions = () => slides().map((slide) => Math.max(0, slide.offsetLeft - strip.offsetLeft));
      const currentIndex = () => {
        const p = positions();
        if (!p.length) return 0;
        let best = 0;
        let distance = Infinity;
        p.forEach((left, index) => {
          const d = Math.abs(left - strip.scrollLeft);
          if (d < distance) { distance = d; best = index; }
        });
        return best;
      };
      const go = (delta) => {
        const p = positions();
        if (p.length < 2) return;
        const next = Math.max(0, Math.min(p.length - 1, currentIndex() + delta));
        strip.scrollTo({ left:p[next], behavior:'smooth' });
      };

      let nav = strip.nextElementSibling && strip.nextElementSibling.classList?.contains('z1n3-single-gallery-nav') ? strip.nextElementSibling : null;
      if (!nav && slides().length > 1) {
        nav = document.createElement('div');
        nav.className = 'z1n3-single-gallery-nav';
        nav.innerHTML = '<button type="button" data-single-gallery-prev aria-label="Previous gallery image">←</button><span data-single-gallery-status>1 / 1</span><button type="button" data-single-gallery-next aria-label="Next gallery image">→</button>';
        strip.insertAdjacentElement('afterend', nav);
      }
      const prev = nav?.querySelector('[data-single-gallery-prev]');
      const next = nav?.querySelector('[data-single-gallery-next]');
      const status = nav?.querySelector('[data-single-gallery-status]');
      const update = () => {
        const count = slides().length;
        const index = currentIndex();
        if (status) status.textContent = `${count ? index + 1 : 0} / ${Math.max(1, count)}`;
        if (prev) prev.disabled = index <= 0;
        if (next) next.disabled = count < 2 || index >= count - 1;
      };

      prev?.addEventListener('click', () => go(-1));
      next?.addEventListener('click', () => go(1));
      strip.addEventListener('keydown', (event) => {
        if (event.key === 'ArrowLeft') { event.preventDefault(); go(-1); }
        if (event.key === 'ArrowRight') { event.preventDefault(); go(1); }
      });
      strip.addEventListener('scroll', () => window.requestAnimationFrame(update), { passive:true });
      ['pointerdown','touchstart','wheel'].forEach((name) => {
        strip.addEventListener(name, (event) => event.stopPropagation(), { capture:true, passive:true });
      });
      window.addEventListener('resize', () => window.setTimeout(update, 80));
      window.setTimeout(update, 80);
      update();
    });
  });
})();


/* v1337-01.23 — definitive single article gallery SLIDER, not just scroll. */
(() => {
  const ready = (fn) => {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, { once:true });
    else fn();
  };

  ready(() => {
    const strips = Array.from(document.querySelectorAll('[data-z1n3-single-gallery], .z1n3-ink-single .z1n3-ink-thumb-strip'));

    strips.forEach((strip) => {
      if (!(strip instanceof HTMLElement)) return;

      // Remove the previous scroll-only controls so there is one clear slider UI.
      const oldNav = strip.nextElementSibling;
      if (oldNav && oldNav.classList && oldNav.classList.contains('z1n3-single-gallery-nav')) oldNav.remove();

      let shell = strip.closest('.z1n3-single-gallery-shell');
      let viewport = strip.closest('.z1n3-single-gallery-viewport');
      if (!shell || !viewport) {
        shell = document.createElement('section');
        shell.className = 'z1n3-single-gallery-shell';
        shell.setAttribute('aria-label', 'Article image slider');

        viewport = document.createElement('div');
        viewport.className = 'z1n3-single-gallery-viewport';

        strip.parentNode.insertBefore(shell, strip);
        shell.appendChild(viewport);
        viewport.appendChild(strip);
      }

      strip.classList.add('z1n3-single-gallery-track');
      strip.removeAttribute('tabindex');
      viewport.setAttribute('tabindex', '0');
      viewport.setAttribute('role', 'region');
      viewport.setAttribute('aria-label', 'Article image slider');

      let nav = shell.querySelector(':scope > .z1n3-single-gallery-nav');
      if (!nav) {
        nav = document.createElement('div');
        nav.className = 'z1n3-single-gallery-nav';
        nav.innerHTML = '<button type="button" data-single-gallery-prev aria-label="Previous gallery image">←</button><span data-single-gallery-status>1 / 1</span><button type="button" data-single-gallery-next aria-label="Next gallery image">→</button>';
        shell.appendChild(nav);
      }

      const prev = nav.querySelector('[data-single-gallery-prev]');
      const next = nav.querySelector('[data-single-gallery-next]');
      const status = nav.querySelector('[data-single-gallery-status]');
      let index = 0;
      let startX = 0;
      let startY = 0;
      let dragging = false;
      let moved = false;

      const slides = () => Array.from(strip.children).filter((el) => el instanceof HTMLElement);
      const clamp = (value) => Math.max(0, Math.min(Math.max(0, slides().length - 1), value));
      const slideLeft = (i) => {
        const slide = slides()[i];
        if (!slide) return 0;
        return Math.max(0, slide.offsetLeft - strip.offsetLeft);
      };
      const apply = (animate = true) => {
        const items = slides();
        index = clamp(index);
        strip.style.transition = animate ? '' : 'none';
        strip.style.transform = `translate3d(${-slideLeft(index)}px,0,0)`;
        if (status) status.textContent = `${items.length ? index + 1 : 0} / ${Math.max(1, items.length)}`;
        if (prev) prev.disabled = index <= 0;
        if (next) next.disabled = items.length < 2 || index >= items.length - 1;
        items.forEach((slide, i) => slide.classList.toggle('is-active', i === index));
      };
      const go = (nextIndex) => {
        index = clamp(nextIndex);
        apply(true);
      };

      prev?.addEventListener('click', (event) => { event.preventDefault(); event.stopPropagation(); go(index - 1); });
      next?.addEventListener('click', (event) => { event.preventDefault(); event.stopPropagation(); go(index + 1); });

      viewport.addEventListener('keydown', (event) => {
        if (event.key === 'ArrowLeft') { event.preventDefault(); go(index - 1); }
        if (event.key === 'ArrowRight') { event.preventDefault(); go(index + 1); }
      });

      viewport.addEventListener('pointerdown', (event) => {
        if (event.button !== undefined && event.button !== 0) return;
        dragging = true;
        moved = false;
        startX = event.clientX;
        startY = event.clientY;
        viewport.classList.add('is-dragging');
      }, { passive:true });

      viewport.addEventListener('pointermove', (event) => {
        if (!dragging) return;
        const dx = event.clientX - startX;
        const dy = event.clientY - startY;
        if (Math.abs(dx) > 8 && Math.abs(dx) > Math.abs(dy)) moved = true;
      }, { passive:true });

      const finishDrag = (event) => {
        if (!dragging) return;
        dragging = false;
        viewport.classList.remove('is-dragging');
        const dx = event.clientX - startX;
        const dy = event.clientY - startY;
        if (Math.abs(dx) > 42 && Math.abs(dx) > Math.abs(dy)) go(index + (dx < 0 ? 1 : -1));
      };
      viewport.addEventListener('pointerup', finishDrag, { passive:true });
      viewport.addEventListener('pointercancel', finishDrag, { passive:true });
      viewport.addEventListener('lostpointercapture', () => { dragging = false; viewport.classList.remove('is-dragging'); }, { passive:true });

      // A swipe should slide; a normal tap/click should still open the image lightbox.
      strip.addEventListener('click', (event) => {
        if (!moved) return;
        event.preventDefault();
        event.stopPropagation();
        moved = false;
      }, true);

      ['touchstart','pointerdown','wheel'].forEach((name) => {
        shell.addEventListener(name, (event) => event.stopPropagation(), { capture:true, passive:true });
      });

      if (window.ResizeObserver) {
        const ro = new ResizeObserver(() => apply(false));
        ro.observe(viewport);
        slides().forEach((slide) => ro.observe(slide));
      }
      window.addEventListener('resize', () => window.setTimeout(() => apply(false), 80));
      window.setTimeout(() => apply(false), 80);
      apply(false);
    });
  });
})();
