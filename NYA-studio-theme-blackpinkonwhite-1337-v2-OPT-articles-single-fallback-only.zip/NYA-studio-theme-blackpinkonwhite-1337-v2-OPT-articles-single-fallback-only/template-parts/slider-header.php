<?php
/**
 * Header slider with a fixed hero illustration and animated title/subtitle slides.
 */

$slide_query = new WP_Query( array(
    'post_type'      => 'as_slide',
    'posts_per_page' => 5,
    'orderby'        => 'menu_order date',
    'order'          => 'ASC',
) );

$slides = array();
$hero_image = get_template_directory_uri() . '/assets/images/hero-crew.webp';

if ( $slide_query->have_posts() ) {
    while ( $slide_query->have_posts() ) {
        $slide_query->the_post();
        $slides[] = array(
            'title' => get_the_title(),
            'text'  => has_excerpt() ? get_the_excerpt() : wp_trim_words( get_the_content(), 22 ),
            'image' => $hero_image,
        );
    }
    wp_reset_postdata();
}

$promo_slides = array(
    array(
        'title' => __( 'Meet the Crew', 'nya-theme' ),
        'text'  => __( 'Creative duo + AI sidekick', 'nya-theme' ),
        'image' => $hero_image,
    ),
    array(
        'title' => __( 'Full Franchise Concepts', 'nya-theme' ),
        'text'  => __( 'Worldbuilding, character systems, and visual identities that scale.', 'nya-theme' ),
        'image' => $hero_image,
    ),
    array(
        'title' => __( 'Graffiti for Promotion', 'nya-theme' ),
        'text'  => __( 'Painted campaigns, launch visuals, and street-ready brand statements.', 'nya-theme' ),
        'image' => $hero_image,
    ),
    array(
        'title' => __( 'Ideas Into Icons', 'nya-theme' ),
        'text'  => __( 'From rough concepts to symbols, mascots, posters, and franchise assets.', 'nya-theme' ),
        'image' => $hero_image,
    ),
    array(
        'title' => __( 'Bold Ideas, Clean Code', 'nya-theme' ),
        'text'  => __( 'Design. Code. Automate. Build the whole story, not just the page.', 'nya-theme' ),
        'image' => $hero_image,
    ),
    array(
        'title' => __( 'Campaigns With Attitude', 'nya-theme' ),
        'text'  => __( 'Promotional visuals with graffiti energy and cross-media presence.', 'nya-theme' ),
        'image' => $hero_image,
    ),
    array(
        'title' => __( 'Characters That Carry Brands', 'nya-theme' ),
        'text'  => __( 'Franchise-first thinking for recurring heroes, stories, and merch lines.', 'nya-theme' ),
        'image' => $hero_image,
    ),
    array(
        'title' => __( 'Street Art, Studio Systems', 'nya-theme' ),
        'text'  => __( 'Creative direction, visual strategy, and promotional painting in one flow.', 'nya-theme' ),
        'image' => $hero_image,
    ),
);

if ( empty( $slides ) ) {
    $site_name        = get_bloginfo( 'name' ) ? get_bloginfo( 'name' ) : __( 'Not You Again', 'nya-theme' );
    $site_description = get_bloginfo( 'description' ) ? get_bloginfo( 'description' ) : __( 'European design studio', 'nya-theme' );

    $slides[] = array(
        'title' => $site_name,
        'text'  => $site_description,
        'image' => $hero_image,
    );

    $slides = array_merge( $slides, $promo_slides );
} else {
    foreach ( $promo_slides as $promo_slide ) {
        if ( count( $slides ) >= 8 ) {
            break;
        }
        $slides[] = $promo_slide;
    }
}
?>

<div class="header-slider" data-static-slider="true" data-autoplay="true" data-delay="4600">
    <button class="slider-arrow slider-arrow-prev" type="button" aria-label="<?php esc_attr_e( 'Previous slide', 'nya-theme' ); ?>">‹</button>

    <div class="slides-shell">
        <?php foreach ( $slides as $index => $slide ) : ?>
            <article class="slide<?php echo 0 === $index ? ' active' : ''; ?>">
                <div class="slide-copy">
                    <h1 class="title-slide"><?php echo esc_html( $slide['title'] ); ?></h1>
                    <?php if ( ! empty( $slide['text'] ) ) : ?>
                        <p class="text-slide"><?php echo esc_html( $slide['text'] ); ?></p>
                    <?php endif; ?>
                </div>

                <div class="slide-figure-wrap">
                    <?php if ( ! empty( $slide['image'] ) ) : ?>
                        <img src="<?php echo esc_url( $slide['image'] ); ?>" alt="<?php echo esc_attr( $slide['title'] ); ?>">
                    <?php endif; ?>
                </div>
            </article>
        <?php endforeach; ?>
    </div>

    <button class="slider-arrow slider-arrow-next" type="button" aria-label="<?php esc_attr_e( 'Next slide', 'nya-theme' ); ?>">›</button>
</div>
