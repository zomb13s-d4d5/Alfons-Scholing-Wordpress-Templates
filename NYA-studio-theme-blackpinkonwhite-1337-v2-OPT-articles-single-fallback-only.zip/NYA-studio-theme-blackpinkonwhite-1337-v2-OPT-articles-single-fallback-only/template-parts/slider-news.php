<?php
/**
 * Compact news slider.
 * Each article panel uses the featured image as the whole inverted black-and-white background.
 * Text sits on top in white.
 */

$news_query = new WP_Query( array(
    'post_type'      => 'post',
    'posts_per_page' => 8,
    'orderby'        => 'date',
    'order'          => 'DESC',
) );

if ( $news_query->have_posts() ) :
    ?>
    <div class="news-slider-viewport">
        <div class="news-controls news-controls-inline">
            <button class="news-arrow news-arrow-prev" type="button" aria-label="<?php esc_attr_e( 'Previous news', 'nya-theme' ); ?>">‹</button>
            <button class="news-arrow news-arrow-next" type="button" aria-label="<?php esc_attr_e( 'Next news', 'nya-theme' ); ?>">›</button>
        </div>
        <div class="news-track">
            <?php while ( $news_query->have_posts() ) : $news_query->the_post(); ?>
                <?php
                $article_fallback = get_template_directory_uri() . '/assets/images/article-fallback.webp';
                $news_image       = has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_ID(), 'large' ) : $article_fallback;
                $style_attr       = ' style="--news-bg: url(' . esc_url( $news_image ) . ');"';
                ?>
                <article class="news-item has-news-bg"<?php echo $style_attr; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
                    <a class="news-card-link" href="<?php the_permalink(); ?>" aria-label="<?php the_title_attribute(); ?>">
                        <div class="news-copy">
                            <h2><?php the_title(); ?></h2>
                            <div class="news-excerpt">
                                <?php
                                if ( has_excerpt() ) {
                                    the_excerpt();
                                } else {
                                    echo '<p>' . esc_html( wp_trim_words( get_the_content(), 22 ) ) . '</p>';
                                }
                                ?>
                            </div>
                        </div>
                    </a>
                </article>
            <?php endwhile; ?>
        </div>
    </div>
    <?php
    wp_reset_postdata();
else :
    ?>
    <div class="news-slider-viewport">
        <div class="news-controls news-controls-inline">
            <button class="news-arrow news-arrow-prev" type="button" aria-label="<?php esc_attr_e( 'Previous news', 'nya-theme' ); ?>">‹</button>
            <button class="news-arrow news-arrow-next" type="button" aria-label="<?php esc_attr_e( 'Next news', 'nya-theme' ); ?>">›</button>
        </div>
        <div class="news-track">
            <article class="news-item placeholder-news">
                <a class="news-card-link" href="#">
                    <div class="news-copy">
                        <h2><?php esc_html_e( 'The Creator!', 'nya-theme' ); ?></h2>
                        <p><?php esc_html_e( 'The whole article panel is now the image area, with white text over the card.', 'nya-theme' ); ?></p>
                    </div>
                </a>
            </article>
            <article class="news-item placeholder-news">
                <a class="news-card-link" href="#">
                    <div class="news-copy">
                        <h2><?php esc_html_e( 'Negative color', 'nya-theme' ); ?></h2>
                        <p><?php esc_html_e( 'Featured images become inverted black-and-white backgrounds.', 'nya-theme' ); ?></p>
                    </div>
                </a>
            </article>
            <article class="news-item placeholder-news">
                <a class="news-card-link" href="#">
                    <div class="news-copy">
                        <h2><?php esc_html_e( 'Less white space', 'nya-theme' ); ?></h2>
                        <p><?php esc_html_e( 'Hero and menu spacing are tightened so the sketch reads in one view.', 'nya-theme' ); ?></p>
                    </div>
                </a>
            </article>
        </div>
    </div>
    <?php
endif;
