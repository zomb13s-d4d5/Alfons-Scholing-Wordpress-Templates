<?php
/**
 * Comments template.
 */

if ( post_password_required() ) {
    return;
}
?>

<section id="comments" class="comments-area accessible-comments">
    <h2 class="comments-title">
        <?php
        $comment_count = get_comments_number();
        if ( '1' === $comment_count ) {
            esc_html_e( 'One comment', 'nya-theme' );
        } else {
            printf(
                esc_html( _nx( '%s comment', '%s comments', $comment_count, 'comments title', 'nya-theme' ) ),
                esc_html( number_format_i18n( $comment_count ) )
            );
        }
        ?>
    </h2>

    <?php if ( have_comments() ) : ?>
        <ol class="comment-list">
            <?php
            wp_list_comments( array(
                'style'      => 'ol',
                'short_ping' => true,
                'avatar_size'=> 56,
            ) );
            ?>
        </ol>

        <?php
        the_comments_navigation( array(
            'prev_text' => esc_html__( 'Older comments', 'nya-theme' ),
            'next_text' => esc_html__( 'Newer comments', 'nya-theme' ),
        ) );
        ?>
    <?php endif; ?>

    <?php
    if ( ! comments_open() && get_comments_number() ) :
        ?>
        <p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'nya-theme' ); ?></p>
        <?php
    endif;

    comment_form( array(
        'title_reply'        => esc_html__( 'Leave a comment', 'nya-theme' ),
        'title_reply_before' => '<h2 id="reply-title" class="comment-reply-title">',
        'title_reply_after'  => '</h2>',
        'label_submit'       => esc_html__( 'Post comment', 'nya-theme' ),
        'class_submit'       => 'submit comment-submit',
    ) );
    ?>
</section>
