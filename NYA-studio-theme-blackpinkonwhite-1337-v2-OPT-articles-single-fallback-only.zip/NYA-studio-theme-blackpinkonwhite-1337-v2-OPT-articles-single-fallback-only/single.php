<?php
/**
 * Single article template.
 */

get_header();

if ( have_posts() ) :
    while ( have_posts() ) :
        the_post();
        $article_fallback = get_template_directory_uri() . '/assets/images/article-fallback.webp';
        $hero_image       = has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_ID(), 'full' ) : ( 'post' === get_post_type() ? $article_fallback : '' );
        ?>
        <main id="primary" class="site-main singular-main accessible-singular">
            <article id="post-<?php the_ID(); ?>" <?php post_class( 'singular-card article-card' ); ?>>
                <header class="singular-hero<?php echo $hero_image ? ' has-singular-bg' : ''; ?>"<?php echo $hero_image ? ' style="--singular-bg: url(' . esc_url( $hero_image ) . ');"' : ''; ?>>
                    <div class="singular-hero-inner">
                        <p class="singular-kicker"><?php esc_html_e( 'Article', 'nya-theme' ); ?></p>
                        <?php the_title( '<h1 class="singular-title">', '</h1>' ); ?>
                        <div class="singular-meta">
                            <span><?php echo esc_html( get_the_date() ); ?></span>
                            <span><?php the_author(); ?></span>
                        </div>
                    </div>
                </header>

                <div class="singular-content-wrap">
                    <div class="entry-content singular-content">
                        <?php
                        the_content();

                        wp_link_pages( array(
                            'before' => '<nav class="page-links">' . esc_html__( 'Pages:', 'nya-theme' ),
                            'after'  => '</nav>',
                        ) );
                        ?>
                    </div>

                    <footer class="entry-footer singular-footer">
                        <?php
                        the_category( ' ' );
                        the_tags( '<div class="tag-row">', ' ', '</div>' );
                        ?>
                    </footer>
                </div>
            </article>

            <?php comments_template(); ?>
        </main>
        <?php
    endwhile;
endif;

get_footer();
