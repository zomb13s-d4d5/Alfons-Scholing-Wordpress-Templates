<?php
/**
 * Functions and definitions for the NYA Studio Theme — Blackpink on White.
 *
 * This file sets up theme defaults and registers support for various WordPress
 * features. It also registers a custom post type for the header slider and
 * enqueues the theme’s styles and scripts.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Set up theme defaults and register support for various WordPress features.
 */
function nya_theme_setup() {
    // Make theme available for translation.
    load_theme_textdomain( 'nya-theme', get_template_directory() . '/languages' );

    // Add default posts and comments RSS feed links to head.
    add_theme_support( 'automatic-feed-links' );

    // Let WordPress manage the document title.
    add_theme_support( 'title-tag' );

    // Enable support for post thumbnails and featured images.
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption', 'style', 'script' ) );

    // Register navigation menus.
    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'nya-theme' ),
    ) );

    // Enable support for custom logo.
    add_theme_support( 'custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
    ) );
}
add_action( 'after_setup_theme', 'nya_theme_setup' );

/**
 * Register a custom post type for header slides.
 *
 * Slides created via this post type will populate the header slider on the
 * front page. Only the post title and featured image are used in the slider.
 */
function nya_register_slide_cpt() {
    $labels = array(
        'name'               => _x( 'Slides', 'post type general name', 'nya-theme' ),
        'singular_name'      => _x( 'Slide', 'post type singular name', 'nya-theme' ),
        'menu_name'          => _x( 'Slides', 'admin menu', 'nya-theme' ),
        'name_admin_bar'     => _x( 'Slide', 'add new on admin bar', 'nya-theme' ),
        'add_new'            => _x( 'Add New', 'slide', 'nya-theme' ),
        'add_new_item'       => __( 'Add New Slide', 'nya-theme' ),
        'new_item'           => __( 'New Slide', 'nya-theme' ),
        'edit_item'          => __( 'Edit Slide', 'nya-theme' ),
        'view_item'          => __( 'View Slide', 'nya-theme' ),
        'all_items'          => __( 'All Slides', 'nya-theme' ),
        'search_items'       => __( 'Search Slides', 'nya-theme' ),
        'parent_item_colon'  => __( 'Parent Slides:', 'nya-theme' ),
        'not_found'          => __( 'No slides found.', 'nya-theme' ),
        'not_found_in_trash' => __( 'No slides found in Trash.', 'nya-theme' )
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => false,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => false,
        'rewrite'            => false,
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'supports'           => array( 'title', 'thumbnail' ),
        'show_in_rest'       => true,
    );

    register_post_type( 'as_slide', $args );
}
add_action( 'init', 'nya_register_slide_cpt' );

/**
 * Enqueue theme scripts and styles.
 */
function nya_enqueue_assets() {
    // Google Fonts for graffiti and condensed style.
    wp_enqueue_style(
        'nya-google-fonts',
        'https://fonts.googleapis.com/css2?family=Permanent+Marker&family=Roboto+Condensed:wght@400;700&display=swap',
        array(),
        null
    );

    // Main stylesheet.
    wp_enqueue_style(
        'nya-style',
        get_template_directory_uri() . '/assets/css/style.css',
        array( 'nya-google-fonts' ),
        filemtime( get_template_directory() . '/assets/css/style.css' )
    );

    // Slider script to rotate header slides.
    wp_enqueue_script(
        'nya-slider',
        get_template_directory_uri() . '/assets/js/slider.js',
        array(),
        filemtime( get_template_directory() . '/assets/js/slider.js' ),
        true
    );

    wp_localize_script(
        'nya-slider',
        'nyaThemeData',
        array(
            'menuIcons' => array(
                get_template_directory_uri() . '/assets/images/nav-face-dot.webp',
                get_template_directory_uri() . '/assets/images/nav-face-dot.webp',
                get_template_directory_uri() . '/assets/images/nav-face-dot.webp',
            ),
        )
    );

    // Lightweight image lightbox for article/page/gallery images.
    wp_enqueue_script(
        'nya-lightbox',
        get_template_directory_uri() . '/assets/js/lightbox.js',
        array(),
        filemtime( get_template_directory() . '/assets/js/lightbox.js' ),
        true
    );

    // Article gallery slider for galleries inside single posts.
    wp_enqueue_script(
        'nya-article-gallery-slider',
        get_template_directory_uri() . '/assets/js/gallery-slider.js',
        array(),
        filemtime( get_template_directory() . '/assets/js/gallery-slider.js' ),
        true
    );

    // Header AI fact-check copy button.
    wp_enqueue_script(
        'nya-ai-fact-copy',
        get_template_directory_uri() . '/assets/js/ai-fact-copy.js',
        array(),
        filemtime( get_template_directory() . '/assets/js/ai-fact-copy.js' ),
        true
    );
}
add_action( 'wp_enqueue_scripts', 'nya_enqueue_assets' );
function nya_enqueue_comment_reply() {
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'nya_enqueue_comment_reply' );
