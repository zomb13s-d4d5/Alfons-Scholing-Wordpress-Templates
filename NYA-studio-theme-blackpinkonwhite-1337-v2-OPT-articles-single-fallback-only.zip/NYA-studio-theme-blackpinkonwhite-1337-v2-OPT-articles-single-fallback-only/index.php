<?php
/**
 * The main template file.
 *
 * Used to display a page when nothing more specific matches a query. It
 * includes the header, content loop, and footer. If you are building a
 * complex front page layout, see front‑page.php instead.
 */

get_header();
?>

<div class="content-container">
    <?php
    if ( have_posts() ) :
        while ( have_posts() ) :
            the_post();
            the_content();
        endwhile;
    else :
        echo '<p>' . __( 'No content found.', 'nya-theme' ) . '</p>';
    endif;
    ?>
</div>

<?php
get_footer();