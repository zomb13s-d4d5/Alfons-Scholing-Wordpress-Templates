<?php
/**
 * Page template.
 */

get_header();

if ( have_posts() ) :
    while ( have_posts() ) :
        the_post();
        $hero_image = has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_ID(), 'full' ) : '';
        ?>
        <main id="primary" class="site-main singular-main accessible-singular">
            <article id="post-<?php the_ID(); ?>" <?php post_class( 'singular-card page-card' ); ?>>
                <header class="singular-hero page-hero<?php echo $hero_image ? ' has-singular-bg' : ''; ?>"<?php echo $hero_image ? ' style="--singular-bg: url(' . esc_url( $hero_image ) . ');"' : ''; ?>>
                    <div class="singular-hero-inner">
                        <p class="singular-kicker"><?php esc_html_e( 'Page', 'nya-theme' ); ?></p>
                        <?php the_title( '<h1 class="singular-title">', '</h1>' ); ?>
                    </div>
                </header>

                <div class="singular-content-wrap">
                    <div class="entry-content singular-content">
                        <?php
                        the_content();

                        wp_link_pages( array(
                            'before' => '<nav class="page-links">' . esc_html__( 'Pages:', 'nya-theme' ),
                            'after'  => '</nav>',
                        ) );
                        ?>
                    </div>
                </div>
            </article>

            <?php comments_template(); ?>
        </main>
        <?php
    endwhile;
endif;

get_footer();
