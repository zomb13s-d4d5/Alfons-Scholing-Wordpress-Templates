<?php
/**
 * Footer template.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<footer class="site-footer">
    <p>© <?php echo esc_html( date_i18n( 'Y' ) ); ?> notyouagain.ai</p>
</footer>

<?php wp_footer(); ?>
</body>
</html>
