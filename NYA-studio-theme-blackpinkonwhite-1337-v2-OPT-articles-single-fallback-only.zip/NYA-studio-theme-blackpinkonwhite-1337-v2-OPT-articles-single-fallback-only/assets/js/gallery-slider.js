// Article gallery slider for single posts.
// Converts WordPress gallery blocks inside article content into a horizontal carousel
// with tiny pink face-dot navigation underneath.
document.addEventListener('DOMContentLoaded', function () {
    function installWheelHorizontal(track) {
        if (!track) return;
        track.addEventListener('wheel', function (event) {
            if (Math.abs(event.deltaY) > Math.abs(event.deltaX) && track.scrollWidth > track.clientWidth) {
                event.preventDefault();
                track.scrollBy({ left: event.deltaY, behavior: 'auto' });
            }
        }, { passive: false });
    }

    function installGalleryDotNav(gallery, track, items) {
        if (!gallery || !track || !items.length) return;
        var nav = gallery.querySelector('.nya-article-gallery-slider__dot-nav');
        if (!nav) {
            nav = document.createElement('div');
            nav.className = 'nya-article-gallery-slider__dot-nav nya-face-dot-nav';
            nav.setAttribute('aria-label', 'Gallery navigation');
            gallery.appendChild(nav);
        }
        nav.innerHTML = '';

        var dots = [];
        items.forEach(function (_item, index) {
            var button = document.createElement('button');
            button.className = 'nya-face-dot';
            button.type = 'button';
            button.setAttribute('aria-label', 'Gallery image ' + (index + 1));
            button.addEventListener('click', function () {
                var item = items[index];
                if (!item) return;
                track.scrollTo({ left: item.offsetLeft, behavior: 'smooth' });
            });
            nav.appendChild(button);
            dots.push(button);
        });

        function updateDots() {
            var canScroll = track.scrollWidth > track.clientWidth + 4;
            nav.hidden = !canScroll || dots.length <= 1;

            var bestIndex = 0;
            var smallestDistance = Infinity;
            items.forEach(function (item, index) {
                var distance = Math.abs(track.scrollLeft - item.offsetLeft);
                if (distance < smallestDistance) {
                    smallestDistance = distance;
                    bestIndex = index;
                }
            });

            dots.forEach(function (button, index) {
                var isActive = index === bestIndex;
                button.classList.toggle('is-active', isActive);
                button.setAttribute('aria-current', isActive ? 'true' : 'false');
            });
        }

        track.addEventListener('scroll', updateDots, { passive: true });
        window.addEventListener('resize', updateDots);
        window.setTimeout(updateDots, 90);
        updateDots();
    }

    var galleries = Array.prototype.slice.call(document.querySelectorAll(
        'body.single .singular-content .wp-block-gallery, ' +
        'body.single-post .singular-content .wp-block-gallery, ' +
        'body.single .singular-content .gallery, ' +
        'body.single-post .singular-content .gallery'
    )).filter(function (gallery) {
        return !gallery.classList.contains('nya-article-gallery-slider') && gallery.querySelectorAll('img').length > 1;
    });

    galleries.forEach(function (gallery, galleryIndex) {
        var items = Array.prototype.slice.call(gallery.children).filter(function (child) {
            return child && child.querySelector && child.querySelector('img');
        });

        if (items.length < 2) {
            items = Array.prototype.slice.call(gallery.querySelectorAll('figure, .gallery-item')).filter(function (child) {
                return child && child.querySelector && child.querySelector('img');
            });
        }

        if (items.length < 2) return;

        gallery.classList.add('nya-article-gallery-slider');
        gallery.setAttribute('data-nya-article-gallery-slider', String(galleryIndex));

        var viewport = document.createElement('div');
        viewport.className = 'nya-article-gallery-slider__viewport';

        var track = document.createElement('div');
        track.className = 'nya-article-gallery-slider__track';

        items.forEach(function (item) {
            item.classList.add('nya-article-gallery-slider__item');
            track.appendChild(item);
        });

        viewport.appendChild(track);
        gallery.replaceChildren(viewport);

        installWheelHorizontal(track);
        installGalleryDotNav(gallery, track, items);
    });
});
