(function () {
    'use strict';

    function getPageContent() {
        var title = document.title ? document.title.trim() : '';
        var url = window.location.href;
        var main = document.querySelector('main, article, .site-main, #content, .entry-content');
        var source = main || document.body;
        var clone = source.cloneNode(true);

        clone.querySelectorAll('script, style, nav, header, footer, button, form, iframe, svg, .screen-reader-text, .nya-ai-checker-foldout, .nya-ai-checker-panel').forEach(function (node) {
            node.remove();
        });

        var text = clone.innerText || clone.textContent || '';
        text = text.replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();

        return [
            'Check the facts through AI',
            title ? 'Title: ' + title : '',
            'URL: ' + url,
            '',
            text
        ].filter(Boolean).join('\n');
    }

    function fallbackCopy(text) {
        var textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.setAttribute('readonly', 'readonly');
        textarea.style.position = 'fixed';
        textarea.style.left = '-9999px';
        document.body.appendChild(textarea);
        textarea.select();
        var ok = document.execCommand('copy');
        document.body.removeChild(textarea);
        return ok ? Promise.resolve() : Promise.reject(new Error('Copy failed'));
    }

    document.addEventListener('click', function (event) {
        var button = event.target.closest('.nya-ai-copy-page-content');
        if (!button) {
            return;
        }

        var panel = button.closest('.nya-ai-checker-panel');
        var status = panel ? panel.querySelector('.nya-ai-copy-status') : null;
        var text = getPageContent();
        var copy = navigator.clipboard && navigator.clipboard.writeText
            ? navigator.clipboard.writeText(text)
            : fallbackCopy(text);

        button.disabled = true;
        if (status) {
            status.textContent = 'Copying…';
        }

        copy.then(function () {
            if (status) {
                status.textContent = 'Copied. Paste it into your AI tool.';
            }
        }).catch(function () {
            if (status) {
                status.textContent = 'Copy failed. Select the page text and copy manually.';
            }
        }).finally(function () {
            button.disabled = false;
        });
    });
}());
