// Manual-only sliders. No automatic animation.
document.addEventListener('DOMContentLoaded', function () {
    function hashString(value) {
        var hash = 0;
        for (var i = 0; i < value.length; i += 1) {
            hash = ((hash << 5) - hash) + value.charCodeAt(i);
            hash |= 0;
        }
        return Math.abs(hash);
    }

    function fitActiveHeroTitle() {
        var headerSlider = document.querySelector('.header-slider');
        if (!headerSlider) return;
        var activeSlide = headerSlider.querySelector('.slide.active');
        if (!activeSlide) return;
        var title = activeSlide.querySelector('.title-slide');
        if (!title) return;

        title.style.removeProperty('font-size');

        window.requestAnimationFrame(function () {
            var rect = title.getBoundingClientRect();
            var available = window.innerWidth - rect.left - 18;
            if (available <= 120) return;

            var computed = window.getComputedStyle(title);
            var maxSize = parseFloat(computed.fontSize) || 48;
            var minSize = window.innerWidth < 700 ? 18 : 26;
            var size = maxSize;

            title.style.whiteSpace = 'nowrap';
            title.style.setProperty('font-size', size + 'px', 'important');

            while (title.scrollWidth > available && size > minSize) {
                size -= 1;
                title.style.setProperty('font-size', size + 'px', 'important');
            }
        });
    }

    function installScrollableDotNav(viewport, track, itemSelector, containerClass, labelPrefix) {
        if (!viewport || !track) return;
        var items = Array.prototype.slice.call(track.querySelectorAll(itemSelector));
        if (!items.length) return;

        var nav = viewport.querySelector('.' + containerClass);
        if (!nav) {
            nav = document.createElement('div');
            nav.className = containerClass + ' nya-face-dot-nav';
            nav.setAttribute('aria-label', labelPrefix + ' navigation');
            viewport.appendChild(nav);
        }
        nav.innerHTML = '';

        var dots = [];

        function scrollToItem(index) {
            var item = items[index];
            if (!item) return;
            track.scrollTo({ left: item.offsetLeft, behavior: 'smooth' });
        }

        items.forEach(function (_item, index) {
            var button = document.createElement('button');
            button.className = 'nya-face-dot';
            button.type = 'button';
            button.setAttribute('aria-label', labelPrefix + ' ' + (index + 1));
            button.addEventListener('click', function () { scrollToItem(index); });
            nav.appendChild(button);
            dots.push(button);
        });

        function updateDots() {
            var canScroll = track.scrollWidth > track.clientWidth + 4;
            nav.hidden = dots.length <= 1;

            var bestIndex = 0;
            var smallestDistance = Infinity;
            items.forEach(function (item, index) {
                var distance = Math.abs(track.scrollLeft - item.offsetLeft);
                if (distance < smallestDistance) {
                    smallestDistance = distance;
                    bestIndex = index;
                }
            });

            dots.forEach(function (button, index) {
                var isActive = index === bestIndex;
                button.classList.toggle('is-active', isActive);
                button.setAttribute('aria-current', isActive ? 'true' : 'false');
            });
        }

        var ticking = false;
        function onScroll() {
            if (ticking) return;
            ticking = true;
            window.requestAnimationFrame(function () {
                updateDots();
                ticking = false;
            });
        }

        track.addEventListener('scroll', onScroll, { passive: true });
        window.addEventListener('resize', updateDots);
        window.setTimeout(updateDots, 90);
        updateDots();
    }

    function installStaticDotNav(host, count, labelPrefix, onSelect, getCurrentIndex) {
        if (!host || count <= 1) return null;

        var nav = host.querySelector('.header-dot-nav');
        if (!nav) {
            nav = document.createElement('div');
            nav.className = 'header-dot-nav nya-face-dot-nav';
            nav.setAttribute('aria-label', labelPrefix + ' navigation');
            host.appendChild(nav);
        }
        nav.innerHTML = '';

        var dots = [];
        for (var i = 0; i < count; i += 1) {
            (function (index) {
                var button = document.createElement('button');
                button.className = 'nya-face-dot';
                button.type = 'button';
                button.setAttribute('aria-label', labelPrefix + ' ' + (index + 1));
                button.addEventListener('click', function () { onSelect(index); update(); });
                nav.appendChild(button);
                dots.push(button);
            }(i));
        }

        function update() {
            var activeIndex = getCurrentIndex();
            dots.forEach(function (button, index) {
                var isActive = index === activeIndex;
                button.classList.toggle('is-active', isActive);
                button.setAttribute('aria-current', isActive ? 'true' : 'false');
            });
        }

        window.addEventListener('resize', update);
        window.setTimeout(update, 50);
        update();
        return update;
    }

    function installWheelHorizontal(track) {
        if (!track) return;
        track.addEventListener('wheel', function (event) {
            if (Math.abs(event.deltaY) > Math.abs(event.deltaX) && track.scrollWidth > track.clientWidth) {
                event.preventDefault();
                track.scrollBy({ left: event.deltaY, behavior: 'auto' });
            }
        }, { passive: false });
    }

    // Header slider
    var headerSlider = document.querySelector('.header-slider');
    if (headerSlider) {
        fitActiveHeroTitle();
        window.addEventListener('resize', fitActiveHeroTitle);
        window.setTimeout(fitActiveHeroTitle, 120);
        if (document.fonts && document.fonts.ready) {
            document.fonts.ready.then(fitActiveHeroTitle);
        }
        var slides = Array.prototype.slice.call(headerSlider.querySelectorAll('.slide'));
        var prev = headerSlider.querySelector('.slider-arrow-prev');
        var next = headerSlider.querySelector('.slider-arrow-next');
        var current = 0;
        var refreshHeaderDots = null;
        var autoplay = headerSlider.getAttribute('data-autoplay') === 'true';
        var delay = parseInt(headerSlider.getAttribute('data-delay') || '4200', 10);
        var timer = null;

        function showSlide(index) {
            if (!slides.length) return;
            slides[current].classList.remove('active');
            current = (index + slides.length) % slides.length;
            slides[current].classList.add('active');
            if (typeof refreshHeaderDots === 'function') refreshHeaderDots();
            fitActiveHeroTitle();
        }

        function stopAutoplay() {
            if (timer) {
                window.clearInterval(timer);
                timer = null;
            }
        }

        function startAutoplay() {
            if (!autoplay || slides.length <= 1) return;
            stopAutoplay();
            timer = window.setInterval(function () {
                showSlide(current + 1);
            }, delay);
        }

        function stepTo(index) {
            showSlide(index);
            startAutoplay();
        }

        if (slides.length <= 1) {
            if (prev) prev.setAttribute('hidden', 'hidden');
            if (next) next.setAttribute('hidden', 'hidden');
        } else {
            if (prev) prev.addEventListener('click', function () { stepTo(current - 1); });
            if (next) next.addEventListener('click', function () { stepTo(current + 1); });
            refreshHeaderDots = installStaticDotNav(
                headerSlider,
                slides.length,
                'Hero slide',
                function (index) { stepTo(index); },
                function () { return current; }
            );

            headerSlider.addEventListener('mouseenter', stopAutoplay);
            headerSlider.addEventListener('mouseleave', startAutoplay);
            headerSlider.addEventListener('focusin', stopAutoplay);
            headerSlider.addEventListener('focusout', startAutoplay);
            document.addEventListener('visibilitychange', function () {
                if (document.hidden) {
                    stopAutoplay();
                } else {
                    startAutoplay();
                }
            });

            startAutoplay();
        }
    }

    // Menu card decoration + scrolling nav
    var menuTrack = document.querySelector('.menu-grid .menu-items');
    var icons = (window.nyaThemeData && Array.isArray(window.nyaThemeData.menuIcons) && window.nyaThemeData.menuIcons.length)
        ? window.nyaThemeData.menuIcons
        : [];

    if (menuTrack) {
        var links = Array.prototype.slice.call(menuTrack.querySelectorAll('li > a'));
        links.forEach(function (link) {
            var labelText = (link.textContent || '').trim();
            var seed = hashString(labelText || String(Math.random()));
            var iconIndex = icons.length ? seed % icons.length : 0;
            var tilt = ((seed % 9) - 4) * 0.45;

            link.classList.add('nya-menu-card');
            link.style.setProperty('--nya-card-tilt', tilt.toFixed(2) + 'deg');

            if (!link.querySelector('.nya-menu-label')) {
                var label = document.createElement('span');
                label.className = 'nya-menu-label';
                label.textContent = labelText;
                link.textContent = '';
                link.appendChild(label);
            }

            if (icons[iconIndex] && !link.querySelector('.nya-menu-art')) {
                var art = document.createElement('span');
                art.className = 'nya-menu-art';
                var img = document.createElement('img');
                img.src = icons[iconIndex];
                img.alt = '';
                img.setAttribute('aria-hidden', 'true');
                art.appendChild(img);
                link.appendChild(art);
            }
        });
        installWheelHorizontal(menuTrack);
        installScrollableDotNav(menuTrack.parentElement, menuTrack, 'li', 'menu-dot-nav', 'Category');
    }

    // Homepage news/article slider nav
    var newsTrack = document.querySelector('.news-track');
    if (newsTrack) {
        installWheelHorizontal(newsTrack);
        installScrollableDotNav(newsTrack.parentElement, newsTrack, '.news-item', 'news-dot-nav', 'Article');
    }

    // Category/archive slider nav
    var archiveTrack = document.querySelector('.archive-track');
    if (archiveTrack) {
        installWheelHorizontal(archiveTrack);
        installScrollableDotNav(archiveTrack.parentElement, archiveTrack, '.archive-card', 'archive-dot-nav', 'Archive article');
    }
});
