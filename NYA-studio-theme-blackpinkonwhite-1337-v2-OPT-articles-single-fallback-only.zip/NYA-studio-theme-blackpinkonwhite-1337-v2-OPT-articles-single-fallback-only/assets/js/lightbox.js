// Lightweight image lightbox for content images.
// Opens article, page, gallery, and WordPress block images in a full-screen viewer.
// Reuses the theme's existing arrow navigation styling/classes instead of introducing separate navigation UI.
document.addEventListener('DOMContentLoaded', function () {
    var selectors = [
        '.singular-content img',
        '.entry-content img',
        '.wp-block-image img',
        '.gallery img',
        '.post-thumbnail img',
        'img.wp-post-image'
    ];

    var seen = [];
    var images = Array.prototype.slice.call(document.querySelectorAll(selectors.join(','))).filter(function (img) {
        if (!img || seen.indexOf(img) !== -1) return false;
        seen.push(img);

        var src = img.currentSrc || img.src || img.getAttribute('data-src') || img.getAttribute('data-full') || img.getAttribute('data-large_image');
        return !!src &&
            !img.closest('.site-header') &&
            !img.closest('.site-logo') &&
            !img.closest('.menu-grid') &&
            !img.closest('.nya-lightbox');
    });

    if (!images.length) return;

    var overlay = document.createElement('div');
    overlay.className = 'nya-lightbox';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-label', 'Image viewer');
    overlay.innerHTML = '' +
        '<div class="nya-lightbox__dialog">' +
            '<button class="nya-lightbox__button nya-lightbox__close" type="button" aria-label="Close image viewer">×</button>' +
            '<button class="news-arrow news-arrow-prev nya-lightbox__button nya-lightbox__nav nya-lightbox__prev" type="button" aria-label="Previous image">‹</button>' +
            '<img class="nya-lightbox__image" alt="">' +
            '<button class="news-arrow news-arrow-next nya-lightbox__button nya-lightbox__nav nya-lightbox__next" type="button" aria-label="Next image">›</button>' +
            '<p class="nya-lightbox__caption"></p>' +
        '</div>';
    document.body.appendChild(overlay);

    var lightboxImage = overlay.querySelector('.nya-lightbox__image');
    var caption = overlay.querySelector('.nya-lightbox__caption');
    var closeButton = overlay.querySelector('.nya-lightbox__close');
    var prevButton = overlay.querySelector('.nya-lightbox__prev');
    var nextButton = overlay.querySelector('.nya-lightbox__next');
    var currentIndex = 0;
    var lastFocused = null;

    function getCaption(img) {
        var figure = img.closest('figure');
        var figcaption = figure ? figure.querySelector('figcaption') : null;
        return (figcaption && figcaption.textContent.trim()) || img.getAttribute('alt') || '';
    }

    function getFullSrc(img) {
        var link = img.closest('a');
        var linkedImage = link && /\.(avif|bmp|gif|jpe?g|png|svg|webp)(\?.*)?$/i.test(link.href || '');
        return (linkedImage && link.href) ||
            img.getAttribute('data-full') ||
            img.getAttribute('data-large_image') ||
            img.currentSrc ||
            img.src ||
            img.getAttribute('data-src');
    }

    function show(index) {
        currentIndex = (index + images.length) % images.length;
        var img = images[currentIndex];
        lightboxImage.src = getFullSrc(img);
        lightboxImage.alt = img.alt || '';
        caption.textContent = getCaption(img);
        caption.hidden = !caption.textContent;
        prevButton.hidden = images.length < 2;
        nextButton.hidden = images.length < 2;
    }

    function open(index) {
        lastFocused = document.activeElement;
        show(index);
        overlay.classList.add('is-open');
        document.documentElement.style.overflow = 'hidden';
        closeButton.focus({ preventScroll: true });
    }

    function close() {
        overlay.classList.remove('is-open');
        document.documentElement.style.overflow = '';
        lightboxImage.removeAttribute('src');
        if (lastFocused && typeof lastFocused.focus === 'function') {
            lastFocused.focus({ preventScroll: true });
        }
    }

    function previous() { show(currentIndex - 1); }
    function next() { show(currentIndex + 1); }

    images.forEach(function (img, index) {
        img.setAttribute('tabindex', '0');
        img.setAttribute('role', 'button');
        img.setAttribute('aria-label', (img.alt ? img.alt + '. ' : '') + 'Open image viewer');

        img.addEventListener('click', function (event) {
            var link = img.closest('a');
            if (link && !/\.(avif|bmp|gif|jpe?g|png|svg|webp)(\?.*)?$/i.test(link.href || '')) {
                return;
            }
            event.preventDefault();
            open(index);
        });

        img.addEventListener('keydown', function (event) {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                open(index);
            }
        });
    });

    closeButton.addEventListener('click', close);
    prevButton.addEventListener('click', previous);
    nextButton.addEventListener('click', next);

    overlay.addEventListener('click', function (event) {
        if (event.target === overlay) close();
    });

    document.addEventListener('keydown', function (event) {
        if (!overlay.classList.contains('is-open')) return;
        if (event.key === 'Escape') close();
        if (event.key === 'ArrowLeft') previous();
        if (event.key === 'ArrowRight') next();
    });

    var touchStartX = null;
    overlay.addEventListener('touchstart', function (event) {
        touchStartX = event.changedTouches[0].screenX;
    }, { passive: true });

    overlay.addEventListener('touchend', function (event) {
        if (touchStartX === null || images.length < 2) return;
        var deltaX = event.changedTouches[0].screenX - touchStartX;
        if (Math.abs(deltaX) > 50) {
            deltaX > 0 ? previous() : next();
        }
        touchStartX = null;
    }, { passive: true });
});
