<?php
/**
 * Category/archive template: one viewport, single-article-inspired style.
 */

get_header();

$archive_title = get_the_archive_title();
$archive_description = get_the_archive_description();
?>

<main id="primary" class="site-main archive-main category-viewport">
    <section class="archive-hero">
        <div class="archive-hero-inner">
            <p class="archive-kicker"><?php esc_html_e( 'Category', 'nya-theme' ); ?></p>
            <h1 class="archive-title"><?php echo wp_kses_post( $archive_title ); ?></h1>
            <?php if ( $archive_description ) : ?>
                <div class="archive-description"><?php echo wp_kses_post( $archive_description ); ?></div>
            <?php endif; ?>
        </div>
    </section>

    <?php if ( have_posts() ) : ?>
        <section class="archive-results" aria-label="<?php esc_attr_e( 'Category posts', 'nya-theme' ); ?>">
            <div class="archive-results-head">
                <p class="section-kicker"><?php esc_html_e( 'Articles', 'nya-theme' ); ?></p>
                <span class="archive-count"><?php echo esc_html( $GLOBALS['wp_query']->found_posts ); ?></span>
            </div>

            <div class="archive-slider-viewport">
                <div class="archive-controls archive-controls-inline">
                    <button class="archive-arrow archive-arrow-prev" type="button" aria-label="<?php esc_attr_e( 'Previous articles', 'nya-theme' ); ?>">‹</button>
                    <button class="archive-arrow archive-arrow-next" type="button" aria-label="<?php esc_attr_e( 'Next articles', 'nya-theme' ); ?>">›</button>
                </div>
                <div class="archive-track">
                    <?php
                    while ( have_posts() ) :
                        the_post();
                        $article_fallback = get_template_directory_uri() . '/assets/images/article-fallback.webp';
                        $card_image       = has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_ID(), 'large' ) : $article_fallback;
                        $style_attr       = ' style="--archive-card-bg: url(' . esc_url( $card_image ) . ');"';
                        ?>
                        <article id="post-<?php the_ID(); ?>" <?php post_class( 'archive-card has-archive-bg' ); ?><?php echo $style_attr; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
                            <a class="archive-card-link" href="<?php the_permalink(); ?>" aria-label="<?php the_title_attribute(); ?>">
                                <div class="archive-card-copy">
                                    <?php the_title( '<h2>', '</h2>' ); ?>
                                    <p class="archive-card-meta"><?php echo esc_html( get_the_date() ); ?></p>
                                    <div class="archive-card-excerpt">
                                        <?php
                                        if ( has_excerpt() ) {
                                            the_excerpt();
                                        } else {
                                            echo '<p>' . esc_html( wp_trim_words( get_the_content(), 24 ) ) . '</p>';
                                        }
                                        ?>
                                    </div>
                                </div>
                            </a>
                        </article>
                    <?php endwhile; ?>
                </div>
            </div>

            <nav class="archive-pagination" aria-label="<?php esc_attr_e( 'Archive pagination', 'nya-theme' ); ?>">
                <?php
                the_posts_pagination( array(
                    'mid_size'           => 1,
                    'prev_text'          => esc_html__( 'Previous', 'nya-theme' ),
                    'next_text'          => esc_html__( 'Next', 'nya-theme' ),
                    'screen_reader_text' => esc_html__( 'Posts navigation', 'nya-theme' ),
                ) );
                ?>
            </nav>
        </section>
    <?php else : ?>
        <section class="archive-results archive-empty">
            <p class="section-kicker"><?php esc_html_e( 'Articles', 'nya-theme' ); ?></p>
            <div class="archive-empty-card">
                <h2><?php esc_html_e( 'No articles yet', 'nya-theme' ); ?></h2>
                <p><?php esc_html_e( 'This category is waiting for its first post.', 'nya-theme' ); ?></p>
            </div>
        </section>
    <?php endif; ?>
</main>

<?php get_footer(); ?>
