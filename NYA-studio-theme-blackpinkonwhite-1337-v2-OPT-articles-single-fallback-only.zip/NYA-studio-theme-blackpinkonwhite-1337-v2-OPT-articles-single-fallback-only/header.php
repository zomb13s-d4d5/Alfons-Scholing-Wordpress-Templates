<?php
/**
 * Header template.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header nya-global-header" role="banner">
    <div class="header-container nya-header-bar">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="top-logo-home" aria-label="<?php esc_attr_e( 'Back to homepage', 'nya-theme' ); ?>">
            <?php if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) : ?>
                <?php
                $custom_logo_id = get_theme_mod( 'custom_logo' );
                $logo_image     = wp_get_attachment_image(
                    $custom_logo_id,
                    'full',
                    false,
                    array(
                        'class' => 'top-logo-image',
                        'alt'   => get_bloginfo( 'name' ),
                    )
                );
                echo $logo_image; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                ?>
            <?php else : ?>
                <span class="top-logo-fallback">NYA</span>
            <?php endif; ?>
        </a>

        <details class="nya-ai-checker-foldout">
            <summary class="nya-ai-checker-trigger" aria-label="<?php esc_attr_e( 'Open AI fact check copy tool', 'nya-theme' ); ?>">
                <img
                    src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/nya-header-menu-icon.png' ); ?>"
                    alt=""
                    class="nya-ai-checker-icon"
                    width="160"
                    height="160"
                >
                <span class="screen-reader-text"><?php esc_html_e( 'Check the facts through AI', 'nya-theme' ); ?></span>
            </summary>

            <aside class="nya-ai-checker-panel" aria-label="<?php esc_attr_e( 'AI fact checking copy panel', 'nya-theme' ); ?>">
                <p class="nya-ai-checker-title"><?php esc_html_e( 'Check the facts through AI', 'nya-theme' ); ?></p>
                <button class="nya-ai-copy-page-content" type="button">
                    <?php esc_html_e( 'Copy page content', 'nya-theme' ); ?>
                </button>
                <p class="nya-ai-copy-help">
                    <?php esc_html_e( 'Paste it into your AI tool to check the facts.', 'nya-theme' ); ?>
                </p>
                <p class="nya-ai-copy-status" role="status" aria-live="polite"></p>
            </aside>
        </details>
    </div>
</header>
