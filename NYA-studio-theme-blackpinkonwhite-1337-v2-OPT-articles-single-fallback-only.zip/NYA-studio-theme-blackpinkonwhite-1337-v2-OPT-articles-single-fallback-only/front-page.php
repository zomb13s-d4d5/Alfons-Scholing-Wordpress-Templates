<?php
/**
 * Front page template: full-view sketch layout.
 */

get_header();
?>

<main class="site-main sketch-home full-view-sketch">
    <section class="sketch-hero-panel" aria-label="Header slider">
        <?php get_template_part( 'template-parts/slider', 'header' ); ?>
    </section>

    <section class="menu-grid" aria-label="Category menu">
        <div class="menu-slider-viewport">
            <div class="menu-controls">
                <button class="menu-arrow menu-arrow-prev" type="button" aria-label="<?php esc_attr_e( 'Previous category', 'nya-theme' ); ?>">‹</button>
                <button class="menu-arrow menu-arrow-next" type="button" aria-label="<?php esc_attr_e( 'Next category', 'nya-theme' ); ?>">›</button>
            </div>
            <?php
            if ( has_nav_menu( 'primary' ) ) {
                wp_nav_menu( array(
                    'theme_location' => 'primary',
                    'container'      => false,
                    'menu_class'     => 'menu-items',
                    'fallback_cb'    => false,
                ) );
            } else {
                $fallback_items = array(
                    'Home', 'Concepts', 'Studio', 'Onderzoek', 'Testimonials',
                    'Papa Opmerkingen!', 'Veiligheid', 'Verhaal', 'Game Theory', 'Sociale Engineer',
                );
                echo '<ul class="menu-items fallback-menu">';
                foreach ( $fallback_items as $fallback_item ) {
                    echo '<li><a href="#news">' . esc_html( $fallback_item ) . '</a></li>';
                }
                echo '</ul>';
            }
            ?>
        </div>
    </section>

    <section id="news" class="news-section" aria-label="News slider">
        <?php get_template_part( 'template-parts/slider', 'news' ); ?>
    </section>
</main>

<?php get_footer(); ?>
